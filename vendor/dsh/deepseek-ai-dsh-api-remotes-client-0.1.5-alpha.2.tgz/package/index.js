import { z } from "zod";
import { Context, Service } from "@deepseek-ai/cordis";
//#region ../../core/agent-default-model/lib/typert.remote-client.js
const _deepseek_ai_dsh_agent_default_model_agentModels_list_result$schema = z.object({
	"writable": z.boolean().readonly(),
	"revision": z.number().readonly(),
	"targets": z.array(z.object({
		"id": z.intersection(z.string(), z.unknown()).readonly(),
		"label": z.string().readonly(),
		"provider": z.string().readonly(),
		"selection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"defaultSelection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"overridden": z.boolean().readonly()
	})).readonly(),
	"catalogs": z.array(z.object({
		"provider": z.string().readonly(),
		"models": z.array(z.object({
			"id": z.string().readonly(),
			"name": z.string().readonly(),
			"description": z.string().readonly().optional(),
			"reasoningEfforts": z.array(z.object({
				"id": z.string().readonly(),
				"name": z.string().readonly(),
				"description": z.string().readonly().optional()
			})).readonly(),
			"defaultReasoningEffort": z.string().readonly().optional()
		})).readonly()
	})).readonly()
});
const _deepseek_ai_dsh_agent_default_model_agentModels_reset_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_agent_default_model_agentModels_reset_parameter_1$schema = z.number();
const _deepseek_ai_dsh_agent_default_model_agentModels_reset_result$schema = z.object({
	"writable": z.boolean().readonly(),
	"revision": z.number().readonly(),
	"targets": z.array(z.object({
		"id": z.intersection(z.string(), z.unknown()).readonly(),
		"label": z.string().readonly(),
		"provider": z.string().readonly(),
		"selection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"defaultSelection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"overridden": z.boolean().readonly()
	})).readonly(),
	"catalogs": z.array(z.object({
		"provider": z.string().readonly(),
		"models": z.array(z.object({
			"id": z.string().readonly(),
			"name": z.string().readonly(),
			"description": z.string().readonly().optional(),
			"reasoningEfforts": z.array(z.object({
				"id": z.string().readonly(),
				"name": z.string().readonly(),
				"description": z.string().readonly().optional()
			})).readonly(),
			"defaultReasoningEffort": z.string().readonly().optional()
		})).readonly()
	})).readonly()
});
const _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_1$schema = z.string();
const _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_2$schema = z.union([z.undefined(), z.string()]);
const _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_3$schema = z.number();
const _deepseek_ai_dsh_agent_default_model_agentModels_save_result$schema = z.object({
	"writable": z.boolean().readonly(),
	"revision": z.number().readonly(),
	"targets": z.array(z.object({
		"id": z.intersection(z.string(), z.unknown()).readonly(),
		"label": z.string().readonly(),
		"provider": z.string().readonly(),
		"selection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"defaultSelection": z.object({
			"model": z.string(),
			"reasoningEffort": z.string().optional()
		}).readonly(),
		"overridden": z.boolean().readonly()
	})).readonly(),
	"catalogs": z.array(z.object({
		"provider": z.string().readonly(),
		"models": z.array(z.object({
			"id": z.string().readonly(),
			"name": z.string().readonly(),
			"description": z.string().readonly().optional(),
			"reasoningEfforts": z.array(z.object({
				"id": z.string().readonly(),
				"name": z.string().readonly(),
				"description": z.string().readonly().optional()
			})).readonly(),
			"defaultReasoningEffort": z.string().readonly().optional()
		})).readonly()
	})).readonly()
});
const TYPERT_REMOTE$15 = {
	package: "@deepseek-ai/dsh-agent-default-model",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:b8bafe0172180f5d09995656edf61e330575d3887d1e3d2dbbd10f8a41b3c170",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-default-model#agentModels/list",
			service: "agentModels",
			namespace: "agentModels",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-default-model/types#AgentModelsSnapshot",
				schema: _deepseek_ai_dsh_agent_default_model_agentModels_list_result$schema
			},
			sourceLocation: {
				"file": "packages/core/agent-default-model/src/index.ts",
				"line": 409,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:2a820bbd50ae0f2776eeb88ff897259f623aa7b00d34dd42ee216abd1d9f553a",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-default-model#agentModels/reset",
			service: "agentModels",
			namespace: "agentModels",
			method: "reset",
			invocation: { kind: "direct" },
			parameters: [{
				name: "id",
				wire: "id",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-agent-default-model/types#AgentModelTargetId",
					schema: _deepseek_ai_dsh_agent_default_model_agentModels_reset_parameter_0$schema
				}
			}, {
				name: "expectedRevision",
				wire: "expectedRevision",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-agent-default-model#agentModels/reset:expectedRevision",
					schema: _deepseek_ai_dsh_agent_default_model_agentModels_reset_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-default-model/types#AgentModelsSnapshot",
				schema: _deepseek_ai_dsh_agent_default_model_agentModels_reset_result$schema
			},
			sourceLocation: {
				"file": "packages/core/agent-default-model/src/index.ts",
				"line": 469,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:865bfd965056a6c003b0245f9d62fc41be6fff8cdb7129615380f0b45ab683b3",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-default-model#agentModels/save",
			service: "agentModels",
			namespace: "agentModels",
			method: "save",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "id",
					wire: "id",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-default-model/types#AgentModelTargetId",
						schema: _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_0$schema
					}
				},
				{
					name: "model",
					wire: "model",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-default-model#agentModels/save:model",
						schema: _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_1$schema
					}
				},
				{
					name: "reasoningEffort",
					wire: "reasoningEffort",
					source: "json",
					acceptsUndefined: true,
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-default-model#agentModels/save:reasoningEffort",
						schema: _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_2$schema
					}
				},
				{
					name: "expectedRevision",
					wire: "expectedRevision",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-default-model#agentModels/save:expectedRevision",
						schema: _deepseek_ai_dsh_agent_default_model_agentModels_save_parameter_3$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-default-model/types#AgentModelsSnapshot",
				schema: _deepseek_ai_dsh_agent_default_model_agentModels_save_result$schema
			},
			sourceLocation: {
				"file": "packages/core/agent-default-model/src/index.ts",
				"line": 449,
				"column": 9
			}
		}
	]
};
//#endregion
//#region ../../preset/agent-presets/lib/typert.remote-client.js
const _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_0$schema = z.string();
const _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_1$schema = z.string();
const _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_2$schema = z.union([z.undefined(), z.string()]);
const _deepseek_ai_dsh_agent_presets_agentPresets_copy_result$schema = z.void();
const _deepseek_ai_dsh_agent_presets_agentPresets_deletePreset_parameter_0$schema = z.string();
const _deepseek_ai_dsh_agent_presets_agentPresets_deletePreset_result$schema = z.void();
const _deepseek_ai_dsh_agent_presets_agentPresets_list_result$schema = z.object({
	"presets": z.array(z.object({
		"id": z.string().readonly(),
		"trust": z.union([z.literal("system"), z.literal("user")]).readonly(),
		"isDefault": z.boolean().readonly(),
		"name": z.string().readonly().optional(),
		"description": z.string().readonly().optional(),
		"broken": z.string().readonly().optional()
	})).readonly(),
	"authorable": z.boolean().readonly()
});
const _deepseek_ai_dsh_agent_presets_agentPresets_read_parameter_0$schema = z.string();
const _deepseek_ai_dsh_agent_presets_agentPresets_read_result$schema = z.object({
	"agentPreset": z.string().readonly(),
	"trust": z.union([z.literal("system"), z.literal("user")]).readonly(),
	"content": z.string().readonly(),
	"name": z.string().readonly().optional(),
	"description": z.string().readonly().optional()
});
const _deepseek_ai_dsh_agent_presets_agentPresets_select_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_agent_presets_agentPresets_select_parameter_1$schema = z.string();
const _deepseek_ai_dsh_agent_presets_agentPresets_select_result$schema = z.string();
const TYPERT_REMOTE$14 = {
	package: "@deepseek-ai/dsh-agent-presets",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:c5459a39c75fbe5bf2348cc0be7b11c69d3a290f80e1001179190fc7d06971d0",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-presets#agentPresets/copy",
			service: "agentPresets",
			namespace: "agentPresets",
			method: "copy",
			implementation: "remoteExportCopy",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "from",
					wire: "from",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/copy:from",
						schema: _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_0$schema
					}
				},
				{
					name: "id",
					wire: "id",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/copy:id",
						schema: _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_1$schema
					}
				},
				{
					name: "name",
					wire: "name",
					source: "json",
					acceptsUndefined: true,
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/copy:name",
						schema: _deepseek_ai_dsh_agent_presets_agentPresets_copy_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/copy:result",
				schema: _deepseek_ai_dsh_agent_presets_agentPresets_copy_result$schema
			},
			sourceLocation: {
				"file": "packages/preset/agent-presets/src/index.ts",
				"line": 566,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:588fb5574bba29627d56a996c0fc64ca5facdcad15d5742b3e5b9d9a34f7d136",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-presets#agentPresets/deletePreset",
			service: "agentPresets",
			namespace: "agentPresets",
			method: "deletePreset",
			implementation: "remoteExportDelete",
			invocation: { kind: "direct" },
			parameters: [{
				name: "id",
				wire: "id",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/deletePreset:id",
					schema: _deepseek_ai_dsh_agent_presets_agentPresets_deletePreset_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/deletePreset:result",
				schema: _deepseek_ai_dsh_agent_presets_agentPresets_deletePreset_result$schema
			},
			sourceLocation: {
				"file": "packages/preset/agent-presets/src/index.ts",
				"line": 604,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:5b4fc02169633ccd8067e79e64b4832db58fda79c972b3bfa8a23b569e9488ad",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-presets#agentPresets/list",
			service: "agentPresets",
			namespace: "agentPresets",
			method: "list",
			implementation: "remoteExportList",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-presets/types#AgentPresetRoster",
				schema: _deepseek_ai_dsh_agent_presets_agentPresets_list_result$schema
			},
			sourceLocation: {
				"file": "packages/preset/agent-presets/src/index.ts",
				"line": 262,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:579faed4bd87a791b10a9b8a12bf235636747eaf5a373d4e328d1f1406daef79",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-presets#agentPresets/read",
			service: "agentPresets",
			namespace: "agentPresets",
			method: "read",
			implementation: "readDocument",
			invocation: { kind: "direct" },
			parameters: [{
				name: "agentPreset",
				wire: "agentPreset",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/read:agentPreset",
					schema: _deepseek_ai_dsh_agent_presets_agentPresets_read_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-presets/types#AgentPresetDocument",
				schema: _deepseek_ai_dsh_agent_presets_agentPresets_read_result$schema
			},
			sourceLocation: {
				"file": "packages/preset/agent-presets/src/index.ts",
				"line": 514,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:5528a335a583c08ab9469b079d9cd2a580e8bf10fe3968143930cb8ce42aedc3",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-agent-presets#agentPresets/select",
			service: "agentPresets",
			namespace: "agentPresets",
			method: "select",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_agent_presets_agentPresets_select_parameter_0$schema
				}
			}, {
				name: "agentPreset",
				wire: "agentPreset",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/select:agentPreset",
					schema: _deepseek_ai_dsh_agent_presets_agentPresets_select_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-agent-presets#agentPresets/select:result",
				schema: _deepseek_ai_dsh_agent_presets_agentPresets_select_result$schema
			},
			sourceLocation: {
				"file": "packages/preset/agent-presets/src/index.ts",
				"line": 696,
				"column": 9
			}
		}
	]
};
//#endregion
//#region ../../interaction/commands/lib/typert.remote-client.js
const _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema = z.string();
const _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema = z.array(z.union([z.intersection(z.object({ "type": z.literal("image").readonly() }), z.object({
	"mediaType": z.union([
		z.literal("image/png"),
		z.literal("image/jpeg"),
		z.literal("image/webp"),
		z.literal("image/gif")
	]),
	"data": z.string(),
	"name": z.string().optional()
})), z.object({
	"type": z.literal("file").readonly(),
	"receiptId": z.string().readonly()
})]));
const _deepseek_ai_dsh_commands_commands_execute_result$schema = z.union([z.undefined(), z.object({
	"commandId": z.intersection(z.string(), z.unknown()).readonly(),
	"result": z.union([z.object({
		"kind": z.literal("success").readonly(),
		"text": z.string().readonly().optional(),
		"sourceEventSeq": z.intersection(z.number(), z.unknown()).readonly().optional()
	}), z.object({
		"kind": z.literal("error").readonly(),
		"text": z.string().readonly()
	})]).readonly()
})]);
const _deepseek_ai_dsh_commands_commands_list_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_commands_commands_list_result$schema = z.array(z.object({
	"name": z.string().readonly(),
	"description": z.string().readonly(),
	"input": z.object({
		"hint": z.string().readonly(),
		"attachments": z.boolean().readonly().optional()
	}).readonly().optional()
}));
const TYPERT_REMOTE$13 = {
	package: "@deepseek-ai/dsh-commands",
	descriptors: [{
		wireFingerprint: "typert-wire-v1:27a5fc35bf712409ab0e73d0b7d674f4e00717959ac466a7e1084768a0b1e618",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-commands#commands/execute",
		service: "commands",
		namespace: "commands",
		method: "execute",
		invocation: { kind: "direct" },
		scope: {
			context: "agent",
			wire: "agentId"
		},
		parameters: [
			{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_commands_commands_execute_parameter_0$schema
				}
			},
			{
				name: "line",
				wire: "line",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:line",
					schema: _deepseek_ai_dsh_commands_commands_execute_parameter_1$schema
				}
			},
			{
				name: "submittedAttachments",
				wire: "submittedAttachments",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:submittedAttachments",
					schema: _deepseek_ai_dsh_commands_commands_execute_parameter_2$schema
				}
			}
		],
		cancellation: { parameter: "signal" },
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-commands#commands/execute:result",
			schema: _deepseek_ai_dsh_commands_commands_execute_result$schema
		},
		sourceLocation: {
			"file": "packages/interaction/commands/src/index.ts",
			"line": 356,
			"column": 9
		}
	}, {
		wireFingerprint: "typert-wire-v1:8366434b42d759c4d6f3c99569db7bd71f2e95e8d0f70cb244f4c1400f6895c1",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-commands#commands/list",
		service: "commands",
		namespace: "commands",
		method: "list",
		invocation: { kind: "direct" },
		scope: {
			context: "agent",
			wire: "agentId"
		},
		parameters: [{
			name: "agent",
			wire: "agentId",
			source: "lookup",
			lookup: "agent",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
				schema: _deepseek_ai_dsh_commands_commands_list_parameter_0$schema
			}
		}],
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-commands#commands/list:result",
			schema: _deepseek_ai_dsh_commands_commands_list_result$schema
		},
		sourceLocation: {
			"file": "packages/interaction/commands/src/index.ts",
			"line": 310,
			"column": 3
		}
	}]
};
//#endregion
//#region ../settings-controller/lib/typert.remote-client.js
const JsonValueRemoteCodec$schema$2 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$2))
]);
const JsonValueRemoteCodec$schema2$2 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema2$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2$2))
]);
const JsonValueRemoteCodec$schema3$2 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema3$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$2))
]);
const JsonValueRemoteCodec$schema4$2 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema4$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4$2))
]);
const JsonValueRemoteCodec$schema5$1 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema5$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5$1))
]);
const JsonValueRemoteCodec$schema6 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema6)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema6))
]);
const JsonValueRemoteCodec$schema7 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema7)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema7))
]);
const _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_2$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_authorization_answer_result$schema = z.void();
const _deepseek_ai_dsh_api_settings_controller_authorization_cancel_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_settings_controller_authorization_cancel_result$schema = z.void();
const _deepseek_ai_dsh_api_settings_controller_authorization_list_result$schema = z.array(z.object({
	"key": z.intersection(z.string(), z.unknown()).readonly(),
	"label": z.string().readonly(),
	"methods": z.array(z.object({
		"id": z.string().readonly(),
		"label": z.string().readonly()
	})).readonly(),
	"configured": z.boolean().readonly(),
	"inFlight": z.boolean().readonly()
}));
const _deepseek_ai_dsh_api_settings_controller_authorization_signIn_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_authorization_signIn_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_authorization_signIn_result$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"status": z.union([
		z.literal("pending"),
		z.literal("failed"),
		z.literal("authorized"),
		z.literal("cancelled")
	]).readonly(),
	"message": z.string().readonly().optional(),
	"url": z.union([z.undefined(), z.string()]).readonly().optional(),
	"code": z.string().readonly().optional(),
	"prompt": z.union([z.undefined(), z.object({
		"id": z.intersection(z.string(), z.unknown()).readonly(),
		"kind": z.union([
			z.literal("text"),
			z.literal("secret"),
			z.literal("select")
		]).readonly(),
		"message": z.string().readonly(),
		"placeholder": z.string().readonly().optional(),
		"options": z.array(z.object({
			"id": z.string().readonly(),
			"label": z.string().readonly(),
			"description": z.string().readonly().optional()
		})).readonly().optional()
	})]).readonly().optional()
});
const _deepseek_ai_dsh_api_settings_controller_authorization_signOut_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_authorization_signOut_result$schema = z.void();
const _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema = z.array(z.string());
const _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema = z.record(z.string(), z.object({
	"configured": z.boolean(),
	"source": z.string().optional(),
	"writable": z.boolean()
}));
const _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema = z.void();
const _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema = z.void();
const _deepseek_ai_dsh_api_settings_controller_settings_canOpenAgentPresetDirectory_result$schema = z.boolean();
const _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema = z.object({
	"writable": z.boolean(),
	"hasDocument": z.boolean(),
	"namespaces": z.array(z.object({
		"ns": z.string(),
		"schema": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$2))
		]),
		"value": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$2))
		]),
		"base": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$2))
		]).optional(),
		"user": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$2))
		]).optional(),
		"applies": z.union([z.literal("live"), z.literal("restart")]),
		"secrets": z.array(z.object({
			"path": z.array(z.string()),
			"set": z.boolean()
		})),
		"revision": z.number()
	}))
});
const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema = z.array(z.union([z.object({
	"op": z.literal("set"),
	"path": z.array(z.string()),
	"value": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema6)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema6))
	])
}), z.object({
	"op": z.literal("unset"),
	"path": z.array(z.string())
})]));
const _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema = z.union([z.undefined(), z.number()]);
const _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema = z.object({
	"ns": z.string(),
	"schema": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema7)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema7))
	]),
	"value": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema7)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema7))
	]),
	"base": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema7)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema7))
	]).optional(),
	"user": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema7)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema7))
	]).optional(),
	"applies": z.union([z.literal("live"), z.literal("restart")]),
	"secrets": z.array(z.object({
		"path": z.array(z.string()),
		"set": z.boolean()
	})),
	"revision": z.number()
});
const _deepseek_ai_dsh_api_settings_controller_settings_openAgentPresetDirectory_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_settings_openAgentPresetDirectory_result$schema = z.union([z.object({ "opened": z.literal(true).readonly() }), z.object({
	"opened": z.literal(false).readonly(),
	"path": z.string().readonly()
})]);
const _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema = z.object({ "opened": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema = z.record(z.string(), z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema4$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4$2))
]));
const _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema = z.union([z.undefined(), z.number()]);
const _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema = z.object({
	"ns": z.string(),
	"schema": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema5$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5$1))
	]),
	"value": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema5$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5$1))
	]),
	"base": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema5$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5$1))
	]).optional(),
	"user": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema5$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5$1))
	]).optional(),
	"applies": z.union([z.literal("live"), z.literal("restart")]),
	"secrets": z.array(z.object({
		"path": z.array(z.string()),
		"set": z.boolean()
	})),
	"revision": z.number()
});
const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema = z.record(z.string(), z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema2$2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2$2))
]));
const _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema = z.union([z.undefined(), z.number()]);
const _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema = z.object({
	"ns": z.string(),
	"schema": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema3$2)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$2))
	]),
	"value": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema3$2)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$2))
	]),
	"base": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema3$2)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$2))
	]).optional(),
	"user": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema3$2)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$2))
	]).optional(),
	"applies": z.union([z.literal("live"), z.literal("restart")]),
	"secrets": z.array(z.object({
		"path": z.array(z.string()),
		"set": z.boolean()
	})),
	"revision": z.number()
});
const TYPERT_REMOTE$12 = {
	package: "@deepseek-ai/dsh-api-settings-controller",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:c3fac98aff1536a1f1a3eb3005485039bd435eee88907b2deb2bd8fd747dae01",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#authorization/answer",
			service: "authorizationController",
			namespace: "authorization",
			method: "answer",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "id",
					wire: "id",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#AccountAttemptId",
						schema: _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_0$schema
					}
				},
				{
					name: "promptId",
					wire: "promptId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#AccountPromptId",
						schema: _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_1$schema
					}
				},
				{
					name: "value",
					wire: "value",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/answer:value",
						schema: _deepseek_ai_dsh_api_settings_controller_authorization_answer_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/answer:result",
				schema: _deepseek_ai_dsh_api_settings_controller_authorization_answer_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/authorization.ts",
				"line": 185,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:fa284e874ea6284388602cb9b9e30ea0e407b27b80babca6596677eb5ed9e419",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#authorization/cancel",
			service: "authorizationController",
			namespace: "authorization",
			method: "cancel",
			invocation: { kind: "direct" },
			parameters: [{
				name: "id",
				wire: "id",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#AccountAttemptId",
					schema: _deepseek_ai_dsh_api_settings_controller_authorization_cancel_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/cancel:result",
				schema: _deepseek_ai_dsh_api_settings_controller_authorization_cancel_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/authorization.ts",
				"line": 196,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:b86f10e45989813f135427e5b2b2810bca8976609a106a4b40b621eb98123c88",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#authorization/list",
			service: "authorizationController",
			namespace: "authorization",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/list:result",
				schema: _deepseek_ai_dsh_api_settings_controller_authorization_list_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/authorization.ts",
				"line": 74,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:50bc535d26317550af7b7761be4893752572224b9621af4450429cc38930f406",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#authorization/signIn",
			service: "authorizationController",
			namespace: "authorization",
			method: "signIn",
			mode: "stream",
			invocation: { kind: "direct" },
			parameters: [{
				name: "key",
				wire: "key",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/signIn:key",
					schema: _deepseek_ai_dsh_api_settings_controller_authorization_signIn_parameter_0$schema
				}
			}, {
				name: "method",
				wire: "method",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/signIn:method",
					schema: _deepseek_ai_dsh_api_settings_controller_authorization_signIn_parameter_1$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#ProviderAccountUpdate",
				schema: _deepseek_ai_dsh_api_settings_controller_authorization_signIn_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/authorization.ts",
				"line": 94,
				"column": 10
			}
		},
		{
			wireFingerprint: "typert-wire-v1:0ab82b3478555d1d2353f348f779d483c3bd9851e835f81fdacfce4fa3f6470c",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#authorization/signOut",
			service: "authorizationController",
			namespace: "authorization",
			method: "signOut",
			invocation: { kind: "direct" },
			parameters: [{
				name: "key",
				wire: "key",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/signOut:key",
					schema: _deepseek_ai_dsh_api_settings_controller_authorization_signOut_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#authorization/signOut:result",
				schema: _deepseek_ai_dsh_api_settings_controller_authorization_signOut_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/authorization.ts",
				"line": 203,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:438decc014ca1e64838bfefad4105c5ed30d0619488c55b89788f3a3c35b185f",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#credentials/describe",
			service: "credentialsController",
			namespace: "credentials",
			method: "describe",
			invocation: { kind: "direct" },
			parameters: [{
				name: "refs",
				wire: "refs",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/describe:refs",
					schema: _deepseek_ai_dsh_api_settings_controller_credentials_describe_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/describe:result",
				schema: _deepseek_ai_dsh_api_settings_controller_credentials_describe_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/credentials.ts",
				"line": 83,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:ad8adf7652590790c66d9d374ead704309161213f0e4744f5da7680a3c2a3750",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#credentials/set",
			service: "credentialsController",
			namespace: "credentials",
			method: "set",
			invocation: { kind: "direct" },
			parameters: [{
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:ref",
					schema: _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_0$schema
				}
			}, {
				name: "value",
				wire: "value",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:value",
					schema: _deepseek_ai_dsh_api_settings_controller_credentials_set_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/set:result",
				schema: _deepseek_ai_dsh_api_settings_controller_credentials_set_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/credentials.ts",
				"line": 100,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:6c20f915d6bd9a22d3c489286301d7a2521387480e55d0752da9e592958c502e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#credentials/unset",
			service: "credentialsController",
			namespace: "credentials",
			method: "unset",
			invocation: { kind: "direct" },
			parameters: [{
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/unset:ref",
					schema: _deepseek_ai_dsh_api_settings_controller_credentials_unset_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#credentials/unset:result",
				schema: _deepseek_ai_dsh_api_settings_controller_credentials_unset_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/credentials.ts",
				"line": 113,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:73e15582ee67744f8b593d0ee0d5bd958381885d44f6bec489b0c71d353fcf9e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/canOpenAgentPresetDirectory",
			service: "settingsController",
			namespace: "settings",
			method: "canOpenAgentPresetDirectory",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/canOpenAgentPresetDirectory:result",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_canOpenAgentPresetDirectory_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 137,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:de4d2520df6ad20d9aad89f7d7b2a926e0e22c8f6988309e244c10ff27aa18b3",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/describe",
			service: "settingsController",
			namespace: "settings",
			method: "describe",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsDescribeValue",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_describe_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 123,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:358a00bd2bf8546627667091f86ad9a42b4fd28e3e9954759e9329b7e5c9082f",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/mutate",
			service: "settingsController",
			namespace: "settings",
			method: "mutate",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "ns",
					wire: "ns",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:ns",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_0$schema
					}
				},
				{
					name: "ops",
					wire: "ops",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:ops",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_1$schema
					}
				},
				{
					name: "expectedRevision",
					wire: "expectedRevision",
					source: "json",
					acceptsUndefined: true,
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/mutate:expectedRevision",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_mutate_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_mutate_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 186,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:edaf966c8ca05c2fb3a7f593407762098250704bba00e5f2f551d0ce5712bf42",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/openAgentPresetDirectory",
			service: "settingsController",
			namespace: "settings",
			method: "openAgentPresetDirectory",
			invocation: { kind: "direct" },
			parameters: [{
				name: "agentPreset",
				wire: "agentPreset",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/openAgentPresetDirectory:agentPreset",
					schema: _deepseek_ai_dsh_api_settings_controller_settings_openAgentPresetDirectory_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#AgentPresetDirectoryOpenValue",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_openAgentPresetDirectory_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 232,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:0202c26151168286c83fb91a8d60441cd49ae38f01aea304b5787f68210ed68b",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/openSettingsDocument",
			service: "settingsController",
			namespace: "settings",
			method: "openSettingsDocument",
			invocation: { kind: "direct" },
			parameters: [],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-settings-controller/types#SettingsDocumentOpenValue",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_openSettingsDocument_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 201,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:e4178256cacabdba9b7e7a2106bd8c77de64a4309aac702a5f5a58500685f384",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/replace",
			service: "settingsController",
			namespace: "settings",
			method: "replace",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "ns",
					wire: "ns",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:ns",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_0$schema
					}
				},
				{
					name: "section",
					wire: "section",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:section",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_1$schema
					}
				},
				{
					name: "expectedRevision",
					wire: "expectedRevision",
					source: "json",
					acceptsUndefined: true,
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/replace:expectedRevision",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_replace_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_replace_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 167,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:5c62d72f0dc6cf54a06ab03a1d7b8b8ba288c84ccc31ecbbfc9d71e6b31f4c32",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-settings-controller#settings/update",
			service: "settingsController",
			namespace: "settings",
			method: "update",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "ns",
					wire: "ns",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:ns",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_0$schema
					}
				},
				{
					name: "patch",
					wire: "patch",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:patch",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_1$schema
					}
				},
				{
					name: "expectedRevision",
					wire: "expectedRevision",
					source: "json",
					acceptsUndefined: true,
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-settings-controller#settings/update:expectedRevision",
						schema: _deepseek_ai_dsh_api_settings_controller_settings_update_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-settings/types#SettingsNamespaceView",
				schema: _deepseek_ai_dsh_api_settings_controller_settings_update_result$schema
			},
			sourceLocation: {
				"file": "packages/api/settings-controller/src/index.ts",
				"line": 150,
				"column": 3
			}
		}
	]
};
//#endregion
//#region ../../goal/goal/lib/typert.remote-client.js
const _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_clear_result$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_complete_result$schema = z.object({
	"roundsStarted": z.number().readonly(),
	"createdAt": z.number().readonly(),
	"updatedAt": z.number().readonly(),
	"activation": z.union([z.literal("armed"), z.literal("disarmed")]).readonly(),
	"objective": z.string().readonly(),
	"phase": z.union([
		z.literal("active"),
		z.literal("paused"),
		z.literal("blocked"),
		z.literal("complete")
	]).readonly(),
	"blockedReason": z.object({
		"code": z.string().readonly(),
		"message": z.string().readonly()
	}).readonly().optional(),
	"maxGoalRounds": z.number().readonly(),
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_create_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_create_parameter_1$schema = z.object({
	"objective": z.string().readonly(),
	"maxGoalRounds": z.number().readonly().optional()
});
const _deepseek_ai_dsh_goal_goals_create_result$schema = z.object({ "ref": z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
}).readonly() });
const _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema = z.object({
	"objective": z.string().readonly().optional(),
	"maxGoalRounds": z.number().readonly().optional()
});
const _deepseek_ai_dsh_goal_goals_edit_result$schema = z.object({
	"roundsStarted": z.number().readonly(),
	"createdAt": z.number().readonly(),
	"updatedAt": z.number().readonly(),
	"activation": z.union([z.literal("armed"), z.literal("disarmed")]).readonly(),
	"objective": z.string().readonly(),
	"phase": z.union([
		z.literal("active"),
		z.literal("paused"),
		z.literal("blocked"),
		z.literal("complete")
	]).readonly(),
	"blockedReason": z.object({
		"code": z.string().readonly(),
		"message": z.string().readonly()
	}).readonly().optional(),
	"maxGoalRounds": z.number().readonly(),
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_get_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_get_result$schema = z.union([z.undefined(), z.object({
	"roundsStarted": z.number().readonly(),
	"createdAt": z.number().readonly(),
	"updatedAt": z.number().readonly(),
	"activation": z.union([z.literal("armed"), z.literal("disarmed")]).readonly(),
	"objective": z.string().readonly(),
	"phase": z.union([
		z.literal("active"),
		z.literal("paused"),
		z.literal("blocked"),
		z.literal("complete")
	]).readonly(),
	"blockedReason": z.object({
		"code": z.string().readonly(),
		"message": z.string().readonly()
	}).readonly().optional(),
	"maxGoalRounds": z.number().readonly(),
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
})]);
const _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_pause_result$schema = z.object({
	"roundsStarted": z.number().readonly(),
	"createdAt": z.number().readonly(),
	"updatedAt": z.number().readonly(),
	"activation": z.union([z.literal("armed"), z.literal("disarmed")]).readonly(),
	"objective": z.string().readonly(),
	"phase": z.union([
		z.literal("active"),
		z.literal("paused"),
		z.literal("blocked"),
		z.literal("complete")
	]).readonly(),
	"blockedReason": z.object({
		"code": z.string().readonly(),
		"message": z.string().readonly()
	}).readonly().optional(),
	"maxGoalRounds": z.number().readonly(),
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema = z.object({
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const _deepseek_ai_dsh_goal_goals_resume_result$schema = z.object({
	"roundsStarted": z.number().readonly(),
	"createdAt": z.number().readonly(),
	"updatedAt": z.number().readonly(),
	"activation": z.union([z.literal("armed"), z.literal("disarmed")]).readonly(),
	"objective": z.string().readonly(),
	"phase": z.union([
		z.literal("active"),
		z.literal("paused"),
		z.literal("blocked"),
		z.literal("complete")
	]).readonly(),
	"blockedReason": z.object({
		"code": z.string().readonly(),
		"message": z.string().readonly()
	}).readonly().optional(),
	"maxGoalRounds": z.number().readonly(),
	"id": z.intersection(z.string(), z.unknown()).readonly(),
	"revision": z.number().readonly()
});
const TYPERT_REMOTE$11 = {
	package: "@deepseek-ai/dsh-goal",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:7b119bd2f0ec38dd0b2e2a7b5e97bce2eda6bf643de52cfe4792bb728e455a6a",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/clear",
			service: "goals",
			namespace: "goals",
			method: "clear",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_clear_parameter_0$schema
				}
			}, {
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
					schema: _deepseek_ai_dsh_goal_goals_clear_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
				schema: _deepseek_ai_dsh_goal_goals_clear_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 433,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:68b8dc5f16333043510389db02c99a8135b17bc78670789dda6c09a8a6906741",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/complete",
			service: "goals",
			namespace: "goals",
			method: "complete",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_complete_parameter_0$schema
				}
			}, {
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
					schema: _deepseek_ai_dsh_goal_goals_complete_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
				schema: _deepseek_ai_dsh_goal_goals_complete_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 391,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:7280fa63da98dfa3a5631bb389a4324b317650664d55e25a9d8e83fc231fb6c0",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/create",
			service: "goals",
			namespace: "goals",
			method: "create",
			implementation: "remoteExportCreate",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_create_parameter_0$schema
				}
			}, {
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-goal/client#CreateGoalRequest",
					schema: _deepseek_ai_dsh_goal_goals_create_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#CreateGoalResult",
				schema: _deepseek_ai_dsh_goal_goals_create_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 647,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:097423f197686ccd07d6dd86f02b3753a9f88f448a8ea5bb91cb1e02986d57d3",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/edit",
			service: "goals",
			namespace: "goals",
			method: "edit",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_goal_goals_edit_parameter_0$schema
					}
				},
				{
					name: "ref",
					wire: "ref",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
						schema: _deepseek_ai_dsh_goal_goals_edit_parameter_1$schema
					}
				},
				{
					name: "request",
					wire: "request",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-goal/client#EditGoalRequest",
						schema: _deepseek_ai_dsh_goal_goals_edit_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
				schema: _deepseek_ai_dsh_goal_goals_edit_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 329,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:a8f8588c0f961faca808570b921369e6f18e5a78d9c7da474670ac5df729299e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/get",
			service: "goals",
			namespace: "goals",
			method: "get",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_get_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal#goals/get:result",
				schema: _deepseek_ai_dsh_goal_goals_get_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 277,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:5c02c9c751d542dd7aef54ad5da8badcbceabf77a02f7d49b2bf3455c9882217",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/pause",
			service: "goals",
			namespace: "goals",
			method: "pause",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_pause_parameter_0$schema
				}
			}, {
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
					schema: _deepseek_ai_dsh_goal_goals_pause_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
				schema: _deepseek_ai_dsh_goal_goals_pause_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 352,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:0f1a3cd6aac2d2d29263abf82bc3840ce7521e0e984c217a66972c4c6fa1b827",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-goal#goals/resume",
			service: "goals",
			namespace: "goals",
			method: "resume",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_goal_goals_resume_parameter_0$schema
				}
			}, {
				name: "ref",
				wire: "ref",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-goal/client#GoalRef",
					schema: _deepseek_ai_dsh_goal_goals_resume_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-goal/client#GoalView",
				schema: _deepseek_ai_dsh_goal_goals_resume_result$schema
			},
			sourceLocation: {
				"file": "packages/goal/goal/src/index.ts",
				"line": 364,
				"column": 3
			}
		}
	]
};
//#endregion
//#region ../../llm/llm/lib/typert.remote-client.js
const _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema = z.string();
const _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema = z.object({
	"provider": z.string().optional(),
	"baseURL": z.string().optional(),
	"api": z.string().optional(),
	"apiKey": z.string().optional()
});
const _deepseek_ai_dsh_llm_llm_discoverModels_result$schema = z.array(z.object({
	"id": z.string(),
	"name": z.string().optional(),
	"contextWindow": z.number().optional(),
	"maxTokens": z.number().optional()
}));
const _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema = z.array(z.object({
	"provider": z.string(),
	"displayName": z.string(),
	"settingsNs": z.string(),
	"settingsPath": z.array(z.string()),
	"declared": z.boolean().optional(),
	"error": z.string().optional()
}));
const _deepseek_ai_dsh_llm_llm_listProviders_result$schema = z.array(z.object({
	"id": z.string(),
	"name": z.string()
}));
const TYPERT_REMOTE$10 = {
	package: "@deepseek-ai/dsh-llm",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:a97c997f0d290314c63b9effb9c8e2f6c834f9aa7f8eeca9524a448d1a1d9a5b",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-llm#llm/discoverModels",
			service: "llm",
			namespace: "llm",
			method: "discoverModels",
			implementation: "remoteDiscoverModels",
			invocation: { kind: "direct" },
			parameters: [{
				name: "settingsNs",
				wire: "settingsNs",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-llm#llm/discoverModels:settingsNs",
					schema: _deepseek_ai_dsh_llm_llm_discoverModels_parameter_0$schema
				}
			}, {
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-llm/types#LlmModelDiscoveryRequest",
					schema: _deepseek_ai_dsh_llm_llm_discoverModels_parameter_1$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-llm#llm/discoverModels:result",
				schema: _deepseek_ai_dsh_llm_llm_discoverModels_result$schema
			},
			sourceLocation: {
				"file": "packages/llm/llm/src/index.ts",
				"line": 628,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:edc0a3b3981604fb26602ed2a6a214edc5e0896d2567f93f0ac70e7d0dc8412e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-llm#llm/listConfigurableProviders",
			service: "llm",
			namespace: "llm",
			method: "listConfigurableProviders",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-llm#llm/listConfigurableProviders:result",
				schema: _deepseek_ai_dsh_llm_llm_listConfigurableProviders_result$schema
			},
			sourceLocation: {
				"file": "packages/llm/llm/src/index.ts",
				"line": 541,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:06cbc6ecc40e4baaab6242e19388e26f4b069caad3228ad59a3a91f125e26696",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-llm#llm/listProviders",
			service: "llm",
			namespace: "llm",
			method: "listProviders",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-llm#llm/listProviders:result",
				schema: _deepseek_ai_dsh_llm_llm_listProviders_result$schema
			},
			sourceLocation: {
				"file": "packages/llm/llm/src/index.ts",
				"line": 469,
				"column": 3
			}
		}
	]
};
//#endregion
//#region ../../extensions/cordis-host-runner/lib/typert.remote-client.js
const JsonValueRemoteCodec$schema$1 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$1))
]);
const JsonValueRemoteCodec$schema2$1 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema2$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2$1))
]);
const JsonValueRemoteCodec$schema3$1 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema3$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$1))
]);
const JsonValueRemoteCodec$schema4$1 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema4$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4$1))
]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema = z.object({
	"code": z.string(),
	"name": z.string(),
	"pluginId": z.intersection(z.string(), z.unknown()),
	"packageId": z.intersection(z.string(), z.unknown()),
	"pluginRunId": z.intersection(z.string(), z.unknown())
});
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema = z.array(z.object({
	"pluginId": z.intersection(z.string(), z.unknown()),
	"agentId": z.intersection(z.string(), z.unknown()),
	"packages": z.array(z.object({
		"packageId": z.intersection(z.string(), z.unknown()),
		"name": z.string(),
		"purpose": z.string(),
		"hasHostHalf": z.boolean(),
		"hasClientHalf": z.boolean()
	})),
	"currentPackageId": z.intersection(z.string(), z.unknown()).optional(),
	"nextPackageId": z.intersection(z.string(), z.unknown()).optional(),
	"activeRun": z.object({
		"pluginRunId": z.intersection(z.string(), z.unknown()),
		"packageId": z.intersection(z.string(), z.unknown())
	}).optional(),
	"latestRun": z.object({
		"pluginRunId": z.intersection(z.string(), z.unknown()),
		"packageId": z.intersection(z.string(), z.unknown()),
		"mode": z.union([z.literal("run"), z.literal("update")]),
		"status": z.union([
			z.literal("running"),
			z.literal("failed"),
			z.literal("cancelled"),
			z.literal("rejected"),
			z.literal("awaiting-approval"),
			z.literal("starting-host"),
			z.literal("client-pending"),
			z.literal("waiting"),
			z.literal("stopped")
		]),
		"approvalRequestId": z.intersection(z.string(), z.unknown()).optional(),
		"requiresApproval": z.boolean().optional(),
		"host": z.object({
			"status": z.union([
				z.literal("pending"),
				z.literal("running"),
				z.literal("failed"),
				z.literal("waiting"),
				z.literal("stopped"),
				z.literal("absent")
			]),
			"waitingFor": z.array(z.string()),
			"error": z.string().optional()
		}),
		"client": z.object({
			"status": z.union([
				z.literal("pending"),
				z.literal("running"),
				z.literal("failed"),
				z.literal("waiting"),
				z.literal("stopped"),
				z.literal("absent")
			]),
			"waitingFor": z.array(z.string()),
			"error": z.string().optional()
		}),
		"error": z.object({
			"phase": z.union([
				z.literal("approval"),
				z.literal("host-load"),
				z.literal("host-apply"),
				z.literal("client-load"),
				z.literal("client-apply"),
				z.literal("client-render")
			]),
			"message": z.string(),
			"stack": z.string().optional(),
			"pluginId": z.intersection(z.string(), z.unknown()),
			"packageId": z.intersection(z.string(), z.unknown()),
			"pluginRunId": z.intersection(z.string(), z.unknown())
		}).optional()
	}).optional()
}));
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema = z.string();
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema3$1)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3$1))
]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema = z.union([z.object({
	"ok": z.literal(true),
	"value": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema4$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4$1))
	])
}), z.intersection(z.object({
	"ok": z.literal(false),
	"code": z.union([
		z.literal("plugin-not-running"),
		z.literal("stale-run"),
		z.literal("method-not-found"),
		z.literal("handler-error")
	])
}), z.object({
	"message": z.string(),
	"stack": z.string().optional()
}))]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema = z.object({
	"message": z.string(),
	"stack": z.string().optional()
});
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema = z.literal(null);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema = z.object({
	"slot": z.string(),
	"message": z.string(),
	"stack": z.string().optional(),
	"abdicated": z.boolean()
});
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema = z.literal(null);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema = z.union([z.object({
	"ok": z.literal(true),
	"data": z.union([
		z.literal(null),
		z.string(),
		z.number(),
		z.literal(false),
		z.literal(true),
		z.array(z.lazy(() => JsonValueRemoteCodec$schema2$1)),
		z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2$1))
	])
}), z.object({
	"ok": z.literal(false),
	"reason": z.union([
		z.literal("cancelled"),
		z.literal("provider-missing"),
		z.literal("method-missing"),
		z.literal("invalid-input"),
		z.literal("provider-error")
	]),
	"message": z.string()
})]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema = z.object({ "accepted": z.boolean() });
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema = z.union([z.object({
	"ok": z.literal(true),
	"pluginRunId": z.intersection(z.string(), z.unknown()),
	"waitingFor": z.array(z.string()).optional()
}), z.object({
	"ok": z.literal(false),
	"reason": z.union([
		z.literal("rejected"),
		z.literal("host-half-failed"),
		z.literal("client-half-failed")
	]),
	"pluginRunId": z.intersection(z.string(), z.unknown()).optional(),
	"startedHere": z.boolean().optional(),
	"message": z.string().optional(),
	"stack": z.string().optional()
})]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema = z.object({ "accepted": z.boolean() });
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema = z.union([z.literal("run"), z.literal("update")]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema = z.union([z.literal(null), z.intersection(z.string(), z.unknown())]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema = z.boolean();
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema = z.union([z.object({
	"ok": z.literal(true),
	"pluginId": z.intersection(z.string(), z.unknown()),
	"packageId": z.intersection(z.string(), z.unknown()),
	"pluginRunId": z.intersection(z.string(), z.unknown()),
	"waitingFor": z.array(z.string()),
	"startedHere": z.boolean()
}), z.intersection(z.object({ "ok": z.literal(false) }), z.object({
	"message": z.string(),
	"stack": z.string().optional()
}))]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema = z.union([z.object({
	"ok": z.literal(true),
	"pluginRunId": z.intersection(z.string(), z.unknown()),
	"waitingFor": z.array(z.string()).optional()
}), z.object({
	"ok": z.literal(false),
	"reason": z.union([
		z.literal("rejected"),
		z.literal("host-half-failed"),
		z.literal("client-half-failed")
	]),
	"pluginRunId": z.intersection(z.string(), z.unknown()).optional(),
	"startedHere": z.boolean().optional(),
	"message": z.string().optional(),
	"stack": z.string().optional()
})]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema = z.union([z.object({
	"ok": z.literal(true),
	"status": z.union([
		z.literal("running"),
		z.literal("awaiting-approval"),
		z.literal("starting")
	]),
	"pluginId": z.intersection(z.string(), z.unknown()),
	"packageId": z.intersection(z.string(), z.unknown()),
	"pluginRunId": z.intersection(z.string(), z.unknown()),
	"waitingFor": z.array(z.string()),
	"clientWaitingFor": z.array(z.string()).optional(),
	"currentPackageId": z.intersection(z.string(), z.unknown()).optional(),
	"nextPackageId": z.intersection(z.string(), z.unknown()).optional(),
	"mode": z.union([z.literal("run"), z.literal("update")])
}), z.object({
	"ok": z.literal(false),
	"reason": z.union([
		z.literal("cancelled"),
		z.literal("plugin-missing"),
		z.literal("rejected"),
		z.literal("host-half-failed"),
		z.literal("client-half-failed"),
		z.literal("package-missing"),
		z.literal("invalid-mode"),
		z.literal("transition-in-flight"),
		z.literal("not-running")
	]),
	"message": z.string(),
	"stack": z.string().optional()
})]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema = z.union([z.object({ "ok": z.literal(true) }), z.object({
	"ok": z.literal(false),
	"reason": z.union([z.literal("plugin-missing"), z.literal("not-running")]),
	"message": z.string()
})]);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema = z.array(z.object({
	"id": z.string(),
	"description": z.string(),
	"methods": z.array(z.object({
		"name": z.string(),
		"description": z.string(),
		"inputSchema": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$1)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$1))
		]),
		"outputSchema": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema$1)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema$1))
		])
	}))
}));
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema = z.literal(null);
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema = z.union([z.object({
	"ok": z.literal(true),
	"wasRunning": z.boolean()
}), z.object({
	"ok": z.literal(false),
	"reason": z.literal("plugin-missing"),
	"message": z.string()
})]);
const TYPERT_REMOTE$9 = {
	package: "@deepseek-ai/dsh-cordis-host-runner",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:1e2309c4a2334c8387dac145c12d85909b2ac7065fe9295584c70cf09e6f0b28",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/getClientCode",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "getClientCode",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_0$schema
					}
				},
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_1$schema
					}
				},
				{
					name: "pluginRunId",
					wire: "pluginRunId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisClientSource",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_getClientCode_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 384,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:e5fd88fef314dc107ee860f3f1e791c90d755696066dad10e1eec957a8fb7f9f",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/inventory",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "inventory",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/inventory:result",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_inventory_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 525,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:9cdd878e8eb09b3562395ad076536e81fcff6c85e63281470b4445ad9783a587",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/invoke",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "invoke",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_0$schema
					}
				},
				{
					name: "pluginRunId",
					wire: "pluginRunId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_1$schema
					}
				},
				{
					name: "method",
					wire: "method",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/invoke:method",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_2$schema
					}
				},
				{
					name: "args",
					wire: "args",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-util-values#JsonValue",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_parameter_3$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisInvokeResult",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_invoke_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 741,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:56d9473ef52969d6afc7c4c3ddbca9589cd48c39fec1389ba265758d355068f5",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportClientGuardFailure",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "reportClientGuardFailure",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_0$schema
					}
				},
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_1$schema
					}
				},
				{
					name: "pluginRunId",
					wire: "pluginRunId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_2$schema
					}
				},
				{
					name: "failure",
					wire: "failure",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisErrorDetails",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_parameter_3$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportClientGuardFailure:result",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportClientGuardFailure_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 718,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:a831f01e1f0331815da6eaa4e838e20872b66720deb30f8a0dce9db0e9fc90ce",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportRenderFailure",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "reportRenderFailure",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_0$schema
					}
				},
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_1$schema
					}
				},
				{
					name: "pluginRunId",
					wire: "pluginRunId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginRunId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_2$schema
					}
				},
				{
					name: "failure",
					wire: "failure",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRenderFailure",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_parameter_3$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/reportRenderFailure:result",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_reportRenderFailure_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 684,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:960a73fdc34189890efbb25bacddfc1b2d7df1eb43e7a51b5f83a50e074d5dbc",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/resolveInspectQuery",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "resolveInspectQuery",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_0$schema
					}
				},
				{
					name: "requestId",
					wire: "requestId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectRequestId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_1$schema
					}
				},
				{
					name: "resolution",
					wire: "resolution",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectQueryResolution",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisInspectResolveAck",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveInspectQuery_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 511,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:6af7e64570777a3be1b551bccc66a8e3e48822756cddac9a7059a2493c8006db",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/resolveRequestRun",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "resolveRequestRun",
			invocation: { kind: "direct" },
			parameters: [{
				name: "requestId",
				wire: "requestId",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#ApprovalRequestId",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_0$schema
				}
			}, {
				name: "resolution",
				wire: "resolution",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResolution",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisResolveAck",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_resolveRequestRun_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 413,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:3762d65e429f95dd59cfef976f83c1f07f69ec50bdf09384831bc72b51f6b4db",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "runHostHalf",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_0$schema
					}
				},
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_1$schema
					}
				},
				{
					name: "packageId",
					wire: "packageId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPackageId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_2$schema
					}
				},
				{
					name: "mode",
					wire: "mode",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicRunMode",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_3$schema
					}
				},
				{
					name: "requestId",
					wire: "requestId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf:requestId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_4$schema
					}
				},
				{
					name: "approveFutureVersions",
					wire: "approveFutureVersions",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/runHostHalf:approveFutureVersions",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_parameter_5$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisHostHalfResult",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_runHostHalf_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 325,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:ecccbbe447aeb582e0a1e0ab3a7857dd170f883ff5033e552f3c1bb216a80e71",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/settleUserRun",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "settleUserRun",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [
				{
					name: "agent",
					wire: "agentId",
					source: "lookup",
					lookup: "agent",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_0$schema
					}
				},
				{
					name: "pluginId",
					wire: "pluginId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_1$schema
					}
				},
				{
					name: "resolution",
					wire: "resolution",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResolution",
						schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisRunResponse",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_settleUserRun_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 438,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:598f303e7facad8b994a16a66f2f62dbe1058b506391d0c603426663fc998355",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/stopFromPanel",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "stopFromPanel",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_0$schema
				}
			}, {
				name: "pluginId",
				wire: "pluginId",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisStopResponse",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_stopFromPanel_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 480,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:0f2ef62f19d4e6f6fdee7740ced8c3f9daa59087d0ed5fb46d8de7a127252112",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "syncInspectManifest",
			invocation: { kind: "direct" },
			parameters: [{
				name: "providers",
				wire: "providers",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest:providers",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/syncInspectManifest:result",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_syncInspectManifest_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 498,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:601fb090b2f50dd0a05c588164c820c4e982768433b2d76f9f1eca48aa932406",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-cordis-host-runner#dynamicCordisRunner/undefineFromPanel",
			service: "dynamicCordisRunner",
			namespace: "dynamicCordisRunner",
			method: "undefineFromPanel",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_0$schema
				}
			}, {
				name: "pluginId",
				wire: "pluginId",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#CordisDynamicPluginId",
					schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-cordis-host-runner/types#DynamicCordisUndefineReceipt",
				schema: _deepseek_ai_dsh_cordis_host_runner_dynamicCordisRunner_undefineFromPanel_result$schema
			},
			sourceLocation: {
				"file": "packages/extensions/cordis-host-runner/src/index.ts",
				"line": 227,
				"column": 9
			}
		}
	]
};
const TYPERT_REMOTE$8 = {
	package: "@deepseek-ai/dsh-host-plugin-inventory",
	descriptors: [{
		wireFingerprint: "typert-wire-v1:c26a25b18004451df7898c78ba045ad300d27e6e6bcf70c6545bbaa155c2ea79",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-host-plugin-inventory#pluginInventory/list",
		service: "pluginInventory",
		namespace: "pluginInventory",
		method: "list",
		invocation: { kind: "direct" },
		parameters: [],
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-host-plugin-inventory/types#PluginInventorySnapshot",
			schema: z.object({
				"entries": z.array(z.object({
					"entryId": z.intersection(z.string(), z.unknown()).readonly(),
					"moduleName": z.string().readonly(),
					"enabled": z.boolean().readonly(),
					"fiberPhase": z.union([
						z.literal(null),
						z.literal("pending"),
						z.literal("active"),
						z.literal("failed"),
						z.literal("loading"),
						z.literal("unloading")
					]).readonly(),
					"author": z.union([z.literal(null), z.string()]).readonly(),
					"description": z.union([z.literal(null), z.string()]).readonly(),
					"version": z.union([z.literal(null), z.string()]).readonly()
				})).readonly(),
				"agentPresets": z.array(z.object({
					"id": z.string().readonly(),
					"trust": z.union([z.literal("system"), z.literal("user")]).readonly(),
					"name": z.string().readonly().optional(),
					"isDefault": z.boolean().readonly(),
					"broken": z.string().readonly().optional(),
					"rows": z.array(z.object({
						"entryId": z.union([z.literal(null), z.string()]).readonly(),
						"moduleName": z.string().readonly(),
						"purpose": z.string().readonly().optional(),
						"enabled": z.union([
							z.literal(false),
							z.literal(true),
							z.literal("conditional")
						]).readonly(),
						"condition": z.string().readonly().optional(),
						"fiberPhase": z.union([
							z.literal(null),
							z.literal("pending"),
							z.literal("active"),
							z.literal("failed"),
							z.literal("loading"),
							z.literal("unloading")
						]).readonly(),
						"author": z.union([z.literal(null), z.string()]).readonly(),
						"description": z.union([z.literal(null), z.string()]).readonly(),
						"version": z.union([z.literal(null), z.string()]).readonly()
					})).readonly()
				})).readonly().optional()
			})
		},
		sourceLocation: {
			"file": "packages/host/plugin-inventory/src/index.ts",
			"line": 68,
			"column": 9
		}
	}]
};
//#endregion
//#region ../../feedback/message-feedback/lib/typert.remote-client.js
const _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"messageId": z.intersection(z.string(), z.unknown()).readonly(),
	"ifVersion": z.intersection(z.string(), z.unknown()).readonly()
});
const _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema = z.union([z.object({
	"ok": z.literal(true).readonly(),
	"value": z.object({ "absent": z.literal(true).readonly() }).readonly()
}), z.object({
	"ok": z.literal(false).readonly(),
	"error": z.union([z.object({
		"code": z.literal("session-not-found").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}), z.object({
		"code": z.literal("version-conflict").readonly(),
		"current": z.union([z.literal(null), z.object({
			"messageId": z.intersection(z.string(), z.unknown()).readonly(),
			"rating": z.union([z.literal("positive"), z.literal("negative")]).readonly(),
			"note": z.string().readonly().optional(),
			"category": z.union([
				z.literal("other"),
				z.literal("task-result"),
				z.literal("instruction-following"),
				z.literal("product-interaction"),
				z.literal("service-stability"),
				z.literal("resource-cost"),
				z.literal("security-privacy-permission")
			]).readonly().optional(),
			"version": z.intersection(z.string(), z.unknown()).readonly(),
			"createdAt": z.number().readonly(),
			"updatedAt": z.number().readonly()
		})]).readonly()
	})]).readonly()
})]);
const _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema = z.object({ "sessionId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema = z.union([z.object({
	"ok": z.literal(true).readonly(),
	"value": z.object({ "items": z.array(z.object({
		"messageId": z.intersection(z.string(), z.unknown()).readonly(),
		"rating": z.union([z.literal("positive"), z.literal("negative")]).readonly(),
		"note": z.string().readonly().optional(),
		"category": z.union([
			z.literal("other"),
			z.literal("task-result"),
			z.literal("instruction-following"),
			z.literal("product-interaction"),
			z.literal("service-stability"),
			z.literal("resource-cost"),
			z.literal("security-privacy-permission")
		]).readonly().optional(),
		"version": z.intersection(z.string(), z.unknown()).readonly(),
		"createdAt": z.number().readonly(),
		"updatedAt": z.number().readonly()
	})).readonly() }).readonly()
}), z.object({
	"ok": z.literal(false).readonly(),
	"error": z.object({
		"code": z.literal("session-not-found").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}).readonly()
})]);
const _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"messageId": z.intersection(z.string(), z.unknown()).readonly(),
	"rating": z.union([z.literal("positive"), z.literal("negative")]).readonly(),
	"note": z.string().readonly().optional(),
	"category": z.union([
		z.literal("other"),
		z.literal("task-result"),
		z.literal("instruction-following"),
		z.literal("product-interaction"),
		z.literal("service-stability"),
		z.literal("resource-cost"),
		z.literal("security-privacy-permission")
	]).readonly().optional(),
	"ifVersion": z.union([z.literal(null), z.intersection(z.string(), z.unknown())]).readonly()
});
const _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema = z.union([z.object({
	"ok": z.literal(true).readonly(),
	"value": z.object({
		"messageId": z.intersection(z.string(), z.unknown()).readonly(),
		"rating": z.union([z.literal("positive"), z.literal("negative")]).readonly(),
		"note": z.string().readonly().optional(),
		"category": z.union([
			z.literal("other"),
			z.literal("task-result"),
			z.literal("instruction-following"),
			z.literal("product-interaction"),
			z.literal("service-stability"),
			z.literal("resource-cost"),
			z.literal("security-privacy-permission")
		]).readonly().optional(),
		"version": z.intersection(z.string(), z.unknown()).readonly(),
		"createdAt": z.number().readonly(),
		"updatedAt": z.number().readonly()
	}).readonly()
}), z.object({
	"ok": z.literal(false).readonly(),
	"error": z.union([
		z.object({
			"code": z.literal("session-not-found").readonly(),
			"sessionId": z.intersection(z.string(), z.unknown()).readonly()
		}),
		z.object({
			"code": z.literal("target-not-found").readonly(),
			"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
			"messageId": z.intersection(z.string(), z.unknown()).readonly()
		}),
		z.object({
			"code": z.literal("version-conflict").readonly(),
			"current": z.union([z.literal(null), z.object({
				"messageId": z.intersection(z.string(), z.unknown()).readonly(),
				"rating": z.union([z.literal("positive"), z.literal("negative")]).readonly(),
				"note": z.string().readonly().optional(),
				"category": z.union([
					z.literal("other"),
					z.literal("task-result"),
					z.literal("instruction-following"),
					z.literal("product-interaction"),
					z.literal("service-stability"),
					z.literal("resource-cost"),
					z.literal("security-privacy-permission")
				]).readonly().optional(),
				"version": z.intersection(z.string(), z.unknown()).readonly(),
				"createdAt": z.number().readonly(),
				"updatedAt": z.number().readonly()
			})]).readonly()
		}),
		z.object({ "code": z.literal("note-blank").readonly() }),
		z.object({
			"code": z.literal("note-too-large").readonly(),
			"maxBytes": z.number().readonly(),
			"actualBytes": z.number().readonly()
		})
	]).readonly()
})]);
const TYPERT_REMOTE$7 = {
	package: "@deepseek-ai/dsh-message-feedback",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:06af453f187bfa011befaf96f17c05498662d82bdba62e858cd88da7c30c018d",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-message-feedback#messageFeedback/delete",
			service: "messageFeedback",
			namespace: "messageFeedback",
			method: "delete",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackDeleteRequest",
					schema: _deepseek_ai_dsh_message_feedback_messageFeedback_delete_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackDeleteResult",
				schema: _deepseek_ai_dsh_message_feedback_messageFeedback_delete_result$schema
			},
			sourceLocation: {
				"file": "packages/feedback/message-feedback/src/index.ts",
				"line": 207,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:32dca57bc4c012732f941624ddd1350a43e360877c8ffef534e317c7a50ae746",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-message-feedback#messageFeedback/list",
			service: "messageFeedback",
			namespace: "messageFeedback",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackListRequest",
					schema: _deepseek_ai_dsh_message_feedback_messageFeedback_list_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackListResult",
				schema: _deepseek_ai_dsh_message_feedback_messageFeedback_list_result$schema
			},
			sourceLocation: {
				"file": "packages/feedback/message-feedback/src/index.ts",
				"line": 155,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:197ca7d6901a0a4533881524b209a776f90a181bfe207fe3d338ad5223913361",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-message-feedback#messageFeedback/put",
			service: "messageFeedback",
			namespace: "messageFeedback",
			method: "put",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackPutRequest",
					schema: _deepseek_ai_dsh_message_feedback_messageFeedback_put_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-message-feedback/types#MessageFeedbackPutResult",
				schema: _deepseek_ai_dsh_message_feedback_messageFeedback_put_result$schema
			},
			sourceLocation: {
				"file": "packages/feedback/message-feedback/src/index.ts",
				"line": 167,
				"column": 3
			}
		}
	]
};
//#endregion
//#region ../../feedback/command-feedback/lib/typert.remote-client.js
const _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"text": z.string().readonly().optional(),
	"category": z.union([
		z.literal("other"),
		z.literal("task-result"),
		z.literal("instruction-following"),
		z.literal("product-interaction"),
		z.literal("service-stability"),
		z.literal("resource-cost"),
		z.literal("security-privacy-permission")
	]).readonly().optional()
});
const _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema = z.union([z.object({
	"ok": z.literal(true).readonly(),
	"value": z.object({ "recorded": z.literal(true).readonly() }).readonly()
}), z.object({
	"ok": z.literal(false).readonly(),
	"error": z.object({
		"code": z.literal("session-not-found").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}).readonly()
})]);
const TYPERT_REMOTE$6 = {
	package: "@deepseek-ai/dsh-command-feedback",
	descriptors: [{
		wireFingerprint: "typert-wire-v1:de3fcdbbf8d5e222f93e53172d34b1dc62ab25e4bdf5723344c5213dd59c5b50",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-command-feedback#sessionFeedback/record",
		service: "sessionFeedback",
		namespace: "sessionFeedback",
		method: "record",
		invocation: { kind: "direct" },
		parameters: [{
			name: "request",
			wire: "request",
			source: "json",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-command-feedback/types#SessionFeedbackRecordRequest",
				schema: _deepseek_ai_dsh_command_feedback_sessionFeedback_record_parameter_0$schema
			}
		}],
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-command-feedback/types#SessionFeedbackRecordResult",
			schema: _deepseek_ai_dsh_command_feedback_sessionFeedback_record_result$schema
		},
		sourceLocation: {
			"file": "packages/feedback/command-feedback/src/index.ts",
			"line": 101,
			"column": 3
		}
	}]
};
//#endregion
//#region ../../client/file-upload/lib/typert.remote-client.js
const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema = z.object({
	"data": z.string().readonly(),
	"name": z.string().readonly().optional()
});
const _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema = z.object({
	"receiptId": z.intersection(z.string(), z.unknown()).readonly(),
	"file": z.object({
		"attachmentId": z.intersection(z.string(), z.unknown()),
		"name": z.string(),
		"bytes": z.number()
	}).readonly()
});
const TYPERT_REMOTE$5 = {
	package: "@deepseek-ai/dsh-client-file-upload",
	descriptors: [{
		wireFingerprint: "typert-wire-v1:d52cb197dad9cf502b4af508d9d716be962d8227b73d0cff370c7969b12c11a2",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-client-file-upload#fileUploads/upload",
		service: "fileUploads",
		namespace: "fileUploads",
		method: "upload",
		invocation: { kind: "direct" },
		scope: {
			context: "agent",
			wire: "agentId"
		},
		parameters: [{
			name: "agent",
			wire: "agentId",
			source: "lookup",
			lookup: "agent",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
				schema: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_0$schema
			}
		}, {
			name: "request",
			wire: "request",
			source: "json",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-client-file-upload/types#EncodedFileUploadRequest",
				schema: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_parameter_1$schema
			}
		}],
		cancellation: { parameter: "signal" },
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-client-file-upload/types#FileUploadValue",
			schema: _deepseek_ai_dsh_client_file_upload_fileUploads_upload_result$schema
		},
		sourceLocation: {
			"file": "packages/client/file-upload/src/index.ts",
			"line": 106,
			"column": 3
		}
	}]
};
//#endregion
//#region ../../context/session-reference/lib/typert.remote-client.js
const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema = z.string();
const _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema = z.array(z.object({
	"mention": z.string(),
	"sessionId": z.intersection(z.string(), z.unknown()),
	"label": z.string(),
	"cwd": z.string().optional(),
	"sameWorkspace": z.boolean(),
	"createdAt": z.number()
}));
const TYPERT_REMOTE$4 = {
	package: "@deepseek-ai/dsh-session-reference",
	descriptors: [{
		wireFingerprint: "typert-wire-v1:b7d70febf5da9be6d41fa5490ef21a64d03551347b7cb1182e71284c22964c27",
		semanticRevision: 1,
		id: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates",
		service: "sessionReferenceResolver",
		namespace: "sessionReferenceResolver",
		method: "candidates",
		implementation: "remoteExportCandidates",
		invocation: { kind: "direct" },
		scope: {
			context: "agent",
			wire: "agentId"
		},
		parameters: [{
			name: "agent",
			wire: "agentId",
			source: "lookup",
			lookup: "agent",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
				schema: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_0$schema
			}
		}, {
			name: "query",
			wire: "query",
			source: "json",
			codec: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates:query",
				schema: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_parameter_1$schema
			}
		}],
		cancellation: { parameter: "signal" },
		result: {
			mode: "strict",
			typeSymbol: "@deepseek-ai/dsh-session-reference#sessionReferenceResolver/candidates:result",
			schema: _deepseek_ai_dsh_session_reference_sessionReferenceResolver_candidates_result$schema
		},
		sourceLocation: {
			"file": "packages/context/session-reference/src/index.ts",
			"line": 274,
			"column": 9
		}
	}]
};
//#endregion
//#region ../../subagent/subagent/lib/typert.remote-client.js
const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema = z.literal("continuable");
const _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema = z.object({ "accepted": z.literal(true).readonly() });
const _deepseek_ai_dsh_subagent_subagents_list_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_subagent_subagents_list_result$schema = z.object({
	"entries": z.array(z.union([
		z.intersection(z.object({
			"kind": z.literal("child").readonly(),
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"activity": z.union([z.literal("running"), z.literal("inactive")]).readonly(),
			"hasChildren": z.boolean().readonly()
		}), z.object({
			"mode": z.literal("one-shot").readonly(),
			"label": z.string().readonly().optional()
		})),
		z.intersection(z.object({
			"kind": z.literal("child").readonly(),
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"activity": z.union([z.literal("running"), z.literal("inactive")]).readonly(),
			"hasChildren": z.boolean().readonly()
		}), z.object({
			"mode": z.literal("continuable").readonly(),
			"label": z.string().readonly()
		})),
		z.object({
			"kind": z.literal("diagnostic").readonly(),
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"reason": z.union([
				z.literal("corrupt"),
				z.literal("unsupported"),
				z.literal("unavailable")
			]).readonly()
		})
	])).readonly(),
	"parentAvailable": z.boolean().readonly()
});
const _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema = z.object({
	"requestId": z.intersection(z.string(), z.unknown()).readonly(),
	"parentSessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"childSessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"mode": z.literal("continuable").readonly(),
	"delivery": z.union([z.literal("queue"), z.literal("steer")]).readonly(),
	"content": z.array(z.union([z.object({
		"type": z.literal("text").readonly(),
		"text": z.string().readonly()
	}), z.object({
		"type": z.literal("image").readonly(),
		"mediaType": z.union([
			z.literal("image/png"),
			z.literal("image/jpeg"),
			z.literal("image/webp"),
			z.literal("image/gif")
		]).readonly(),
		"data": z.string().readonly(),
		"name": z.string().readonly().optional()
	})])).readonly(),
	"clientTimeZone": z.string().readonly().optional()
});
const _deepseek_ai_dsh_subagent_subagents_prompt_result$schema = z.object({ "messageId": z.intersection(z.string(), z.unknown()).readonly() });
const TYPERT_REMOTE$3 = {
	package: "@deepseek-ai/dsh-subagent",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:ab778e0efd3c4e5833c214778f000251be7549ca2ad597f14f4af4ee4106f354",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-subagent#subagents/interruptByParent",
			service: "subagents",
			namespace: "subagents",
			method: "interruptByParent",
			invocation: { kind: "direct" },
			parameters: [
				{
					name: "childSessionId",
					wire: "childSessionId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_0$schema
					}
				},
				{
					name: "parentSessionId",
					wire: "parentSessionId",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_1$schema
					}
				},
				{
					name: "mode",
					wire: "mode",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-subagent#subagents/interruptByParent:mode",
						schema: _deepseek_ai_dsh_subagent_subagents_interruptByParent_parameter_2$schema
					}
				}
			],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentInterruptReceipt",
				schema: _deepseek_ai_dsh_subagent_subagents_interruptByParent_result$schema
			},
			sourceLocation: {
				"file": "packages/subagent/subagent/src/index.ts",
				"line": 490,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:b01993db71d82370bb15b0151e10750ec663916ae9d1c0ede8bebad0ebeb0b5c",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-subagent#subagents/list",
			service: "subagents",
			namespace: "subagents",
			method: "list",
			implementation: "remoteExportList",
			invocation: { kind: "direct" },
			parameters: [{
				name: "parentSessionId",
				wire: "parentSessionId",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_subagent_subagents_list_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentCatalog",
				schema: _deepseek_ai_dsh_subagent_subagents_list_result$schema
			},
			sourceLocation: {
				"file": "packages/subagent/subagent/src/index.ts",
				"line": 396,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:dc0496ee7956957f633fbbdb1bb814cdddd0fa30cc37d03979ca9d41206a1949",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-subagent#subagents/prompt",
			service: "subagents",
			namespace: "subagents",
			method: "prompt",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentPromptRequest",
					schema: _deepseek_ai_dsh_subagent_subagents_prompt_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-subagent/client#SubagentPromptReceipt",
				schema: _deepseek_ai_dsh_subagent_subagents_prompt_result$schema
			},
			sourceLocation: {
				"file": "packages/subagent/subagent/src/index.ts",
				"line": 423,
				"column": 9
			}
		}
	]
};
//#endregion
//#region ../session-controller/lib/typert.remote-client.js
const ContentBlockRemoteCodec$schema = z.union([
	z.object({
		"type": z.literal("file"),
		"attachment": z.object({
			"attachmentId": z.intersection(z.string(), z.unknown()),
			"name": z.string(),
			"bytes": z.number()
		})
	}),
	z.object({
		"type": z.literal("text"),
		"text": z.string()
	}),
	z.object({
		"type": z.literal("image"),
		"attachment": z.object({
			"attachmentId": z.intersection(z.string(), z.unknown()),
			"mediaType": z.union([
				z.literal("image/png"),
				z.literal("image/jpeg"),
				z.literal("image/webp"),
				z.literal("image/gif")
			]),
			"bytes": z.number(),
			"width": z.number(),
			"height": z.number(),
			"name": z.string().optional(),
			"originalDimensions": z.object({
				"width": z.number(),
				"height": z.number()
			}).optional()
		})
	}),
	z.object({
		"type": z.literal("reasoning"),
		"text": z.string()
	}),
	z.object({
		"type": z.literal("tool-call"),
		"id": z.intersection(z.string(), z.unknown()),
		"name": z.string(),
		"arguments": z.string()
	}),
	z.object({
		"type": z.literal("tool-result"),
		"toolCallId": z.intersection(z.string(), z.unknown()),
		"content": z.array(z.lazy(() => ContentBlockRemoteCodec$schema)),
		"isError": z.boolean().optional()
	})
]);
const JsonValueRemoteCodec$schema = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema))
]);
const JsonValueRemoteCodec$schema2 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema2)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2))
]);
const JsonValueRemoteCodec$schema3 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema3)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3))
]);
const JsonValueRemoteCodec$schema4 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
]);
const JsonValueRemoteCodec$schema5 = z.union([
	z.literal(null),
	z.string(),
	z.number(),
	z.literal(false),
	z.literal(true),
	z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
	z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
]);
const _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema = z.array(z.object({
	"path": z.string(),
	"kind": z.union([z.literal("file"), z.literal("directory")])
}));
const _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"attachmentId": z.intersection(z.string(), z.unknown()).readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema = z.object({
	"attachment": z.object({
		"attachmentId": z.intersection(z.string(), z.unknown()),
		"mediaType": z.union([
			z.literal("image/png"),
			z.literal("image/jpeg"),
			z.literal("image/webp"),
			z.literal("image/gif")
		]),
		"bytes": z.number(),
		"width": z.number(),
		"height": z.number(),
		"name": z.string().optional(),
		"originalDimensions": z.object({
			"width": z.number(),
			"height": z.number()
		}).optional()
	}).readonly(),
	"data": z.string().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema = z.object({ "sessionId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema = z.object({ "accepted": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema = z.boolean();
const _deepseek_ai_dsh_api_session_controller_session_control_result$schema = z.union([
	z.object({
		"type": z.literal("baseline").readonly(),
		"value": z.object({
			"queues": z.record(z.intersection(z.string(), z.unknown()), z.array(z.object({
				"id": z.intersection(z.string(), z.unknown()).readonly(),
				"placement": z.union([
					z.literal("queued"),
					z.literal("steering"),
					z.literal("context")
				]).readonly(),
				"rpcId": z.intersection(z.string(), z.unknown()).readonly().optional(),
				"message": z.object({
					"id": z.intersection(z.string(), z.unknown()).readonly(),
					"content": z.array(z.union([
						z.literal(null),
						z.string(),
						z.number(),
						z.literal(false),
						z.literal(true),
						z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
						z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
					])).readonly()
				}).readonly()
			}))).readonly().readonly(),
			"jobs": z.record(z.intersection(z.string(), z.unknown()), z.array(z.object({
				"id": z.intersection(z.string(), z.unknown()).readonly(),
				"kind": z.string().readonly(),
				"label": z.string().readonly(),
				"status": z.union([
					z.literal("completed"),
					z.literal("running"),
					z.literal("stopping"),
					z.literal("killed"),
					z.literal("failed")
				]).readonly(),
				"detail": z.string().readonly().optional(),
				"startedAt": z.number().readonly(),
				"finishedAt": z.number().readonly().optional()
			}))).readonly().readonly(),
			"projections": z.record(z.intersection(z.string(), z.unknown()), z.object({
				"asOfSeq": z.number().readonly(),
				"values": z.intersection(z.object({
					"inbox": z.object({
						"next-turn": z.array(z.union([
							z.literal(null),
							z.string(),
							z.number(),
							z.literal(false),
							z.literal(true),
							z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
							z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
						])).readonly(),
						"next-step": z.array(z.union([
							z.literal(null),
							z.string(),
							z.number(),
							z.literal(false),
							z.literal(true),
							z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
							z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
						])).readonly()
					}).optional(),
					"agentPreset": z.union([z.literal(null), z.string()]).optional(),
					"title": z.union([z.literal(null), z.string()]).optional(),
					"todos": z.union([z.literal(null), z.array(z.object({
						"content": z.string(),
						"status": z.union([
							z.literal("pending"),
							z.literal("in_progress"),
							z.literal("completed")
						])
					}))]).optional(),
					"sessionListMetadata": z.object({
						"blank": z.boolean().readonly(),
						"lastPromptAt": z.union([z.literal(null), z.number()]).readonly()
					}).optional(),
					"imageLimits": z.object({
						"maxImageBytes": z.number(),
						"maxImagesPerMessage": z.number(),
						"maxMessageImageBytes": z.number(),
						"maxImagePixels": z.number(),
						"maxImageDimension": z.number(),
						"mediaTypes": z.array(z.union([
							z.literal("image/png"),
							z.literal("image/jpeg"),
							z.literal("image/webp"),
							z.literal("image/gif")
						]))
					}).optional(),
					"modelSelection": z.object({
						"lastUsed": z.union([z.literal(null), z.object({
							"provider": z.string().readonly(),
							"model": z.string().readonly(),
							"reasoningEffort": z.string().readonly().optional()
						})]).readonly(),
						"next": z.union([z.literal(null), z.object({
							"provider": z.string().readonly(),
							"model": z.string().readonly(),
							"reasoningEffort": z.string().readonly().optional()
						})]).readonly()
					}).optional(),
					"subagentCatalog": z.array(z.union([z.intersection(z.object({
						"id": z.intersection(z.string(), z.unknown()).readonly(),
						"createdAt": z.number().readonly()
					}), z.object({
						"mode": z.literal("one-shot").readonly(),
						"label": z.string().readonly().optional()
					})), z.intersection(z.object({
						"id": z.intersection(z.string(), z.unknown()).readonly(),
						"createdAt": z.number().readonly()
					}), z.object({
						"mode": z.literal("continuable").readonly(),
						"label": z.string().readonly()
					}))])).optional(),
					"subagentTiming": z.object({
						"settledMs": z.number(),
						"active": z.object({
							"since": z.number(),
							"through": z.number()
						}).optional()
					}).optional(),
					"subagent": z.union([
						z.literal(null),
						z.object({
							"mode": z.literal("one-shot"),
							"label": z.string().optional(),
							"seq": z.intersection(z.number(), z.unknown())
						}),
						z.object({
							"mode": z.literal("continuable"),
							"label": z.string(),
							"seq": z.intersection(z.number(), z.unknown())
						})
					]).optional(),
					"goal": z.union([z.literal(null), z.object({
						"goal": z.object({
							"objective": z.string().readonly(),
							"phase": z.union([
								z.literal("active"),
								z.literal("paused"),
								z.literal("blocked"),
								z.literal("complete")
							]).readonly(),
							"blockedReason": z.object({
								"code": z.string().readonly(),
								"message": z.string().readonly()
							}).readonly().optional(),
							"maxGoalRounds": z.number().readonly(),
							"id": z.intersection(z.string(), z.unknown()).readonly(),
							"revision": z.number().readonly()
						}).readonly(),
						"roundsStarted": z.number().readonly(),
						"createdAt": z.number().readonly(),
						"updatedAt": z.number().readonly()
					})]).optional()
				}), z.record(z.string(), z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
				])).readonly()).readonly()
			})).readonly().readonly()
		}).readonly()
	}),
	z.object({
		"type": z.literal("queue").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"items": z.array(z.object({
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"placement": z.union([
				z.literal("queued"),
				z.literal("steering"),
				z.literal("context")
			]).readonly(),
			"rpcId": z.intersection(z.string(), z.unknown()).readonly().optional(),
			"message": z.object({
				"id": z.intersection(z.string(), z.unknown()).readonly(),
				"content": z.array(z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
				])).readonly()
			}).readonly()
		})).readonly()
	}),
	z.object({
		"type": z.literal("jobs").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"jobs": z.array(z.object({
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"kind": z.string().readonly(),
			"label": z.string().readonly(),
			"status": z.union([
				z.literal("completed"),
				z.literal("running"),
				z.literal("stopping"),
				z.literal("killed"),
				z.literal("failed")
			]).readonly(),
			"detail": z.string().readonly().optional(),
			"startedAt": z.number().readonly(),
			"finishedAt": z.number().readonly().optional()
		})).readonly()
	}),
	z.intersection(z.object({ "type": z.literal("projection").readonly() }), z.object({
		"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"key": z.string().readonly(),
		"value": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema5)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema5))
		]).readonly(),
		"seq": z.number().readonly()
	}))
]);
const _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema = z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly().optional(),
	"cwd": z.string().readonly().optional(),
	"sessionId": z.intersection(z.string(), z.unknown()).readonly().optional(),
	"agentPreset": z.string().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_create_result$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"agentPreset": z.string().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema = z.object({
	"address": z.union([z.object({
		"kind": z.literal("session").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}), z.object({
		"kind": z.literal("subagent").readonly(),
		"parentSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"childSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"mode": z.union([z.literal("one-shot"), z.literal("continuable")]).readonly()
	})]).readonly(),
	"maxMessages": z.number().readonly().optional(),
	"assistantStream": z.literal(true).readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_follow_result$schema = z.union([
	z.object({
		"type": z.literal("event").readonly(),
		"event": z.object({
			"type": z.string().readonly(),
			"seq": z.number().readonly(),
			"time": z.number().readonly(),
			"data": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
			]).readonly(),
			"ignorable": z.literal(true).readonly().optional(),
			"sourceEventSeqs": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
			]).readonly().optional(),
			"surfaceOp": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
			]).readonly().optional()
		}).readonly(),
		"detail": z.object({
			"kind": z.literal("tool-result").readonly(),
			"bytes": z.number().readonly()
		}).readonly().optional()
	}),
	z.object({
		"type": z.literal("snapshot").readonly(),
		"header": z.object({
			"version": z.number().readonly(),
			"id": z.intersection(z.string(), z.unknown()).readonly(),
			"createdAt": z.number().readonly(),
			"cwd": z.string().readonly().optional(),
			"parentSession": z.intersection(z.string(), z.unknown()).readonly().optional(),
			"isSeeded": z.boolean().readonly(),
			"origin": z.literal("subagent").readonly().optional(),
			"delegationDepth": z.number().readonly().optional(),
			"agentPreset": z.string().readonly().optional()
		}).readonly(),
		"cursor": z.number().readonly(),
		"records": z.array(z.object({
			"type": z.literal("event").readonly(),
			"event": z.object({
				"type": z.string().readonly(),
				"seq": z.number().readonly(),
				"time": z.number().readonly(),
				"data": z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
				]).readonly(),
				"ignorable": z.literal(true).readonly().optional(),
				"sourceEventSeqs": z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
				]).readonly().optional(),
				"surfaceOp": z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
				]).readonly().optional()
			}).readonly(),
			"detail": z.object({
				"kind": z.literal("tool-result").readonly(),
				"bytes": z.number().readonly()
			}).readonly().optional()
		})).readonly(),
		"hasMore": z.boolean().readonly(),
		"oversized": z.object({ "bytes": z.number().readonly() }).readonly().optional(),
		"projections": z.object({
			"asOfSeq": z.number().readonly(),
			"values": z.intersection(z.object({
				"inbox": z.object({
					"next-turn": z.array(z.union([
						z.literal(null),
						z.string(),
						z.number(),
						z.literal(false),
						z.literal(true),
						z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
						z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
					])).readonly(),
					"next-step": z.array(z.union([
						z.literal(null),
						z.string(),
						z.number(),
						z.literal(false),
						z.literal(true),
						z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
						z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
					])).readonly()
				}).optional(),
				"agentPreset": z.union([z.literal(null), z.string()]).optional(),
				"title": z.union([z.literal(null), z.string()]).optional(),
				"todos": z.union([z.literal(null), z.array(z.object({
					"content": z.string(),
					"status": z.union([
						z.literal("pending"),
						z.literal("in_progress"),
						z.literal("completed")
					])
				}))]).optional(),
				"sessionListMetadata": z.object({
					"blank": z.boolean().readonly(),
					"lastPromptAt": z.union([z.literal(null), z.number()]).readonly()
				}).optional(),
				"imageLimits": z.object({
					"maxImageBytes": z.number(),
					"maxImagesPerMessage": z.number(),
					"maxMessageImageBytes": z.number(),
					"maxImagePixels": z.number(),
					"maxImageDimension": z.number(),
					"mediaTypes": z.array(z.union([
						z.literal("image/png"),
						z.literal("image/jpeg"),
						z.literal("image/webp"),
						z.literal("image/gif")
					]))
				}).optional(),
				"modelSelection": z.object({
					"lastUsed": z.union([z.literal(null), z.object({
						"provider": z.string().readonly(),
						"model": z.string().readonly(),
						"reasoningEffort": z.string().readonly().optional()
					})]).readonly(),
					"next": z.union([z.literal(null), z.object({
						"provider": z.string().readonly(),
						"model": z.string().readonly(),
						"reasoningEffort": z.string().readonly().optional()
					})]).readonly()
				}).optional(),
				"subagentCatalog": z.array(z.union([z.intersection(z.object({
					"id": z.intersection(z.string(), z.unknown()).readonly(),
					"createdAt": z.number().readonly()
				}), z.object({
					"mode": z.literal("one-shot").readonly(),
					"label": z.string().readonly().optional()
				})), z.intersection(z.object({
					"id": z.intersection(z.string(), z.unknown()).readonly(),
					"createdAt": z.number().readonly()
				}), z.object({
					"mode": z.literal("continuable").readonly(),
					"label": z.string().readonly()
				}))])).optional(),
				"subagentTiming": z.object({
					"settledMs": z.number(),
					"active": z.object({
						"since": z.number(),
						"through": z.number()
					}).optional()
				}).optional(),
				"subagent": z.union([
					z.literal(null),
					z.object({
						"mode": z.literal("one-shot"),
						"label": z.string().optional(),
						"seq": z.intersection(z.number(), z.unknown())
					}),
					z.object({
						"mode": z.literal("continuable"),
						"label": z.string(),
						"seq": z.intersection(z.number(), z.unknown())
					})
				]).optional(),
				"goal": z.union([z.literal(null), z.object({
					"goal": z.object({
						"objective": z.string().readonly(),
						"phase": z.union([
							z.literal("active"),
							z.literal("paused"),
							z.literal("blocked"),
							z.literal("complete")
						]).readonly(),
						"blockedReason": z.object({
							"code": z.string().readonly(),
							"message": z.string().readonly()
						}).readonly().optional(),
						"maxGoalRounds": z.number().readonly(),
						"id": z.intersection(z.string(), z.unknown()).readonly(),
						"revision": z.number().readonly()
					}).readonly(),
					"roundsStarted": z.number().readonly(),
					"createdAt": z.number().readonly(),
					"updatedAt": z.number().readonly()
				})]).optional()
			}), z.record(z.string(), z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
			])).readonly()).readonly()
		}).readonly(),
		"assistantStream": z.object({
			"revision": z.number().readonly(),
			"activeAttempt": z.object({
				"attemptId": z.intersection(z.string(), z.unknown()).readonly(),
				"startedAfterSeq": z.union([z.intersection(z.number(), z.unknown()), z.literal(-1)]).readonly(),
				"turn": z.number().readonly(),
				"step": z.number().readonly(),
				"nextIndex": z.number().readonly(),
				"stream": z.array(z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
				])).readonly()
			}).readonly().optional()
		}).readonly().optional()
	}),
	z.object({
		"type": z.literal("assistant-stream").readonly(),
		"frame": z.union([
			z.object({
				"type": z.literal("start").readonly(),
				"attemptId": z.intersection(z.string(), z.unknown()).readonly(),
				"revision": z.number().readonly(),
				"startedAfterSeq": z.union([z.intersection(z.number(), z.unknown()), z.literal(-1)]).readonly(),
				"turn": z.number().readonly(),
				"step": z.number().readonly()
			}),
			z.object({
				"type": z.literal("chunk").readonly(),
				"attemptId": z.intersection(z.string(), z.unknown()).readonly(),
				"revision": z.number().readonly(),
				"index": z.number().readonly(),
				"time": z.number().readonly(),
				"chunk": z.union([
					z.literal(null),
					z.string(),
					z.number(),
					z.literal(false),
					z.literal(true),
					z.array(z.lazy(() => JsonValueRemoteCodec$schema4)),
					z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema4))
				]).readonly()
			}),
			z.object({
				"type": z.literal("end").readonly(),
				"attemptId": z.intersection(z.string(), z.unknown()).readonly(),
				"revision": z.number().readonly(),
				"index": z.number().readonly(),
				"outcome": z.union([z.object({
					"kind": z.literal("committed").readonly(),
					"eventType": z.union([z.literal("assistant/message"), z.literal("assistant/attempt")]).readonly(),
					"seq": z.number().readonly()
				}), z.object({ "kind": z.literal("abandoned").readonly() })]).readonly()
			})
		]).readonly()
	})
]);
const _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"atSeq": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_fork_result$schema = z.object({ "sessionId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_historyDetail_parameter_0$schema = z.object({
	"address": z.union([z.object({
		"kind": z.literal("session").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}), z.object({
		"kind": z.literal("subagent").readonly(),
		"parentSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"childSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"mode": z.union([z.literal("one-shot"), z.literal("continuable")]).readonly()
	})]).readonly(),
	"seq": z.number().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_historyDetail_result$schema = z.object({
	"type": z.literal("event").readonly(),
	"event": z.object({
		"type": z.string().readonly(),
		"seq": z.number().readonly(),
		"time": z.number().readonly(),
		"data": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2))
		]).readonly(),
		"ignorable": z.literal(true).readonly().optional(),
		"sourceEventSeqs": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2))
		]).readonly().optional(),
		"surfaceOp": z.union([
			z.literal(null),
			z.string(),
			z.number(),
			z.literal(false),
			z.literal(true),
			z.array(z.lazy(() => JsonValueRemoteCodec$schema2)),
			z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema2))
		]).readonly().optional()
	}).readonly(),
	"detail": z.object({
		"kind": z.literal("tool-result").readonly(),
		"bytes": z.number().readonly()
	}).readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema = z.object({
	"cursor": z.intersection(z.string(), z.unknown()).readonly().optional(),
	"includeSessionId": z.intersection(z.string(), z.unknown()).readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_list_result$schema = z.object({
	"items": z.array(z.object({
		"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"updatedAt": z.number().readonly(),
		"running": z.boolean().readonly(),
		"blank": z.boolean().readonly(),
		"parentSessionId": z.intersection(z.string(), z.unknown()).readonly().optional(),
		"origin": z.literal("subagent").readonly().optional(),
		"cwd": z.string().readonly().optional(),
		"projections": z.object({
			"asOfSeq": z.number().readonly(),
			"values": z.intersection(z.object({
				"inbox": z.object({
					"next-turn": z.array(z.union([
						z.literal(null),
						z.string(),
						z.number(),
						z.literal(false),
						z.literal(true),
						z.array(z.lazy(() => JsonValueRemoteCodec$schema)),
						z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema))
					])).readonly(),
					"next-step": z.array(z.union([
						z.literal(null),
						z.string(),
						z.number(),
						z.literal(false),
						z.literal(true),
						z.array(z.lazy(() => JsonValueRemoteCodec$schema)),
						z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema))
					])).readonly()
				}).optional(),
				"agentPreset": z.union([z.literal(null), z.string()]).optional(),
				"title": z.union([z.literal(null), z.string()]).optional(),
				"todos": z.union([z.literal(null), z.array(z.object({
					"content": z.string(),
					"status": z.union([
						z.literal("pending"),
						z.literal("in_progress"),
						z.literal("completed")
					])
				}))]).optional(),
				"sessionListMetadata": z.object({
					"blank": z.boolean().readonly(),
					"lastPromptAt": z.union([z.literal(null), z.number()]).readonly()
				}).optional(),
				"imageLimits": z.object({
					"maxImageBytes": z.number(),
					"maxImagesPerMessage": z.number(),
					"maxMessageImageBytes": z.number(),
					"maxImagePixels": z.number(),
					"maxImageDimension": z.number(),
					"mediaTypes": z.array(z.union([
						z.literal("image/png"),
						z.literal("image/jpeg"),
						z.literal("image/webp"),
						z.literal("image/gif")
					]))
				}).optional(),
				"modelSelection": z.object({
					"lastUsed": z.union([z.literal(null), z.object({
						"provider": z.string().readonly(),
						"model": z.string().readonly(),
						"reasoningEffort": z.string().readonly().optional()
					})]).readonly(),
					"next": z.union([z.literal(null), z.object({
						"provider": z.string().readonly(),
						"model": z.string().readonly(),
						"reasoningEffort": z.string().readonly().optional()
					})]).readonly()
				}).optional(),
				"subagentCatalog": z.array(z.union([z.intersection(z.object({
					"id": z.intersection(z.string(), z.unknown()).readonly(),
					"createdAt": z.number().readonly()
				}), z.object({
					"mode": z.literal("one-shot").readonly(),
					"label": z.string().readonly().optional()
				})), z.intersection(z.object({
					"id": z.intersection(z.string(), z.unknown()).readonly(),
					"createdAt": z.number().readonly()
				}), z.object({
					"mode": z.literal("continuable").readonly(),
					"label": z.string().readonly()
				}))])).optional(),
				"subagentTiming": z.object({
					"settledMs": z.number(),
					"active": z.object({
						"since": z.number(),
						"through": z.number()
					}).optional()
				}).optional(),
				"subagent": z.union([
					z.literal(null),
					z.object({
						"mode": z.literal("one-shot"),
						"label": z.string().optional(),
						"seq": z.intersection(z.number(), z.unknown())
					}),
					z.object({
						"mode": z.literal("continuable"),
						"label": z.string(),
						"seq": z.intersection(z.number(), z.unknown())
					})
				]).optional(),
				"goal": z.union([z.literal(null), z.object({
					"goal": z.object({
						"objective": z.string().readonly(),
						"phase": z.union([
							z.literal("active"),
							z.literal("paused"),
							z.literal("blocked"),
							z.literal("complete")
						]).readonly(),
						"blockedReason": z.object({
							"code": z.string().readonly(),
							"message": z.string().readonly()
						}).readonly().optional(),
						"maxGoalRounds": z.number().readonly(),
						"id": z.intersection(z.string(), z.unknown()).readonly(),
						"revision": z.number().readonly()
					}).readonly(),
					"roundsStarted": z.number().readonly(),
					"createdAt": z.number().readonly(),
					"updatedAt": z.number().readonly()
				})]).optional()
			}), z.record(z.string(), z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema))
			])).readonly()).readonly()
		}).readonly().optional()
	})).readonly(),
	"hasMore": z.boolean().readonly(),
	"nextCursor": z.intersection(z.string(), z.unknown()).readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema = z.object({
	"default": z.object({
		"provider": z.string().readonly(),
		"model": z.string().readonly(),
		"reasoningEffort": z.string().readonly().optional()
	}).readonly(),
	"routableProviders": z.array(z.string()).readonly(),
	"groups": z.array(z.object({
		"id": z.string().readonly(),
		"name": z.string().readonly(),
		"models": z.array(z.object({
			"id": z.string().readonly(),
			"name": z.string().readonly(),
			"description": z.string().readonly().optional(),
			"reasoning": z.object({
				"efforts": z.array(z.object({
					"id": z.string().readonly(),
					"name": z.string().readonly(),
					"description": z.string().readonly().optional()
				})).readonly(),
				"defaultEffort": z.string().readonly().optional()
			}).readonly().optional()
		})).readonly()
	})).readonly(),
	"failures": z.array(z.object({
		"id": z.string().readonly(),
		"name": z.string().readonly(),
		"message": z.string().readonly()
	})).readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema = z.object({
	"action": z.literal("reveal").readonly().optional(),
	"path": z.string().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema = z.object({ "opened": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema = z.object({
	"address": z.union([z.object({
		"kind": z.literal("session").readonly(),
		"sessionId": z.intersection(z.string(), z.unknown()).readonly()
	}), z.object({
		"kind": z.literal("subagent").readonly(),
		"parentSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"childSessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"mode": z.union([z.literal("one-shot"), z.literal("continuable")]).readonly()
	})]).readonly(),
	"throughSeq": z.number().readonly(),
	"beforeSeq": z.number().readonly().optional(),
	"maxMessages": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_page_result$schema = z.object({
	"records": z.array(z.object({
		"type": z.literal("event").readonly(),
		"event": z.object({
			"type": z.string().readonly(),
			"seq": z.number().readonly(),
			"time": z.number().readonly(),
			"data": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema3)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3))
			]).readonly(),
			"ignorable": z.literal(true).readonly().optional(),
			"sourceEventSeqs": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema3)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3))
			]).readonly().optional(),
			"surfaceOp": z.union([
				z.literal(null),
				z.string(),
				z.number(),
				z.literal(false),
				z.literal(true),
				z.array(z.lazy(() => JsonValueRemoteCodec$schema3)),
				z.record(z.string(), z.lazy(() => JsonValueRemoteCodec$schema3))
			]).readonly().optional()
		}).readonly(),
		"detail": z.object({
			"kind": z.literal("tool-result").readonly(),
			"bytes": z.number().readonly()
		}).readonly().optional()
	})).readonly(),
	"hasMore": z.boolean().readonly(),
	"oversized": z.object({ "bytes": z.number().readonly() }).readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema = z.object({
	"requestId": z.intersection(z.string(), z.unknown()).readonly(),
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"mode": z.union([z.literal("queue"), z.literal("steer")]).readonly(),
	"content": z.array(z.union([
		z.object({
			"type": z.literal("text").readonly(),
			"text": z.string().readonly()
		}),
		z.object({
			"type": z.literal("image").readonly(),
			"mediaType": z.union([
				z.literal("image/png"),
				z.literal("image/jpeg"),
				z.literal("image/webp"),
				z.literal("image/gif")
			]).readonly(),
			"data": z.string().readonly(),
			"name": z.string().readonly().optional()
		}),
		z.object({
			"type": z.literal("file").readonly(),
			"receiptId": z.intersection(z.string(), z.unknown()).readonly()
		})
	])).readonly(),
	"clientTimeZone": z.string().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema = z.object({ "accepted": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"title": z.string().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_rename_result$schema = z.object({
	"title": z.string().readonly(),
	"seq": z.number().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema = z.object({ "query": z.string().readonly() });
const _deepseek_ai_dsh_api_session_controller_session_search_result$schema = z.object({
	"items": z.array(z.object({
		"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
		"snippet": z.string().readonly()
	})).readonly(),
	"hasMore": z.boolean().readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"provider": z.string().readonly(),
	"model": z.string().readonly(),
	"reasoningEffort": z.string().readonly().optional()
});
const _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema = z.object({ "selected": z.object({
	"provider": z.string().readonly(),
	"model": z.string().readonly(),
	"reasoningEffort": z.string().readonly().optional()
}).readonly() });
const _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema = z.object({
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"itemId": z.intersection(z.string(), z.unknown()).readonly(),
	"action": z.union([
		z.object({
			"kind": z.literal("edit").readonly(),
			"content": z.array(z.union([
				z.object({
					"type": z.literal("file"),
					"attachment": z.object({
						"attachmentId": z.intersection(z.string(), z.unknown()),
						"name": z.string(),
						"bytes": z.number()
					})
				}),
				z.object({
					"type": z.literal("text"),
					"text": z.string()
				}),
				z.object({
					"type": z.literal("image"),
					"attachment": z.object({
						"attachmentId": z.intersection(z.string(), z.unknown()),
						"mediaType": z.union([
							z.literal("image/png"),
							z.literal("image/jpeg"),
							z.literal("image/webp"),
							z.literal("image/gif")
						]),
						"bytes": z.number(),
						"width": z.number(),
						"height": z.number(),
						"name": z.string().optional(),
						"originalDimensions": z.object({
							"width": z.number(),
							"height": z.number()
						}).optional()
					})
				}),
				z.object({
					"type": z.literal("reasoning"),
					"text": z.string()
				}),
				z.object({
					"type": z.literal("tool-call"),
					"id": z.intersection(z.string(), z.unknown()),
					"name": z.string(),
					"arguments": z.string()
				}),
				z.object({
					"type": z.literal("tool-result"),
					"toolCallId": z.intersection(z.string(), z.unknown()),
					"content": z.array(z.lazy(() => ContentBlockRemoteCodec$schema)),
					"isError": z.boolean().optional()
				})
			])).readonly()
		}),
		z.object({ "kind": z.literal("remove").readonly() }),
		z.object({ "kind": z.literal("steer").readonly() })
	]).readonly()
});
const _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema = z.object({ "accepted": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema = z.object({ "sessionId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_api_session_controller_skills_list_result$schema = z.object({ "skills": z.array(z.object({
	"name": z.string().readonly(),
	"description": z.string().readonly(),
	"whenToUse": z.string().readonly().optional(),
	"modelInvocable": z.boolean().readonly()
})).readonly() });
const TYPERT_REMOTE$2 = {
	package: "@deepseek-ai/dsh-api-session-controller",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:6442148cc4276aa49d21fa9f28bfd4e794f0a038ca3ad862749c2409d9509969",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#fileReferences/list",
			service: "sessionFileReferences",
			namespace: "fileReferences",
			method: "list",
			invocation: { kind: "direct" },
			scope: {
				context: "agent",
				wire: "agentId"
			},
			parameters: [{
				name: "agent",
				wire: "agentId",
				source: "lookup",
				lookup: "agent",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
					schema: _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_0$schema
				}
			}, {
				name: "query",
				wire: "query",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller#fileReferences/list:query",
					schema: _deepseek_ai_dsh_api_session_controller_fileReferences_list_parameter_1$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller#fileReferences/list:result",
				schema: _deepseek_ai_dsh_api_session_controller_fileReferences_list_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/file-references.ts",
				"line": 33,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:ccc046117b60bcb5820198b4ae59e99922e048c646a8e306501e0ab60995ebe8",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/attachment",
			service: "sessionController",
			namespace: "session",
			method: "attachment",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionAttachmentRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_attachment_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionAttachmentValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_attachment_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 398,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:910009c78249b4eea14dbde9d84e2b09ff032983419a2cefcb8501ff317d7db7",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/cancel",
			service: "sessionController",
			namespace: "session",
			method: "cancel",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCancelRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_cancel_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCancelValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_cancel_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 418,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:52110afd8439fe076c3311c6bde6d16ca4acfc6d70b6912466d16c38ee4a7cb2",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/canOpenWorkspacePath",
			service: "sessionController",
			namespace: "session",
			method: "canOpenWorkspacePath",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller#session/canOpenWorkspacePath:result",
				schema: _deepseek_ai_dsh_api_session_controller_session_canOpenWorkspacePath_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 313,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:0945d432df499fe2d3b163f2057b242581e24f3995a235932cbd4aad94854306",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/control",
			service: "sessionController",
			namespace: "session",
			method: "control",
			mode: "stream",
			invocation: { kind: "direct" },
			parameters: [],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionControlFrame",
				schema: _deepseek_ai_dsh_api_session_controller_session_control_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 462,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:f78ed48876c35b0cded89469e9f5838ee686b7a5f8102aba111580b269a97e0b",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/create",
			service: "sessionController",
			namespace: "session",
			method: "create",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCreateRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_create_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionCreateValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_create_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 285,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:d7b9d0bd8dcc6b774e3771be123a111c2a47e7a5e724b401d7824c043a86ad1b",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/follow",
			service: "sessionController",
			namespace: "session",
			method: "follow",
			mode: "stream",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionFollowRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_follow_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionFollowFrame",
				schema: _deepseek_ai_dsh_api_session_controller_session_follow_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 452,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:ac5f0b7e5fef3aec3037dc597b4e8977de9fd68f51cf59a3c154f635671aedcf",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/fork",
			service: "sessionController",
			namespace: "session",
			method: "fork",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionForkRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_fork_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionForkValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_fork_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 376,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:7ed6cbe37f9c100425f2a1e9459d435b47fc2dec8f48ae7ec6fce019e84256f4",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/historyDetail",
			service: "sessionController",
			namespace: "session",
			method: "historyDetail",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionHistoryDetailRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_historyDetail_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionEventEntry",
				schema: _deepseek_ai_dsh_api_session_controller_session_historyDetail_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 429,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:390cf359e487fc5e1d845b44ea7ea2c2ee8fe315b0c2a7098611ebacd6554170",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/list",
			service: "sessionController",
			namespace: "session",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionListRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_list_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionListValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_list_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 236,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:67f6d9b6a5c6253db8b29796e5428caeefe2aca57be0e09963bbf3a520dd90ec",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/modelCatalog",
			service: "sessionController",
			namespace: "session",
			method: "modelCatalog",
			invocation: { kind: "direct" },
			parameters: [],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#ModelCatalog",
				schema: _deepseek_ai_dsh_api_session_controller_session_modelCatalog_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 304,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:efb4bd9f866251c77b2aaabfb90869566af824e3041842b1ad29eae171384045",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/openWorkspacePath",
			service: "sessionController",
			namespace: "session",
			method: "openWorkspacePath",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionOpenWorkspacePathRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionOpenWorkspacePathValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_openWorkspacePath_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 334,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:c595417ccfeec5a203b81ed59b22adc0997bd050294372096a2e0672233793dd",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/page",
			service: "sessionController",
			namespace: "session",
			method: "page",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPageRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_page_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPage",
				schema: _deepseek_ai_dsh_api_session_controller_session_page_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 440,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:ad63af7191985232264ecc93d8194cb00ccfe60da400b3be566d7c395b6bac46",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/prompt",
			service: "sessionController",
			namespace: "session",
			method: "prompt",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPromptRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_prompt_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionPromptValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_prompt_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 387,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:b524e85b0c96ca6b9905be91311e4d3089ab1e256319316fae2fb0e4fb97f90d",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/rename",
			service: "sessionController",
			namespace: "session",
			method: "rename",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionRenameRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_rename_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionRenameValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_rename_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 366,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:4f4f29df2d1293c24bcf722115a20b2ba77108d14d6d6bf47093e38785c378b0",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/search",
			service: "sessionController",
			namespace: "session",
			method: "search",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSearchRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_search_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSearchValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_search_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 275,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:70d5b3819de44bdb2e588d7f2da2e2cae106b06b4a8c39e35323438229d973d7",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/selectModel",
			service: "sessionController",
			namespace: "session",
			method: "selectModel",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSelectModelRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_selectModel_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionSelectModelValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_selectModel_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 295,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:57d537e2bec931c12638883b54142d9ace0f75d7c6d5df782834b442fe6740ad",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#session/updateQueue",
			service: "sessionController",
			namespace: "session",
			method: "updateQueue",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionUpdateQueueRequest",
					schema: _deepseek_ai_dsh_api_session_controller_session_updateQueue_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SessionUpdateQueueValue",
				schema: _deepseek_ai_dsh_api_session_controller_session_updateQueue_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/index.ts",
				"line": 408,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:846504cd924875e79376f6705426fa20731ce414cb8c205bd738205ca448b68a",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-session-controller#skills/list",
			service: "sessionSkillCatalog",
			namespace: "skills",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SkillListRequest",
					schema: _deepseek_ai_dsh_api_session_controller_skills_list_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-session-controller/types#SkillListValue",
				schema: _deepseek_ai_dsh_api_session_controller_skills_list_result$schema
			},
			sourceLocation: {
				"file": "packages/api/session-controller/src/skill-catalog.ts",
				"line": 36,
				"column": 9
			}
		}
	]
};
//#endregion
//#region ../workspace-controller/lib/typert.remote-client.js
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema = z.string();
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema = z.string();
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema = z.union([z.undefined(), z.string()]);
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema = z.object({
	"path": z.string(),
	"home": z.string(),
	"crumbs": z.array(z.object({
		"name": z.string(),
		"path": z.string(),
		"hidden": z.boolean()
	})),
	"entries": z.array(z.object({
		"name": z.string(),
		"path": z.string(),
		"hidden": z.boolean()
	})),
	"truncated": z.boolean()
});
const _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema = z.union([z.literal(null), z.string()]);
const _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema = z.object({ "sessionId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema = z.object({ "archivedSessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema = z.object({ "path": z.string().readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema = z.object({
	"workspace": z.object({
		"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
		"path": z.string().readonly(),
		"title": z.string().readonly(),
		"sessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly(),
		"createdAt": z.string().readonly(),
		"updatedAt": z.string().readonly()
	}).readonly(),
	"created": z.boolean().readonly()
});
const _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema = z.object({ "workspaceId": z.intersection(z.string(), z.unknown()).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema = z.object({ "deleted": z.literal(true).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema = z.union([
	z.object({
		"type": z.literal("baseline").readonly(),
		"value": z.object({
			"items": z.array(z.object({
				"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
				"path": z.string().readonly(),
				"title": z.string().readonly(),
				"sessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly(),
				"createdAt": z.string().readonly(),
				"updatedAt": z.string().readonly()
			})).readonly(),
			"archivedSessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly()
		}).readonly()
	}),
	z.object({
		"type": z.literal("upsert").readonly(),
		"workspace": z.object({
			"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
			"path": z.string().readonly(),
			"title": z.string().readonly(),
			"sessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly(),
			"createdAt": z.string().readonly(),
			"updatedAt": z.string().readonly()
		}).readonly()
	}),
	z.object({
		"type": z.literal("remove").readonly(),
		"workspaceId": z.intersection(z.string(), z.unknown()).readonly()
	}),
	z.object({
		"type": z.literal("order").readonly(),
		"workspaceIds": z.array(z.intersection(z.string(), z.unknown())).readonly()
	}),
	z.object({
		"type": z.literal("archived").readonly(),
		"archivedSessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly()
	})
]);
const _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema = z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
	"beforeWorkspaceId": z.intersection(z.string(), z.unknown()).readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema = z.object({ "workspaceIds": z.array(z.intersection(z.string(), z.unknown())).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema = z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
	"sessionId": z.intersection(z.string(), z.unknown()).readonly(),
	"beforeSessionId": z.intersection(z.string(), z.unknown()).readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema = z.object({ "workspace": z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
	"path": z.string().readonly(),
	"title": z.string().readonly(),
	"sessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly(),
	"createdAt": z.string().readonly(),
	"updatedAt": z.string().readonly()
}).readonly() });
const _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema = z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
	"title": z.string().readonly()
});
const _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema = z.object({ "workspace": z.object({
	"workspaceId": z.intersection(z.string(), z.unknown()).readonly(),
	"path": z.string().readonly(),
	"title": z.string().readonly(),
	"sessionIds": z.array(z.intersection(z.string(), z.unknown())).readonly(),
	"createdAt": z.string().readonly(),
	"updatedAt": z.string().readonly()
}).readonly() });
const TYPERT_REMOTE$1 = {
	package: "@deepseek-ai/dsh-api-workspace-controller",
	descriptors: [
		{
			wireFingerprint: "typert-wire-v1:f9e8ee2fa493042d6776840f5a0a0e0f52571d9aedc6f87f4e34e7766a71a2e0",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory",
			service: "directoryPickerController",
			namespace: "directoryPicker",
			method: "createDirectory",
			invocation: { kind: "direct" },
			parameters: [{
				name: "path",
				wire: "path",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:path",
					schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_0$schema
				}
			}, {
				name: "name",
				wire: "name",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:name",
					schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_parameter_1$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/createDirectory:result",
				schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_createDirectory_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/directory-picker.ts",
				"line": 88,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:db7493caa2868b2dc82a126144b41077f0d81ff6e90fa4ddef34b23136661bb3",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/list",
			service: "directoryPickerController",
			namespace: "directoryPicker",
			method: "list",
			invocation: { kind: "direct" },
			parameters: [{
				name: "path",
				wire: "path",
				source: "json",
				acceptsUndefined: true,
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/list:path",
					schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_parameter_0$schema
				}
			}],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-host-directory-picker/types#DirectoryListing",
				schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_list_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/directory-picker.ts",
				"line": 72,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:dc371c219ffd2088a66a1263886f655219e4d10bddb6ef6ad766b007d11b860e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/pick",
			service: "directoryPickerController",
			namespace: "directoryPicker",
			method: "pick",
			invocation: { kind: "direct" },
			parameters: [],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller#directoryPicker/pick:result",
				schema: _deepseek_ai_dsh_api_workspace_controller_directoryPicker_pick_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/directory-picker.ts",
				"line": 55,
				"column": 9
			}
		},
		{
			wireFingerprint: "typert-wire-v1:d5dc528a92b3963a4aa133f80c7fbd98b94150bca571b8adcc8cfa2fdb1753f6",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/archiveSession",
			service: "workspaceController",
			namespace: "workspace",
			method: "archiveSession",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceArchiveSessionRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceArchiveValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_archiveSession_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 108,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:9d7a815ba41a11d141424f59a51574de7fea9997474710c4089de6b6a8dffd61",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/create",
			service: "workspaceController",
			namespace: "workspace",
			method: "create",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceCreateRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_create_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceCreateValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_create_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 58,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:454fb83b6a52e69f912c58ca5d0b73c39630fdd1bcdbd8c0432e98c82209005e",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/delete",
			service: "workspaceController",
			namespace: "workspace",
			method: "delete",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceDeleteRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_delete_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceDeleteValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_delete_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 78,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:fed5290e8c0afaf47eed0ceb57feeee6effd5bb5a89f8929d655bcf5152ce83a",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/follow",
			service: "workspaceController",
			namespace: "workspace",
			method: "follow",
			mode: "stream",
			invocation: { kind: "direct" },
			parameters: [],
			cancellation: { parameter: "signal" },
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceFollowFrame",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_follow_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 118,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:72e1eba635e8b487794ee16ff4162a86db3d120520f4ce123643aa576e9f089d",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/insertBefore",
			service: "workspaceController",
			namespace: "workspace",
			method: "insertBefore",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceInsertBeforeRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceOrderValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_insertBefore_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 88,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:e7a511e16e0c2fe6f97dea2e4410a856f300d188ea8b210e5b1d4e7bf5d18feb",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/insertSessionBefore",
			service: "workspaceController",
			namespace: "workspace",
			method: "insertSessionBefore",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceInsertSessionBeforeRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_insertSessionBefore_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 98,
				"column": 3
			}
		},
		{
			wireFingerprint: "typert-wire-v1:4405e5bb12799f7fdf667b77ce15bcad12af2d0f90b069c3e25d336d28ed9bb7",
			semanticRevision: 1,
			id: "@deepseek-ai/dsh-api-workspace-controller#workspace/rename",
			service: "workspaceController",
			namespace: "workspace",
			method: "rename",
			invocation: { kind: "direct" },
			parameters: [{
				name: "request",
				wire: "request",
				source: "json",
				codec: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceRenameRequest",
					schema: _deepseek_ai_dsh_api_workspace_controller_workspace_rename_parameter_0$schema
				}
			}],
			result: {
				mode: "strict",
				typeSymbol: "@deepseek-ai/dsh-api-workspace-controller/types#WorkspaceValue",
				schema: _deepseek_ai_dsh_api_workspace_controller_workspace_rename_result$schema
			},
			sourceLocation: {
				"file": "packages/api/workspace-controller/src/index.ts",
				"line": 68,
				"column": 3
			}
		}
	]
};
//#endregion
//#region ../workspace-files/lib/typert.remote-client.js
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema = z.union([z.object({ "kind": z.literal("ready").readonly() }), z.object({
	"kind": z.literal("change").readonly(),
	"change": z.union([z.object({
		"absolutePath": z.string().readonly(),
		"version": z.string().readonly()
	}), z.object({
		"absolutePath": z.string().readonly(),
		"absent": z.literal(true).readonly()
	})]).readonly()
})]);
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema = z.object({
	"path": z.string().readonly(),
	"entries": z.array(z.object({
		"name": z.string().readonly(),
		"type": z.union([
			z.literal("file"),
			z.literal("directory"),
			z.literal("other")
		]).readonly(),
		"size": z.number().readonly().optional()
	})).readonly(),
	"truncated": z.boolean().readonly()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema = z.object({
	"offset": z.number().readonly().optional(),
	"limit": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema = z.object({
	"offset": z.number().readonly(),
	"text": z.string().readonly(),
	"lines": z.number().readonly(),
	"eof": z.boolean().readonly(),
	"absolutePath": z.string().readonly(),
	"version": z.string().readonly(),
	"bytes": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_result$schema = z.object({
	"offset": z.number().readonly(),
	"data": z.string().readonly(),
	"eof": z.boolean().readonly(),
	"absolutePath": z.string().readonly(),
	"version": z.string().readonly(),
	"bytes": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema = z.object({
	"offset": z.number().readonly().optional(),
	"length": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema = z.object({
	"offset": z.number().readonly(),
	"data": z.string().readonly(),
	"eof": z.boolean().readonly(),
	"absolutePath": z.string().readonly(),
	"version": z.string().readonly(),
	"bytes": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_2$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_result$schema = z.object({
	"offset": z.number().readonly(),
	"data": z.string().readonly(),
	"eof": z.boolean().readonly(),
	"absolutePath": z.string().readonly(),
	"version": z.string().readonly(),
	"bytes": z.number().readonly().optional()
});
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema = z.intersection(z.string(), z.unknown());
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema = z.string();
const _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema = z.object({
	"absolutePath": z.string().readonly(),
	"version": z.string().readonly(),
	"bytes": z.number().readonly().optional()
});
//#endregion
//#region lib/types/client/index.js
/** Platform-neutral assembly of generated Host Remote contributions. */
const contributions = [
	TYPERT_REMOTE$15,
	TYPERT_REMOTE$14,
	TYPERT_REMOTE$13,
	TYPERT_REMOTE$12,
	TYPERT_REMOTE$11,
	TYPERT_REMOTE$10,
	TYPERT_REMOTE$9,
	TYPERT_REMOTE$8,
	TYPERT_REMOTE$7,
	TYPERT_REMOTE$6,
	TYPERT_REMOTE$5,
	TYPERT_REMOTE$4,
	TYPERT_REMOTE$3,
	TYPERT_REMOTE$2,
	TYPERT_REMOTE$1,
	{
		package: "@deepseek-ai/dsh-api-workspace-files",
		descriptors: [
			{
				wireFingerprint: "typert-wire-v1:4f4d9ce263ac74327f3d6e275227c89c4f3fdc0a275416a4decfd9c18a3a62f5",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/changes",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "changes",
				mode: "stream",
				invocation: { kind: "direct" },
				parameters: [{
					name: "workspaceFileScope",
					wire: "workspaceFileScopeId",
					source: "lookup",
					lookup: "workspaceFileScope",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_parameter_0$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileWatchFrame",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_changes_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 365,
					"column": 3
				}
			},
			{
				wireFingerprint: "typert-wire-v1:c42f2ad752c6cecb8bbbd867ad949feeb04843f53111780bfd35d329fc514509",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/list",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "list",
				invocation: { kind: "direct" },
				parameters: [{
					name: "workspaceFileScope",
					wire: "workspaceFileScopeId",
					source: "lookup",
					lookup: "workspaceFileScope",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_0$schema
					}
				}, {
					name: "path",
					wire: "path",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/list:path",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceDirectoryListing",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_list_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 337,
					"column": 9
				}
			},
			{
				wireFingerprint: "typert-wire-v1:a02c8d20967feb3422fe4a34a50f12aead6f0acbc7b12ca0c15fad16ec6c1227",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/read",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "read",
				invocation: { kind: "direct" },
				parameters: [
					{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_0$schema
						}
					},
					{
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/read:path",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_1$schema
						}
					},
					{
						name: "range",
						wire: "range",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileRange",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_parameter_2$schema
						}
					}
				],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileText",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_read_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 232,
					"column": 9
				}
			},
			{
				wireFingerprint: "typert-wire-v1:801ff2c6c08f69979ba452aa2206bc47f1ab1569b2ef4f6b1c74200b6ae647fa",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readAll",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "readAll",
				invocation: { kind: "direct" },
				parameters: [{
					name: "workspaceFileScope",
					wire: "workspaceFileScopeId",
					source: "lookup",
					lookup: "workspaceFileScope",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_parameter_0$schema
					}
				}, {
					name: "path",
					wire: "path",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readAll:path",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileBytes",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readAll_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 278,
					"column": 9
				}
			},
			{
				wireFingerprint: "typert-wire-v1:75b52a5e0a239b08e80c69eb64d00bc5a30287b9178e746a8f293be88b1e1f8a",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readBytes",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "readBytes",
				invocation: { kind: "direct" },
				parameters: [
					{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_0$schema
						}
					},
					{
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readBytes:path",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_1$schema
						}
					},
					{
						name: "range",
						wire: "range",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceByteRange",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_parameter_2$schema
						}
					}
				],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileBytes",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readBytes_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 257,
					"column": 9
				}
			},
			{
				wireFingerprint: "typert-wire-v1:9ef8512643632636fa09585b7fda3567d84c6da5e61ca479603ee577d52a31ad",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readRelated",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "readRelated",
				invocation: { kind: "direct" },
				parameters: [
					{
						name: "workspaceFileScope",
						wire: "workspaceFileScopeId",
						source: "lookup",
						lookup: "workspaceFileScope",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_0$schema
						}
					},
					{
						name: "path",
						wire: "path",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readRelated:path",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_1$schema
						}
					},
					{
						name: "relativePath",
						wire: "relativePath",
						source: "json",
						codec: {
							mode: "strict",
							typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/readRelated:relativePath",
							schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_parameter_2$schema
						}
					}
				],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileBytes",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_readRelated_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 300,
					"column": 9
				}
			},
			{
				wireFingerprint: "typert-wire-v1:a7376924c0ee7ee6b6534b9650d352b7234477e8d25c20bc9954745b18794809",
				semanticRevision: 1,
				id: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/stat",
				service: "workspaceFiles",
				namespace: "workspaceFiles",
				method: "stat",
				invocation: { kind: "direct" },
				parameters: [{
					name: "workspaceFileScope",
					wire: "workspaceFileScopeId",
					source: "lookup",
					lookup: "workspaceFileScope",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-session/types#SessionId",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_0$schema
					}
				}, {
					name: "path",
					wire: "path",
					source: "json",
					codec: {
						mode: "strict",
						typeSymbol: "@deepseek-ai/dsh-api-workspace-files#workspaceFiles/stat:path",
						schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_parameter_1$schema
					}
				}],
				cancellation: { parameter: "signal" },
				result: {
					mode: "strict",
					typeSymbol: "@deepseek-ai/dsh-api-workspace-files/types#WorkspaceFileStat",
					schema: _deepseek_ai_dsh_api_workspace_files_workspaceFiles_stat_result$schema
				},
				sourceLocation: {
					"file": "packages/api/workspace-files/src/index.ts",
					"line": 324,
					"column": 9
				}
			}
		]
	}
];
/**
* Select admission requirements from the exact generated descriptors this assembly mounts.
* @param endpoints - required endpoints; duplicates collapse and an empty selection admits metadata only.
* @returns requirements sorted by endpoint, ready before any Client plugin mounts.
* @throws when an endpoint is absent from this assembly or lacks generated compatibility evidence.
*/
function selectRemoteCapabilities(endpoints) {
	const descriptors = new Map(contributions.flatMap((contribution) => contribution.descriptors).map((descriptor) => [`${descriptor.namespace}/${descriptor.method}`, descriptor]));
	return [...new Set(endpoints)].sort().map((endpoint) => {
		const descriptor = descriptors.get(endpoint);
		if (descriptor?.wireFingerprint === void 0 || descriptor.semanticRevision === void 0) throw new Error(`Client Remote ${endpoint} lacks generated compatibility evidence`);
		return {
			endpoint,
			mode: descriptor.mode === "stream" ? "stream" : "unary",
			wireFingerprint: descriptor.wireFingerprint,
			semanticRevision: descriptor.semanticRevision
		};
	});
}
/** Required service: the typed Client Remote contribution mount. */
const inject = ["remote"];
/**
* Mount the Host capabilities explicitly selected for this Client assembly.
* @param ctx - Client Cordis root carrying the typed API service.
* @returns disposer after every selected Remote namespace is ready.
*/
async function apply$4(ctx) {
	const disposers = [];
	try {
		for (const contribution of contributions) disposers.push(await ctx.remote.$mount(contribution));
	} catch (error) {
		for (const dispose of disposers.reverse()) await dispose();
		throw error;
	}
	return async () => {
		for (const dispose of disposers.reverse()) await dispose();
	};
}
//#endregion
//#region ../../typert/protocol/lib/index.js
/** The one Remote failure class shared by owners, the Gateway, and consumers. */
/**
* One Remote call failure: a real Error carrying its stable code and typed
* details. Owners throw it at the failure point; the Host Gateway encodes it
* onto the wire unchanged; the Client face rebuilds an instance for the
* `RemoteResult` error branch, so `throw result.error` keeps throw semantics.
* Discrimination is always by `code`, never by instanceof.
*/
var RemoteError = class extends Error {
	code;
	details;
	/** Structural marker: cross-realm/bundle identification never uses instanceof. */
	isDSHRemoteError = true;
	/**
	* @param code - stable failure code declared in {@link RemoteErrorDetailsMap}.
	* @param message - human diagnostic carried across the wire.
	* @param details - structured payload typed by the code.
	* @param options - standard Error options (`cause` survives in-process only).
	*/
	constructor(code, message, details, options) {
		super(message, options);
		this.code = code;
		this.details = details;
		this.name = "RemoteError";
	}
};
/**
* Structurally identify a RemoteError thrown across module or realm copies of
* this class. Mechanism-internal: the Gateway and test assertions use it;
* business code receives typed failures and never needs it.
* @param value - a caught value.
* @returns the failure when the marker matches, otherwise undefined.
*/
function remoteErrorOf(value) {
	if (typeof value === "object" && value !== null && value.isDSHRemoteError === true && typeof value.code === "string") return value;
}
//#endregion
//#region ../../util/brand/lib/index.js
/**
* Apply a compile-time number brand without changing the value.
* @param value - number admitted by the domain that owns the target brand.
* @returns the same number with the requested compile-time brand.
*/
function brandNumber(value) {
	return value;
}
//#endregion
//#region ../../core/session/lib/types/known-event-types.js
/**
* GENERATED by `scripts/gen-persistence-catalog.ts` — do not edit by hand; run
* `pnpm run gen-persistence-catalog` to regenerate (verified fresh by
* `pnpm run verify-persistence-catalog`, part of `doc-sync`).
* @module @deepseek-ai/dsh-session/known-event-types
*/
/**
* Every `SessionEventMap` member declared in this repository — the event
* vocabulary this build understands. The persistence read path refuses to
* interpret a log containing a type outside this set unless the event
* carries the envelope's `ignorable` marker (see `SessionEvent.ignorable`
* in `./types.ts`): such a log was likely written by a newer harness, and
* silently skipping a required event would reconstruct a wrong session.
* Downstream (out-of-repo) plugin events are outside this list by
* construction. The persisted `SessionEvent.ignorable` marker is the
* compatibility mechanism; event-name registration was rejected because
* it does not classify omission safety and would make reads
* composition-dependent. The rationale is in
* `.agents/notes/implemented/architecture/2026-08-30-retain-ignorable-external-session-events.md`.
*/
const KNOWN_SESSION_EVENT_TYPES = new Set([
	"agent-preset/selected",
	"agent/inbox/spliced",
	"approval/asked",
	"approval/decided",
	"approval/policy",
	"assistant/attempt",
	"assistant/message",
	"command/done",
	"command/run",
	"compaction/end",
	"compaction/prune",
	"compaction/start",
	"compaction/summary",
	"deliverables/presented",
	"english-output/translation-request",
	"english-output/translation-result",
	"feedback/message-delete",
	"feedback/message-put",
	"feedback/record",
	"goal/change",
	"hook/invoked",
	"hook/result",
	"llm/retry",
	"llm/retry-started",
	"memory/extraction-request",
	"memory/extraction-result",
	"model/selection",
	"permission/preset",
	"plan/mode",
	"request/context",
	"request/header",
	"sandbox/mode",
	"schedule/change",
	"session-log-deepseek/delivery-accepted",
	"session/end-seed",
	"session/title",
	"session/title-llm-request",
	"step/end",
	"step/start",
	"subagent/catalog",
	"subagent/descriptor",
	"subagent/model-selection-policy",
	"system/message",
	"team/member",
	"team/message/delivered",
	"team/message/queued",
	"team/task",
	"todo/write",
	"tool-policy/classifier-request",
	"tool-policy/decision",
	"tool-policy/intent-context",
	"tool-workflow/agent-end",
	"tool-workflow/agent-start",
	"tool-workflow/run-end",
	"tool-workflow/run-start",
	"tool/call",
	"tool/ptc-dispatch",
	"tool/ptc-dispatch-start",
	"tool/result",
	"turn/end",
	"turn/start",
	"user/message",
	"web/openrouter-search-llm-request"
]);
//#endregion
//#region ../../core/session/lib/types/types.js
/**
* Admit a numeric value as an existing Session event position.
* @param value - non-negative safe integer admitted by the owning log operation.
* @returns the same number with the Session-sequence brand.
*/
function SessionSeq(value) {
	if (!Number.isSafeInteger(value) || value < 0 || Object.is(value, -0)) throw new TypeError(`SessionSeq must be a non-negative safe integer, got ${String(value)}`);
	return brandNumber(value);
}
/**
* Admit a numeric value as a Session log offset.
* @param value - non-negative safe integer used as a gap or prefix length.
* @returns the same number with the Session-log-offset brand.
*/
function SessionLogOffset(value) {
	if (!Number.isSafeInteger(value) || value < 0 || Object.is(value, -0)) throw new TypeError(`SessionLogOffset must be a non-negative safe integer, got ${String(value)}`);
	return brandNumber(value);
}
//#endregion
//#region ../gateway/lib/types/stream-protocol.js
/** Wire messages for Gateway-owned Remote streams and event-result RPCs. */
/** Exact WebSocket route carrying every Typert Remote stream. */
const REMOTE_STREAM_MUX_PATH = "/api/remote.mux";
/** Gateway-internal logical stream carrying application-selected Cordis events. */
const REMOTE_EVENT_STREAM_ENDPOINT = "$events";
/** Gateway-internal unary endpoint returning one Client Remote Event outcome. */
const REMOTE_EVENT_RESULT_ENDPOINT = "$events/result";
/** Empty standard Remote payload used to open the forwarded-event stream. */
const REMOTE_EVENT_STREAM_PAYLOAD = { args: {} };
/** Discriminator for the first item proving the Host event source is ready. */
const REMOTE_EVENT_STREAM_READY = {
	type: "ready",
	protocolVersion: 1
};
/**
* Project an arbitrary rejection to stable, JSON-safe error fields.
* @param reason - value thrown or rejected by a Client listener.
* @returns wire-safe rejection fields.
*/
function projectRemoteEventRejection(reason) {
	const record = typeof reason === "object" && reason !== null ? reason : void 0;
	const name = stringProperty(record, "name") ?? "Error";
	const message = stringProperty(record, "message") ?? String(reason);
	const code = stringProperty(record, "code");
	const details = record === void 0 ? void 0 : Reflect.get(record, "details");
	return {
		name,
		message,
		...code === void 0 ? {} : { code },
		...details === void 0 || !isRemoteJsonValue(details) ? {} : { details }
	};
}
/**
* Test whether a value crosses JSON transport without coercion or omission.
* @param value - candidate boundary value.
* @returns whether the value is losslessly JSON-compatible.
*/
function isRemoteJsonValue(value) {
	return visitJsonValue(value, /* @__PURE__ */ new Set());
}
/**
* Recognize a non-empty Remote Event correlation id at a wire boundary.
* @param value - untrusted wire value.
* @returns whether the value is a valid Remote Event id.
*/
function isRemoteEventId(value) {
	return typeof value === "string" && value.length > 0;
}
/**
* Recognize a non-empty Remote Event Client id at a wire boundary.
* @param value - untrusted wire value.
* @returns whether the value identifies one event-stream generation.
*/
function isRemoteEventClientId(value) {
	return typeof value === "string" && value.length > 0;
}
/**
* Recognize the direct Agent identity used by a scoped Remote Event.
* @param value - untrusted wire value.
* @returns whether the value is a non-empty Agent identity.
*/
function isRemoteEventAgentId(value) {
	return typeof value === "string" && value.length > 0;
}
/**
* Parse and validate one Host-to-browser text message.
* @param text - complete WebSocket text message.
* @returns the validated logical-stream frame.
*/
function parseRemoteStreamServerMessage(text) {
	return parseMessage(text, (value) => {
		if (value.type === "item" && (exactKeys$1(value, ["type", "streamId"]) || exactKeys$1(value, [
			"type",
			"streamId",
			"value"
		])) && validId(value.streamId)) return value;
		if (value.type === "end" && exactKeys$1(value, ["type", "streamId"]) && validId(value.streamId)) return value;
		if (value.type === "error" && exactKeys$1(value, [
			"type",
			"streamId",
			"error"
		]) && validId(value.streamId) && isRecord$2(value.error) && exactKeys$1(value.error, [
			"code",
			"message",
			"details"
		]) && typeof value.error.code === "string" && typeof value.error.message === "string" && isRecord$2(value.error.details)) return value;
		throw new Error("api gateway: invalid Remote stream server message");
	});
}
function parseMessage(text, validate) {
	let decoded;
	try {
		decoded = JSON.parse(text);
	} catch (cause) {
		throw new Error("api gateway: Remote stream message is not JSON", { cause });
	}
	if (!isRecord$2(decoded)) throw new Error("api gateway: Remote stream message must be an object");
	return validate(decoded);
}
function isRecord$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function exactKeys$1(value, expected) {
	return Reflect.ownKeys(value).length === expected.length && expected.every((key) => Object.hasOwn(value, key));
}
function validId(value) {
	return typeof value === "string" && value.length > 0;
}
function stringProperty(value, key) {
	if (value === void 0) return void 0;
	const candidate = Reflect.get(value, key);
	return typeof candidate === "string" ? candidate : void 0;
}
function visitJsonValue(value, ancestors) {
	if (value === null || typeof value === "string" || typeof value === "boolean") return true;
	if (typeof value === "number") return Number.isFinite(value) && !Object.is(value, -0);
	if (typeof value !== "object") return false;
	if (ancestors.has(value)) return false;
	ancestors.add(value);
	try {
		if (Array.isArray(value)) {
			if (Object.getPrototypeOf(value) !== Array.prototype || Reflect.ownKeys(value).length !== value.length + 1) return false;
			for (let index = 0; index < value.length; index++) if (!Object.hasOwn(value, index) || !visitJsonValue(value[index], ancestors)) return false;
			return true;
		}
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return false;
		for (const key of Reflect.ownKeys(value)) {
			if (typeof key !== "string") return false;
			if (Object.getOwnPropertyDescriptor(value, key)?.enumerable !== true || !visitJsonValue(Reflect.get(value, key), ancestors)) return false;
		}
		return true;
	} finally {
		ancestors.delete(value);
	}
}
//#endregion
//#region ../../util/deque/lib/index.js
/**
* Zero-dependency circular deque for queues that retain entries across asynchronous work.
* @module @deepseek-ai/dsh-deque
*/
const MIN_CAPACITY = 16;
/**
* A circular deque with amortized constant-time insertion and removal.
* Removed entries are cleared immediately, and sparse storage shrinks after
* the live entry count reaches one quarter of its capacity.
*/
var Deque = class {
	buffer = new Array(MIN_CAPACITY);
	head = 0;
	count = 0;
	/** Number of entries available to remove. */
	get size() {
		return this.count;
	}
	/**
	* Append one entry after the current tail.
	* @param value - entry to append.
	*/
	pushBack(value) {
		this.ensureCapacity();
		const tail = this.head + this.count;
		this.buffer[tail < this.buffer.length ? tail : tail - this.buffer.length] = value;
		this.count += 1;
	}
	/**
	* Insert one entry before the current head.
	* @param value - entry to prepend.
	*/
	pushFront(value) {
		this.ensureCapacity();
		this.head = this.head === 0 ? this.buffer.length - 1 : this.head - 1;
		this.buffer[this.head] = value;
		this.count += 1;
	}
	/**
	* Remove the current head entry and clear its retained reference.
	* Callers whose element type includes `undefined` use {@link size} to
	* distinguish an empty deque from an `undefined` entry.
	* @returns the removed entry, or `undefined` when the deque is empty.
	*/
	popFront() {
		if (this.count === 0) return void 0;
		const value = this.buffer[this.head];
		this.buffer[this.head] = void 0;
		this.head += 1;
		if (this.head === this.buffer.length) this.head = 0;
		this.count -= 1;
		this.compact();
		return value;
	}
	/** Drop every entry and release the current backing storage. */
	clear() {
		this.buffer = new Array(MIN_CAPACITY);
		this.head = 0;
		this.count = 0;
	}
	ensureCapacity() {
		if (this.count < this.buffer.length) return;
		this.resize(this.buffer.length * 2);
	}
	compact() {
		if (this.count === 0) {
			this.head = 0;
			return;
		}
		if (this.buffer.length > MIN_CAPACITY && this.count <= this.buffer.length / 4) this.resize(Math.max(MIN_CAPACITY, this.buffer.length / 2));
	}
	resize(capacity) {
		const next = new Array(capacity);
		let source = this.head;
		for (let index = 0; index < this.count; index += 1) {
			next[index] = this.buffer[source];
			source += 1;
			if (source === this.buffer.length) source = 0;
		}
		this.buffer = next;
		this.head = 0;
	}
};
//#endregion
//#region ../gateway/lib/types/client/stream-client.js
/** Shared owner for the Gateway multiplexed Remote stream socket. */
const SOCKET_OPEN = 1;
/** Physical Remote stream socket failure that may be retried by a domain transport. */
var RemoteStreamCarrierError = class extends Error {
	/**
	* @param message - physical carrier failure description.
	* @param options - optional causal error.
	*/
	constructor(message, options) {
		super(message, options);
		this.name = "RemoteStreamCarrierError";
	}
};
/** Keep one physical WebSocket and share it among independently cancellable Remote streams. */
var RemoteStreamMuxClient = class {
	transport;
	socket;
	cancelCandidate;
	keepAlive;
	revision = 0;
	streams = /* @__PURE__ */ new Map();
	waiters = /* @__PURE__ */ new Set();
	running = false;
	disposed = false;
	/** @param transport - per-owner socket creation and logical stream identity. */
	constructor(transport) {
		this.transport = transport;
	}
	/** Ensure a physical attempt exists, following the current attempt once if needed. */
	start() {
		if (this.disposed) return;
		this.running = true;
		if (this.socket?.readyState === SOCKET_OPEN) return;
		const pending = this.keepAlive;
		if (pending === void 0) this.maintain();
		else pending.then(() => {
			this.maintain();
		});
	}
	/** Cancel the current socket or retry wait and start a fresh attempt immediately. */
	reconnect() {
		if (!this.running || this.disposed) return;
		const failure = new RemoteStreamCarrierError("api gateway: Remote stream reconnect requested");
		const pending = this.keepAlive;
		this.revision++;
		this.cancelCandidate?.(failure);
		const socket = this.socket;
		if (socket !== void 0) {
			this.socket = void 0;
			this.failAll(failure);
			socket.close(4e3, "reconnect requested");
		}
		if (pending === void 0) this.maintain();
		else pending.then(() => {
			this.maintain();
		});
	}
	/**
	* Open one logical stream on the persistent physical connection.
	* If no physical attempt is active, opening waits for Connection to request
	* one or for the signal to abort.
	* @param endpoint - Typert Remote stream endpoint.
	* @param payload - endpoint request encoded on the wire.
	* @param signal - cancellation for this logical stream.
	* @returns Host items until completion, cancellation, or failure.
	*/
	async *open(endpoint, payload, signal) {
		throwIfAborted(signal);
		const streamId = this.transport.randomId();
		const inbox = new StreamInbox();
		let carrier;
		let opened = false;
		let terminal = false;
		const abort = () => {
			inbox.fail(abortReason(signal));
		};
		signal.addEventListener("abort", abort, { once: true });
		try {
			const socket = await this.waitForSocket(signal);
			throwIfAborted(signal);
			carrier = socket;
			this.streams.set(streamId, inbox);
			this.send(socket, {
				type: "open",
				streamId,
				endpoint,
				payload
			});
			opened = true;
			while (true) {
				const frame = await inbox.next();
				throwIfAborted(signal);
				if (frame.type === "item") {
					yield frame.value;
					continue;
				}
				terminal = true;
				if (frame.type === "error") throw new RemoteError(frame.error.code, frame.error.message, frame.error.details);
				return;
			}
		} finally {
			signal.removeEventListener("abort", abort);
			this.streams.delete(streamId);
			if (opened && !terminal && carrier?.readyState === SOCKET_OPEN) this.send(carrier, {
				type: "cancel",
				streamId
			});
		}
	}
	/**
	* Permanently stop the carrier, close the physical socket, and fail every
	* active logical stream.
	* @returns once the active connection attempt has stopped.
	*/
	async close() {
		if (!this.disposed) {
			this.disposed = true;
			this.running = false;
			const error = /* @__PURE__ */ new Error("api gateway: Remote stream client disposed");
			this.failAll(error);
			for (const waiter of [...this.waiters]) waiter.reject(error);
			this.cancelCandidate?.(error);
			const socket = this.socket;
			this.socket = void 0;
			socket?.close(1e3, "disposed");
		}
		await this.keepAlive;
	}
	connect() {
		const socket = this.transport.createSocket();
		return new Promise((resolve, reject) => {
			let settled = false;
			const rejectCandidate = (error) => {
				settled = true;
				socket.removeEventListener("open", opened);
				socket.removeEventListener("error", failed);
				socket.removeEventListener("message", received);
				socket.removeEventListener("close", closed);
				this.cancelCandidate = void 0;
				socket.close();
				reject(error);
			};
			const opened = () => {
				settled = true;
				this.cancelCandidate = void 0;
				this.socket = socket;
				for (const waiter of [...this.waiters]) waiter.resolve(socket);
				resolve(socket);
			};
			const failed = () => {
				if (!settled) {
					rejectCandidate(new RemoteStreamCarrierError("api gateway: Remote stream WebSocket failed to open"));
					return;
				}
				const error = new RemoteStreamCarrierError("api gateway: Remote stream WebSocket failed");
				this.lost(socket, error);
				socket.close();
			};
			const closed = () => {
				if (!settled) {
					rejectCandidate(new RemoteStreamCarrierError("api gateway: Remote stream WebSocket closed before opening"));
					return;
				}
				this.lost(socket);
			};
			const received = (event) => {
				this.receive(socket, event.data);
			};
			this.cancelCandidate = rejectCandidate;
			socket.addEventListener("open", opened, { once: true });
			socket.addEventListener("error", failed, { once: true });
			socket.addEventListener("message", received);
			socket.addEventListener("close", closed, { once: true });
		});
	}
	waitForSocket(signal) {
		throwIfAborted(signal);
		if (this.socket?.readyState === SOCKET_OPEN) return Promise.resolve(this.socket);
		if (this.disposed) return Promise.reject(/* @__PURE__ */ new Error("api gateway: Remote stream client disposed"));
		if (!this.running) return Promise.reject(/* @__PURE__ */ new Error("api gateway: Remote stream client not started"));
		return new Promise((resolve, reject) => {
			const aborted = () => {
				waiter.reject(abortReason(signal));
			};
			const cleanup = () => {
				this.waiters.delete(waiter);
				signal.removeEventListener("abort", aborted);
			};
			const waiter = {
				revision: this.revision,
				resolve: (socket) => {
					cleanup();
					resolve(socket);
				},
				reject: (error) => {
					cleanup();
					reject(error);
				}
			};
			this.waiters.add(waiter);
			signal.addEventListener("abort", aborted, { once: true });
		});
	}
	receive(socket, data) {
		if (socket !== this.socket) return;
		try {
			if (typeof data !== "string") throw new Error("api gateway: Remote stream WebSocket requires text messages");
			const frame = parseRemoteStreamServerMessage(data);
			this.streams.get(frame.streamId)?.push(frame);
		} catch (error) {
			const failure = new RemoteStreamCarrierError("api gateway: invalid Remote stream frame", { cause: error });
			this.failAll(failure);
			this.lost(socket, failure);
			socket.close(4002, "invalid Remote stream frame");
		}
	}
	lost(socket, error = new RemoteStreamCarrierError("api gateway: Remote stream WebSocket closed")) {
		if (this.socket !== socket) return;
		this.socket = void 0;
		this.failAll(error);
	}
	maintain() {
		if (!this.running || this.disposed) return;
		if (this.socket?.readyState === SOCKET_OPEN || this.keepAlive !== void 0) return;
		const revision = this.revision;
		const task = this.connect().then(() => void 0, (error) => {
			if (!this.running) return;
			for (const waiter of [...this.waiters]) if (waiter.revision <= revision) waiter.reject(error);
		});
		this.keepAlive = task;
		task.then(() => {
			this.keepAlive = void 0;
		});
	}
	failAll(error) {
		for (const stream of this.streams.values()) stream.fail(error);
	}
	send(socket, message) {
		socket.send(JSON.stringify(message));
	}
};
var StreamInbox = class {
	frames = new Deque();
	wake;
	failure;
	push(frame) {
		if (this.failure !== void 0) return;
		this.frames.pushBack(frame);
		this.wake?.();
		this.wake = void 0;
	}
	fail(error) {
		if (this.failure !== void 0) return;
		this.failure = error instanceof Error ? error : new Error(String(error), { cause: error });
		this.frames.clear();
		this.wake?.();
		this.wake = void 0;
	}
	async next() {
		while (this.frames.size === 0) {
			if (this.failure !== void 0) throw this.failure;
			await new Promise((resolve) => {
				this.wake = resolve;
			});
		}
		return this.frames.popFront();
	}
};
function abortReason(signal) {
	if ("reason" in signal) return signal.reason;
	const error = /* @__PURE__ */ new Error("api gateway: Remote stream aborted");
	error.name = "AbortError";
	return error;
}
function throwIfAborted(signal) {
	if (signal.aborted) throw abortReason(signal);
}
//#endregion
//#region ../../client/connection/lib/types/host-identity-protocol.js
/** Host correlation values shared by authenticated Connection carriers. */
const uuid = z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
/** Validate a persisted or transferred Host reference without inventing an activation. */
const connectionHostIdSchema = uuid.transform((id) => id);
/** Durable owner payload; signing secrets have a separate credential record. */
const storedHostIdentitySchema = z.object({
	version: z.literal(1),
	hostId: connectionHostIdSchema
}).strict();
/** Exact identity response accepted at the Client wire boundary. */
const connectionIdentitySchema = storedHostIdentitySchema.extend({ activationId: uuid.transform((id) => id) }).strict();
z.object({}).strict();
/** Connection-owned endpoint shared by Host registration and portable callers. */
const CONNECTION_IDENTITY_ENDPOINT = "connection/identity";
//#endregion
//#region ../gateway/lib/types/compatibility-protocol.js
/** Operation expectations checked against the current Host before business execution. */
/** Versioned generated codec checksum; algorithm versions match by exact equality. */
const wireFingerprintSchema = z.string().regex(/^typert-wire-v[1-9][0-9]*:[0-9a-f]{64}$/);
/** Positive safe integer authored independently of generated schemas. */
const semanticRevisionSchema = z.number().int().positive().max(Number.MAX_SAFE_INTEGER);
z.object({
	wireFingerprint: wireFingerprintSchema,
	semanticRevision: semanticRevisionSchema,
	identity: connectionIdentitySchema.optional()
}).strict();
//#endregion
//#region ../gateway/lib/types/capabilities-protocol.js
/** Advisory dispatch metadata carried by the authenticated Gateway. */
/** Gateway-owned unary endpoint; the request is an empty object. */
const HOST_CAPABILITIES_ENDPOINT = "$capabilities";
z.object({}).strict();
const endpoint = {
	endpoint: z.string().regex(/^[^/]+\/[^/]+$/),
	mode: z.enum(["unary", "stream"]),
	wireFingerprint: wireFingerprintSchema.optional(),
	semanticRevision: semanticRevisionSchema.optional()
};
const capability = z.discriminatedUnion("availability", [
	z.object({
		...endpoint,
		availability: z.literal("available")
	}).strict(),
	z.object({
		...endpoint,
		availability: z.literal("context-required")
	}).strict(),
	z.object({
		...endpoint,
		availability: z.literal("unavailable"),
		reason: z.enum([
			"service",
			"binding",
			"method",
			"lookup",
			"context"
		])
	}).strict()
]);
/** Exact versioned response with unique endpoints in code-point order. */
const hostCapabilitiesSchema = z.object({
	version: z.literal(3),
	identity: connectionIdentitySchema,
	capabilities: z.array(capability).refine((values) => values.every((value, index) => {
		const next = values[index + 1];
		return next === void 0 || value.endpoint < next.endpoint;
	}), "capability endpoints must be unique and sorted")
}).strict();
//#endregion
//#region ../gateway/lib/types/client/host-capabilities.js
/**
* Read advisory Host dispatch facts without retries or implicit generation recovery.
* @param rpc - authenticated carrier for the selected Host.
* @param expectedIdentity - validated event-stream identity; both Host and activation must match.
* @param signal - caller-owned lifetime, cancelled when its generation ends.
* @returns validated facts or a failure; carrier rejection and cancellation propagate.
*/
async function readHostCapabilities(rpc, expectedIdentity, signal) {
	signal?.throwIfAborted();
	const result = await rpc.call("/api", HOST_CAPABILITIES_ENDPOINT, {}, signal);
	signal?.throwIfAborted();
	if (!result.ok) return result;
	const parsed = hostCapabilitiesSchema.safeParse(result.value);
	if (!parsed.success) return {
		ok: false,
		error: {
			code: "gateway/invalid-capabilities",
			message: "Invalid Host capability response",
			details: {}
		}
	};
	if (parsed.data.identity.hostId !== expectedIdentity.hostId || parsed.data.identity.activationId !== expectedIdentity.activationId) return {
		ok: false,
		error: {
			code: "gateway/capability-identity-mismatch",
			message: "Host capability response identifies another activation",
			details: {}
		}
	};
	return {
		ok: true,
		value: parsed.data
	};
}
/**
* Require matching endpoint evidence before accepting a native generation.
* @param rpc - authenticated carrier for this generation.
* @param identity - identity validated on this generation's event-stream opening.
* @param requirements - Client-generated requirements independent of Host metadata.
* @param signal - generation lifetime; cancelled reads cannot return accepted facts.
* @returns the full validated snapshot, including optional endpoint availability.
*/
async function admitHostCapabilities(rpc, identity, requirements, signal) {
	const result = await readHostCapabilities(rpc, identity, signal);
	if (!result.ok) throw new RemoteError(result.error.code, result.error.message, result.error.details);
	const endpoints = new Map(result.value.capabilities.map((capability) => [capability.endpoint, capability]));
	for (const requirement of requirements) {
		const capability = endpoints.get(requirement.endpoint);
		if (capability === void 0 || capability.availability === "unavailable" || capability.mode !== requirement.mode || capability.wireFingerprint !== requirement.wireFingerprint || capability.semanticRevision !== requirement.semanticRevision) throw new RemoteError("gateway/api-incompatible", `Required Remote ${requirement.endpoint} is unavailable or incompatible`, { endpoint: requirement.endpoint });
	}
	return result.value;
}
//#endregion
//#region ../gateway/lib/types/client/cancellation.js
/** Cancellation links whose event listeners have an explicit operation lifetime. */
/**
* Link operation lifetimes without requiring AbortSignal.any or garbage collection.
* @param signals - cancellation sources, in priority order when already aborted.
* @param createController - platform controller preserving abort reasons and signal helpers.
* @returns combined signal; the owner must dispose it when its operation settles.
*/
function combineRemoteCancellation(signals, createController) {
	const controller = createController();
	const listeners = /* @__PURE__ */ new Map();
	const dispose = () => {
		for (const [signal, listener] of listeners) signal.removeEventListener("abort", listener);
		listeners.clear();
	};
	const scope = {
		signal: controller.signal,
		dispose
	};
	for (const signal of signals) if (signal.aborted) {
		controller.abort(signal.reason);
		return scope;
	}
	for (const signal of new Set(signals)) {
		const abort = () => {
			dispose();
			controller.abort(signal.reason);
		};
		listeners.set(signal, abort);
		signal.addEventListener("abort", abort, { once: true });
	}
	return scope;
}
//#endregion
//#region ../gateway/lib/types/client/remote-events.js
/** Client owner for forwarded Remote Event subscriptions and deliveries. */
/** Private end-of-chain marker that cannot collide with a JSON listener result. */
const REMOTE_EVENT_NEXT = Symbol("api-gateway.remote-event.next");
/** Own Cordis registrations, generation pumping, waterfall dispatch, and HTTP replies. */
var ClientRemoteEvents = class {
	ownerCtx;
	connection;
	openStream;
	createController;
	admission;
	eventPrefix;
	unregisterGeneration;
	activeGeneration;
	admitted;
	/**
	* @param ownerCtx - Client Gateway root used for Agent Context resolution.
	* @param connection - Connection carrier used for HTTP result calls.
	* @param openStream - selected in-process or WebSocket stream opener.
	* @param eventId - unique identity for this instance's private event registrations.
	* @param createController - platform controller factory preserving abort reasons and signal helpers.
	* @param admission - paired Host and required capabilities for native consumers.
	*/
	constructor(ownerCtx, connection, openStream, eventId, createController, admission) {
		this.ownerCtx = ownerCtx;
		this.connection = connection;
		this.openStream = openStream;
		this.createController = createController;
		this.admission = admission;
		this.eventPrefix = `internal/api-gateway/remote-event/${eventId}/`;
		this.unregisterGeneration = connection.registerGenerationSource(this.runGeneration);
	}
	/**
	* Read only the capability snapshot belonging to the active Connection generation.
	* @param host - the current Connection generation's Host object.
	* @returns admitted metadata, absent before readiness or after generation loss.
	*/
	capabilities(host) {
		const admitted = this.admitted;
		return admitted !== void 0 && admitted.host === host && !admitted.signal.aborted ? admitted.capabilities : void 0;
	}
	/**
	* Register one typed Remote Event listener in its calling fiber.
	* @param callerCtx - fiber Context owning the registration.
	* @param event - selected forwarded event.
	* @param listener - listener derived from that event's declaration.
	* @returns disposer for this exact registration.
	*/
	subscribe(callerCtx, event, listener) {
		const dispose = privateEvents(callerCtx).on(this.eventKey(event), listener);
		return () => {
			dispose();
		};
	}
	/** Withdraw the generation source and wait for active listener work to quiesce. */
	async dispose() {
		this.unregisterGeneration();
		await Promise.allSettled([this.activeGeneration]);
	}
	/** Track the current generation so plugin disposal waits for listener work to stop. */
	runGeneration = (signal, ready) => {
		const tracked = this.pumpEvents(signal, ready).finally(() => {
			if (this.activeGeneration === tracked) this.activeGeneration = void 0;
		});
		this.activeGeneration = tracked;
		return tracked;
	};
	/** Deliver one notification through Cordis while containing listener failures. */
	deliver(frame) {
		privateEvents(this.ownerCtx).parallel(this.eventKey(frame.event), ...frame.args).catch((error) => {
			this.reportError(frame.event, error);
		});
	}
	/** Run one Connection generation over the forwarded-event logical stream. */
	async pumpEvents(signal, ready) {
		let clientId;
		const failed = this.createController();
		const generation = combineRemoteCancellation([signal, failed.signal], this.createController);
		const generationSignal = generation.signal;
		const active = /* @__PURE__ */ new Map();
		const tasks = /* @__PURE__ */ new Set();
		let streamFailed = false;
		let streamError;
		try {
			const source = this.openStream(REMOTE_EVENT_STREAM_ENDPOINT, REMOTE_EVENT_STREAM_PAYLOAD, generationSignal);
			for await (const value of source) {
				if (clientId === void 0) {
					const opening = parseRemoteEventReady(value);
					if (this.admission !== void 0 && opening.host.identity.hostId !== this.admission.expectedHostId) throw new Error("client api: the event stream does not belong to the paired Host");
					if (this.admission !== void 0) {
						const capabilities = await abortable(admitHostCapabilities(this.connection.rpc, opening.host.identity, this.admission.requiredCapabilities, generationSignal), generationSignal);
						generationSignal.throwIfAborted();
						this.admitted = {
							host: opening.host,
							capabilities,
							signal: generationSignal
						};
					}
					clientId = opening.clientId;
					ready(opening.host);
					continue;
				}
				const frame = parseRemoteEventFrame(value);
				if (frame.type === "cancel") {
					active.get(frame.eventId)?.abort(/* @__PURE__ */ new Error("client api: Remote event was cancelled by the Host"));
					continue;
				}
				if (frame.type === "emit") {
					this.deliver(frame);
					continue;
				}
				const controller = this.createController();
				active.set(frame.eventId, controller);
				const delivery = combineRemoteCancellation([generationSignal, controller.signal], this.createController);
				const deliverySignal = delivery.signal;
				const task = this.answer(frame, clientId, deliverySignal).catch((error) => {
					if (!deliverySignal.aborted) failed.abort(error);
				}).finally(() => {
					delivery.dispose();
					active.delete(frame.eventId);
					tasks.delete(task);
				});
				tasks.add(task);
			}
		} catch (error) {
			streamFailed = true;
			streamError = error;
		} finally {
			if (this.admitted?.signal === generationSignal) this.admitted = void 0;
			for (const controller of active.values()) controller.abort(/* @__PURE__ */ new Error("client api: Remote event generation ended"));
			await Promise.allSettled(tasks);
			generation.dispose();
		}
		if (failed.signal.aborted) throw toError(failed.signal.reason, "client api: Remote event result delivery failed");
		if (signal.aborted) return;
		if (streamFailed) throw streamError;
		throw new Error("client api: forwarded Remote event stream ended unexpectedly");
	}
	async answer(frame, clientId, signal) {
		const adapter = this.ownerCtx.typert.contexts.getClient("agent");
		let target;
		try {
			target = adapter?.resolve(frame.agentId);
		} catch (error) {
			this.reportError(frame.event, error);
		}
		let outcome = { kind: "next" };
		if (target !== void 0) try {
			outcome = await this.dispatchWaterfall(target, frame, signal);
		} catch (error) {
			if (signal.aborted) return;
			outcome = {
				kind: "rejected",
				error: projectRemoteEventRejection(error)
			};
		}
		if (signal.aborted) return;
		const result = {
			clientId,
			eventId: frame.eventId,
			outcome: outcome.kind === "result" && outcome.value === void 0 ? { kind: "result" } : outcome
		};
		const response = await this.connection.rpc.call("/api", REMOTE_EVENT_RESULT_ENDPOINT, { args: result }, signal);
		if (!response.ok) throw new Error(response.error.message);
	}
	async dispatchWaterfall(target, frame, signal) {
		const request = {
			...frame.request,
			agent: target,
			signal
		};
		const value = await abortable(Promise.resolve(privateEvents(target).waterfall(target, this.eventKey(frame.event), request, () => Promise.resolve(REMOTE_EVENT_NEXT))), signal);
		if (value !== REMOTE_EVENT_NEXT && value !== void 0 && !isRemoteJsonValue(value)) throw new TypeError("Remote event listener result is not lossless JSON data");
		return value === REMOTE_EVENT_NEXT ? { kind: "next" } : {
			kind: "result",
			value
		};
	}
	eventKey(event) {
		return `${this.eventPrefix}${event}`;
	}
	reportError(event, error) {
		console.error(`client api: Remote event ${JSON.stringify(event)} listener threw:`, error);
	}
};
/** Validate and return one generation's Client identity and Host facts. */
function parseRemoteEventReady(value) {
	if (!isRemoteEventRecord(value) || !hasExactRemoteEventKeys(value, [
		"type",
		"protocolVersion",
		"clientId",
		"host"
	]) || value.type !== "ready" || value.protocolVersion !== REMOTE_EVENT_STREAM_READY.protocolVersion || !isRemoteEventClientId(value.clientId) || !isRemoteEventRecord(value.host) || !hasExactRemoteEventKeys(value.host, ["home", "identity"]) || typeof value.host.home !== "string") throw new TypeError("client api: forwarded Remote event stream did not begin with ready");
	const identity = connectionIdentitySchema.safeParse(value.host.identity);
	if (!identity.success) throw new TypeError("client api: forwarded Remote event stream has invalid Host identity");
	return {
		clientId: value.clientId,
		host: {
			home: value.host.home,
			identity: identity.data
		}
	};
}
/** Validate one untrusted value from the Gateway-internal forwarded-event stream. */
function parseRemoteEventFrame(value) {
	if (!isRemoteEventRecord(value)) invalidRemoteEventFrame();
	if (value.type === "cancel" && hasExactRemoteEventKeys(value, ["type", "eventId"]) && isRemoteEventId(value.eventId)) return {
		type: "cancel",
		eventId: value.eventId
	};
	if (value.type === "emit" && hasExactRemoteEventKeys(value, [
		"type",
		"event",
		"args"
	]) && validRemoteEventName(value.event) && Array.isArray(value.args) && isRemoteJsonValue(value.args)) return {
		type: "emit",
		event: value.event,
		args: value.args
	};
	if (value.type === "waterfall" && hasExactRemoteEventKeys(value, [
		"type",
		"event",
		"eventId",
		"agentId",
		"request"
	]) && validRemoteEventName(value.event) && isRemoteEventId(value.eventId) && isRemoteEventAgentId(value.agentId) && isRemoteEventRecord(value.request) && !Object.hasOwn(value.request, "agent") && !Object.hasOwn(value.request, "signal") && isRemoteJsonValue(value.request)) return {
		type: "waterfall",
		event: value.event,
		eventId: value.eventId,
		agentId: value.agentId,
		request: value.request
	};
	invalidRemoteEventFrame();
}
function isRemoteEventRecord(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function hasExactRemoteEventKeys(value, keys) {
	return Reflect.ownKeys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
}
function validRemoteEventName(value) {
	return typeof value === "string" && value.length > 0;
}
function invalidRemoteEventFrame() {
	throw new TypeError("client api: invalid forwarded Remote event frame");
}
/** Race listener completion against its delivery lifetime. */
async function abortable(value, signal) {
	signal.throwIfAborted();
	let rejectAbort;
	const aborted = new Promise((_resolve, reject) => {
		rejectAbort = reject;
	});
	const onAbort = () => {
		rejectAbort?.(signal.reason);
	};
	signal.addEventListener("abort", onAbort, { once: true });
	try {
		return await Promise.race([Promise.resolve(value), aborted]);
	} finally {
		signal.removeEventListener("abort", onAbort);
	}
}
function privateEvents(ctx) {
	return ctx;
}
function toError(reason, message) {
	return reason instanceof Error ? reason : new Error(message, { cause: reason });
}
//#endregion
//#region ../gateway/lib/types/client/pinned-generation.js
/**
* Require the paired Host before dispatch and cancel when that generation ends.
* @param connection - per-Host generation source and RPC carrier.
* @param expectedHostId - paired identity; omitted by origin-authenticated Web compositions.
* @param signal - caller and Remote method lifetime.
* @param createController - platform cancellation factory.
* @returns a scoped generation binding, or undefined for an unpinned composition.
*/
function bindPinnedGeneration(connection, expectedHostId, signal, createController) {
	if (expectedHostId === void 0) return void 0;
	const accepted = connection.generation.getSnapshot();
	if (accepted === void 0) throw new RemoteStreamCarrierError("client api: the paired Host has no ready connection generation");
	if (accepted.host.identity?.hostId !== expectedHostId) throw new Error("client api: the paired Host has no ready connection generation");
	const lifetime = createController();
	const cancellation = combineRemoteCancellation([signal, lifetime.signal], createController);
	const changed = new RemoteStreamCarrierError("client api: the Host connection generation ended; operation outcome may be uncertain");
	const stop = connection.generation.subscribe(() => {
		if (connection.generation.getSnapshot() !== accepted) lifetime.abort(changed);
	});
	return {
		signal: cancellation.signal,
		identity: accepted.host.identity,
		assertCurrent() {
			if (connection.generation.getSnapshot() !== accepted) throw changed;
		},
		dispose() {
			stop();
			cancellation.dispose();
		}
	};
}
//#endregion
//#region ../gateway/lib/types/client/remote-stream.js
/** Reconnecting lifecycle for one single-consumer Remote stream. */
/**
* Reopens one logical Remote stream across carrier generations.
*
* Connection owns physical retry timing; Gateway performs each requested
* replacement. The domain consumer owns its opening item and every later
* item, and calls {@link RemoteStreamItem.accept} only after validating the
* opening baseline or cursor.
*/
var RemoteStream = class {
	connection;
	options;
	createController;
	lifetime;
	generationAbort;
	iterator;
	closing;
	revision = 0;
	taken = false;
	/**
	* @param connection - observable Host generation source used to pace retries.
	* @param options - domain stream opener, end classification, and diagnostics.
	* @param createController - controller factory; defaults to the platform AbortController.
	*/
	constructor(connection, options, createController = () => new AbortController()) {
		this.connection = connection;
		this.options = options;
		this.createController = createController;
		this.lifetime = createController();
	}
	/** Cancellation lifetime shared by the stream and sibling page requests. */
	get signal() {
		return this.lifetime.signal;
	}
	/** Interrupt the current generation and immediately request a replacement. */
	restart() {
		if (this.lifetime.signal.aborted) return;
		this.revision++;
		this.generationAbort?.abort(/* @__PURE__ */ new Error(`${this.options.name} generation restarted`));
	}
	/**
	* Permanently stop this stream and wait for its iterator to close.
	* @returns when the active generation and consumer iterator are quiescent.
	*/
	dispose() {
		if (this.closing !== void 0) return this.closing;
		if (!this.lifetime.signal.aborted) {
			const reason = /* @__PURE__ */ new Error(`${this.options.name} disposed`);
			this.lifetime.abort(reason);
			this.generationAbort?.abort(reason);
		}
		const iterator = this.iterator;
		if (iterator === void 0) return Promise.resolve();
		const closing = closeRemoteStreamIterator(iterator);
		this.closing = closing;
		return closing;
	}
	/** @inheritdoc */
	[Symbol.asyncIterator]() {
		if (this.taken) throw new Error(`${this.options.name} already has a consumer`);
		this.taken = true;
		const iterator = this.read();
		this.iterator = iterator;
		return iterator;
	}
	async *read() {
		let attempt = 0;
		let generation = 0;
		let observedRevision = this.revision;
		try {
			while (!isAborted(this.lifetime.signal)) {
				if (observedRevision !== this.revision) {
					observedRevision = this.revision;
					attempt = 0;
				}
				const revision = this.revision;
				const generationAbort = this.createController();
				this.generationAbort = generationAbort;
				const cancellation = combineRemoteCancellation([this.lifetime.signal, generationAbort.signal], this.createController);
				const signal = cancellation.signal;
				const generationId = ++generation;
				let accepted = false;
				try {
					for await (const value of this.options.open(signal)) {
						if (isAborted(this.lifetime.signal)) return;
						if (revision !== this.revision) break;
						yield {
							generation: generationId,
							value,
							signal,
							accept: () => {
								if (this.generationAbort !== generationAbort || revision !== this.revision) return;
								accepted = true;
								attempt = 0;
							}
						};
					}
					if (isAborted(this.lifetime.signal)) return;
					if (revision !== this.revision) continue;
					throw this.options.ended(accepted);
				} catch (error) {
					if (isAborted(this.lifetime.signal)) return;
					if (revision !== this.revision) continue;
					if (!(error instanceof RemoteStreamCarrierError)) throw terminalStreamFailure(error);
					this.options.carrierFailed?.(error);
					if (revision !== this.revision) continue;
					attempt++;
					try {
						await waitForRemoteStreamRetry(this.connection, error, attempt, signal);
					} catch (retryError) {
						if (isAborted(this.lifetime.signal)) return;
						if (revision !== this.revision) continue;
						throw terminalStreamFailure(retryError);
					}
				} finally {
					this.generationAbort = void 0;
					if (!generationAbort.signal.aborted) generationAbort.abort(/* @__PURE__ */ new Error(`${this.options.name} generation ended`));
					cancellation.dispose();
				}
			}
		} finally {
			if (!this.lifetime.signal.aborted) this.lifetime.abort(/* @__PURE__ */ new Error(`${this.options.name} consumer closed`));
			this.generationAbort?.abort(this.lifetime.signal.reason);
			this.generationAbort = void 0;
		}
	}
};
async function waitForRemoteStreamRetry(connection, error, attempt, signal) {
	signal.throwIfAborted();
	if (connection.generation.getSnapshot() !== void 0) {
		if (attempt === 1) return;
		throw error;
	}
	await new Promise((resolve, reject) => {
		const subscription = { finished: false };
		const finish = (failure) => {
			if (subscription.finished) return;
			subscription.finished = true;
			subscription.dispose?.();
			signal.removeEventListener("abort", aborted);
			if (failure === void 0) resolve();
			else reject(failure);
		};
		const inspect = () => {
			if (connection.generation.getSnapshot() !== void 0) finish();
		};
		const aborted = () => {
			finish(new Error("Remote stream retry aborted", { cause: signal.reason }));
		};
		const dispose = connection.generation.subscribe(inspect);
		subscription.dispose = dispose;
		if (subscription.finished) dispose();
		signal.addEventListener("abort", aborted, { once: true });
		if (signal.aborted) aborted();
		else inspect();
	});
}
/**
* Mark a terminal escape before it crosses the stream boundary: consumers
* discriminate failures by code, so an unmarked throw reads as a local bug.
* Marked failures pass through verbatim. The carrier class never escapes as a
* terminal outcome — it stays the retry-internal signal fed to `carrierFailed`
* and the `ended(true)` retry trigger.
*/
function terminalStreamFailure(error) {
	return remoteErrorOf(error) ?? new RemoteError("gateway/internal", error instanceof Error ? error.message : String(error), {}, { cause: error });
}
function isAborted(signal) {
	return signal.aborted;
}
async function closeRemoteStreamIterator(iterator) {
	try {
		await iterator.return?.();
	} catch {}
}
//#endregion
//#region ../gateway/lib/types/client/journal-stream.js
/** Cursor, page, and live-tail coordination over a reconnecting Remote stream. */
/** Host-side stream protocol violation, marked so consumers surface it as an error state. */
function protocolViolation$1(message) {
	return new RemoteError("gateway/internal", message, {});
}
/**
* Owns snapshot-first opening, ordered live delivery, pagination, and repair.
*
* The domain retains its published window during reconnection. A replacement is
* published only after the opening page reaches the generation's cursor.
* Notifications never change a cursor and wait behind an in-flight gap repair.
*/
var RemoteJournalStream = class {
	options;
	stream;
	initialRequest;
	resumeCursor;
	hasResumeCursor = false;
	generation = 0;
	firstCursor;
	lastCursor;
	started = false;
	opened = false;
	disposed = false;
	done;
	closing;
	pendingNext;
	/**
	* @param remote - Gateway factory for the reconnecting physical-generation stream.
	* @param options - cursor algebra and domain publication sinks.
	*/
	constructor(remote, options) {
		this.options = options;
		this.stream = remote.$stream({
			name: options.name,
			open: (signal) => this.follow(this.initialRequest, signal),
			ended: (accepted) => accepted ? new RemoteStreamCarrierError(`${options.name} ended without a terminal result`) : protocolViolation$1(`${this.hasResumeCursor ? "resumed " : ""}${options.name} ended before its opening cursor`),
			...options.carrierFailed === void 0 ? {} : { carrierFailed: options.carrierFailed }
		});
	}
	/** Cancellation lifetime shared by follow and page calls. */
	get signal() {
		return this.stream.signal;
	}
	/**
	* Establish follow and publish the opening snapshot carried by its first frame.
	* @param request - initial tail-page request.
	* @returns after the first complete window is published.
	*/
	async open(request) {
		if (this.started) throw new Error(`${this.options.name} already opened`);
		this.started = true;
		this.initialRequest = request;
		const iterator = this.stream[Symbol.asyncIterator]();
		try {
			const first = await this.takeNext(iterator);
			if (first.done) throw protocolViolation$1(`${this.options.name} ended before its opening cursor`);
			this.replaceGeneration(first.value, false);
			this.opened = true;
			this.done = this.consume(iterator);
		} catch (error) {
			await this.stream.dispose();
			throw error;
		}
	}
	/**
	* Read and prepend one older page after a successful open.
	* @param request - domain page request bound to this stream's address.
	* @returns after the page is applied or rejected as discontinuous.
	*/
	async prepend(request) {
		if (!this.opened || this.disposed) throw new Error(`${this.options.name} is not open`);
		const page = await this.readPage(request, this.currentCursor(), this.stream.signal);
		this.stream.signal.throwIfAborted();
		const entries = this.options.entries(page);
		this.assertPage(entries);
		const before = this.firstCursor;
		const accepted = before === void 0 ? [...entries] : entries.filter((entry) => this.options.compare(this.options.first(entry), before) < 0);
		const tail = accepted.at(-1);
		if (tail !== void 0 && before !== void 0 && !this.options.follows(this.options.last(tail), before)) {
			this.options.publish({
				type: "prepend",
				page,
				entries: [],
				hasMore: false
			});
			throw protocolViolation$1(`${this.options.name} history page is discontinuous`);
		}
		const first = accepted[0];
		if (first !== void 0) this.firstCursor = this.options.first(first);
		this.options.publish({
			type: "prepend",
			page,
			entries: accepted,
			hasMore: this.options.hasMore(page)
		});
	}
	/** Replace the active physical generation while retaining the published window. */
	restart() {
		this.stream.restart();
	}
	/**
	* Permanently stop follow, page requests, and the background consumer.
	* @returns when no stream work or publication callback can still run.
	*/
	dispose() {
		if (this.closing !== void 0) return this.closing;
		this.disposed = true;
		const done = this.done;
		const closing = (async () => {
			await this.stream.dispose();
			await done;
		})();
		this.closing = closing;
		return closing;
	}
	async consume(iterator) {
		try {
			while (true) {
				const next = await this.takeNext(iterator);
				if (next.done) return;
				const item = next.value;
				if (item.generation !== this.generation) {
					this.replaceGeneration(item, true);
					continue;
				}
				if (item.value.type === "opened") throw protocolViolation$1(`${this.options.name} emitted more than one opening cursor`);
				if (item.value.type === "notification") {
					this.publishNotification(item.value.notification);
					continue;
				}
				await this.acceptEntry(item.value.entry, item, iterator);
			}
		} catch (error) {
			if (!this.disposed) this.options.failed(error);
		}
	}
	replaceGeneration(initial, resumed) {
		const opening = this.opening(initial, resumed);
		this.replaceFromOpening(opening.page, opening.cursor);
	}
	opening(item, resumed) {
		if (item.value.type !== "opened") throw protocolViolation$1(`${resumed ? "resumed " : ""}${this.options.name} emitted an entry before its opening cursor`);
		const cursor = item.value.cursor;
		if (resumed && this.lastCursor !== void 0 && this.options.compare(cursor, this.lastCursor) < 0) throw protocolViolation$1(`${this.options.name} resumed at a cursor behind the last applied entry`);
		this.generation = item.generation;
		item.accept();
		return {
			cursor,
			page: item.value.page
		};
	}
	/** Publish a generation's opening page without issuing a second Remote call. */
	replaceFromOpening(page, cursor) {
		this.assertPageThrough(page, cursor);
		const entries = [...this.options.entries(page)];
		this.assertPage(entries);
		const first = entries[0];
		this.firstCursor = first === void 0 ? void 0 : this.options.first(first);
		this.lastCursor = cursor;
		this.setResumeCursor(cursor);
		this.options.publish({
			type: "replace",
			page,
			entries,
			hasMore: this.options.hasMore(page)
		});
	}
	async acceptEntry(entry, item, iterator) {
		const { first, last: cursor } = this.entryRange(entry);
		const last = this.lastCursor;
		if (this.options.compare(cursor, last) <= 0) return;
		if (this.options.compare(first, last) <= 0) throw protocolViolation$1(`${this.options.name} emitted a partially overlapping entry`);
		if (!this.options.follows(last, first)) {
			const request = this.repairPageRequest();
			const superseded = await this.replaceThrough(request, cursor, item.generation, item.signal, iterator, [entry], []);
			if (superseded !== void 0) this.replaceGeneration(superseded, true);
			return;
		}
		if (this.firstCursor === void 0) this.firstCursor = first;
		this.lastCursor = cursor;
		this.setResumeCursor(cursor);
		this.options.publish({
			type: "append",
			entry
		});
	}
	async replaceThrough(request, requiredCursor, generation, signal, iterator, queued, notifications) {
		let read = await this.readPageWhileFollowing(request, requiredCursor, generation, signal, iterator, queued, notifications);
		if (read.type === "superseded") return read.item;
		let page = read.page;
		this.assertPageThrough(page, requiredCursor);
		let entries = this.mergeReplacement(page, queued);
		let target = this.maxCursor(requiredCursor, queued);
		if (entries === void 0 || this.options.compare(this.tailCursor(entries), target) < 0) {
			read = await this.readPageWhileFollowing(this.repairPageRequest(), target, generation, signal, iterator, queued, notifications);
			if (read.type === "superseded") return read.item;
			page = read.page;
			this.assertPageThrough(page, target);
			entries = this.mergeReplacement(page, queued);
			target = this.maxCursor(requiredCursor, queued);
		}
		if (entries === void 0 || this.options.compare(this.tailCursor(entries), target) < 0) throw protocolViolation$1(`${this.options.name} page did not reach its opening cursor`);
		const first = entries[0];
		/* v8 ignore next -- a successful positive-cursor replacement page cannot be empty. */
		this.firstCursor = first === void 0 ? void 0 : this.options.first(first);
		this.lastCursor = this.tailCursor(entries);
		this.setResumeCursor(this.lastCursor);
		this.options.publish({
			type: "replace",
			page,
			entries,
			hasMore: this.options.hasMore(page)
		});
		for (const notification of notifications) this.publishNotification(notification);
	}
	async readPageWhileFollowing(request, through, generation, signal, iterator, queued, notifications) {
		const page = this.readPage(request, through, signal).then((value) => ({
			type: "page",
			value
		}), (error) => ({
			type: "page-error",
			error
		}));
		while (true) {
			const pending = this.nextResult(iterator);
			const next = pending.then((value) => ({
				type: "next",
				value
			}), (error) => ({
				type: "next-error",
				error
			}));
			const result = await Promise.race([page, next]);
			if (result.type === "page") {
				signal.throwIfAborted();
				return {
					type: "page",
					page: result.value
				};
			}
			if (result.type === "page-error") {
				if (!signal.aborted || this.stream.signal.aborted) throw result.error;
				return this.awaitReplacementGeneration(generation, iterator, pending);
			}
			this.releaseNext();
			if (result.type === "next-error") throw result.error;
			if (result.value.done) {
				signal.throwIfAborted();
				throw protocolViolation$1(`${this.options.name} ended while reading its replacement page`);
			}
			const item = result.value.value;
			if (item.generation !== generation) return {
				type: "superseded",
				item
			};
			if (item.value.type === "opened") throw protocolViolation$1(`${this.options.name} emitted more than one opening cursor`);
			if (item.value.type === "notification") {
				notifications.push(item.value.notification);
				continue;
			}
			queued.push(item.value.entry);
		}
	}
	async awaitReplacementGeneration(generation, iterator, initial) {
		let pending = initial;
		while (true) {
			let next;
			try {
				next = await pending;
			} finally {
				this.releaseNext();
			}
			if (next.done) {
				this.stream.signal.throwIfAborted();
				throw protocolViolation$1(`${this.options.name} ended while replacing an aborted page generation`);
			}
			const item = next.value;
			if (item.generation !== generation) return {
				type: "superseded",
				item
			};
			if (item.value.type === "opened") throw protocolViolation$1(`${this.options.name} emitted more than one opening cursor`);
			pending = this.nextResult(iterator);
		}
	}
	mergeReplacement(page, queued) {
		const entries = [...this.options.entries(page)];
		this.assertPage(entries);
		for (const entry of queued) this.entryRange(entry);
		const sorted = [...queued].sort((left, right) => this.options.compare(this.options.first(left), this.options.first(right)));
		let tail = this.tailCursor(entries);
		for (const entry of sorted) {
			const first = this.options.first(entry);
			const last = this.options.last(entry);
			if (this.options.compare(last, tail) <= 0) continue;
			if (this.options.compare(first, tail) <= 0) throw protocolViolation$1(`${this.options.name} replacement contains a partially overlapping entry`);
			if (!this.options.follows(tail, first)) return void 0;
			entries.push(entry);
			tail = last;
		}
		return entries;
	}
	maxCursor(cursor, entries) {
		let result = cursor;
		for (const entry of entries) {
			const candidate = this.options.last(entry);
			if (this.options.compare(candidate, result) > 0) result = candidate;
		}
		return result;
	}
	nextResult(iterator) {
		this.pendingNext ??= iterator.next();
		return this.pendingNext;
	}
	async takeNext(iterator) {
		const pending = this.nextResult(iterator);
		try {
			return await pending;
		} finally {
			this.releaseNext();
		}
	}
	releaseNext() {
		this.pendingNext = void 0;
	}
	publishNotification(notification) {
		this.options.publish({
			type: "notification",
			notification
		});
	}
	repairPageRequest() {
		return this.repairRequest(this.initialRequest);
	}
	setResumeCursor(cursor) {
		this.resumeCursor = cursor;
		this.hasResumeCursor = true;
	}
	currentCursor() {
		return this.resumeCursor;
	}
	tailCursor(entries) {
		const tail = entries.at(-1);
		return tail === void 0 ? this.options.emptyCursor : this.options.last(tail);
	}
	assertPage(entries) {
		const iterator = entries[Symbol.iterator]();
		const first = iterator.next();
		if (first.done) return;
		let previousRange = this.entryRange(first.value);
		for (const entry of iterator) {
			const range = this.entryRange(entry);
			if (!this.options.follows(previousRange.last, range.first)) throw protocolViolation$1(`${this.options.name} page contains discontinuous entries`);
			previousRange = range;
		}
	}
	entryRange(entry) {
		const first = this.options.first(entry);
		const last = this.options.last(entry);
		if (this.options.compare(first, last) > 0) throw protocolViolation$1(`${this.options.name} entry has an inverted cursor range`);
		return {
			first,
			last
		};
	}
	assertPageThrough(page, through) {
		const tail = this.tailCursor(this.options.entries(page));
		if (this.options.compare(tail, through) !== 0) throw protocolViolation$1(`${this.options.name} page did not end at its requested cursor`);
	}
};
//#endregion
//#region ../gateway/lib/types/client/snapshot-stream.js
/** Baseline-and-delta protocol layered over a reconnecting Remote stream. */
/** Host-side stream protocol violation, marked so consumers surface it as an error state. */
function protocolViolation(message) {
	return new RemoteError("gateway/internal", message, {});
}
/**
* Consumes generations that each contain exactly one opening snapshot followed by deltas.
*
* The previous domain snapshot remains published while the underlying stream retries. A
* replacement becomes accepted only after the domain owner applies it successfully.
*/
var RemoteSnapshotStream = class {
	stream;
	options;
	started = false;
	disposed = false;
	done;
	/**
	* @param stream - reconnecting physical-generation stream.
	* @param options - frame discriminator and domain state destinations.
	*/
	constructor(stream, options) {
		this.stream = stream;
		this.options = options;
	}
	/** Start the single consumer; repeated calls are inert. */
	start() {
		if (this.started) return;
		this.started = true;
		this.done = this.consume();
	}
	/** Replace the active physical generation without discarding the published snapshot. */
	restart() {
		this.stream.restart();
	}
	/**
	* Permanently stop the stream and wait for its consumer to become quiescent.
	* @returns when no generation or callback can still run.
	*/
	async dispose() {
		this.disposed = true;
		await this.stream.dispose();
		await this.done;
	}
	async consume() {
		let generation = 0;
		let snapshotSeen = false;
		try {
			for await (const item of this.stream) {
				if (item.generation !== generation) {
					generation = item.generation;
					snapshotSeen = false;
				}
				if (this.options.isSnapshot(item.value)) {
					if (snapshotSeen) throw protocolViolation(`${this.options.name} emitted more than one opening snapshot`);
					this.options.replace(item.value);
					snapshotSeen = true;
					item.accept();
					continue;
				}
				if (!snapshotSeen) throw protocolViolation(`${this.options.name} emitted an update before its opening snapshot`);
				this.options.update(item.value);
			}
		} catch (error) {
			if (!this.disposed) this.options.failed(error);
		}
	}
};
//#endregion
//#region ../gateway/lib/types/client/service.js
/**
* Client projection of generated Typert Remote descriptors. Contributions
* install traced `remote.<namespace>` services; no JavaScript Proxy
* participates in method lookup, invocation, or type exposure.
*/
/**
* Install the shared typed Remote service with explicit platform inputs.
* @param ctx - Client Cordis root with Typert and Connection services.
* @param streams - physical stream carrier owned and disposed by this service.
* @param eventId - unique identity for this service's private event registrations.
* @param createController - fresh platform controllers preserving abort reasons and signal helpers.
* @param admission - paired Host and Client-required endpoints checked before native readiness.
*/
function installRemoteClient(ctx, streams, eventId, createController, admission) {
	new ClientRemoteService(ctx, streams, eventId, createController, admission);
}
var ClientRemoteService = class extends Service {
	streams;
	createController;
	admission;
	ownerCtx;
	connection;
	namespaces = /* @__PURE__ */ new Map();
	hostFacts;
	events;
	mutations = Promise.resolve();
	constructor(ctx, streams, eventId, createController, admission) {
		super(ctx, "remote");
		this.streams = streams;
		this.createController = createController;
		this.admission = admission;
		this.ownerCtx = ctx;
		const connection = ctx.get("connection");
		this.connection = connection;
		this.events = new ClientRemoteEvents(ctx, connection, (endpoint, payload, signal) => this.openRemoteStream(endpoint, payload, signal), eventId, createController, admission);
		if (connection.rpc.open === void 0) this.streams.start();
		let disposed = false;
		let loop;
		const start = () => {
			if (disposed) return;
			if (connection.rpc.open === void 0) this.streams.start();
			loop = connection.start({
				onConnected: () => {
					this.ownerCtx.emit("connection/reset");
				},
				onReconnectRequested: () => {
					if (connection.rpc.open === void 0) this.streams.reconnect();
				}
			});
		};
		const loader = ctx.get("loader");
		if (loader === void 0) start();
		else loader.await().then(start, () => {});
		ctx.effect(() => async () => {
			disposed = true;
			loop?.stop();
			await this.events.dispose();
			await this.streams.close();
		}, "api-gateway.client.transport");
	}
	$stream(options) {
		return new RemoteStream(this.connection, options, this.createController);
	}
	get $host() {
		const host = this.connection.generation.getSnapshot()?.host;
		const home = host?.home;
		const identity = host?.identity;
		const capabilities = this.events.capabilities(host);
		if (this.hostFacts === void 0 || this.hostFacts.home !== home || this.hostFacts.identity !== identity || this.hostFacts.capabilities !== capabilities) this.hostFacts = {
			home,
			identity,
			capabilities,
			isLoopback: this.connection.isLoopback
		};
		return this.hostFacts;
	}
	async $mount(contribution) {
		const callerCtx = this.ctx;
		const owned = callerCtx.effect(async () => {
			const dispose = await this.enqueue(() => this.mountContribution(callerCtx, contribution));
			return () => this.enqueue(dispose);
		}, `api-gateway.client.$mount(${JSON.stringify(contribution.package)})`);
		await owned;
		return async () => {
			await owned();
		};
	}
	$on(event, listener) {
		return this.events.subscribe(this.ctx, event, listener);
	}
	/** Open one Remote stream and normalize a worker-local carrier's structural failures. */
	openRemoteStream(endpoint, payload, signal, noConnection = `client api: ${endpoint} has no active Connection`) {
		const connection = this.ownerCtx.get("connection");
		if (connection === void 0) throw new Error(noConnection);
		const local = connection.rpc.open?.("/api", endpoint, payload, signal);
		return local === void 0 ? this.streams.open(endpoint, payload, signal) : normalizeConnectionStream(local);
	}
	enqueue(operation) {
		const result = this.mutations.then(operation, operation);
		this.mutations = result.then(() => void 0, () => void 0);
		return result;
	}
	async mountContribution(callerCtx, contribution) {
		this.validateContribution(contribution);
		const disposeRemote = callerCtx.typert.remotes.register(contribution);
		const groups = /* @__PURE__ */ new Map();
		for (const descriptor of contribution.descriptors) {
			const group = groups.get(descriptor.namespace);
			if (group === void 0) groups.set(descriptor.namespace, [descriptor]);
			else group.push(descriptor);
		}
		const installed = [];
		try {
			for (const [namespace, descriptors] of groups) installed.push(await this.installNamespace(namespace, descriptors));
		} catch (error) {
			for (const dispose of installed.reverse()) await dispose();
			await disposeRemote();
			throw error;
		}
		return async () => {
			for (const dispose of installed.reverse()) await dispose();
			await disposeRemote();
		};
	}
	validateContribution(contribution) {
		const direct = /* @__PURE__ */ new Map();
		const scoped = /* @__PURE__ */ new Map();
		const add = (table, descriptor, kind) => {
			const methods = table.get(descriptor.namespace) ?? /* @__PURE__ */ new Set();
			if (methods.has(descriptor.method)) throw new Error(`client api: contribution repeats ${kind} method ${endpointOf(descriptor)}`);
			methods.add(descriptor.method);
			table.set(descriptor.namespace, methods);
			if ((this.namespaces.get(descriptor.namespace)?.service)?.has(kind, descriptor.method) === true) throw new Error(`client api: ${kind} method ${endpointOf(descriptor)} is already mounted`);
		};
		for (const descriptor of contribution.descriptors) {
			requireStrictDescriptor(descriptor);
			if (descriptor.invocation.kind === "direct") add(direct, descriptor, "direct");
			if (scopedProjection(descriptor) !== void 0) add(scoped, descriptor, "scoped");
		}
		const namespaces = new Set([...direct.keys(), ...scoped.keys()]);
		for (const namespace of namespaces) {
			const service = this.namespaces.get(namespace)?.service;
			if (service === void 0) {
				if (namespace in this) throw new Error(`client api: namespace ${JSON.stringify(namespace)} conflicts with the Remote service`);
				const serviceKey = remoteServiceKey(namespace);
				if (this.ownerCtx.reflect.props[serviceKey]?.type === "accessor" || this.ownerCtx.get(serviceKey) !== void 0) throw new Error(`client api: namespace ${JSON.stringify(namespace)} conflicts with an existing Remote namespace`);
			}
			for (const method of new Set([...direct.get(namespace) ?? [], ...scoped.get(namespace) ?? []])) if (service === void 0) RemoteNamespaceService.assertMethodAvailable(namespace, method);
			else service.assertMethodAvailable(method);
		}
	}
	/**
	* Mount one namespace's descriptor group with no visibility gap: a fresh
	* namespace installs its whole group synchronously inside its fiber's
	* apply, so a plugin parked on the namespace service never observes it
	* without the methods the same contribution carries; an existing namespace
	* takes the group in one synchronous step.
	* @param name - Remote namespace.
	* @param descriptors - Every contribution descriptor naming that namespace.
	* @returns disposer unmounting the group and the namespace once empty.
	*/
	async installNamespace(name, descriptors) {
		let namespace = this.namespaces.get(name);
		let installed;
		if (namespace === void 0) ({namespace, installed} = await this.createNamespace(name, descriptors));
		else installed = installMethods(namespace.service, descriptors, this.createController);
		const handle = namespace;
		return async () => {
			for (const method of [...installed].reverse()) {
				/* v8 ignore next -- Cordis effect disposers are idempotent and invoke this cleanup at most once. */
				if (!method.token.active) continue;
				method.token.active = false;
				method.token.abort.abort();
				if (method.scoped) handle.service.remove("scoped", method.descriptor.method, method.token);
				if (method.direct) handle.service.remove("direct", method.descriptor.method, method.token);
			}
			await this.disposeNamespace(name, handle);
		};
	}
	async createNamespace(name, descriptors) {
		let service;
		let installed;
		const fiber = this.ownerCtx.plugin({
			name: remoteServiceKey(name),
			apply: (ctx) => {
				service = new RemoteNamespaceService(ctx, name, (direct, scoped, caller, args) => this.invokeMethod(direct, scoped, caller, args));
				installed = installMethods(service, descriptors, this.createController);
			}
		});
		try {
			await fiber;
		} catch (error) {
			await fiber.dispose();
			throw error;
		}
		/* v8 ignore next 3 -- a settled namespace fiber synchronously constructs its Service and installs the group. */
		if (service === void 0 || installed === void 0) throw new Error(`client api: namespace ${JSON.stringify(name)} did not start`);
		const namespace = {
			service,
			dispose: fiber.dispose
		};
		this.namespaces.set(name, namespace);
		return {
			namespace,
			installed
		};
	}
	async disposeNamespace(name, namespace) {
		if (!namespace.service.empty || this.namespaces.get(name) !== namespace) return;
		this.namespaces.delete(name);
		await namespace.dispose();
	}
	invokeMethod(direct, scoped, callerCtx, values) {
		if (scoped !== void 0) {
			const identity = this.ownerCtx.typert.contexts.getClient(scoped.projection.context)?.identity(callerCtx);
			if (identity !== void 0) return this.invokeSelected(scoped.descriptor, scoped.projection, scoped.token, callerCtx, values, { value: identity });
		}
		if (direct !== void 0) return this.invokeSelected(direct.descriptor, void 0, direct.token, callerCtx, values);
		if (scoped !== void 0) return this.invokeSelected(scoped.descriptor, scoped.projection, scoped.token, callerCtx, values);
		throw new Error("client api: Remote method is no longer mounted");
	}
	invokeSelected(descriptor, projection, token, callerCtx, values, boundIdentity) {
		if (descriptor.mode === "stream") return this.invokeStream(descriptor, projection, token, callerCtx, values, boundIdentity);
		return this.invoke(descriptor, projection, token, callerCtx, values, boundIdentity);
	}
	operationPayload(descriptor, args, pinned) {
		if (descriptor.wireFingerprint === void 0 || descriptor.semanticRevision === void 0) {
			if (pinned !== void 0) throw new RemoteError("gateway/api-incompatible", "client api: native operations require schema and business revision evidence", { endpoint: endpointOf(descriptor) });
			return { args };
		}
		return {
			args,
			compatibility: {
				wireFingerprint: descriptor.wireFingerprint,
				semanticRevision: descriptor.semanticRevision,
				...pinned === void 0 ? {} : { identity: pinned.identity }
			}
		};
	}
	async invoke(descriptor, projection, token, callerCtx, values, boundIdentity) {
		const endpoint = endpointOf(descriptor);
		if (!token.active) return withdrawn(endpoint);
		const connection = this.ownerCtx.get("connection");
		if (connection === void 0) throw new Error(`client api: ${endpoint} has no active Connection`);
		const prepared = this.prepareInvocation(descriptor, projection, token, callerCtx, values, boundIdentity);
		let pinned;
		try {
			pinned = bindPinnedGeneration(connection, this.admission?.expectedHostId, prepared.signal, this.createController);
			const payload = this.operationPayload(descriptor, prepared.args, pinned);
			const result = await connection.rpc.call("/api", endpoint, payload, pinned?.signal ?? prepared.signal);
			pinned?.assertCurrent();
			if (!mountActive(token)) return withdrawn(endpoint);
			if (!result.ok) return {
				ok: false,
				error: rebuiltFailure(result.error)
			};
			return {
				ok: true,
				value: result.value
			};
		} catch (error) {
			if (prepared.signal.aborted) return cancelledFailure(endpoint, error);
			if (isRemoteFailure(error)) return {
				ok: false,
				error
			};
			return carrierFailure(endpoint, pinned?.signal.aborted === true ? pinned.signal.reason : error);
		} finally {
			pinned?.dispose();
			prepared.cancellation?.dispose();
		}
	}
	async *invokeStream(descriptor, projection, token, callerCtx, values, boundIdentity) {
		const endpoint = endpointOf(descriptor);
		if (!token.active) throw new Error(withdrawn(endpoint).error.message);
		const prepared = this.prepareInvocation(descriptor, projection, token, callerCtx, values, boundIdentity);
		let pinned;
		try {
			pinned = bindPinnedGeneration(this.connection, this.admission?.expectedHostId, prepared.signal, this.createController);
			const payload = this.operationPayload(descriptor, prepared.args, pinned);
			const stream = this.openRemoteStream(endpoint, payload, pinned?.signal ?? prepared.signal);
			for await (const value of stream) {
				pinned?.assertCurrent();
				if (!mountActive(token)) throw new Error(withdrawn(endpoint).error.message);
				yield value;
			}
			pinned?.assertCurrent();
		} catch (error) {
			if (pinned?.signal.aborted === true && !prepared.signal.aborted) throw pinned.signal.reason;
			throw error;
		} finally {
			pinned?.dispose();
			prepared.cancellation?.dispose();
		}
	}
	prepareInvocation(descriptor, projection, token, callerCtx, values, boundIdentity) {
		const endpoint = endpointOf(descriptor);
		const expected = descriptor.parameters.length - (projection?.parameterIndex === void 0 ? 0 : 1);
		const hasCallerSignal = descriptor.cancellation !== void 0 && values.length === expected + 1;
		if (values.length !== expected && !hasCallerSignal) {
			const contract = descriptor.cancellation === void 0 ? `${String(expected)} argument(s)` : `${String(expected)} business argument(s) plus an optional AbortSignal`;
			throw new Error(`client api: ${endpoint} expected ${contract}, got ${String(values.length)}`);
		}
		const args = Object.create(null);
		if (projection !== void 0) {
			const adapter = boundIdentity === void 0 ? this.ownerCtx.typert.contexts.getClient(projection.context) : void 0;
			if (boundIdentity === void 0 && adapter === void 0) throw new Error(`client api: ${endpoint} has no Client Context adapter for ${JSON.stringify(projection.context)}`);
			const identity = boundIdentity === void 0 ? adapter?.identity(callerCtx) : boundIdentity.value;
			if (identity === void 0) throw new Error(`client api: ${endpoint} requires a ${JSON.stringify(projection.context)} Context`);
			args[projection.wire] = parseInput(projection.codec, identity, endpoint, projection.wire);
		}
		let valueIndex = 0;
		descriptor.parameters.forEach((parameter, parameterIndex) => {
			if (parameterIndex === projection?.parameterIndex) return;
			const value = parseInput(parameter.codec, values[valueIndex], endpoint, parameter.wire);
			if (value !== void 0) args[parameter.wire] = value;
			valueIndex += 1;
		});
		const callerSignal = hasCallerSignal ? values[expected] : void 0;
		const cancellation = callerSignal === void 0 ? void 0 : combineRemoteCancellation([token.abort.signal, callerSignal], this.createController);
		return {
			endpoint,
			args,
			signal: cancellation?.signal ?? token.abort.signal,
			cancellation
		};
	}
};
var RemoteNamespaceService = class RemoteNamespaceService extends Service {
	invokeRemote;
	methods = /* @__PURE__ */ new Map();
	namespace;
	static assertMethodAvailable(namespace, method) {
		if (REMOTE_NAMESPACE_FIELDS.has(method) || method in RemoteNamespaceService.prototype) throw new Error(`client api: method ${JSON.stringify(`${namespace}/${method}`)} conflicts with its namespace service`);
	}
	constructor(ctx, name, invokeRemote) {
		super(ctx, remoteServiceKey(name));
		this.invokeRemote = invokeRemote;
		this.namespace = name;
	}
	assertMethodAvailable(method) {
		RemoteNamespaceService.assertMethodAvailable(this.namespace, method);
		if (method in this && !this.methods.has(method)) throw new Error(`client api: method ${JSON.stringify(`${this.namespace}/${method}`)} conflicts with its namespace service`);
	}
	get empty() {
		return this.methods.size === 0;
	}
	has(kind, method) {
		return this.methods.get(method)?.[kind] !== void 0;
	}
	installDirect(descriptor, token) {
		this.install(descriptor.method, "direct", {
			descriptor,
			token
		});
	}
	installScoped(descriptor, projection, token) {
		this.install(descriptor.method, "scoped", {
			descriptor,
			projection,
			token
		});
	}
	install(method, kind, value) {
		this.assertMethodAvailable(method);
		let record = this.methods.get(method);
		const fresh = record === void 0;
		record ??= {};
		if (fresh) {
			Object.defineProperty(this, method, {
				configurable: true,
				enumerable: true,
				get: function() {
					const callerCtx = this.ctx;
					const current = this.methods.get(method);
					const direct = current?.direct;
					const scoped = current?.scoped;
					return (...args) => {
						return this.invokeRemote(direct, scoped, callerCtx, args);
					};
				}
			});
			this.methods.set(method, record);
		}
		if (kind === "direct") record.direct = value;
		else record.scoped = value;
	}
	remove(kind, method, token) {
		const record = this.methods.get(method);
		const current = record?.[kind];
		/* v8 ignore next -- duplicate live variants are rejected before installation, so no newer token can replace this one. */
		if (record === void 0 || current?.token !== token) return;
		if (kind === "direct") delete record.direct;
		else delete record.scoped;
		if (record.direct !== void 0 || record.scoped !== void 0) return;
		this.methods.delete(method);
		Reflect.deleteProperty(this, method);
	}
};
/**
* Install one descriptor group on a namespace service, unwinding the partial
* group when a descriptor is refused.
* @param service - Namespace service taking the methods.
* @param descriptors - Descriptor group of one contribution.
* @param createController - controller factory for each mounted method lifetime.
* @returns per-descriptor records for the group disposer.
*/
function installMethods(service, descriptors, createController) {
	const installed = [];
	try {
		for (const descriptor of descriptors) {
			const method = {
				descriptor,
				token: {
					active: true,
					abort: createController()
				},
				direct: false,
				scoped: false
			};
			installed.push(method);
			if (descriptor.invocation.kind === "direct") {
				service.installDirect(descriptor, method.token);
				method.direct = true;
			}
			const projection = scopedProjection(descriptor);
			if (projection !== void 0) {
				service.installScoped(descriptor, projection, method.token);
				method.scoped = true;
			}
		}
	} catch (error) {
		for (const method of [...installed].reverse()) {
			method.token.active = false;
			method.token.abort.abort();
			if (method.scoped) service.remove("scoped", method.descriptor.method, method.token);
			if (method.direct) service.remove("direct", method.descriptor.method, method.token);
		}
		throw error;
	}
	return installed;
}
const REMOTE_NAMESPACE_FIELDS = new Set([
	"ctx",
	"empty",
	"invokeRemote",
	"methods",
	"name",
	"namespace"
]);
function remoteServiceKey(namespace) {
	return `remote.${namespace}`;
}
function endpointOf(descriptor) {
	return `${descriptor.namespace}/${descriptor.method}`;
}
function mountActive(token) {
	return token.active;
}
function scopedProjection(descriptor) {
	if (descriptor.invocation.kind === "context") return {
		context: descriptor.invocation.context,
		wire: descriptor.invocation.wire,
		codec: descriptor.invocation.codec
	};
	if (descriptor.scope === void 0) return void 0;
	const lookupParameters = descriptor.parameters.map((parameter, index) => ({
		parameter,
		index
	})).filter((candidate) => candidate.parameter.source === "lookup");
	const selected = lookupParameters.length === 1 ? lookupParameters[0] : void 0;
	if (selected === void 0 || selected.parameter.wire !== descriptor.scope.wire || selected.parameter.lookup !== descriptor.scope.context) throw new Error(`client api: generated Remote ${endpointOf(descriptor)} scope must select its only lookup parameter`);
	return {
		context: descriptor.scope.context,
		wire: descriptor.scope.wire,
		codec: selected.parameter.codec,
		parameterIndex: selected.index
	};
}
function requireStrictDescriptor(descriptor) {
	const endpoint = endpointOf(descriptor);
	for (const parameter of descriptor.parameters) requireStrictCodec(parameter.codec, endpoint, parameter.wire);
	if (descriptor.invocation.kind === "context") requireStrictCodec(descriptor.invocation.codec, endpoint, descriptor.invocation.wire);
}
function requireStrictCodec(codec, endpoint, field) {
	if (codec.mode !== "strict") throw new Error(`client api: generated Remote ${endpoint} field ${JSON.stringify(field)} has no strict codec`);
}
function parseInput(codec, value, endpoint, field) {
	if (codec.mode !== "strict") throw new Error(`client api: generated Remote ${endpoint} field ${JSON.stringify(field)} has no strict codec`);
	try {
		return codec.schema.parse(value);
	} catch (cause) {
		throw new Error(`client api: ${endpoint} rejected ${JSON.stringify(field)}`, { cause });
	}
}
/** The namespace retired before or during the call, so no request outcome exists. */
function withdrawn(endpoint) {
	return internalFailure(`client api: Remote method ${endpoint} is no longer mounted`);
}
function carrierFailure(endpoint, error) {
	return internalFailure(`client api: ${endpoint} failed: ${error instanceof Error ? error.message : String(error)}`);
}
function cancelledFailure(endpoint, cause) {
	return {
		ok: false,
		error: new RemoteError("gateway/cancelled", `client api: Remote invocation "${endpoint}" was aborted`, {}, { cause })
	};
}
function internalFailure(message) {
	return {
		ok: false,
		error: new RemoteError("gateway/internal", message, {})
	};
}
/**
* Whether a caught value is a Remote failure this face delivered or threw.
* The one consumer-facing discrimination point: marked instances carry their
* Host code; anything else is a local fault the caller should let crash.
* @param error - a caught value.
* @returns true when the value narrows to RemoteFailure.
*/
function isRemoteFailure(error) {
	return remoteErrorOf(error) !== void 0;
}
/**
* Rebuild the wire failure as a local RemoteError instance so the error branch
* carries a real Error and `throw result.error` keeps throw semantics. The code
* is passed through verbatim without runtime validation: a code outside this
* Client's merged map still surfaces as-is, so a newer Host stays readable.
*/
function rebuiltFailure(error) {
	return new RemoteError(error.code, error.message, error.details);
}
/** Preserve Gateway error classes across a worker transport's separately bundled page half. */
async function* normalizeConnectionStream(source) {
	try {
		yield* source;
	} catch (error) {
		if (!(error instanceof Error)) throw error;
		const marker = error.dshRemoteStreamFailure;
		if (marker?.kind === "remote") throw new RemoteError(marker.code, error.message, marker.details);
		if (marker?.kind === "carrier") throw new RemoteStreamCarrierError(error.message, { cause: error });
		throw error;
	}
}
//#endregion
//#region ../gateway/lib/types/client/portable.js
/**
* Create one host's stream carrier without browser globals. Start/reconnect belongs to Connection;
* streams never replay themselves. Close permanently releases this instance's transport.
* @param options - host URL, authenticated socket adapter and correlation identity generator.
* @returns an independent multiplexed carrier; invalid host URLs throw before any socket is opened.
*/
function createRemoteStreamMux(options) {
	const url = new URL(REMOTE_STREAM_MUX_PATH, options.baseUrl);
	if (url.protocol !== "http:" && url.protocol !== "https:") throw new TypeError("api gateway: Remote stream host must use HTTP or HTTPS");
	if (url.username !== "" || url.password !== "") throw new TypeError("api gateway: Remote stream credentials belong in the socket adapter");
	url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
	return new RemoteStreamMuxClient({
		createSocket: () => options.createSocket(url.href),
		randomId: () => options.randomId()
	});
}
/**
* Install typed Remote calls, streams and forwarded events for one HTTP(S) host.
* The owning Cordis fiber disposes the transport and registrations together.
* @param ctx - Client Cordis root with Typert and Connection services.
* @param options - authenticated socket adapter, host URL and identity generator.
*/
function applyRemoteClient(ctx, options) {
	installRemoteClient(ctx, createRemoteStreamMux(options), options.randomId(), options.createAbortController, {
		expectedHostId: options.expectedHostId,
		requiredCapabilities: options.requiredCapabilities.map((requirement) => ({ ...requirement }))
	});
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/history-records.js
/** Client range access and type narrowing for aligned Session history records. */
/**
* Narrow aligned wire records to their Client event types without allocation.
* @param records - validated history transport records.
* @returns the same record array with typed inner events.
*/
function historyEntries(records) {
	return records;
}
/**
* Read the first logical sequence represented by one wire record.
* @param record - validated Session event.
* @returns inclusive first Session sequence.
*/
function historyRecordFirstSeq(record) {
	return record.event.seq;
}
/**
* Read the final logical sequence represented by one wire record.
* @param record - validated Session event.
* @returns inclusive final Session sequence.
*/
function historyRecordLastSeq(record) {
	return record.event.seq;
}
//#endregion
//#region ../../core/session/lib/types/surface.js
/** Runtime counterpart of the message-producing event union. */
const SURFACE_EVENT_TYPES = new Set([
	"system/message",
	"user/message",
	"assistant/message",
	"tool/result"
]);
/**
* Whether an event type can join the model-visible surface.
* @param type - event type to test.
* @returns true for one of the four message-producing event types.
*/
function isSurfaceEligibleType(type) {
	return SURFACE_EVENT_TYPES.has(type);
}
/** Whether a payload field is a JSON object rather than an array or scalar. */
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
/**
* Reject noncanonical request-header fields and contradictory tool failure metadata.
* This does not validate complete event payloads or embedded provider streams.
* @param event - event whose locally related payload fields are inspected.
* @param subject - event location to include in validation errors.
* @throws when request data/header is not an object, optional header fields are empty, or tool failure metadata contradicts its message.
*/
function validateSessionEventData(event, subject) {
	const data = event.data;
	if (event.type === "request/header") {
		if (!isRecord$1(data)) throw new Error(`${subject} data must be an object`);
		const header = data["header"];
		if (!isRecord$1(header)) throw new Error(`${subject} header must be an object`);
		if (Object.hasOwn(header, "system")) throw new Error(`${subject} must omit header.system; use system/message`);
		if (Array.isArray(header["tools"]) && header["tools"].length === 0) throw new Error(`${subject} must omit empty tools`);
		const defaults = header["adapterDefaults"];
		if (isRecord$1(defaults) && Object.keys(defaults).length === 0) throw new Error(`${subject} must omit empty adapterDefaults`);
	} else if (event.type === "tool/result") {
		if (!isRecord$1(data)) throw new Error(`${subject} data must be an object`);
		if (data["error"] === void 0) return;
		const message = data["message"];
		const content = isRecord$1(message) ? message["content"] : void 0;
		const block = Array.isArray(content) ? content[0] : void 0;
		if (!isRecord$1(block) || block["isError"] !== true) throw new Error(`${subject} error requires message content[0].isError === true`);
	}
}
/** Whether a runtime value is a non-negative safe event sequence. */
function isEventSeq(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && !Object.is(value, -0);
}
/** Whether a runtime value is the exact positional-replacement shape. */
function isReplaceOp(value) {
	const op = value;
	return Object.keys(op).length === 3 && Object.hasOwn(op, "op") && Object.hasOwn(op, "startSeq") && Object.hasOwn(op, "endSeq") && op["op"] === "replace" && isEventSeq(op["startSeq"]) && isEventSeq(op["endSeq"]);
}
/** Validate event-local surface eligibility and return its operation. */
function surfaceOpOf(event) {
	const raw = event;
	if (!isSurfaceEligibleType(event.type)) {
		if (!KNOWN_SESSION_EVENT_TYPES.has(event.type) && event.ignorable === true) return;
		if (raw.surfaceOp !== void 0) throw new Error(`session event "${event.type}" is not surface-eligible and cannot carry surfaceOp`);
		if (raw.sourceEventSeqs !== void 0) throw new Error(`session event "${event.type}" is not surface-eligible and cannot carry sourceEventSeqs`);
		return;
	}
	const op = raw.surfaceOp;
	if (op === void 0) throw new Error(`session event "${event.type}" is surface-eligible and requires a surfaceOp marker`);
	if (op === "append") return op;
	if (op === null || typeof op !== "object" || Array.isArray(op)) throw new Error(`session event "${event.type}" carries an invalid surfaceOp`);
	if (!isReplaceOp(op)) throw new Error(`session event "${event.type}" carries an invalid replace surfaceOp`);
	return op;
}
/** Validate cited source-event seqs against prior log entries and the replacement range. */
function assertProvenance(event, shadowedSeqs) {
	const raw = event.sourceEventSeqs;
	if (event.type === "assistant/message" && raw !== void 0) throw new Error("assistant/message embeds its source stream and cannot carry sourceEventSeqs");
	const sources = /* @__PURE__ */ new Set();
	if (raw !== void 0) {
		if (!Array.isArray(raw)) throw new Error(`sourceEventSeqs on event at seq ${event.seq} must be an array when present`);
		if (raw.length === 0) throw new Error("sourceEventSeqs must not be empty");
		let nonEarlierSource;
		for (const source of raw) {
			if (!isEventSeq(source)) throw new Error(`session event "${event.type}" sourceEventSeqs must densely contain non-negative safe integers`);
			sources.add(source);
			if (nonEarlierSource === void 0 && source >= event.seq) nonEarlierSource = source;
		}
		if (sources.size !== raw.length) throw new Error("sourceEventSeqs must not contain duplicates");
		if (nonEarlierSource !== void 0) throw new Error(`sourceEventSeqs must reference earlier events: ${nonEarlierSource} >= current seq ${event.seq}`);
	}
	const missing = shadowedSeqs.filter((seq) => !sources.has(seq));
	if (missing.length > 0) throw new Error(`surface replace: sourceEventSeqs must include every shadowed surface node; missing ${missing.join(", ")}`);
}
/**
* Validate one event's surface metadata without checking membership in a log or surface.
* @param event - event whose marker and source sequence values are inspected.
* Unknown ignorable records retain opaque metadata and never change the surface.
* @returns the validated operation, or undefined for a log-only or unknown ignorable event.
* @throws when metadata violates event-local eligibility, marker, or source-sequence rules.
*/
function validateSurfaceMetadata(event) {
	const op = surfaceOpOf(event);
	if (op !== void 0 && op !== "append" && (op.startSeq >= event.seq || op.endSeq >= event.seq)) throw new Error(`surface replace at seq ${event.seq}: startSeq and endSeq must reference earlier events`);
	if (op !== void 0) assertProvenance(event, []);
	return op;
}
//#endregion
//#region ../session-controller/lib/types/client/session-wire-event.js
/** Event-local acceptance for raw Session journal responses; payloads remain owner-defined JSON. */
/**
* Reject non-current envelopes and unknown required events without stripping wire fields.
* Range membership and source existence require the durable log and remain Host-owned.
* @param value - one event received in a follow frame or history page.
* @returns nothing after narrowing the accepted event envelope.
* @throws when the type is unsupported or the envelope or event-local metadata is invalid.
*/
function assertSessionWireEvent(value) {
	const subject = "session wire event";
	if (typeof value !== "object" || value === null || Array.isArray(value)) throw new Error(`${subject} must be an object`);
	const event = value;
	for (const key of Object.keys(event)) switch (key) {
		case "type":
		case "seq":
		case "time":
		case "data":
		case "ignorable":
		case "surfaceOp":
		case "sourceEventSeqs": break;
		default: throw new Error(`${subject} has unexpected field ${key}`);
	}
	const seq = event["seq"];
	if (typeof event["type"] !== "string" || typeof seq !== "number" || !Number.isSafeInteger(seq) || seq < 0 || Object.is(seq, -0) || typeof event["time"] !== "number" || !Number.isSafeInteger(event["time"]) || !Object.hasOwn(event, "data") || event["data"] === void 0 || Object.hasOwn(event, "ignorable") && event["ignorable"] !== true) throw new Error(`${subject} has an invalid envelope`);
	if (!KNOWN_SESSION_EVENT_TYPES.has(event["type"]) && event["ignorable"] !== true) throw new Error(`${subject} type ${JSON.stringify(event["type"])} is unknown to this client and is not marked ignorable`);
	const current = event;
	validateSurfaceMetadata(current);
	validateSessionEventData(current, subject);
}
//#endregion
//#region ../session-controller/lib/types/client/transport.js
/** Session-specific adapters for Gateway-owned Remote stream lifecycles. */
function toSessionJournalChange(change) {
	switch (change.type) {
		case "replace":
		case "prepend": return {
			...change,
			entries: historyEntries(change.entries)
		};
		case "append": return {
			type: "append",
			entry: change.entry
		};
		case "notification": return {
			type: "assistant-stream",
			frame: change.notification
		};
	}
}
/**
* Create the Host-wide Session control snapshot stream.
* @param remote - generated Session namespace and Gateway stream factory.
* @param options - Session state destinations.
* @returns an unstarted stream owned by the Client Session runtime.
*/
function createSessionControlStream(remote, options) {
	return new RemoteSnapshotStream(remote.$stream({
		name: "session control stream",
		open: (signal) => remote.session.control(signal),
		ended: (accepted) => accepted ? new RemoteStreamCarrierError("session control stream ended without a terminal result") : /* @__PURE__ */ new Error("session control stream ended before its opening snapshot"),
		...options.carrierFailed === void 0 ? {} : { carrierFailed: options.carrierFailed }
	}), {
		name: "session control stream",
		isSnapshot: (frame) => frame.type === "baseline",
		replace: options.accept,
		update: options.accept,
		failed: options.failed
	});
}
/** Gateway-owned event journal bound to one ordinary or direct-subagent Session address. */
var SessionEventStream = class extends RemoteJournalStream {
	remote;
	address;
	/**
	* @param remote - generated Session namespace and Gateway stream factory.
	* @param address - durable ordinary-Session or direct-subagent address.
	* @param options - Session event-window destinations.
	*/
	constructor(remote, address, options) {
		super(remote, {
			name: "session event stream",
			emptyCursor: -1,
			entries: (page) => page.records,
			hasMore: (page) => page.hasMore,
			first: historyRecordFirstSeq,
			last: historyRecordLastSeq,
			compare: (left, right) => left - right,
			follows: (left, right) => right === left + 1,
			publish: (change) => {
				options.publish(toSessionJournalChange(change));
			},
			...options.carrierFailed === void 0 ? {} : { carrierFailed: options.carrierFailed },
			failed: options.failed
		});
		this.remote = remote;
		this.address = address;
	}
	/** @inheritdoc */
	async *follow(request, signal) {
		let assistantRevision;
		for await (const frame of this.remote.session.follow({
			address: this.address,
			assistantStream: true,
			...request.maxMessages === void 0 ? {} : { maxMessages: request.maxMessages }
		}, signal)) {
			if (frame.type === "snapshot") {
				const version = frame.header.version;
				if (version !== 3) throw new Error(`unsupported Session format ${String(version)}; this client requires ${String(3)}`);
				for (const record of frame.records) assertSessionWireEvent(record.event);
				if (frame.assistantStream === void 0) throw new RemoteError("gateway/internal", "session assistant stream omitted its opted-in opening baseline", {});
				assistantRevision = frame.assistantStream.revision;
				yield {
					type: "opened",
					cursor: frame.cursor,
					page: {
						records: frame.records,
						hasMore: frame.hasMore,
						projections: frame.projections,
						assistantStream: frame.assistantStream
					}
				};
				continue;
			}
			if (frame.type === "assistant-stream") {
				const expected = (assistantRevision ?? 0) + 1;
				if (frame.frame.revision !== expected) throw new RemoteStreamCarrierError(`session assistant stream skipped revision ${String(expected)}`);
				assistantRevision = frame.frame.revision;
				yield {
					type: "notification",
					notification: frame.frame
				};
				continue;
			}
			assertSessionWireEvent(frame.event);
			yield {
				type: "entry",
				entry: frame
			};
		}
	}
	/** @inheritdoc */
	async readPage(request, throughSeq, signal) {
		const result = await this.remote.session.page({
			address: this.address,
			throughSeq,
			...request
		}, signal);
		if (!result.ok) throw result.error;
		for (const record of result.value.records) assertSessionWireEvent(record.event);
		return result.value;
	}
	/** @inheritdoc */
	repairRequest(request) {
		return request.maxMessages === void 0 ? {} : { maxMessages: request.maxMessages };
	}
};
//#endregion
//#region ../../util/workspace-path/lib/index.js
/**
* Read the final non-empty segment of a Workspace path for display.
* Workspace-label surfaces use this helper instead of deriving another basename.
* @param path - Workspace directory path using POSIX or Windows separators.
* @returns the final segment, or an empty string for a separator-only path.
*/
function workspaceTitleOf(path) {
	const trimmed = path.replace(/[/\\]+$/, "");
	const separator = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
	return trimmed.slice(separator + 1);
}
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/zustand@4.4.7_@types+react@18.3.31_immer@10.2.0_react@18.3.1/node_modules/zustand/esm/vanilla.mjs
const createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const destroy = () => {
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected.");
		listeners.clear();
	};
	const api = {
		setState,
		getState,
		subscribe,
		destroy
	};
	state = createState(setState, getState, api);
	return api;
};
const createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/zustand@4.4.7_@types+react@18.3.31_immer@10.2.0_react@18.3.1/node_modules/zustand/esm/middleware.mjs
const subscribeWithSelectorImpl = (fn) => (set, get, api) => {
	const origSubscribe = api.subscribe;
	api.subscribe = (selector, optListener, options) => {
		let listener = selector;
		if (optListener) {
			const equalityFn = (options == null ? void 0 : options.equalityFn) || Object.is;
			let currentSlice = selector(api.getState());
			listener = (state) => {
				const nextSlice = selector(state);
				if (!equalityFn(currentSlice, nextSlice)) {
					const previousSlice = currentSlice;
					optListener(currentSlice = nextSlice, previousSlice);
				}
			};
			if (options == null ? void 0 : options.fireImmediately) optListener(currentSlice, currentSlice);
		}
		return origSubscribe(listener);
	};
	return fn(set, get, api);
};
const subscribeWithSelector = subscribeWithSelectorImpl;
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/immer@10.2.0/node_modules/immer/dist/immer.mjs
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");
function die(error, ...args) {
	throw new Error(`[Immer] minified error nr: ${error}. Full error at: https://bit.ly/3cXEKWf`);
}
var getPrototypeOf = Object.getPrototypeOf;
function isDraft(value) {
	return !!value && !!value[DRAFT_STATE];
}
function isDraftable(value) {
	if (!value) return false;
	return isPlainObject$1(value) || Array.isArray(value) || !!value[DRAFTABLE] || !!value.constructor?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = Object.prototype.constructor.toString();
var cachedCtorStrings = /* @__PURE__ */ new WeakMap();
function isPlainObject$1(value) {
	if (!value || typeof value !== "object") return false;
	const proto = Object.getPrototypeOf(value);
	if (proto === null || proto === Object.prototype) return true;
	const Ctor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
	if (Ctor === Object) return true;
	if (typeof Ctor !== "function") return false;
	let ctorString = cachedCtorStrings.get(Ctor);
	if (ctorString === void 0) {
		ctorString = Function.toString.call(Ctor);
		cachedCtorStrings.set(Ctor, ctorString);
	}
	return ctorString === objectCtorString;
}
function each(obj, iter, strict = true) {
	if (getArchtype(obj) === 0) (strict ? Reflect.ownKeys(obj) : Object.keys(obj)).forEach((key) => {
		iter(key, obj[key], obj);
	});
	else obj.forEach((entry, index) => iter(index, entry, obj));
}
function getArchtype(thing) {
	const state = thing[DRAFT_STATE];
	return state ? state.type_ : Array.isArray(thing) ? 1 : isMap(thing) ? 2 : isSet(thing) ? 3 : 0;
}
function has(thing, prop) {
	return getArchtype(thing) === 2 ? thing.has(prop) : Object.prototype.hasOwnProperty.call(thing, prop);
}
function set(thing, propOrOldValue, value) {
	const t = getArchtype(thing);
	if (t === 2) thing.set(propOrOldValue, value);
	else if (t === 3) thing.add(value);
	else thing[propOrOldValue] = value;
}
function is$1(x, y) {
	if (x === y) return x !== 0 || 1 / x === 1 / y;
	else return x !== x && y !== y;
}
function isMap(target) {
	return target instanceof Map;
}
function isSet(target) {
	return target instanceof Set;
}
function latest(state) {
	return state.copy_ || state.base_;
}
function shallowCopy(base, strict) {
	if (isMap(base)) return new Map(base);
	if (isSet(base)) return new Set(base);
	if (Array.isArray(base)) return Array.prototype.slice.call(base);
	const isPlain = isPlainObject$1(base);
	if (strict === true || strict === "class_only" && !isPlain) {
		const descriptors = Object.getOwnPropertyDescriptors(base);
		delete descriptors[DRAFT_STATE];
		let keys = Reflect.ownKeys(descriptors);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			const desc = descriptors[key];
			if (desc.writable === false) {
				desc.writable = true;
				desc.configurable = true;
			}
			if (desc.get || desc.set) descriptors[key] = {
				configurable: true,
				writable: true,
				enumerable: desc.enumerable,
				value: base[key]
			};
		}
		return Object.create(getPrototypeOf(base), descriptors);
	} else {
		const proto = getPrototypeOf(base);
		if (proto !== null && isPlain) return { ...base };
		return Object.assign(Object.create(proto), base);
	}
}
function freeze(obj, deep = false) {
	if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
	if (getArchtype(obj) > 1) Object.defineProperties(obj, {
		set: dontMutateMethodOverride,
		add: dontMutateMethodOverride,
		clear: dontMutateMethodOverride,
		delete: dontMutateMethodOverride
	});
	Object.freeze(obj);
	if (deep) Object.values(obj).forEach((value) => freeze(value, true));
	return obj;
}
function dontMutateFrozenCollections() {
	die(2);
}
var dontMutateMethodOverride = { value: dontMutateFrozenCollections };
function isFrozen(obj) {
	if (obj === null || typeof obj !== "object") return true;
	return Object.isFrozen(obj);
}
var plugins = {};
function getPlugin(pluginKey) {
	const plugin = plugins[pluginKey];
	if (!plugin) die(0, pluginKey);
	return plugin;
}
var currentScope;
function getCurrentScope() {
	return currentScope;
}
function createScope$1(parent_, immer_) {
	return {
		drafts_: [],
		parent_,
		immer_,
		canAutoFreeze_: true,
		unfinalizedDrafts_: 0
	};
}
function usePatchesInScope(scope, patchListener) {
	if (patchListener) {
		getPlugin("Patches");
		scope.patches_ = [];
		scope.inversePatches_ = [];
		scope.patchListener_ = patchListener;
	}
}
function revokeScope(scope) {
	leaveScope(scope);
	scope.drafts_.forEach(revokeDraft);
	scope.drafts_ = null;
}
function leaveScope(scope) {
	if (scope === currentScope) currentScope = scope.parent_;
}
function enterScope(immer2) {
	return currentScope = createScope$1(currentScope, immer2);
}
function revokeDraft(draft) {
	const state = draft[DRAFT_STATE];
	if (state.type_ === 0 || state.type_ === 1) state.revoke_();
	else state.revoked_ = true;
}
function processResult(result, scope) {
	scope.unfinalizedDrafts_ = scope.drafts_.length;
	const baseDraft = scope.drafts_[0];
	if (result !== void 0 && result !== baseDraft) {
		if (baseDraft[DRAFT_STATE].modified_) {
			revokeScope(scope);
			die(4);
		}
		if (isDraftable(result)) {
			result = finalize(scope, result);
			if (!scope.parent_) maybeFreeze(scope, result);
		}
		if (scope.patches_) getPlugin("Patches").generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope.patches_, scope.inversePatches_);
	} else result = finalize(scope, baseDraft, []);
	revokeScope(scope);
	if (scope.patches_) scope.patchListener_(scope.patches_, scope.inversePatches_);
	return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value, path) {
	if (isFrozen(value)) return value;
	const useStrictIteration = rootScope.immer_.shouldUseStrictIteration();
	const state = value[DRAFT_STATE];
	if (!state) {
		each(value, (key, childValue) => finalizeProperty(rootScope, state, value, key, childValue, path), useStrictIteration);
		return value;
	}
	if (state.scope_ !== rootScope) return value;
	if (!state.modified_) {
		maybeFreeze(rootScope, state.base_, true);
		return state.base_;
	}
	if (!state.finalized_) {
		state.finalized_ = true;
		state.scope_.unfinalizedDrafts_--;
		const result = state.copy_;
		let resultEach = result;
		let isSet2 = false;
		if (state.type_ === 3) {
			resultEach = new Set(result);
			result.clear();
			isSet2 = true;
		}
		each(resultEach, (key, childValue) => finalizeProperty(rootScope, state, result, key, childValue, path, isSet2), useStrictIteration);
		maybeFreeze(rootScope, result, false);
		if (path && rootScope.patches_) getPlugin("Patches").generatePatches_(state, path, rootScope.patches_, rootScope.inversePatches_);
	}
	return state.copy_;
}
function finalizeProperty(rootScope, parentState, targetObject, prop, childValue, rootPath, targetIsSet) {
	if (childValue == null) return;
	if (typeof childValue !== "object" && !targetIsSet) return;
	const childIsFrozen = isFrozen(childValue);
	if (childIsFrozen && !targetIsSet) return;
	if (isDraft(childValue)) {
		const res = finalize(rootScope, childValue, rootPath && parentState && parentState.type_ !== 3 && !has(parentState.assigned_, prop) ? rootPath.concat(prop) : void 0);
		set(targetObject, prop, res);
		if (isDraft(res)) rootScope.canAutoFreeze_ = false;
		else return;
	} else if (targetIsSet) targetObject.add(childValue);
	if (isDraftable(childValue) && !childIsFrozen) {
		if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) return;
		if (parentState && parentState.base_ && parentState.base_[prop] === childValue && childIsFrozen) return;
		finalize(rootScope, childValue);
		if ((!parentState || !parentState.scope_.parent_) && typeof prop !== "symbol" && (isMap(targetObject) ? targetObject.has(prop) : Object.prototype.propertyIsEnumerable.call(targetObject, prop))) maybeFreeze(rootScope, childValue);
	}
}
function maybeFreeze(scope, value, deep = false) {
	if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) freeze(value, deep);
}
function createProxyProxy(base, parent) {
	const isArray = Array.isArray(base);
	const state = {
		type_: isArray ? 1 : 0,
		scope_: parent ? parent.scope_ : getCurrentScope(),
		modified_: false,
		finalized_: false,
		assigned_: {},
		parent_: parent,
		base_: base,
		draft_: null,
		copy_: null,
		revoke_: null,
		isManual_: false
	};
	let target = state;
	let traps = objectTraps;
	if (isArray) {
		target = [state];
		traps = arrayTraps;
	}
	const { revoke, proxy } = Proxy.revocable(target, traps);
	state.draft_ = proxy;
	state.revoke_ = revoke;
	return proxy;
}
var objectTraps = {
	get(state, prop) {
		if (prop === DRAFT_STATE) return state;
		const source = latest(state);
		if (!has(source, prop)) return readPropFromProto(state, source, prop);
		const value = source[prop];
		if (state.finalized_ || !isDraftable(value)) return value;
		if (value === peek(state.base_, prop)) {
			prepareCopy(state);
			return state.copy_[prop] = createProxy(value, state);
		}
		return value;
	},
	has(state, prop) {
		return prop in latest(state);
	},
	ownKeys(state) {
		return Reflect.ownKeys(latest(state));
	},
	set(state, prop, value) {
		const desc = getDescriptorFromProto(latest(state), prop);
		if (desc?.set) {
			desc.set.call(state.draft_, value);
			return true;
		}
		if (!state.modified_) {
			const current2 = peek(latest(state), prop);
			const currentState = current2?.[DRAFT_STATE];
			if (currentState && currentState.base_ === value) {
				state.copy_[prop] = value;
				state.assigned_[prop] = false;
				return true;
			}
			if (is$1(value, current2) && (value !== void 0 || has(state.base_, prop))) return true;
			prepareCopy(state);
			markChanged(state);
		}
		if (state.copy_[prop] === value && (value !== void 0 || prop in state.copy_) || Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
		state.copy_[prop] = value;
		state.assigned_[prop] = true;
		return true;
	},
	deleteProperty(state, prop) {
		if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
			state.assigned_[prop] = false;
			prepareCopy(state);
			markChanged(state);
		} else delete state.assigned_[prop];
		if (state.copy_) delete state.copy_[prop];
		return true;
	},
	getOwnPropertyDescriptor(state, prop) {
		const owner = latest(state);
		const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
		if (!desc) return desc;
		return {
			writable: true,
			configurable: state.type_ !== 1 || prop !== "length",
			enumerable: desc.enumerable,
			value: owner[prop]
		};
	},
	defineProperty() {
		die(11);
	},
	getPrototypeOf(state) {
		return getPrototypeOf(state.base_);
	},
	setPrototypeOf() {
		die(12);
	}
};
var arrayTraps = {};
each(objectTraps, (key, fn) => {
	arrayTraps[key] = function() {
		arguments[0] = arguments[0][0];
		return fn.apply(this, arguments);
	};
});
arrayTraps.deleteProperty = function(state, prop) {
	return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function(state, prop, value) {
	return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
	const state = draft[DRAFT_STATE];
	return (state ? latest(state) : draft)[prop];
}
function readPropFromProto(state, source, prop) {
	const desc = getDescriptorFromProto(source, prop);
	return desc ? `value` in desc ? desc.value : desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
	if (!(prop in source)) return void 0;
	let proto = getPrototypeOf(source);
	while (proto) {
		const desc = Object.getOwnPropertyDescriptor(proto, prop);
		if (desc) return desc;
		proto = getPrototypeOf(proto);
	}
}
function markChanged(state) {
	if (!state.modified_) {
		state.modified_ = true;
		if (state.parent_) markChanged(state.parent_);
	}
}
function prepareCopy(state) {
	if (!state.copy_) state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
}
var Immer2 = class {
	constructor(config) {
		this.autoFreeze_ = true;
		this.useStrictShallowCopy_ = false;
		this.useStrictIteration_ = true;
		/**
		* The `produce` function takes a value and a "recipe function" (whose
		* return value often depends on the base state). The recipe function is
		* free to mutate its first argument however it wants. All mutations are
		* only ever applied to a __copy__ of the base state.
		*
		* Pass only a function to create a "curried producer" which relieves you
		* from passing the recipe function every time.
		*
		* Only plain objects and arrays are made mutable. All other objects are
		* considered uncopyable.
		*
		* Note: This function is __bound__ to its `Immer` instance.
		*
		* @param {any} base - the initial state
		* @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
		* @param {Function} patchListener - optional function that will be called with all the patches produced here
		* @returns {any} a new state, or the initial state if nothing was modified
		*/
		this.produce = (base, recipe, patchListener) => {
			if (typeof base === "function" && typeof recipe !== "function") {
				const defaultBase = recipe;
				recipe = base;
				const self = this;
				return function curriedProduce(base2 = defaultBase, ...args) {
					return self.produce(base2, (draft) => recipe.call(this, draft, ...args));
				};
			}
			if (typeof recipe !== "function") die(6);
			if (patchListener !== void 0 && typeof patchListener !== "function") die(7);
			let result;
			if (isDraftable(base)) {
				const scope = enterScope(this);
				const proxy = createProxy(base, void 0);
				let hasError = true;
				try {
					result = recipe(proxy);
					hasError = false;
				} finally {
					if (hasError) revokeScope(scope);
					else leaveScope(scope);
				}
				usePatchesInScope(scope, patchListener);
				return processResult(result, scope);
			} else if (!base || typeof base !== "object") {
				result = recipe(base);
				if (result === void 0) result = base;
				if (result === NOTHING) result = void 0;
				if (this.autoFreeze_) freeze(result, true);
				if (patchListener) {
					const p = [];
					const ip = [];
					getPlugin("Patches").generateReplacementPatches_(base, result, p, ip);
					patchListener(p, ip);
				}
				return result;
			} else die(1, base);
		};
		this.produceWithPatches = (base, recipe) => {
			if (typeof base === "function") return (state, ...args) => this.produceWithPatches(state, (draft) => base(draft, ...args));
			let patches, inversePatches;
			return [
				this.produce(base, recipe, (p, ip) => {
					patches = p;
					inversePatches = ip;
				}),
				patches,
				inversePatches
			];
		};
		if (typeof config?.autoFreeze === "boolean") this.setAutoFreeze(config.autoFreeze);
		if (typeof config?.useStrictShallowCopy === "boolean") this.setUseStrictShallowCopy(config.useStrictShallowCopy);
		if (typeof config?.useStrictIteration === "boolean") this.setUseStrictIteration(config.useStrictIteration);
	}
	createDraft(base) {
		if (!isDraftable(base)) die(8);
		if (isDraft(base)) base = current(base);
		const scope = enterScope(this);
		const proxy = createProxy(base, void 0);
		proxy[DRAFT_STATE].isManual_ = true;
		leaveScope(scope);
		return proxy;
	}
	finishDraft(draft, patchListener) {
		const state = draft && draft[DRAFT_STATE];
		if (!state || !state.isManual_) die(9);
		const { scope_: scope } = state;
		usePatchesInScope(scope, patchListener);
		return processResult(void 0, scope);
	}
	/**
	* Pass true to automatically freeze all copies created by Immer.
	*
	* By default, auto-freezing is enabled.
	*/
	setAutoFreeze(value) {
		this.autoFreeze_ = value;
	}
	/**
	* Pass true to enable strict shallow copy.
	*
	* By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
	*/
	setUseStrictShallowCopy(value) {
		this.useStrictShallowCopy_ = value;
	}
	/**
	* Pass false to use faster iteration that skips non-enumerable properties
	* but still handles symbols for compatibility.
	*
	* By default, strict iteration is enabled (includes all own properties).
	*/
	setUseStrictIteration(value) {
		this.useStrictIteration_ = value;
	}
	shouldUseStrictIteration() {
		return this.useStrictIteration_;
	}
	applyPatches(base, patches) {
		let i;
		for (i = patches.length - 1; i >= 0; i--) {
			const patch = patches[i];
			if (patch.path.length === 0 && patch.op === "replace") {
				base = patch.value;
				break;
			}
		}
		if (i > -1) patches = patches.slice(i + 1);
		const applyPatchesImpl = getPlugin("Patches").applyPatches_;
		if (isDraft(base)) return applyPatchesImpl(base, patches);
		return this.produce(base, (draft) => applyPatchesImpl(draft, patches));
	}
};
function createProxy(value, parent) {
	const draft = isMap(value) ? getPlugin("MapSet").proxyMap_(value, parent) : isSet(value) ? getPlugin("MapSet").proxySet_(value, parent) : createProxyProxy(value, parent);
	(parent ? parent.scope_ : getCurrentScope()).drafts_.push(draft);
	return draft;
}
function current(value) {
	if (!isDraft(value)) die(10, value);
	return currentImpl(value);
}
function currentImpl(value) {
	if (!isDraftable(value) || isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	let copy;
	let strict = true;
	if (state) {
		if (!state.modified_) return state.base_;
		state.finalized_ = true;
		copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
		strict = state.scope_.immer_.shouldUseStrictIteration();
	} else copy = shallowCopy(value, true);
	each(copy, (key, childValue) => {
		set(copy, key, currentImpl(childValue));
	}, strict);
	if (state) state.finalized_ = false;
	return copy;
}
var produce = new Immer2().produce;
//#endregion
//#region ../../client/store/lib/types/index.js
/**
* React-free snapshot store engine (zustand vanilla + immer + subscribeWithSelector +
* rafFlush middleware + opt-in persist + dev freeze) plus the declarative
* shell over it: {@link defineStore} bakes an init/persist/actions literal
* into a {@link StoreHandle}, the registration-side store seat of slot
* terminals. Engine products are bare observables — subscribe/getSnapshot/
* update/set, NO selector hook. Hook synthesis is ui-renderer's (the one
* uSES bridge, cached per source at the binding site).
*/
/**
* Notify an observer set without allowing one callback to starve the rest.
* @param listeners - current observer callbacks; copied before dispatch.
* @param label - diagnostic owner prefix.
* @param args - callback arguments.
*/
function notifySubscribers(listeners, label, ...args) {
	for (const listener of [...listeners]) try {
		listener(...args);
	} catch (error) {
		console.error(`${label} subscriber failed:`, error);
	}
}
/** Batches subscriber notification into one flush per animation frame. */
function rafBatch(notify) {
	const schedule = typeof requestAnimationFrame === "function" ? (fn) => {
		requestAnimationFrame(() => {
			fn();
		});
	} : (fn) => {
		queueMicrotask(fn);
	};
	let scheduled = false;
	return () => {
		if (scheduled) return;
		scheduled = true;
		schedule(() => {
			scheduled = false;
			notify();
		});
	};
}
/**
* Create a snapshot store.
*
* Flush default is 'sync' (controlled inputs need same-tick echo); frame-driven
* stores opt into 'raf', where a frame's worth of updates coalesces into one
* notification. Known raf-mode tradeoff: a component mounting mid-frame reads
* fresh state while existing subscribers hear it next flush — transient
* frame-level skew, same nature as the object layer's microtask batching.
*
* @param init - initial state.
* @param opts - flush mode and opt-in persistence (localStorage, keyed by name).
* @returns the store.
*/
function createSnapshotStore(init, opts) {
	const withSelector = subscribeWithSelector(() => init);
	const api = createStore()(withSelector);
	if (opts?.persist) attachPersistence(api, opts.persist.name);
	let subscribe = (fn) => api.subscribe(() => {
		notifySubscribers([fn], "[client-store]");
	});
	if (opts?.flush === "raf") {
		const listeners = /* @__PURE__ */ new Set();
		const flush = rafBatch(() => {
			notifySubscribers(listeners, "[client-store]");
		});
		api.subscribe(flush);
		subscribe = (fn) => {
			listeners.add(fn);
			return () => {
				listeners.delete(fn);
			};
		};
	}
	return {
		getSnapshot: () => api.getState(),
		subscribe: (fn) => subscribe(fn),
		update: (mutator) => {
			api.setState(produce(api.getState(), (draft) => {
				mutator(draft);
			}), true);
		},
		set: (next) => {
			api.setState(devFreeze(next), true);
		}
	};
}
/**
* Whole-value JSON persistence to localStorage. Hand-rolled instead of the
* zustand persist middleware: its write path spreads state into an object
* (`partialize({ ...get() })`), exploding primitive state (a persisted string
* draft becomes {0:'h',1:'e',...}) — not fixable via merge/deserialize options
* because the corruption happens before serialization. Storage failures
* (quota, private mode) only disable persistence, never break the store.
*/
function attachPersistence(api, name) {
	if (typeof localStorage === "undefined") return;
	try {
		const raw = localStorage.getItem(name);
		if (raw !== null) api.setState(devFreeze(JSON.parse(raw)), true);
	} catch (error) {
		console.error(`snapshot store '${name}' rehydration failed:`, error);
	}
	api.subscribe((state) => {
		try {
			localStorage.setItem(name, JSON.stringify(state));
		} catch (error) {
			console.error(`snapshot store '${name}' persistence failed:`, error);
		}
	});
}
/** Deep-freeze draftable wholesale-set state outside production: set() bypasses immer's freeze. */
function devFreeze(value) {
	return value;
}
//#endregion
//#region ../session-controller/lib/types/client/scope.js
/**
* Client Agent-scope primitive: mint a Cordis context tagged with the owning
* Agent's identity. The mechanism mirrors the host `dsh-scope` architecture
* (no-op plugin fiber + context tag + `Context.filter` routing predicate);
* the shape deliberately diverges: the filter lives on the actx itself
* instead of a separate carrier object, so scoped dispatch is plain cordis —
* `actx.bail(actx, event, payload)` / `actx.emit(actx, ...)` — with no
* wrapper. The host needs a detached carrier because its dispatch subject is
* the business Agent object; client scope events carry only ids, so the
* actx is the natural subject. The second divergence stands: the scope key
* is the branded `SessionId` (value compared), not an object identity — the
* agent and its session share one id (1:1, same axis; no separate AgentId
* brand), and a client scope's identity IS that wire id. Third divergence,
* deliberate: the client scopes the Agent IDENTITY, not a live Agent object
* — a cold session's host Agent is already disposed while its client actx
* stays alive for history viewing.
*/
/** Context tag written by {@link createScope}. */
const kScope = Symbol("dsh.client.scope");
/** Shared no-op plugin backing each Agent scope fiber. */
function agentScope() {}
/**
* Mint an Agent scope under `ctx`: a no-op plugin fiber whose context
* carries the agent tag and the dispatch filter — untagged listeners are
* admitted globally, tagged listeners only for a matching agent.
* Registrations through the returned ctx dispose with the fiber.
* @param ctx - client root context the scope fiber mounts under.
* @param key - owning agent identity (the routing tag; agent id === session id).
* @returns the tagged context and its backing fiber.
*/
function createScope(ctx, key) {
	const fiber = ctx.plugin(agentScope);
	return {
		fiber,
		ctx: fiber.ctx.extend({
			[kScope]: key,
			[Context.filter](listenerCtx) {
				const tag = scopeOf(listenerCtx);
				return tag === void 0 || tag === key;
			}
		})
	};
}
/**
* Read the nearest agent tag inherited by a context.
* @param ctx - any client context.
* @returns its agent identity (the session id), or undefined for root contexts.
*/
function scopeOf(ctx) {
	return ctx[kScope];
}
//#endregion
//#region ../session-controller/lib/types/client/ordered-baseline.js
/**
* Merge an authoritative baseline without moving identities already visible to
* the client. Baseline-only identities are inserted relative to the nearest
* following known identity; identities absent from the baseline are removed.
*
* @param current - the established client order.
* @param baseline - the latest authoritative rows.
* @param keyOf - stable identity selector.
* @returns baseline-valued rows with the established relative order retained.
*/
function mergeOrderedBaseline(current, baseline, keyOf) {
	const baselineByKey = /* @__PURE__ */ new Map();
	for (const value of baseline) baselineByKey.set(keyOf(value), value);
	const merged = current.map((value) => baselineByKey.get(keyOf(value))).filter((value) => value !== void 0);
	const mergedKeys = new Set(merged.map(keyOf));
	for (let index = 0; index < baseline.length; index++) {
		const value = baseline[index];
		/* v8 ignore next -- dense-array guard: index is bounded by baseline.length. */
		if (value === void 0 || mergedKeys.has(keyOf(value))) continue;
		let insertion = merged.length;
		for (let following = index + 1; following < baseline.length; following++) {
			const candidate = baseline[following];
			/* v8 ignore next -- dense-array guard: following is bounded by baseline.length. */
			if (candidate === void 0) continue;
			const known = merged.findIndex((item) => keyOf(item) === keyOf(candidate));
			if (known !== -1) {
				insertion = known;
				break;
			}
		}
		merged.splice(insertion, 0, value);
		mergedKeys.add(keyOf(value));
	}
	return merged;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/lineage.js
/**
* Summaries -> flat list with lineage indentation. Root and sibling order
* follows the established input order; this projection never re-sorts a
* hydrated list from mutable timestamps.
* @param summaries - the host's session.list items.
* @param completed - sessions with a pending completion reminder (manager-owned live fact; absent = false).
* @returns display rows in render order.
*/
function flattenLineage(summaries, completed) {
	const byId = /* @__PURE__ */ new Map();
	for (const s of summaries) byId.set(s.sessionId, s);
	const children = /* @__PURE__ */ new Map();
	const roots = [];
	for (const s of summaries) if (s.parentSessionId !== void 0 && byId.has(s.parentSessionId)) {
		const list = children.get(s.parentSessionId) ?? [];
		list.push(s);
		children.set(s.parentSessionId, list);
	} else roots.push(s);
	const out = [];
	const visited = /* @__PURE__ */ new Set();
	const walk = (s, depth) => {
		if (visited.has(s.sessionId)) {
			console.warn(`[session-controller] lineage cycle at ${s.sessionId}; emitting as root`);
			return;
		}
		visited.add(s.sessionId);
		out.push({
			...s,
			completed: completed?.has(s.sessionId) ?? false,
			depth
		});
		const kids = children.get(s.sessionId);
		if (kids === void 0) return;
		for (const kid of kids) walk(kid, depth + 1);
	};
	for (const root of roots) walk(root, 0);
	for (const s of summaries) if (!visited.has(s.sessionId)) walk(s, 0);
	return out;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/notifier.js
/**
* Batches structural updates in microtasks and stream updates by animation
* frame. Reads may rebuild a dirty snapshot without consuming the pending
* subscriber notification.
*/
var Notifier = class {
	rebuild;
	listeners = /* @__PURE__ */ new Set();
	dirty = false;
	notifyPending = false;
	scheduled = "none";
	scheduleGeneration = 0;
	/** @param rebuild - snapshot rebuild function injected by the owner (writes the owner's snapshotCache). */
	constructor(rebuild) {
		this.rebuild = rebuild;
	}
	/**
	* uSES subscription entry.
	* @param listener - change callback.
	* @returns the unsubscribe function.
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	}
	/** Mark the snapshot dirty and notify in a microtask. */
	markDirty() {
		this.dirty = true;
		this.notifyPending = true;
		if (this.scheduled === "microtask") return;
		this.schedule("microtask");
	}
	/** Mark the snapshot dirty and publish cumulative state at most once per frame. */
	markFrameDirty() {
		this.dirty = true;
		this.notifyPending = true;
		if (this.scheduled !== "none") return;
		this.schedule(typeof globalThis.requestAnimationFrame === "function" ? "frame" : "microtask");
	}
	/**
	* Synchronous flush: controlled-input writes must notify in the same tick as
	* onChange, or React rolls the DOM back to the stale value and the caret jumps to the end.
	*/
	notifyNow() {
		this.dirty = true;
		this.notifyPending = true;
		this.invalidateSchedule();
		this.flush();
	}
	/**
	* Pre-getSnapshot check: rebuild synchronously when dirty (read path
	* before first subscribe / while unobserved). Notification stays pending.
	*/
	ensureFresh() {
		if (!this.dirty) return;
		this.dirty = false;
		this.rebuild();
	}
	schedule(kind) {
		const generation = ++this.scheduleGeneration;
		this.scheduled = kind;
		const publish = () => {
			if (generation !== this.scheduleGeneration) return;
			this.scheduled = "none";
			this.flush();
		};
		if (kind === "frame") globalThis.requestAnimationFrame(publish);
		else queueMicrotask(publish);
	}
	invalidateSchedule() {
		this.scheduleGeneration++;
		this.scheduled = "none";
	}
	flush() {
		if (!this.notifyPending) return;
		if (this.listeners.size === 0) return;
		this.notifyPending = false;
		if (this.dirty) {
			this.dirty = false;
			this.rebuild();
		}
		notifySubscribers(this.listeners, "[session-controller]");
	}
};
//#endregion
//#region ../session-controller/lib/types/client/sessions/projection-store.js
/**
* One session's projection values. Framework semantics, uniform across every
* key: a baseline seeds rows at its cut, a push frame updates one row, and in
* both paths a lower-or-equal seq loses — a replayed frame cannot regress a
* value, a stale baseline cannot overwrite a newer frame. A key the store has
* never seen reads `undefined` (capability absent). Faces are identity-stable
* per key (create-on-demand, cached) so the React side binds each exactly
* once; the store-level channel (`subscribeAny`) serves coarse consumers (the
* manager's list projection reads the `title` key).
*/
var ProjectionValueStore = class {
	rows = /* @__PURE__ */ new Map();
	channels = /* @__PURE__ */ new Map();
	valuesCache;
	/** Coarse any-key channel (no snapshot cache to rebuild: reads hit rows directly). */
	anyNotifier = new Notifier(() => {});
	/**
	* Key-addressed bare observable face (the useProjection resolution path).
	* Always defined — absence is an `undefined` snapshot, never a missing
	* face, so a component may subscribe before the key ever carries a value.
	* @param key - projection key.
	* @returns the identity-stable face for this key.
	*/
	faceOf(key) {
		return this.channel(key).face;
	}
	/**
	* Current whole value for a key (erased framework read; typed reads go
	* through `useProjection`'s map lookup).
	* @param key - projection key.
	* @returns the value, or undefined while the key is absent.
	*/
	get(key) {
		return this.rows.get(key)?.value;
	}
	/**
	* Read every current projection value as one reference-stable snapshot.
	* @returns The same frozen value map until a row changes.
	*/
	values() {
		if (this.valuesCache === void 0) this.valuesCache = Object.freeze(Object.fromEntries([...this.rows].map(([key, row]) => [key, row.value])));
		return this.valuesCache;
	}
	/**
	* Subscribe to any-key changes (microtask-batched) — the manager's list
	* rebuild channel.
	* @param listener - change callback.
	* @returns the unsubscribe function.
	*/
	subscribeAny(listener) {
		return this.anyNotifier.subscribe(listener);
	}
	/**
	* Apply one finished value from the Session control stream.
	* @param key - projection key.
	* @param value - whole value computed by the host unit.
	* @param seq - the unit's watermark at emission.
	*/
	apply(key, value, seq) {
		const row = this.rows.get(key);
		if (row !== void 0 && seq <= row.seq) return;
		this.rows.set(key, {
			value,
			seq
		});
		this.changed(key);
	}
	/**
	* Seed from a history tail page's projections block: every carried key
	* lands under the same seq rule as frames; a key the block omits is
	* capability-absent as of the cut — its row clears unless a newer frame
	* already superseded the cut (a stale baseline can neither overwrite nor
	* clear newer values).
	* @param baseline - the response's projections block.
	*/
	seed(baseline) {
		const values = baseline.values;
		for (const key of Object.keys(values)) this.apply(key, values[key], baseline.asOfSeq);
		for (const [key, row] of this.rows) {
			if (Object.hasOwn(values, key)) continue;
			if (row.seq > baseline.asOfSeq) continue;
			this.rows.delete(key);
			this.changed(key);
		}
	}
	/**
	* Drop rows beyond a replacement control baseline. Such rows describe
	* process state the Host lost before persisting it and would otherwise
	* outrank recomputed lower-seq values forever. The caller seeds the new
	* baseline immediately afterward.
	* @param lastSeq - highest durable sequence reflected by the baseline.
	*/
	truncate(lastSeq) {
		for (const [key, row] of this.rows) {
			if (row.seq <= lastSeq) continue;
			this.rows.delete(key);
			this.changed(key);
		}
	}
	changed(key) {
		this.valuesCache = void 0;
		this.channels.get(key)?.notifier.markDirty();
		this.anyNotifier.markDirty();
	}
	channel(key) {
		let channel = this.channels.get(key);
		if (channel === void 0) {
			const notifier = new Notifier(() => {});
			channel = {
				notifier,
				face: {
					getSnapshot: () => this.rows.get(key)?.value,
					subscribe: (listener) => notifier.subscribe(listener)
				}
			};
			this.channels.set(key, channel);
		}
		return channel;
	}
};
//#endregion
//#region ../session-controller/lib/types/client/contract/events.js
/** Observable contiguous Session event window consumed by domain assemblers. */
function leaf(entries) {
	return {
		kind: "leaf",
		entries,
		length: entries.length
	};
}
function concat(left, right) {
	return {
		kind: "concat",
		left,
		right,
		length: left.length + right.length
	};
}
function materialize(node) {
	if (node.kind === "leaf") return node.entries;
	const entries = new Array(node.length);
	const pending = [node];
	let index = 0;
	while (pending.length > 0) {
		const current = pending.pop();
		if (current.kind === "concat") {
			pending.push(current.right, current.left);
			continue;
		}
		for (const entry of current.entries) {
			entries[index] = entry;
			index += 1;
		}
	}
	return entries;
}
function windowSnapshot(node, hasMore, revision, change) {
	let entries;
	return {
		get entries() {
			entries ??= materialize(node);
			return entries;
		},
		hasMore,
		revision,
		change
	};
}
/** Session-owned event feed; every accepted window mutation publishes synchronously. */
var MutableSessionEventSource = class {
	listeners = /* @__PURE__ */ new Set();
	window = leaf([]);
	snapshot = windowSnapshot(this.window, false, 0, {
		kind: "replace",
		entries: []
	});
	/** @returns the cached event-window snapshot. */
	getSnapshot() {
		return this.snapshot;
	}
	/**
	* Subscribe to synchronous window publication.
	* @param listener - invalidation callback.
	* @returns unsubscribe function.
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	}
	/**
	* Replace the complete contiguous window.
	* @param entries - complete window.
	* @param hasMore - whether older history remains.
	*/
	replace(entries, hasMore) {
		this.window = leaf(entries);
		this.publish(hasMore, {
			kind: "replace",
			entries
		});
	}
	/**
	* Prepend one older contiguous page.
	* @param entries - newly loaded older entries.
	* @param hasMore - whether still older history remains.
	*/
	prepend(entries, hasMore) {
		this.window = concat(leaf(entries), this.window);
		this.publish(hasMore, {
			kind: "prepend",
			entries
		});
	}
	/**
	* Append one contiguous live entry.
	* @param entry - live tail entry.
	*/
	append(entry) {
		const entries = [entry];
		this.window = concat(this.window, leaf(entries));
		this.publish(this.snapshot.hasMore, {
			kind: "append",
			entries
		});
	}
	/**
	* Replace one attempt's transient rows with its committed durable settlement.
	* @param attemptId - process-local attempt whose live rows are now redundant.
	* @param entry - durable settlement committed for that attempt.
	*/
	settleAssistant(attemptId, entry) {
		const entries = materialize(this.window).filter((candidate) => candidate.type !== "transient" || candidate.event.data.attemptId !== attemptId);
		if (entry !== void 0) {
			const index = entries.findIndex((candidate) => candidate.event.seq > entry.event.seq);
			if (index < 0) entries.push(entry);
			else entries.splice(index, 0, entry);
		}
		this.window = leaf(entries);
		this.publish(this.snapshot.hasMore, {
			kind: "settle-assistant",
			attemptId,
			...entry === void 0 ? {} : { entry }
		});
	}
	publish(hasMore, change) {
		this.snapshot = windowSnapshot(this.window, hasMore, this.snapshot.revision + 1, change);
		notifySubscribers(this.listeners, "[session-controller] event feed");
	}
};
//#endregion
//#region ../session-controller/lib/types/client/sessions/queue-mirror.js
const QUEUE_PREVIEW_CHARS = 200;
function previewOf(content) {
	const flat = content.filter((block) => block.type !== "image" && block.type !== "file").map((block) => block.type === "text" ? block.text : `[${block.type}]`).join(" ").replace(/\s+/g, " ").trim();
	const chars = Array.from(flat);
	return chars.length > QUEUE_PREVIEW_CHARS ? `${chars.slice(0, QUEUE_PREVIEW_CHARS).join("")}…` : flat;
}
function textOf(content) {
	if (!content.every((block) => block.type === "text")) return null;
	return content.map((block) => block.text).join("");
}
/** Authoritative transient queue projection and durable steering handoff. */
var SessionQueueMirror = class {
	current = [];
	/**
	* Return the current immutable queue projection.
	* @returns current queue rows.
	*/
	snapshot() {
		return this.current;
	}
	/**
	* Replace from one authoritative stream queue frame.
	* @param items - complete host queue snapshot.
	*/
	replace(items) {
		this.current = items.map((item) => {
			const content = item.message.content;
			return {
				id: item.id,
				messageId: item.message.id,
				placement: item.placement,
				...item.rpcId === void 0 ? {} : { rpcId: item.rpcId },
				content,
				preview: previewOf(content),
				text: textOf(content)
			};
		});
	}
	/**
	* Retire a transient steering row once its durable message enters the log.
	* @param event - newly contiguous durable Session event.
	* @returns whether the projection changed.
	*/
	acceptDurable(event) {
		if (event.type !== "user/message") return false;
		const messageId = event.data.id;
		const index = this.current.findIndex((item) => item.placement === "steering" && item.messageId === messageId);
		if (index < 0) return false;
		this.current = this.current.filter((_item, candidate) => candidate !== index);
		return true;
	}
};
//#endregion
//#region ../../util/values/lib/index.js
/** Whether a realm-owned intrinsic prototype is backed by its native constructor. */
function hasIntrinsicConstructor(prototype, name) {
	const constructor = Object.getOwnPropertyDescriptor(prototype, "constructor")?.value;
	if (typeof constructor !== "function") return false;
	try {
		return constructor.name === name && constructor.prototype === prototype && Function.prototype.toString.call(constructor) === `function ${name}() { [native code] }`;
	} catch {
		return false;
	}
}
/** Whether a candidate is one realm's intrinsic `Object.prototype`. */
function isIntrinsicObjectPrototype(value) {
	return Object.getPrototypeOf(value) === null && hasIntrinsicConstructor(value, "Object");
}
/** Whether an array uses one realm's intrinsic `Array.prototype`, not a subclass or forged prototype. */
function hasPlainArrayPrototype(value) {
	const prototype = Object.getPrototypeOf(value);
	if (!Array.isArray(prototype) || !hasIntrinsicConstructor(prototype, "Array")) return false;
	const objectPrototype = Object.getPrototypeOf(prototype);
	return typeof objectPrototype === "object" && objectPrototype !== null && isIntrinsicObjectPrototype(objectPrototype);
}
/** Whether an object is a plain or null-prototype record from any JavaScript realm. */
function hasPlainObjectPrototype(value) {
	const prototype = Object.getPrototypeOf(value);
	return prototype === null || typeof prototype === "object" && isIntrinsicObjectPrototype(prototype);
}
/** Return every JSON-visible object key, or reject own data JSON would discard. */
function enumerableStringKeys(value) {
	const keys = Reflect.ownKeys(value);
	if (keys.some((key) => typeof key !== "string" || !Object.prototype.propertyIsEnumerable.call(value, key))) return void 0;
	return keys;
}
/** Validate lossless JSON iteratively, optionally materializing a detached snapshot. */
function walkJsonValue(value, detach) {
	const ancestors = /* @__PURE__ */ new Set();
	let root;
	const assign = (destination, item) => {
		if (destination === void 0) return;
		if (destination.kind === "root") root = item;
		else if (destination.kind === "array") destination.target[destination.index] = item;
		else Object.defineProperty(destination.target, destination.key, {
			value: item,
			enumerable: true,
			configurable: true,
			writable: true
		});
	};
	const tasks = [{
		kind: "visit",
		value,
		...detach ? { destination: { kind: "root" } } : {}
	}];
	for (let task = tasks.pop(); task !== void 0; task = tasks.pop()) {
		if (task.kind === "leave") {
			ancestors.delete(task.source);
			continue;
		}
		if (task.kind === "array-item") {
			if (!Object.prototype.hasOwnProperty.call(task.source, task.index)) return void 0;
			tasks.push({
				kind: "visit",
				value: task.source[task.index],
				...task.target === void 0 ? {} : { destination: {
					kind: "array",
					target: task.target,
					index: task.index
				} }
			});
			continue;
		}
		if (task.kind === "object-property") {
			tasks.push({
				kind: "visit",
				value: task.source[task.key],
				...task.target === void 0 ? {} : { destination: {
					kind: "object",
					target: task.target,
					key: task.key
				} }
			});
			continue;
		}
		const current = task.value;
		if (current === null) {
			assign(task.destination, null);
			continue;
		}
		if (typeof current === "boolean" || typeof current === "string") {
			assign(task.destination, current);
			continue;
		}
		if (typeof current === "number") {
			if (!Number.isFinite(current) || Object.is(current, -0)) return void 0;
			assign(task.destination, current);
			continue;
		}
		if (typeof current !== "object") return void 0;
		if (ancestors.has(current)) return void 0;
		if (Array.isArray(current)) {
			if (!hasPlainArrayPrototype(current)) return void 0;
			const length = current.length;
			if (Reflect.ownKeys(current).length !== length + 1) return void 0;
			const target = detach ? [] : void 0;
			if (target !== void 0) assign(task.destination, target);
			ancestors.add(current);
			tasks.push({
				kind: "leave",
				source: current
			});
			for (let index = length - 1; index >= 0; index--) tasks.push({
				kind: "array-item",
				source: current,
				index,
				...target === void 0 ? {} : { target }
			});
			continue;
		}
		if (!hasPlainObjectPrototype(current)) return void 0;
		const keys = enumerableStringKeys(current);
		if (keys === void 0) return void 0;
		const target = detach ? {} : void 0;
		if (target !== void 0) assign(task.destination, target);
		ancestors.add(current);
		tasks.push({
			kind: "leave",
			source: current
		});
		for (let index = keys.length - 1; index >= 0; index--) {
			const key = keys[index];
			/* v8 ignore next -- the loop is bounded by the captured key count. */
			if (key === void 0) return void 0;
			tasks.push({
				kind: "object-property",
				source: current,
				key,
				...target === void 0 ? {} : { target }
			});
		}
	}
	return detach ? root : true;
}
/**
* Validate and detach lossless JSON in one read per property.
* @param value - candidate value to validate and detach.
* @returns the detached snapshot, or `undefined` when the value is not losslessly JSON-serializable.
*/
function snapshotJsonValue(value) {
	return walkJsonValue(value, true);
}
/**
* Deep-freeze an object graph in place while leaving live AbortSignal objects mutable.
* @param value - value to freeze.
* @returns the same value after every reachable enumerable child is frozen.
*/
function deepFreeze(value) {
	const seen = /* @__PURE__ */ new WeakSet();
	const pending = [{
		kind: "visit",
		node: value
	}];
	while (pending.length > 0) {
		const task = pending.pop();
		/* v8 ignore next -- the loop condition guarantees one pending task. */
		if (task === void 0) continue;
		if (task.kind === "property") {
			pending.push({
				kind: "visit",
				node: task.source[task.key]
			});
			continue;
		}
		const node = task.node;
		if (node === null || typeof node !== "object") continue;
		if (node instanceof AbortSignal) continue;
		if (seen.has(node)) continue;
		seen.add(node);
		Object.freeze(node);
		const keys = Object.keys(node);
		for (let index = keys.length - 1; index >= 0; index--) {
			const key = keys[index];
			/* v8 ignore next -- the loop is bounded by the captured key count. */
			if (key === void 0) continue;
			pending.push({
				kind: "property",
				source: node,
				key
			});
		}
	}
	return value;
}
//#endregion
//#region ../../llm/llm/lib/types/assistant-stream.js
/**
* Lossless compact representation of one model-stream attempt, plus record-level
* readers that answer common consumer questions without materializing members.
* Readers trust the static record type; expandAssistantStream is the validating
* path for records read at a durable boundary.
*/
function safeTime(value) {
	if (!Number.isSafeInteger(value)) throw new TypeError(`Assistant stream time must be a safe integer, got ${String(value)}`);
	return value;
}
function safeIndex(value, label) {
	if (!Number.isSafeInteger(value) || value < 0 || Object.is(value, -0)) throw new TypeError(`${label} index must be a non-negative safe integer`);
	return value;
}
function snapshotChunk(chunk) {
	const snapshot = snapshotJsonValue(chunk);
	if (snapshot === void 0) throw new TypeError("Assistant stream chunk must be losslessly JSON-serializable");
	return snapshot;
}
/**
* Expand compact records into the exact timed chunk sequence.
* @param stream - compact records from one durable Assistant settlement.
* @returns detached timed chunks with every original delta boundary preserved.
* @throws {TypeError} when a record or reconstructed timestamp is invalid.
*/
function expandAssistantStream(stream) {
	const chunks = [];
	for (const candidate of stream) {
		const record = validateRecord(candidate);
		if (record.type === "chunk") {
			chunks.push({
				time: record.time,
				chunk: record.chunk
			});
			continue;
		}
		const members = record.type === "tool-call-chunks" ? record.args : record.texts;
		let time = record.time0;
		for (let index = 0; index < members.length; index += 1) {
			if (index > 0) time += record.dt[index - 1];
			let chunk;
			if (record.type === "text-chunks") chunk = {
				type: "text-delta",
				index: record.index,
				text: members[index]
			};
			else if (record.type === "reasoning-chunks") chunk = {
				type: "reasoning-delta",
				index: record.index,
				text: members[index]
			};
			else chunk = {
				type: "tool-call-delta",
				index: record.index,
				id: record.id,
				...Object.hasOwn(record, "name") ? { name: record.name } : {},
				argumentsDelta: members[index]
			};
			chunks.push({
				time,
				chunk
			});
		}
	}
	return chunks;
}
function validateRecord(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) throw new TypeError("Assistant stream record must be an object");
	const record = value;
	switch (record.type) {
		case "text-chunks":
		case "reasoning-chunks": {
			exactKeys(record, [
				"type",
				"time0",
				"index",
				"dt",
				"texts"
			], record.type);
			const texts = stringArray(record.texts, `${record.type} texts`);
			if (texts.length === 0) throw new TypeError(`${record.type} texts must be non-empty`);
			validateRun(record, texts.length, record.type);
			return record;
		}
		case "tool-call-chunks": {
			exactKeys(record, Object.hasOwn(record, "name") ? [
				"type",
				"time0",
				"index",
				"dt",
				"id",
				"name",
				"args"
			] : [
				"type",
				"time0",
				"index",
				"dt",
				"id",
				"args"
			], record.type);
			const args = stringArray(record.args, "tool-call-chunks args");
			if (args.length === 0) throw new TypeError("tool-call-chunks args must be non-empty");
			if (typeof record.id !== "string" || record.id.length === 0) throw new TypeError("tool-call-chunks id must be a non-empty string");
			if (record.name !== void 0 && (typeof record.name !== "string" || record.name.length === 0)) throw new TypeError("tool-call-chunks name must be a non-empty string");
			validateRun(record, args.length, record.type);
			return record;
		}
		case "chunk": {
			exactKeys(record, [
				"type",
				"time",
				"chunk"
			], "chunk");
			const time = safeTime(record.time);
			if (typeof record.chunk !== "object" || record.chunk === null || Array.isArray(record.chunk)) throw new TypeError("Assistant stream raw chunk must be a lossless JSON object");
			let chunk;
			try {
				chunk = snapshotChunk(record.chunk);
			} catch (error) {
				throw new TypeError("Assistant stream raw chunk must be a lossless JSON object", { cause: error });
			}
			return deepFreeze({
				type: "chunk",
				time,
				chunk
			});
		}
		default: throw new TypeError(`Unsupported Assistant stream record ${JSON.stringify(record.type)}`);
	}
}
function validateRun(record, members, label) {
	safeTime(record.time0);
	safeIndex(record.index, label);
	if (!Array.isArray(record.dt) || record.dt.some((value) => !Number.isSafeInteger(value))) throw new TypeError(`${label} dt must contain safe integers`);
	if (record.dt.length !== members - 1) throw new TypeError(`${label} dt length must be one less than its members`);
	let time = record.time0;
	for (const gap of record.dt) {
		time += gap;
		if (!Number.isSafeInteger(time)) throw new TypeError(`${label} member times must stay safe integers`);
	}
}
function stringArray(value, label) {
	if (!Array.isArray(value) || value.some((member) => typeof member !== "string")) throw new TypeError(`${label} must be a string array`);
	return value;
}
function exactKeys(record, keys, label) {
	if (Object.keys(record).length !== keys.length || !keys.every((key) => Object.hasOwn(record, key))) throw new TypeError(`${label} Assistant stream record must contain exactly ${keys.join(", ")}`);
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/assistant-stream.js
/** Web presentation fold joining transient Assistant frames to one durable v2 settlement. */
/** Keeps transient Assistant presentation behind one settlement-aware interface. */
var ClientAssistantStream = class {
	activeAttempt;
	pending = /* @__PURE__ */ new Map();
	publishedSeqs = /* @__PURE__ */ new Set();
	durableCursor = -1;
	transientInGap = 0;
	/**
	* Replace the durable Web window and adopt an optional reconnect baseline.
	* @param entries - durable entries in the replacement window.
	* @param baseline - compact prefix for an Assistant attempt that is still live.
	* @returns immediately visible durable entries plus reconstructed transient chunks.
	*/
	replace(entries, baseline) {
		this.pending.clear();
		this.transientInGap = 0;
		this.activeAttempt = void 0;
		const opening = baseline?.activeAttempt;
		if (opening !== void 0) this.activeAttempt = {
			attemptId: opening.attemptId,
			startedAfterSeq: opening.startedAfterSeq,
			turn: opening.turn,
			step: opening.step,
			nextIndex: opening.nextIndex
		};
		const visible = [...entries];
		this.publishedSeqs = new Set(visible.map((entry) => entry.event.seq));
		this.durableCursor = visible.reduce((cursor, entry) => Math.max(cursor, entry.event.seq), -1);
		if (opening !== void 0) for (const [index, member] of expandAssistantStream(opening.stream).entries()) {
			this.transientInGap += 1;
			visible.push({
				type: "transient",
				event: {
					type: "assistant/live-chunk",
					seq: this.durableCursor + 1 - 1 / (this.transientInGap + 1),
					time: member.time,
					data: {
						attemptId: opening.attemptId,
						turn: opening.turn,
						step: opening.step,
						chunk: member.chunk
					}
				}
			});
			if (index + 1 >= opening.nextIndex) break;
		}
		return visible;
	}
	/**
	* Stage one durable v2 settlement while its matching live attempt is open.
	* @param entry - newly followed durable entry.
	* @returns a publication decision, or `undefined` when no entry becomes visible.
	*/
	acceptDurable(entry) {
		const event = entry.event;
		this.durableCursor = Math.max(this.durableCursor, event.seq);
		this.transientInGap = 0;
		const settlement = assistantSettlementEntry(entry);
		if (settlement !== void 0 && this.attemptForSettlement(settlement.event) !== void 0) {
			if (this.pending.has(event.seq)) return { type: "rebaseline" };
			this.pending.set(event.seq, settlement);
			return;
		}
		return this.publish(entry);
	}
	/**
	* Fold one dense transient frame and release its named durable settlement.
	* @param frame - next Assistant stream frame received by the follow connection.
	* @returns a transient, publication, or rebaseline decision, or `undefined` when no entry becomes visible.
	*/
	acceptFrame(frame) {
		switch (frame.type) {
			case "start":
				if (this.activeAttempt !== void 0 || this.pending.size > 0) return { type: "rebaseline" };
				this.pending.clear();
				this.activeAttempt = {
					attemptId: frame.attemptId,
					startedAfterSeq: frame.startedAfterSeq,
					turn: frame.turn,
					step: frame.step,
					nextIndex: 0
				};
				return;
			case "chunk": {
				const attempt = this.activeAttempt;
				if (attempt === void 0 || attempt.attemptId !== frame.attemptId) return void 0;
				if (frame.index !== attempt.nextIndex) return { type: "rebaseline" };
				attempt.nextIndex += 1;
				this.transientInGap += 1;
				return {
					type: "transient",
					entry: {
						type: "transient",
						event: {
							type: "assistant/live-chunk",
							seq: this.durableCursor + 1 - 1 / (this.transientInGap + 1),
							time: frame.time,
							data: {
								attemptId: frame.attemptId,
								turn: attempt.turn,
								step: attempt.step,
								chunk: frame.chunk
							}
						}
					}
				};
			}
			case "end": {
				const attempt = this.activeAttempt;
				if (attempt === void 0 || attempt.attemptId !== frame.attemptId) return;
				this.activeAttempt = void 0;
				if (frame.index !== attempt.nextIndex) return { type: "rebaseline" };
				if (frame.outcome.kind === "abandoned") return this.pending.size === 0 ? {
					type: "abandonment",
					attemptId: attempt.attemptId
				} : { type: "rebaseline" };
				if (this.publishedSeqs.has(frame.outcome.seq)) return void 0;
				const entry = this.pending.get(frame.outcome.seq);
				if (entry === void 0 || entry.event.type !== frame.outcome.eventType) return { type: "rebaseline" };
				this.pending.delete(frame.outcome.seq);
				this.publishedSeqs.add(entry.event.seq);
				return {
					type: "settlement",
					attemptId: attempt.attemptId,
					entry
				};
			}
		}
	}
	attemptForSettlement(event) {
		const attempt = this.activeAttempt;
		if (attempt === void 0 || event.type === "assistant/message" && event.surfaceOp !== "append" || event.seq <= attempt.startedAfterSeq || attempt.turn !== event.data.turn || attempt.step !== event.data.step) return void 0;
		return attempt;
	}
	publish(entry) {
		this.publishedSeqs.add(entry.event.seq);
		return {
			type: "publish",
			entry
		};
	}
};
function assistantSettlementEntry(entry) {
	return entry.event.type === "assistant/message" || entry.event.type === "assistant/attempt" ? entry : void 0;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/session.js
function projectionsBaseline(value) {
	return {
		...value,
		asOfSeq: value.asOfSeq === -1 ? -1 : SessionSeq(value.asOfSeq)
	};
}
/**
* Owns a session's event window, lifecycle state, and observable
* snapshot. React bindings remain outside this data layer. Features see only
* the {@link SessionFace} slice (ISession verbs + the snapshot source); the
* remaining public members are Session Controller internals.
*/
var Session = class {
	sessionId;
	remote;
	platform;
	options;
	baseSeq = SessionLogOffset(0);
	hasMore = false;
	detailLoads = /* @__PURE__ */ new Map();
	syncing = false;
	openState = "cold";
	openError = null;
	openPromise = null;
	/** Bumped by stream replacement to invalidate an in-flight doOpen. Stale
	*  passes drop all writes once the generation moves on. */
	openGeneration = 0;
	loadingOlder = false;
	/** Shared low-water target of the running jump loop; null when no jump is paging. */
	jumpTargetSeq = null;
	/** The running jump loop's completion, shared by retargeting callers. */
	jumpPromise = null;
	/** Authoritative stream-only inbox snapshot; pending work never hits history. */
	queueMirror = new SessionQueueMirror();
	assistantStream = new ClientAssistantStream();
	running = false;
	address;
	parentAvailable;
	/**
	* Sticky send marker, private input of the composerPhase derivation: set
	* synchronously before prompt()'s first await, never reset — the blank →
	* engaging edge of the phase machine (see ComposerPhase).
	*/
	promptAttempted = false;
	/** A first accepted prompt stays in the engaging phase until its turn is observable. */
	firstPromptPendingTurn = false;
	/** Empty-log mirror (see ConversationSnapshot.blank); unknown bare sessions begin conservatively blank. */
	blankBit = true;
	removed = false;
	promptError = null;
	lastAgentError = null;
	/** Local submission echoes, insertion-ordered (see SessionSnapshot.pendingSubmissions). */
	pendingSubmissions = [];
	/** Per-echo settlement state; `retiring` latches the first observation so a
	*  queue frame and its durable event cannot both retire one echo. */
	submissionSettlements = /* @__PURE__ */ new Map();
	/** Owns the addressed page/follow lifecycle while this Session is open. */
	events;
	/**
	* Per-session projection value store (push model; see the session-projection
	* subsystem page, docs/subsystems/session-projection.md): finished whole
	* values computed on the Host, seeded by the tail page's
	* projections block and updated by Session Controller control frames under the
	* one higher-seq-wins rule. Keys are read via `projections.faceOf(key)`
	* (the useProjection resolution face); the conversation snapshot never
	* carries projection values, and no client-side domain folding exists.
	* Manager-owned when constructed through SessionManager (frames route and
	* the store outlives instantiation, the title-snapshot precedent); a bare
	* construction gets a private store.
	*/
	projections;
	/** Contiguous history and live tail consumed by Conversation assembly. */
	eventSource = new MutableSessionEventSource();
	snapshotCache;
	notifier;
	/**
	* Agent-scoped cordis context, bound once by ClientSessions when it
	* mints the scope (the client mirror of the host Agent's loopCtx). The
	* Session dispatches its own scoped events through it; undefined means
	* unbound (bare object-layer construction) or already pruned — both skip
	* dispatch-dependent behavior rather than fail.
	*/
	actx;
	/**
	* @param sessionId - Host session identity (client sessions are always Host-born).
	* @param remote - generated Remote namespaces this session calls.
	* @param platform - request identity and client time zone supplied by the host connection owner.
	* @param options - optional manager-owned state observers.
	*/
	constructor(sessionId, remote, platform, options = {}) {
		this.sessionId = sessionId;
		this.remote = remote;
		this.platform = platform;
		this.options = options;
		this.projections = options.projections ?? new ProjectionValueStore();
		this.address = options.address;
		this.parentAvailable = options.parentAvailable;
		this.notifier = new Notifier(() => {
			this.snapshotCache = this.buildSnapshot();
		});
		this.snapshotCache = this.buildSnapshot();
	}
	/**
	* Bind the Agent-scoped context minted by ClientSessions (single write;
	* a second bind is a wiring error and throws). Direction stays one-way at
	* this binding boundary: consumers still reach the Session via `sessions.sessionOf`,
	* while the Session holds its own dispatch point (host Agent.loopCtx
	* mirror).
	* @param actx - the agent's scoped context.
	*/
	bindScope(actx) {
		if (this.actx !== void 0) throw new Error(`session ${this.sessionId} already has a bound scope`);
		this.actx = actx;
	}
	/** Release the bound scope at prune time (a later rebind accompanies a freshly minted scope). */
	unbindScope() {
		this.actx = void 0;
	}
	/**
	* Register one local submission echo (see the ISession declaration).
	* Synchronous through markDirty: the echo is in the very next snapshot, so
	* the conversation can paint it before the caller starts serializing.
	* @param input - echo content and the optional settlement callback.
	* @returns the minted identity for {@link prompt} plus the pre-prompt abandon path.
	*/
	beginSubmission(input) {
		const requestId = this.platform.createRequestId();
		this.pendingSubmissions = [...this.pendingSubmissions, {
			requestId,
			placement: this.running ? input.mode === "steer" ? "steering" : "queued" : "transcript",
			time: Date.now(),
			text: input.text,
			attachments: input.attachments
		}];
		this.submissionSettlements.set(requestId, {
			onRetire: input.onRetire,
			retiring: false
		});
		this.promptAttempted = true;
		this.notifier.markDirty();
		return {
			requestId,
			abandon: () => {
				this.retireFailedSubmission(requestId);
			}
		};
	}
	/**
	* Send (queue/steer passed through 1:1); failures land in the snapshot's promptError.
	* @param content - text, browser-owned temporary image uploads, and staged-file receipts.
	* @param mode - queue appends after the current turn; steer interrupts it.
	* @param signal - optional caller cancellation for the complete admission round-trip.
	* @param requestId - identity from {@link beginSubmission}; a failed identified prompt retires its echo.
	* @returns the prompt result (also mirrored into promptError on failure).
	*/
	async prompt(content, mode, signal, requestId) {
		this.promptError = null;
		this.lastAgentError = null;
		this.promptAttempted = true;
		if (this.blankBit) this.firstPromptPendingTurn = true;
		this.notifier.markDirty();
		let result;
		if (this.address === void 0) {
			const clientTimeZone = this.platform.timeZone();
			result = await this.remote.session.prompt({
				requestId: requestId ?? this.platform.createRequestId(),
				sessionId: this.sessionId,
				mode,
				content,
				clientTimeZone
			}, signal);
		} else if (content.some((part) => part.type === "file")) result = {
			ok: false,
			error: new RemoteError("subagent/attachment-invalid", "subagent continuation does not accept files", { reason: "SUBAGENT_FILE_UNSUPPORTED" })
		};
		else {
			const routedContent = content;
			const routed = await this.remote.subagents.prompt({
				requestId: this.platform.createRequestId(),
				parentSessionId: this.address.parentSessionId,
				childSessionId: this.address.childSessionId,
				mode: "continuable",
				delivery: mode,
				content: routedContent,
				clientTimeZone: this.platform.timeZone()
			}, signal);
			result = routed.ok ? {
				ok: true,
				value: { accepted: true }
			} : routed;
		}
		if (!result.ok) {
			if (requestId !== void 0) this.retireFailedSubmission(requestId);
			this.promptError = {
				op: "send",
				error: result.error
			};
			this.notifier.markDirty();
			return result;
		}
		if (this.blankBit) {
			this.blankBit = false;
			this.options.onEngaged?.(this);
			this.notifier.markDirty();
		}
		return result;
	}
	/**
	* Resolve one image referenced by this session into browser-consumable bytes.
	* @param attachmentId - opaque id found in the folded session log.
	* @returns the authenticated reference and decoded bytes.
	*/
	async readAttachment(attachmentId) {
		const result = await this.remote.session.attachment({
			sessionId: this.sessionId,
			attachmentId
		});
		if (!result.ok) return result;
		const binary = atob(result.value.data);
		const data = Uint8Array.from(binary, (char) => char.charCodeAt(0));
		return {
			ok: true,
			value: {
				attachment: result.value.attachment,
				data
			}
		};
	}
	/** Apply one operation to a still-pending queue occurrence. */
	async updateQueue(itemId, action) {
		return this.remote.session.updateQueue({
			sessionId: this.sessionId,
			itemId,
			action
		});
	}
	/**
	* Stop the active turn while the Host preserves pending inbox work; failures
	* land in promptError (same error-strip display slot). A subagent address
	* routes through `subagents.interruptByParent`, whose durable parent-address
	* authority works without a live parent Agent.
	* @returns the cancel result.
	*/
	async cancel() {
		const address = this.address;
		const result = address !== void 0 ? await this.remote.subagents.interruptByParent(address.childSessionId, address.parentSessionId, "continuable") : await this.remote.session.cancel({ sessionId: this.sessionId });
		if (!result.ok) {
			this.promptError = {
				op: "stop",
				error: result.error
			};
			this.notifier.markDirty();
		}
		return result;
	}
	/**
	* Rename: contract session.rename 1:1. On success settle the 'title'
	* projection cell from the response's `{title, seq}` under the store's
	* higher-seq-wins rule (the push frame arriving later is a no-op replay),
	* so the list row and any useProjection('title') reader update without
	* waiting for the control-stream projection update.
	* @param title - raw title text (the host normalizes acceptance).
	* @returns the rename result (normalized accepted title + title event seq).
	*/
	async rename(title) {
		const result = await this.remote.session.rename({
			sessionId: this.sessionId,
			title
		});
		if (!result.ok) return result;
		const seq = SessionSeq(result.value.seq);
		this.projections.apply("title", result.value.title, seq);
		return {
			ok: true,
			value: {
				title: result.value.title,
				seq
			}
		};
	}
	/**
	* Execute one slash-command line against this session's agent — pure
	* admission semantics (the host executor durably logs the lifecycle;
	* outcomes render as flow nodes, never as a response echo).
	* @param line - the full command line, leading slash included.
	* @returns the admission result.
	*/
	async command(line) {
		const result = await this.remote.commands.execute(this.sessionId, line, []);
		if (!result.ok) return result;
		return {
			ok: true,
			value: { matched: result.value !== void 0 }
		};
	}
	/** First open: pull the tail page (idempotent — in-flight/already-open returns the existing promise). */
	open() {
		if (this.openState === "open") return Promise.resolve();
		if (this.openPromise !== null) return this.openPromise;
		const promise = this.doOpen(this.openGeneration).finally(() => {
			if (this.openPromise === promise) this.openPromise = null;
		});
		this.openPromise = promise;
		return promise;
	}
	/** Fetch an exact result and replace only its still-deferred entry. */
	loadHistoryDetail(seq) {
		const pending = this.detailLoads.get(seq);
		if (pending !== void 0) return pending;
		const generation = this.openGeneration;
		const task = (async () => {
			const result = await this.remote.session.historyDetail({
				address: this.sessionAddress(),
				seq
			});
			if (!result.ok) throw result.error;
			if (generation !== this.openGeneration) return;
			const window = this.eventSource.getSnapshot();
			const entry = window.entries.find((value) => value.event.seq === seq);
			if (entry?.type !== "event" || entry.detail === void 0) return;
			const replacement = result.value;
			this.eventSource.replace(window.entries.map((value) => value === entry ? replacement : value), window.hasMore);
		})().finally(() => {
			this.detailLoads.delete(seq);
		});
		this.detailLoads.set(seq, task);
		return task;
	}
	/** Retry a failed initial history load. */
	retryOpen() {
		return this.open();
	}
	/** Page up: pull one earlier page with the window's first seq as beforeSeq and prepend. */
	async loadOlder() {
		if (this.openState !== "open" || !this.hasMore || this.loadingOlder) return;
		const events = this.events;
		if (events === void 0) return;
		this.loadingOlder = true;
		this.notifier.markDirty();
		try {
			await events.prepend({
				beforeSeq: this.baseSeq,
				maxMessages: 50
			});
		} catch (error) {
			if (!isRemoteFailure(error)) console.error("[session-controller] loadOlder failed:", error);
		} finally {
			this.loadingOlder = false;
			this.notifier.markDirty();
		}
	}
	/** Jump loader: page backwards until the window covers seq (see ISession.loadThrough). */
	loadThrough(seq) {
		if (this.openState !== "open" || !this.hasMore || this.baseSeq <= seq) return Promise.resolve();
		if (this.jumpPromise !== null) {
			this.jumpTargetSeq = SessionSeq(Math.min(this.jumpTargetSeq ?? seq, seq));
			return this.jumpPromise;
		}
		if (this.loadingOlder) return Promise.resolve();
		this.jumpTargetSeq = seq;
		this.loadingOlder = true;
		this.notifier.markDirty();
		const generation = this.openGeneration;
		this.jumpPromise = (async () => {
			try {
				while (this.hasMore && this.jumpTargetSeq !== null && this.baseSeq > this.jumpTargetSeq) {
					if (generation !== this.openGeneration) return;
					const events = this.events;
					if (events === void 0) return;
					const before = this.baseSeq;
					await events.prepend({
						beforeSeq: this.baseSeq,
						maxMessages: 200
					});
					if (this.baseSeq >= before) return;
				}
			} catch (error) {
				if (!isRemoteFailure(error)) console.error("[session-controller] loadThrough failed:", error);
			} finally {
				this.jumpTargetSeq = null;
				this.jumpPromise = null;
				this.loadingOlder = false;
				this.notifier.markDirty();
			}
		})();
		return this.jumpPromise;
	}
	/** Rebuild an opened history source after address replacement.
	*  Invalidates any in-flight open first; queue state belongs to the independently
	*  reconnecting control stream and remains untouched. */
	async resync() {
		if (this.openState === "cold") return;
		this.openGeneration++;
		const events = this.events;
		this.events = void 0;
		await events?.dispose();
		this.openPromise = null;
		this.openState = "cold";
		this.openError = null;
		this.baseSeq = SessionLogOffset(0);
		this.notifier.markDirty();
		await this.open();
	}
	/**
	* uSES subscription entry.
	* @param listener - change callback.
	* @returns the unsubscribe function.
	*/
	subscribe(listener) {
		return this.notifier.subscribe(listener);
	}
	/**
	* Cached Session snapshot (rebuilt lazily when dirty with no listeners).
	* @returns the cached reference (stable until the next flush).
	*/
	getSnapshot() {
		this.notifier.ensureFresh();
		return this.snapshotCache;
	}
	/**
	* Replace every transient control value for this Session from one stream baseline.
	* @param queue - complete pending queue for this Session.
	*/
	replaceControl(queue) {
		this.queueMirror.replace(queue);
		this.observeSubmissionQueue(queue);
		this.notifier.markDirty();
	}
	/**
	* Apply one Session-addressed live control update.
	* @param frame - queue replacement addressed to this Session.
	*/
	handleControlFrame(frame) {
		this.queueMirror.replace(frame.items);
		this.observeSubmissionQueue(frame.items);
		this.notifier.markDirty();
	}
	/**
	* Running-bit relay from the host stream (list entry and snapshot stay consistent).
	* @param running - the new running state.
	*/
	handleRunning(running) {
		if (running && this.blankBit) {
			this.blankBit = false;
			this.notifier.markDirty();
		}
		if (running) this.firstPromptPendingTurn = false;
		if (this.running === running) return;
		this.running = running;
		this.notifier.markDirty();
	}
	/**
	* Install or clear the catalog-discovered transport address. A changed
	* address rebuilds an already-open window through its new history route.
	* @param address - direct parent/child address, or undefined for ordinary transport.
	* @param parentAvailable - latest exact-parent availability hint, or undefined before a catalog read.
	*/
	configureSubagent(address, parentAvailable) {
		const same = this.address?.parentSessionId === address?.parentSessionId && this.address?.childSessionId === address?.childSessionId && this.address?.mode === address?.mode;
		this.address = address;
		this.parentAvailable = parentAvailable;
		if (!same && this.openState !== "cold") this.resync();
		else this.notifier.markDirty();
	}
	/**
	* Update only the parent availability hint from a catalog refresh.
	* @param available - whether the exact direct parent is live.
	*/
	handleSubagentParentAvailable(available) {
		if (this.parentAvailable === available) return;
		this.parentAvailable = available;
		this.notifier.markDirty();
	}
	/**
	* Blank-bit relay from the authoritative summary source (`session.list` and
	* `api-session/added`). Monotone: once any signal (local first send,
	* running flip, an earlier summary) cleared it, a stale true never
	* re-blanks.
	* @param blank - the summary's derived empty-log bit.
	*/
	handleBlank(blank) {
		if (blank === this.blankBit) return;
		if (blank && (this.promptAttempted || this.running)) return;
		this.blankBit = blank;
		this.notifier.markDirty();
	}
	/** `api-session/removed` relay: flag the snapshot while retaining the resident instance. */
	handleRemoved() {
		this.removed = true;
		this.notifier.markDirty();
	}
	/**
	* `api-session/error` relay: the outlet for live failures with no turn position.
	* @param message - the stringified error.
	*/
	handleAgentError(message) {
		this.lastAgentError = message;
		this.notifier.markDirty();
	}
	/**
	* Stop the Session's live Remote source.
	* @returns when the Remote iterator has completed teardown.
	*/
	async dispose() {
		for (const requestId of [...this.submissionSettlements.keys()]) this.retireFailedSubmission(requestId);
		this.openGeneration++;
		const events = this.events;
		this.events = void 0;
		await events?.dispose();
	}
	/** Keep an open transcript readable while its Host generation is unavailable. */
	handleDisconnected() {
		if (this.openState !== "open" || this.syncing) return;
		this.syncing = true;
		this.notifier.markDirty();
	}
	/** @param generation - openGeneration at launch; stale passes cannot publish after replacement. */
	async doOpen(generation) {
		this.openState = "loading";
		this.openError = null;
		this.notifier.markDirty();
		const events = new SessionEventStream(this.remote, this.sessionAddress(), {
			publish: (change) => {
				if (generation !== this.openGeneration || this.events !== events) return;
				this.acceptEventChange(change);
			},
			carrierFailed: () => {
				this.syncing = true;
				this.notifier.markDirty();
			},
			failed: (error) => {
				this.failEventStream(events, generation, error);
			}
		});
		this.events = events;
		try {
			await events.open({ maxMessages: 50 });
			if (generation !== this.openGeneration || this.events !== events) return;
			this.openState = "open";
		} catch (error) {
			if (generation !== this.openGeneration || this.events !== events) return;
			if (!isRemoteFailure(error)) throw error;
			this.events = void 0;
			this.openState = "error";
			this.openError = error;
		} finally {
			if (generation === this.openGeneration) this.notifier.markDirty();
		}
	}
	/** Apply one contiguous journal update already reconciled by the Remote stream. */
	acceptEventChange(change) {
		switch (change.type) {
			case "replace":
				this.syncing = false;
				this.notifier.markDirty();
				this.installWindow(change.entries, change.hasMore, change.page.projections === void 0 ? void 0 : projectionsBaseline(change.page.projections), change.page.assistantStream);
				return;
			case "prepend":
				this.prependWindow(change.entries, change.hasMore);
				return;
			case "append":
				this.publishAssistantEntry(this.assistantStream.acceptDurable(change.entry));
				return;
			case "assistant-stream": this.publishAssistantEntry(this.assistantStream.acceptFrame(change.frame));
		}
	}
	/** Replace the complete contiguous window and apply page-owned projection metadata. */
	installWindow(entries, hasMore, projections, assistantStream) {
		const visible = this.assistantStream.replace(entries, assistantStream);
		this.baseSeq = SessionLogOffset(entries[0]?.event.seq ?? 0);
		this.hasMore = hasMore;
		if (visible.some((entry) => entry.event.type === "turn/start")) this.firstPromptPendingTurn = false;
		if (projections !== void 0) this.projections.seed(projections);
		this.eventSource.replace(visible, hasMore);
		for (const entry of visible) this.observeSubmissionEvent(entry.event);
		this.notifier.markDirty();
	}
	publishAssistantEntry(result) {
		if (result?.type === "rebaseline") {
			const events = this.events;
			queueMicrotask(() => {
				if (events !== void 0 && this.events === events) events.restart();
			});
			return;
		}
		if (result?.type === "settlement") {
			this.eventSource.settleAssistant(result.attemptId, result.entry);
			this.observeSubmissionEvent(result.entry.event);
			this.notifier.markDirty();
			return;
		}
		if (result?.type === "abandonment") {
			this.eventSource.settleAssistant(result.attemptId);
			this.notifier.markDirty();
			return;
		}
		if (result?.type === "publish" && this.appendLive(result.entry)) this.notifier.markDirty();
		else if (result?.type === "transient") {
			this.eventSource.append(result.entry);
			this.notifier.markDirty();
		}
	}
	/** Prepend one stream-validated history page. */
	prependWindow(entries, hasMore) {
		this.baseSeq = entries[0] === void 0 ? this.baseSeq : SessionLogOffset(entries[0].event.seq);
		this.hasMore = hasMore;
		this.eventSource.prepend(entries, hasMore);
	}
	/** Append one stream-validated live event. */
	appendLive(entry) {
		const event = entry.event;
		const awaitingFirstTurn = this.firstPromptPendingTurn;
		if (event.type === "turn/start") this.firstPromptPendingTurn = false;
		const queueChanged = this.queueMirror.acceptDurable(event);
		this.eventSource.append(entry);
		this.observeSubmissionEvent(event);
		return queueChanged || awaitingFirstTurn !== this.firstPromptPendingTurn;
	}
	/** Retire the matching echo when a durable browser-prompt `user/message` becomes visible. */
	observeSubmissionEvent(event) {
		if (this.submissionSettlements.size === 0 || event.type !== "user/message") return;
		const data = event.data;
		const source = data?.source;
		if (source?.kind !== "user" || typeof source.rpcId !== "string") return;
		this.scheduleObservedRetirement(source.rpcId, attachmentRefsIn(data?.content));
	}
	/** Retire echoes whose prompts landed in the host inbox instead of the log (running-turn submissions). */
	observeSubmissionQueue(items) {
		if (this.submissionSettlements.size === 0) return;
		for (const item of items) if (item.rpcId !== void 0) this.scheduleObservedRetirement(item.rpcId, attachmentRefsIn(item.message.content));
	}
	/**
	* Latch one observed settlement and remove the echo an animation frame
	* later. The delay keeps the echo in the snapshot until the frame in which
	* the durable node (whose assembly frame was registered first) is
	* renderable; the render-time rpcId dedupe hides the one-frame overlap.
	*/
	scheduleObservedRetirement(requestId, attachments) {
		const settlement = this.submissionSettlements.get(requestId);
		if (settlement === void 0 || settlement.retiring) return;
		settlement.retiring = true;
		scheduleFrame(() => {
			this.finishSubmission(requestId, {
				reason: "observed",
				attachments
			});
		});
	}
	/** Remove one unsettled echo immediately (prompt rejection, abort, or disposal). */
	retireFailedSubmission(requestId) {
		const settlement = this.submissionSettlements.get(requestId);
		if (settlement === void 0 || settlement.retiring) return;
		settlement.retiring = true;
		this.finishSubmission(requestId, { reason: "failed" });
	}
	/** Single removal point: drop the echo, publish, then notify the owner. */
	finishSubmission(requestId, retirement) {
		const settlement = this.submissionSettlements.get(requestId);
		/* v8 ignore next -- retiring latches before every schedule, so one settlement never finishes twice. */
		if (settlement === void 0) return;
		this.submissionSettlements.delete(requestId);
		this.pendingSubmissions = this.pendingSubmissions.filter((echo) => echo.requestId !== requestId);
		this.notifier.markDirty();
		settlement.onRetire?.(retirement);
	}
	/** Publish a terminal background failure only while this stream still owns the Session. */
	failEventStream(events, generation, error) {
		if (generation !== this.openGeneration || this.events !== events) return;
		if (!isRemoteFailure(error)) throw error;
		this.openGeneration++;
		this.events = void 0;
		this.openPromise = null;
		this.openState = "error";
		this.syncing = false;
		this.openError = error;
		events.dispose();
		this.notifier.markDirty();
	}
	buildSnapshot() {
		return {
			sessionId: this.sessionId,
			queue: this.queueMirror.snapshot(),
			pendingSubmissions: this.pendingSubmissions,
			running: this.running,
			subagent: this.address === void 0 ? null : {
				address: this.address,
				...this.parentAvailable === void 0 ? {} : { parentAvailable: this.parentAvailable }
			},
			removed: this.removed,
			openState: this.openState,
			syncing: this.syncing,
			openError: this.openError,
			hasMore: this.hasMore,
			loadingOlder: this.loadingOlder,
			promptError: this.promptError,
			blank: this.blankBit,
			lastAgentError: this.lastAgentError,
			promptAttempted: this.promptAttempted,
			awaitingFirstTurn: this.firstPromptPendingTurn
		};
	}
	sessionAddress() {
		return this.address === void 0 ? {
			kind: "session",
			sessionId: this.sessionId
		} : {
			kind: "subagent",
			...this.address
		};
	}
};
/** Run one callback on the next animation frame, or a macrotask where no frame clock exists. */
function scheduleFrame(fn) {
	if (typeof requestAnimationFrame === "function") requestAnimationFrame(() => {
		fn();
	});
	else setTimeout(fn, 0);
}
/** Attachment references in one structurally-read content block list, in block order. */
function attachmentRefsIn(content) {
	if (!Array.isArray(content)) return [];
	const refs = [];
	for (const block of content) {
		if (typeof block !== "object" || block === null) continue;
		const candidate = block;
		if ((candidate.type === "image" || candidate.type === "file") && typeof candidate.attachment === "object" && candidate.attachment !== null) refs.push(candidate.attachment);
	}
	return refs;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/manager.js
function sessionSeqCursor(value) {
	return value === -1 ? -1 : SessionSeq(value);
}
function catalogAvailability(parentAvailable) {
	return parentAvailable === void 0 ? {} : { parentAvailable };
}
/** Instance cluster + frame entry + the session list. */
var SessionManager = class {
	remote;
	platform;
	sessions = /* @__PURE__ */ new Map();
	/** In-flight Session disposals remain here after instances leave `sessions`, so manager disposal can await quiescence. */
	sessionDisposals = /* @__PURE__ */ new Set();
	/** Latest transient queues, retained independently of Session object materialization. */
	queues = /* @__PURE__ */ new Map();
	/**
	* Sessions that finished running while not selected — the sidebar's green
	* "done" reminder (manager-owned, survives connection generations; cleared
	* on select and session-removed, re-armed by the next completion).
	*/
	completedNotifications = /* @__PURE__ */ new Set();
	/** Last-observed running bits per session; the true→false edge here arms {@link completedNotifications}. */
	prevRunning = /* @__PURE__ */ new Map();
	/** Per-session projection value stores, retained independently of instance arrival (the
	*  title-snapshot precedent, generalized): push frames land here whether or not the Session
	*  is instantiated (list rows read the 'title' key), and an instantiated Session adopts the
	*  same store so history-baseline seeding and frames converge on one row set. */
	projectionStores = /* @__PURE__ */ new Map();
	summaries = [];
	listState = "idle";
	/** Arrival phase; the pending → ready edge fires on the first successful pull (see SessionListPhase). */
	listPhase = "pending";
	listError = null;
	listInflight = null;
	listCursor;
	listHasMore = false;
	listLoadingMore = false;
	/** Mutations arriving after a list request starts are replayed over its response. */
	listMutations = null;
	addresses = /* @__PURE__ */ new Map();
	catalogs = /* @__PURE__ */ new Map();
	catalogInflight = /* @__PURE__ */ new Map();
	/** Catalog owners whose membership changed while a pull was in flight: one trailing refresh after it settles. */
	catalogStale = /* @__PURE__ */ new Set();
	openCatalogs = /* @__PURE__ */ new Set();
	catalogDebounce = /* @__PURE__ */ new Map();
	/**
	* Background jobs per session, last-wins from Session Controller's control
	* stream. An empty set is stored as an absent key, so absence and `[]` are
	* one representation.
	*/
	jobsBySession = /* @__PURE__ */ new Map();
	selected;
	listSnapshotCache;
	/** Entry-identity cache (reference stability): list rebuilds reuse the previous entry
	*  object when every field matches — wire refreshes mint all-new summary objects, so identity
	*  must be recovered by value or every SessionListItem memo misses on every refresh. */
	entryCache = /* @__PURE__ */ new Map();
	itemsCache = [];
	notifier = new Notifier(() => {
		this.listSnapshotCache = this.buildListSnapshot();
	});
	/**
	* @param remote - generated Remote namespaces the Session cluster calls.
	* @param platform - shared request identity and device time zone callbacks.
	* @param restoredSelection - persisted real-Session selection candidate.
	*/
	constructor(remote, platform, restoredSelection, restoredAddress) {
		this.remote = remote;
		this.platform = platform;
		this.selected = restoredSelection;
		if (restoredAddress !== void 0) this.addresses.set(restoredAddress.childSessionId, restoredAddress);
		this.listSnapshotCache = this.buildListSnapshot();
	}
	/**
	* Select a listed Session or a retained catalog-addressed child.
	* @param sessionId - listed or catalog-addressed Session id.
	*/
	select(sessionId) {
		const address = this.navigationAddress(sessionId);
		if (!this.summaries.some((summary) => summary.sessionId === sessionId) && address === void 0) throw new Error(`sessions.select: unknown session ${sessionId}`);
		if (address !== void 0) this.addresses.set(sessionId, address);
		this.sessions.get(sessionId)?.configureSubagent(address, address === void 0 ? void 0 : this.catalogs.get(address.parentSessionId)?.parentAvailable);
		this.selected = sessionId;
		this.completedNotifications.delete(sessionId);
		this.refreshSubagents(sessionId);
		this.notifier.notifyNow();
	}
	/**
	* Select a healthy child through its durable direct-parent address.
	* @param address - catalog-derived parent and child ids.
	*/
	selectSubagent(address) {
		const catalog = this.catalogs.get(address.parentSessionId);
		const entry = catalog?.entries.find((candidate) => candidate.id === address.childSessionId);
		if (entry === void 0 || entry.kind !== "child" || entry.mode !== address.mode) throw new Error(`sessions.selectSubagent: ${address.childSessionId} is not a healthy catalog child`);
		this.addresses.set(address.childSessionId, address);
		this.sessions.get(address.childSessionId)?.configureSubagent(address, catalog?.parentAvailable);
		this.selected = address.childSessionId;
		this.completedNotifications.delete(address.childSessionId);
		this.refreshSubagents(address.childSessionId);
		this.notifier.notifyNow();
	}
	/** Clear the selection (the layout falls to the no-session view state). */
	clearSelection() {
		this.selected = void 0;
		this.notifier.notifyNow();
	}
	/**
	* Return the durable catalog address retained for one child.
	* @param sessionId - possible addressed child id.
	* @returns The direct-parent address, when navigation discovered one.
	*/
	subagentAddress(sessionId) {
		return this.addresses.get(sessionId);
	}
	/**
	* Resolve an address for breadcrumb navigation without retaining transport authority.
	* @param sessionId - possible child id in an already-loaded catalog.
	* @returns A retained or catalog-derived direct-parent address.
	*/
	navigationAddress(sessionId) {
		const retained = this.addresses.get(sessionId);
		if (retained !== void 0) return retained;
		for (const [parentSessionId, catalog] of this.catalogs) {
			const child = catalog.entries.find((entry) => entry.kind === "child" && entry.id === sessionId);
			if (child?.kind === "child") return {
				parentSessionId,
				childSessionId: sessionId,
				mode: child.mode
			};
		}
	}
	/**
	* Drop a session instance (scope-prune companion: instance
	* and scope share one lifecycle). The host session log is the durable
	* truth — a later get() lazily rebuilds and open() backfills history.
	* @param sessionId - the session to drop.
	*/
	async drop(sessionId) {
		const session = this.sessions.get(sessionId);
		this.sessions.delete(sessionId);
		if (session !== void 0) await this.startSessionDisposal(session);
	}
	/**
	* Stop owned timers and every remaining Session instance.
	* @returns when every Session Remote iterator has completed teardown.
	*/
	async dispose() {
		for (const timer of this.catalogDebounce.values()) clearTimeout(timer);
		this.catalogDebounce.clear();
		this.catalogStale.clear();
		this.openCatalogs.clear();
		const sessions = [...this.sessions.values()];
		this.sessions.clear();
		for (const session of sessions) this.startSessionDisposal(session);
		await this.drainSessionDisposals();
	}
	startSessionDisposal(session) {
		const disposal = session.dispose();
		this.sessionDisposals.add(disposal);
		disposal.then(() => {
			this.sessionDisposals.delete(disposal);
		}, () => {
			this.sessionDisposals.delete(disposal);
		});
		return disposal;
	}
	async drainSessionDisposals() {
		while (this.sessionDisposals.size > 0) await Promise.allSettled([...this.sessionDisposals]);
	}
	/**
	* Lazy build: return the existing instance or construct one (no auto-open —
	* open is triggered by the container's select callback).
	* @param sessionId - the session to get.
	* @returns the resident instance.
	*/
	get(sessionId) {
		let session = this.sessions.get(sessionId);
		if (session === void 0) {
			session = this.createSession(sessionId);
			this.sessions.set(sessionId, session);
			session.replaceControl(this.queues.get(sessionId) ?? []);
			const summary = this.summaries.find((s) => s.sessionId === sessionId);
			if (summary !== void 0) {
				session.handleBlank(summary.blank);
				session.handleRunning(summary.running);
			} else {
				const address = this.addresses.get(sessionId);
				const child = address === void 0 ? void 0 : this.catalogs.get(address.parentSessionId)?.entries.find((entry) => entry.kind === "child" && entry.id === sessionId);
				if (child?.kind === "child") {
					session.handleBlank(false);
					session.handleRunning(child.activity === "running");
				}
			}
		}
		return session;
	}
	createSession(sessionId) {
		const address = this.addresses.get(sessionId);
		const parentAvailable = address === void 0 ? void 0 : this.catalogs.get(address.parentSessionId)?.parentAvailable;
		return new Session(sessionId, this.remote, this.platform, {
			...address === void 0 ? {} : {
				address,
				...catalogAvailability(parentAvailable)
			},
			onEngaged: (engaged) => {
				this.recordMutation({
					kind: "engaged",
					sessionId: engaged.sessionId
				});
			},
			projections: this.projectionStore(sessionId)
		});
	}
	/** Resident per-session projection store (create-on-demand; outlives instantiation). */
	projectionStore(sessionId) {
		let store = this.projectionStores.get(sessionId);
		if (store === void 0) {
			store = new ProjectionValueStore();
			store.subscribeAny(() => {
				this.notifier.markDirty();
			});
			this.projectionStores.set(sessionId, store);
		}
		return store;
	}
	/**
	* Refresh one direct-child catalog, reusing its in-flight request.
	* @param parentSessionId - catalog owner.
	*/
	refreshSubagents(parentSessionId) {
		const existing = this.catalogInflight.get(parentSessionId);
		if (existing !== void 0) return existing.promise;
		const previous = this.catalogs.get(parentSessionId);
		const expandableRows = /* @__PURE__ */ new Set();
		const activityRows = /* @__PURE__ */ new Map();
		this.catalogs.set(parentSessionId, {
			entries: previous?.entries ?? [],
			...previous?.parentAvailable === void 0 ? {} : { parentAvailable: previous.parentAvailable },
			state: "loading",
			error: null
		});
		this.notifier.markDirty();
		const operation = (async () => {
			try {
				const result = await this.remote.subagents.list(parentSessionId);
				if (result.ok) {
					const parentAvailable = this.catalogInflight.get(parentSessionId)?.parentAvailableOverride ?? result.value.parentAvailable;
					this.catalogs.set(parentSessionId, {
						...result.value,
						entries: this.withCatalogMutations(result.value.entries, expandableRows, activityRows),
						parentAvailable,
						state: "ready",
						error: null
					});
					for (const [childId, address] of this.addresses) {
						if (address.parentSessionId !== parentSessionId) continue;
						this.sessions.get(childId)?.handleSubagentParentAvailable(parentAvailable);
					}
				} else this.catalogs.set(parentSessionId, {
					entries: this.withCatalogMutations(previous?.entries ?? [], expandableRows, activityRows),
					...catalogAvailability(this.catalogInflight.get(parentSessionId)?.parentAvailableOverride ?? previous?.parentAvailable),
					state: "error",
					error: result.error
				});
			} catch (error) {
				if (!isRemoteFailure(error)) throw error;
				this.catalogs.set(parentSessionId, {
					entries: this.withCatalogMutations(previous?.entries ?? [], expandableRows, activityRows),
					...catalogAvailability(this.catalogInflight.get(parentSessionId)?.parentAvailableOverride ?? previous?.parentAvailable),
					state: "error",
					error
				});
			} finally {
				this.catalogInflight.delete(parentSessionId);
				if (this.catalogStale.delete(parentSessionId)) this.refreshSubagents(parentSessionId);
				this.notifier.markDirty();
			}
		})();
		this.catalogInflight.set(parentSessionId, {
			promise: operation,
			expandableRows,
			activityRows,
			parentAvailableOverride: void 0
		});
		return operation;
	}
	/**
	* Mark whether a catalog menu is consuming live membership updates.
	* @param parentSessionId - catalog owner.
	* @param open - current menu state.
	*/
	setSubagentCatalogOpen(parentSessionId, open) {
		if (open) {
			this.openCatalogs.add(parentSessionId);
			this.refreshSubagents(parentSessionId);
		} else {
			this.openCatalogs.delete(parentSessionId);
			const timer = this.catalogDebounce.get(parentSessionId);
			if (timer !== void 0) {
				clearTimeout(timer);
				this.catalogDebounce.delete(parentSessionId);
			}
		}
	}
	/** Full refresh via session.list (single-flight: an in-flight call is reused). */
	refreshList() {
		if (this.listInflight !== null) return this.listInflight;
		this.listState = "loading";
		this.listError = null;
		const established = this.summaries;
		const mutations = [];
		this.listMutations = mutations;
		this.notifier.markDirty();
		this.listInflight = (async () => {
			try {
				const result = await this.remote.session.list({ ...this.selected === void 0 ? {} : { includeSessionId: this.selected } });
				if (result.ok) {
					this.listCursor = result.value.nextCursor;
					this.listHasMore = result.value.hasMore;
					const baseline = this.listPhase === "pending" ? [...result.value.items] : mergeOrderedBaseline(established, result.value.items, (summary) => summary.sessionId);
					for (const s of baseline) if (!this.prevRunning.has(s.sessionId)) this.prevRunning.set(s.sessionId, s.running);
					let summaries = baseline;
					for (const mutation of mutations) {
						summaries = applyMutation(summaries, mutation);
						this.summaries = summaries;
						this.syncCompletedNotifications();
					}
					this.summaries = summaries;
					this.listState = "idle";
					this.listPhase = "ready";
					this.syncCompletedNotifications();
					for (const s of this.summaries) {
						const session = this.sessions.get(s.sessionId);
						if (session === void 0) continue;
						session.handleBlank(s.blank);
						session.handleRunning(s.running);
					}
					for (const s of result.value.items) {
						const block = s.projections;
						if (block === void 0) continue;
						const store = this.projectionStore(s.sessionId);
						const values = block.values;
						for (const key of Object.keys(values)) store.apply(key, values[key], sessionSeqCursor(block.asOfSeq));
					}
				} else {
					this.listState = "error";
					this.listError = result.error;
				}
			} catch (error) {
				if (!isRemoteFailure(error)) throw error;
				this.listState = "error";
				this.listError = error;
			} finally {
				this.listMutations = null;
				this.listInflight = null;
				this.notifier.markDirty();
			}
		})();
		return this.listInflight;
	}
	/** Append one explicit continuation page; concurrent requests share it. */
	loadMoreList() {
		if (this.listInflight !== null) return this.listInflight;
		if (!this.listHasMore || this.listCursor === void 0) return Promise.resolve();
		this.listLoadingMore = true;
		this.listError = null;
		this.notifier.markDirty();
		const cursor = this.listCursor;
		const established = this.summaries;
		const mutations = [];
		this.listMutations = mutations;
		this.listInflight = (async () => {
			try {
				const result = await this.remote.session.list({ cursor });
				if (!result.ok) {
					this.listError = result.error;
					return;
				}
				const pageById = new Map(result.value.items.map((summary) => [summary.sessionId, summary]));
				this.summaries = established.map((summary) => pageById.get(summary.sessionId) ?? summary);
				const known = new Set(this.summaries.map((summary) => summary.sessionId));
				for (const summary of result.value.items) {
					if (known.has(summary.sessionId)) continue;
					this.summaries.push(summary);
					known.add(summary.sessionId);
				}
				for (const summary of this.summaries) if (!this.prevRunning.has(summary.sessionId)) this.prevRunning.set(summary.sessionId, summary.running);
				for (const mutation of mutations) {
					this.summaries = applyMutation(this.summaries, mutation);
					this.syncCompletedNotifications();
				}
				this.syncCompletedNotifications();
				this.listCursor = result.value.nextCursor;
				this.listHasMore = result.value.hasMore;
				for (const summary of this.summaries) {
					const session = this.sessions.get(summary.sessionId);
					if (session !== void 0) {
						session.handleBlank(summary.blank);
						session.handleRunning(summary.running);
					}
					const block = summary.projections;
					if (block === void 0) continue;
					const store = this.projectionStore(summary.sessionId);
					const values = block.values;
					for (const key of Object.keys(values)) store.apply(key, values[key], sessionSeqCursor(block.asOfSeq));
				}
			} catch (error) {
				if (!isRemoteFailure(error)) throw error;
				this.listError = error;
			} finally {
				this.listLoadingMore = false;
				this.listMutations = null;
				this.listInflight = null;
				this.notifier.markDirty();
			}
		})();
		return this.listInflight;
	}
	/**
	* Search visible session message content without adding transient query
	* state to the list snapshot.
	* @param query - non-blank literal phrase.
	* @param signal - cancellation for superseded UI queries.
	* @returns the Host result or a folded transport error.
	*/
	async search(query, signal) {
		const result = await this.remote.session.search({ query }, signal);
		if (!result.ok) return result;
		return {
			ok: true,
			value: {
				items: [...result.value.items],
				hasMore: result.value.hasMore
			}
		};
	}
	/**
	* Contract session.create; on success merge into summaries immediately (no
	* wait for the next refresh). A created session is blank by definition
	* (entity birth precedes the first message).
	* @param opts - target workspace or working directory, plus an optional caller-owned id.
	* @returns the create result.
	*/
	async create(opts = {}) {
		const shared = opts.sessionId === void 0 ? {} : { sessionId: opts.sessionId };
		const payload = opts.workspaceId !== void 0 ? {
			workspaceId: opts.workspaceId,
			...shared
		} : {
			...opts.cwd === void 0 ? {} : { cwd: opts.cwd },
			...shared
		};
		const result = await this.remote.session.create(payload);
		if (result.ok) this.recordMutation({
			kind: "upsert",
			summary: {
				sessionId: result.value.sessionId,
				updatedAt: Date.now(),
				running: false,
				blank: true,
				...opts.cwd !== void 0 ? { cwd: opts.cwd } : {}
			}
		});
		else {
			const publishedSessionId = workspaceAttachSessionId(result.error);
			if (publishedSessionId !== void 0) this.recordMutation({
				kind: "upsert",
				summary: {
					sessionId: publishedSessionId,
					updatedAt: Date.now(),
					running: false,
					blank: true
				}
			});
		}
		return result;
	}
	/**
	* Contract session.fork; on success merge the child into summaries
	* immediately (same synchronous-addressability guarantee as create). The
	* child carries the source's history, so it is never blank; lineage rides
	* parentSessionId so the list nests it under its source. A child published
	* before Workspace attachment fails is also reconciled into the list.
	* @param opts - source session and the optional seq anchoring the cut.
	* @returns the fork result (the child session id).
	*/
	async fork(opts) {
		const source = this.summaries.find((s) => s.sessionId === opts.sessionId);
		const result = await this.remote.session.fork({
			sessionId: opts.sessionId,
			...opts.atSeq === void 0 ? {} : { atSeq: opts.atSeq }
		});
		const childId = result.ok ? result.value.sessionId : workspaceAttachSessionId(result.error);
		if (childId !== void 0) this.recordMutation({
			kind: "upsert",
			summary: {
				sessionId: childId,
				updatedAt: Date.now(),
				running: false,
				blank: false,
				parentSessionId: opts.sessionId,
				...source?.cwd !== void 0 ? { cwd: source.cwd } : {}
			}
		});
		return result;
	}
	/**
	* Insert-or-enrich a locally synthesized summary: a new id prepends; an
	* existing entry only gains fields it lacks (the session-added frame and the
	* create() echo race — whichever lands second must fill the placeholder's
	* missing cwd/parentSessionId, never overwrite list-refresh data).
	*/
	mergeSummary(summary) {
		this.recordMutation({
			kind: "upsert",
			summary
		});
	}
	/** Apply immediately and retain for replay when a list response is in flight. */
	recordMutation(mutation) {
		this.listMutations?.push(mutation);
		this.summaries = applyMutation(this.summaries, mutation);
		this.syncCompletedNotifications();
		this.notifier.markDirty();
	}
	/**
	* uSES subscription entry for useSessionList.
	* @param listener - change callback.
	* @returns the unsubscribe function.
	*/
	subscribe(listener) {
		return this.notifier.subscribe(listener);
	}
	/**
	* Cached list snapshot (rebuilt lazily when dirty with no listeners).
	* @returns the cached reference (stable until the next flush).
	*/
	getListSnapshot() {
		this.notifier.ensureFresh();
		return this.listSnapshotCache;
	}
	/**
	* Apply a complete control baseline or one later replacement frame.
	* @param frame - baseline or live control replacement from Session Controller.
	*/
	handleControlFrame(frame) {
		if (frame.type === "baseline") {
			this.replaceControlBaseline(frame.value);
			return;
		}
		if (frame.type === "projection") {
			this.projectionStore(frame.sessionId).apply(frame.key, frame.value, SessionSeq(frame.seq));
			this.notifier.markDirty();
			return;
		}
		if (frame.type === "jobs") {
			if (frame.jobs.length === 0) this.jobsBySession.delete(frame.sessionId);
			else this.jobsBySession.set(frame.sessionId, frame.jobs);
			this.notifier.markDirty();
			return;
		}
		this.queues.set(frame.sessionId, frame.items);
		this.sessions.get(frame.sessionId)?.handleControlFrame(frame);
	}
	replaceControlBaseline(baseline) {
		this.queues.clear();
		for (const [sessionId, items] of Object.entries(baseline.queues)) this.queues.set(sessionId, items);
		this.jobsBySession.clear();
		for (const [sessionId, jobs] of Object.entries(baseline.jobs)) if (jobs.length > 0) this.jobsBySession.set(sessionId, jobs);
		for (const [sessionId, block] of Object.entries(baseline.projections)) {
			const store = this.projectionStore(sessionId);
			const asOfSeq = sessionSeqCursor(block.asOfSeq);
			store.truncate(asOfSeq);
			store.seed({
				...block,
				asOfSeq
			});
		}
		for (const [sessionId, session] of this.sessions) session.replaceControl(this.queues.get(sessionId) ?? []);
		this.notifier.markDirty();
	}
	/**
	* Apply one Session-list addition forwarded through `ctx.remote.$on`.
	* @param summary - current Host summary for the added Session.
	*/
	handleSessionAdded(summary) {
		this.mergeSummary(summary);
		this.sessions.get(summary.sessionId)?.handleBlank(summary.blank);
		const projections = summary.projections;
		if (projections !== void 0) {
			const store = this.projectionStore(summary.sessionId);
			for (const [key, value] of Object.entries(projections.values)) store.apply(key, value, sessionSeqCursor(projections.asOfSeq));
		}
		if (summary.origin === "subagent" && summary.parentSessionId !== void 0) this.markCatalogParentExpandable(summary.parentSessionId);
		if (summary.parentSessionId !== void 0 && (this.selected === summary.parentSessionId || this.openCatalogs.has(summary.parentSessionId))) this.scheduleCatalogRefresh(summary.parentSessionId);
	}
	/**
	* Apply one Session removal forwarded through `ctx.remote.$on`.
	* @param sessionId - removed Session identity.
	*/
	handleSessionRemoved(sessionId) {
		const durableSubagent = this.summaries.find((candidate) => candidate.sessionId === sessionId)?.origin === "subagent" || this.addresses.has(sessionId);
		this.recordMutation(durableSubagent ? {
			kind: "status",
			sessionId,
			running: false
		} : {
			kind: "remove",
			sessionId
		});
		this.updateCatalogActivity(sessionId, false);
		if (durableSubagent) this.sessions.get(sessionId)?.handleRunning(false);
		else this.sessions.get(sessionId)?.handleRemoved();
		this.queues.delete(sessionId);
		this.jobsBySession.delete(sessionId);
		if (!durableSubagent) this.projectionStores.delete(sessionId);
		const inflightCatalog = this.catalogInflight.get(sessionId);
		if (inflightCatalog !== void 0) {
			inflightCatalog.parentAvailableOverride = false;
			this.catalogStale.add(sessionId);
		}
		const ownedCatalog = this.catalogs.get(sessionId);
		if (ownedCatalog !== void 0 && ownedCatalog.parentAvailable) this.catalogs.set(sessionId, {
			...ownedCatalog,
			parentAvailable: false
		});
		for (const [childId, address] of this.addresses) if (address.parentSessionId === sessionId) this.sessions.get(childId)?.handleSubagentParentAvailable(false);
	}
	/**
	* Apply one live Agent running-state change.
	* @param sessionId - Session whose Agent state changed.
	* @param running - current Agent running state.
	*/
	handleSessionStatus(sessionId, running) {
		this.recordMutation({
			kind: "status",
			sessionId,
			running
		});
		this.sessions.get(sessionId)?.handleRunning(running);
		this.updateCatalogActivity(sessionId, running);
	}
	/**
	* Advance Session-list activity from one user-authored durable message.
	* @param sessionId - Session whose activity changed.
	* @param updatedAt - durable message timestamp.
	*/
	handleSessionActivity(sessionId, updatedAt) {
		this.recordMutation({
			kind: "activity",
			sessionId,
			updatedAt
		});
	}
	/**
	* Surface one live Agent failure on an already-materialized Session.
	* @param sessionId - Session whose Agent failed.
	* @param message - caller-visible failure description.
	*/
	handleSessionError(sessionId, message) {
		this.sessions.get(sessionId)?.handleAgentError(message);
	}
	/** Mark resident open transcripts as waiting for the next Host baseline. */
	handleDisconnected() {
		for (const session of this.sessions.values()) session.handleDisconnected();
	}
	/**
	* Repair one re-established Host-event generation with queryable baselines.
	* Opened Session follow streams resume independently through API Gateway.
	*/
	handleConnected() {
		this.refreshList();
		const selectedAddress = this.selected === void 0 ? void 0 : this.addresses.get(this.selected);
		if (selectedAddress !== void 0) this.refreshSubagents(selectedAddress.parentSessionId);
		if (this.selected !== void 0) this.refreshSubagents(this.selected);
		for (const parentSessionId of this.openCatalogs) this.refreshSubagents(parentSessionId);
	}
	/** Debounce membership refetches while one parent catalog is selected or open. */
	scheduleCatalogRefresh(parentSessionId) {
		if (this.catalogDebounce.has(parentSessionId)) return;
		const timer = setTimeout(() => {
			this.catalogDebounce.delete(parentSessionId);
			if (this.catalogInflight.has(parentSessionId)) {
				this.catalogStale.add(parentSessionId);
				return;
			}
			this.refreshSubagents(parentSessionId);
		}, 50);
		this.catalogDebounce.set(parentSessionId, timer);
	}
	/** Apply one Agent-driver transition to loaded and in-flight catalogs. */
	updateCatalogActivity(childSessionId, running) {
		const activity = running ? "running" : "inactive";
		for (const inflight of this.catalogInflight.values()) inflight.activityRows.set(childSessionId, activity);
		let changed = false;
		for (const [parentSessionId, catalog] of this.catalogs) {
			if (!catalog.entries.some((entry) => entry.kind === "child" && entry.id === childSessionId && entry.activity !== activity)) continue;
			const entries = catalog.entries.map((entry) => {
				if (entry.kind !== "child" || entry.id !== childSessionId) return entry;
				return {
					...entry,
					activity
				};
			});
			changed = true;
			this.catalogs.set(parentSessionId, {
				...catalog,
				entries
			});
		}
		if (changed) this.notifier.markDirty();
	}
	/** Preserve and project a positive expandability hint after one direct subagent publishes. */
	markCatalogParentExpandable(parentSessionId) {
		this.applyCatalogParentExpandable(parentSessionId);
		for (const inflight of this.catalogInflight.values()) inflight.expandableRows.add(parentSessionId);
	}
	/** Apply one positive expandability hint to every loaded catalog containing that unique row id. */
	applyCatalogParentExpandable(parentSessionId) {
		let changed = false;
		for (const [catalogParentId, catalog] of this.catalogs) {
			if (!catalog.entries.some((entry) => entry.kind === "child" && entry.id === parentSessionId && !entry.hasChildren)) continue;
			const entries = catalog.entries.map((entry) => {
				if (entry.kind !== "child" || entry.id !== parentSessionId || entry.hasChildren) return entry;
				return {
					...entry,
					hasChildren: true
				};
			});
			changed = true;
			this.catalogs.set(catalogParentId, {
				...catalog,
				entries
			});
		}
		if (changed) this.notifier.markDirty();
	}
	/** Fold request-local row mutations into one catalog result before publication. */
	withCatalogMutations(entries, expandableRows, activityRows) {
		return entries.map((entry) => {
			if (entry.kind !== "child") return entry;
			const activity = activityRows.get(entry.id);
			if (!expandableRows.has(entry.id) && activity === void 0) return entry;
			return {
				...entry,
				...expandableRows.has(entry.id) ? { hasChildren: true } : {},
				...activity === void 0 ? {} : { activity }
			};
		});
	}
	/**
	* Reconcile completion reminders against the latest summaries, eagerly after
	* every mutation and pull (a snapshot-build-time pass would collapse
	* consecutive status frames into one observation). A running→idle edge of a
	* non-selected session arms its reminder; running disarms it; removal drops
	* it. First observation only records the running bit — sessions already
	* idle at load get no reminder.
	*/
	syncCompletedNotifications() {
		const seen = /* @__PURE__ */ new Set();
		for (const s of this.summaries) {
			seen.add(s.sessionId);
			const prev = this.prevRunning.get(s.sessionId);
			if (prev === void 0) {
				this.prevRunning.set(s.sessionId, s.running);
				continue;
			}
			if (prev && !s.running) {
				if (s.sessionId !== this.selected) this.completedNotifications.add(s.sessionId);
			} else if (s.running) this.completedNotifications.delete(s.sessionId);
			this.prevRunning.set(s.sessionId, s.running);
		}
		for (const id of this.prevRunning.keys()) if (!seen.has(id)) this.prevRunning.delete(id);
		for (const id of this.completedNotifications) if (!seen.has(id)) this.completedNotifications.delete(id);
	}
	buildListSnapshot() {
		const items = flattenLineage(this.summaries.map((summary) => {
			const projectionStore = this.projectionStores.get(summary.sessionId);
			const title = projectionStore?.get("title");
			const projectionValues = projectionStore?.values();
			return {
				...summary,
				...typeof title === "string" && title !== "" ? { title } : {},
				...projectionValues === void 0 ? {} : { projectionValues }
			};
		}), this.completedNotifications).map((entry) => {
			const prev = this.entryCache.get(entry.sessionId);
			if (prev !== void 0 && prev.updatedAt === entry.updatedAt && prev.running === entry.running && prev.blank === entry.blank && prev.parentSessionId === entry.parentSessionId && prev.cwd === entry.cwd && prev.origin === entry.origin && prev.title === entry.title && prev.depth === entry.depth && prev.projectionValues === entry.projectionValues && prev.completed === entry.completed) return prev;
			this.entryCache.set(entry.sessionId, entry);
			return entry;
		});
		for (const id of this.entryCache.keys()) if (!items.some((e) => e.sessionId === id)) this.entryCache.delete(id);
		if (!(items.length === this.itemsCache.length && items.every((e, i) => e === this.itemsCache[i]))) this.itemsCache = items;
		const selected = this.selected;
		const current = selected !== void 0 && (items.some((item) => item.sessionId === selected) || this.addresses.has(selected)) ? selected : void 0;
		return {
			items: this.itemsCache,
			current,
			state: this.listState,
			phase: this.listPhase,
			error: this.listError,
			hasMore: this.listHasMore,
			loadingMore: this.listLoadingMore,
			subagentsByParent: Object.fromEntries(this.catalogs),
			jobsBySession: Object.fromEntries(this.jobsBySession),
			currentAddress: current === void 0 ? void 0 : this.addresses.get(current)
		};
	}
};
/** Apply one list mutation without deriving display order. */
function applyMutation(summaries, mutation) {
	switch (mutation.kind) {
		case "upsert": {
			const existing = summaries.find((summary) => summary.sessionId === mutation.summary.sessionId);
			if (existing === void 0) return [mutation.summary, ...summaries];
			const filled = {
				...existing,
				blank: existing.blank && mutation.summary.blank,
				...existing.cwd === void 0 && mutation.summary.cwd !== void 0 ? { cwd: mutation.summary.cwd } : {},
				...existing.parentSessionId === void 0 && mutation.summary.parentSessionId !== void 0 ? { parentSessionId: mutation.summary.parentSessionId } : {},
				...existing.origin === void 0 && mutation.summary.origin !== void 0 ? { origin: mutation.summary.origin } : {}
			};
			if (filled.cwd === existing.cwd && filled.parentSessionId === existing.parentSessionId && filled.origin === existing.origin && filled.blank === existing.blank) return [...summaries];
			return summaries.map((summary) => summary.sessionId === mutation.summary.sessionId ? filled : summary);
		}
		case "remove": return summaries.filter((summary) => summary.sessionId !== mutation.sessionId);
		case "status": return summaries.map((summary) => summary.sessionId === mutation.sessionId && (summary.running !== mutation.running || mutation.running && summary.blank) ? {
			...summary,
			running: mutation.running,
			blank: summary.blank && !mutation.running
		} : summary);
		case "activity": return summaries.map((summary) => summary.sessionId === mutation.sessionId && mutation.updatedAt > summary.updatedAt ? {
			...summary,
			updatedAt: mutation.updatedAt
		} : summary);
		case "engaged": return summaries.map((summary) => summary.sessionId === mutation.sessionId && summary.blank ? {
			...summary,
			blank: false
		} : summary);
	}
}
/** Temporary source-plane bridge while the Host contract and client project build independently. */
function workspaceAttachSessionId(error) {
	return error.code === "session/workspace-attach-failed" ? error.details.sessionId : void 0;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/service.js
/** Structured session-create failure. */
var SessionCreateError = class extends Error {
	rpcError;
	requestedSessionId;
	name = "SessionCreateError";
	/**
	* @param rpcError - Host business or folded transport error.
	* @param requestedSessionId - caller-preallocated id used for later stream/list reconciliation.
	*/
	constructor(rpcError, requestedSessionId) {
		super(`session create failed: ${rpcError.code}: ${rpcError.message}`);
		this.rpcError = rpcError;
		this.requestedSessionId = requestedSessionId;
	}
};
/** Structured session-fork failure. */
var SessionForkError = class extends Error {
	rpcError;
	sourceSessionId;
	name = "SessionForkError";
	/**
	* @param rpcError - Host business or folded transport error.
	* @param sourceSessionId - the session the fork was cut from.
	*/
	constructor(rpcError, sourceSessionId) {
		super(`session fork failed: ${rpcError.code}: ${rpcError.message}`);
		this.rpcError = rpcError;
		this.sourceSessionId = sourceSessionId;
	}
};
/**
* Display title projection: durable title, project directory basename, then
* the raw id.
*/
function displayTitleOf(title, cwd, id) {
	if (title !== void 0) return title;
	if (cwd !== void 0 && cwd !== "") {
		const base = workspaceTitleOf(cwd);
		if (base !== "") return base;
	}
	return id;
}
/**
* Increment a trailing fork number while preserving its half-width or
* full-width parentheses; an unnumbered title starts with ` (1)`.
* @param title - source session's durable title.
* @returns the title assigned to the fork child.
*/
function increasedForkTitle(title) {
	const ascii = /^(.*?)\((\d+)\)$/u.exec(title);
	if (ascii?.[1] !== void 0 && ascii[2] !== void 0) return `${ascii[1]}(${BigInt(ascii[2]) + 1n})`;
	const fullWidth = /^(.*?)（(\d+)）$/u.exec(title);
	if (fullWidth?.[1] !== void 0 && fullWidth[2] !== void 0) return `${fullWidth[1]}（${BigInt(fullWidth[2]) + 1n}）`;
	return `${title} (1)`;
}
/** Root sessions service: list store, current selection, object-layer manager, scope tree, bindings, and breadcrumb routes. */
var ClientSessions = class {
	rootCtx;
	/**
	* The wire schema's own result bound, re-exposed for presentation plugins as
	* injected data. Not per-connection state: the `session.search` response
	* schema caps `items` at this constant, so every transport (fixture included)
	* reports the same number.
	*/
	searchResultLimit = 20;
	/** List snapshot store (list RPC + host stream increments; re-pulled on reconnect) — the useSessions standard feed, current included. */
	list;
	/** The object-layer instance cluster and frame dispatch entry. */
	manager;
	/**
	* Persisted selection cell (the durable half of `list.current`). Private on
	* purpose: reads go through the list snapshot; writes through {@link
	* ClientSessions.open} / {@link ClientSessions.clear}. Projection
	* validates it against the live list instead of destructively pruning, so a
	* selection survives transient list states (reconnect re-pull) and
	* resurfaces when its session returns.
	*/
	selection;
	scopes = /* @__PURE__ */ new Map();
	/** In-flight scope drops remain here after records leave `scopes`, so root disposal can await quiescence. */
	scopeDrops = /* @__PURE__ */ new Set();
	/**
	* The staged session id — follows `list.current` exactly, holding its last
	* defined value across masked gaps (a transiently absent selection blanks
	* `current` without moving the stage, so reconnect re-pulls and removals
	* keep the staged scope's frozen view alive until the stage moves on).
	*/
	watched;
	/** Removed-while-staged sessions whose teardown waits for the stage to move away. */
	deferredRemovals = /* @__PURE__ */ new Set();
	/**
	* @param ctx - client root context (scope fibers mount under it).
	* @param remote - generated Remote namespaces shared with every Session.
	* @param options - platform inputs and hydrated navigation for this host.
	*/
	constructor(rootCtx, remote, options) {
		this.rootCtx = rootCtx;
		this.selection = options.selection;
		const restored = this.selection.getSnapshot();
		this.manager = new SessionManager(remote, options.platform, restored.sessionId, restored.subagentAddress);
		this.list = createSnapshotStore({
			ids: [],
			byId: {},
			current: void 0,
			phase: "pending",
			hasMore: false,
			loadingMore: false,
			subagentsByParent: {},
			jobsBySession: {},
			currentAddress: void 0
		});
		const disposeManagerProjection = this.manager.subscribe(() => {
			this.projectList();
		});
		const disposeStageFollower = this.list.subscribe(() => {
			this.followCurrent();
		});
		rootCtx.effect(() => async () => {
			disposeStageFollower();
			disposeManagerProjection();
			const scopes = [...this.scopes];
			this.scopes.clear();
			this.deferredRemovals.clear();
			this.watched = void 0;
			for (const [id, record] of scopes) this.startScopeDrop(id, record);
			await this.drainScopeDrops();
			await this.manager.dispose();
		}, "session-controller.client.sessions");
		rootCtx.reflect.provide("sessions", this, void 0);
	}
	/**
	* Select a listed or retained catalog-addressed session as current.
	* @param id - listed or addressed session id.
	*/
	open(id) {
		this.manager.select(id);
	}
	/**
	* Open a healthy catalog child through its direct-parent address.
	* @param address - catalog-derived parent and child ids.
	*/
	openSubagent(address) {
		this.manager.selectSubagent(address);
	}
	/**
	* Resolve an already discovered direct-parent address without opening it.
	* Feature plugins use this to avoid Agent-bound RPCs in persisted child views.
	* @param id - possible addressed child id.
	* @returns The retained address, when present.
	*/
	subagentAddress(id) {
		return this.manager.subagentAddress(id);
	}
	/**
	* Inform the Session Controller whether a catalog menu is consuming membership updates.
	* @param parentSessionId - selected parent.
	* @param open - menu state.
	*/
	setSubagentCatalogOpen(parentSessionId, open) {
		this.manager.setSubagentCatalogOpen(parentSessionId, open);
	}
	/**
	* Refresh one direct-child catalog.
	* @param parentSessionId - catalog owner.
	*/
	refreshSubagents(parentSessionId) {
		return this.manager.refreshSubagents(parentSessionId);
	}
	/**
	* Clear the current selection so the layout shows the no-session empty
	* state (new-session affordance and the workspace preselection flow).
	* Wipes the persisted selection too — a reload stays on empty until the
	* user opens or starts a session. The staged scope keeps its frozen view
	* per the masked-gap contract until the next open() moves the stage.
	*/
	clear() {
		this.manager.clearSelection();
	}
	/**
	* Refresh the real Session baseline, reusing an in-flight pull.
	* @returns completion of the current or newly started baseline pull.
	*/
	refresh() {
		return this.manager.refreshList();
	}
	/** Fetch the next explicit session-list page. */
	loadMore() {
		return this.manager.loadMoreList();
	}
	/**
	* Search the Host's visible message-content index. Results stay
	* request-local; the list snapshot remains the metadata authority.
	* @param query - non-blank literal phrase.
	* @param signal - cancellation for a superseded search.
	* @returns bounded results or a business/transport error.
	*/
	search(query, signal) {
		return this.manager.search(query, signal);
	}
	/**
	* Apply one Session Controller live-control frame.
	* @param frame - baseline or live control replacement.
	*/
	handleControlFrame(frame) {
		this.manager.handleControlFrame(frame);
	}
	/**
	* Apply one remotely forwarded Session-list addition.
	* @param summary - current Host summary for the added Session.
	*/
	handleSessionAdded(summary) {
		this.manager.handleSessionAdded(summary);
	}
	/**
	* Apply one remotely forwarded Session removal.
	* @param sessionId - removed Session identity.
	*/
	handleSessionRemoved(sessionId) {
		this.manager.handleSessionRemoved(sessionId);
	}
	/**
	* Apply one remotely forwarded running-state change.
	* @param args - Session identity and current Agent running state.
	*/
	handleSessionStatus(...args) {
		this.manager.handleSessionStatus(...args);
	}
	/**
	* Apply one remotely forwarded list-activity change.
	* @param args - Session identity and durable activity timestamp.
	*/
	handleSessionActivity(...args) {
		this.manager.handleSessionActivity(...args);
	}
	/**
	* Apply one remotely forwarded Agent failure.
	* @param args - Session identity and caller-visible failure description.
	*/
	handleSessionError(...args) {
		this.manager.handleSessionError(...args);
	}
	/** Retain loaded transcripts while the Host generation is unavailable. */
	handleDisconnected() {
		this.manager.handleDisconnected();
	}
	/** Repair queryable baselines after the Host connection returns. */
	handleConnected() {
		this.manager.handleConnected();
	}
	/**
	* Create a session on the host. Resolution guarantee: by the time the
	* promise resolves, the created session is in the list store and
	* {@link ClientSessions.binding} resolves it — callers (New Session
	* draft hand-off) may address the scope synchronously, without waiting a
	* notifier flush. The synchronous projection below makes this structural
	* rather than an accident of microtask ordering.
	* @param opts - target workspace or directory and an optional preallocated id.
	* @returns the new session id.
	* @throws {SessionCreateError} with the requested id.
	*/
	async create(opts = {}) {
		const result = await this.manager.create(opts);
		if (!result.ok) throw new SessionCreateError(result.error, opts.sessionId);
		this.projectList();
		return result.value.sessionId;
	}
	/**
	* Fork a session from a completed-turn prefix of the source (same
	* synchronous-addressability guarantee as {@link ClientSessions.create}:
	* on resolution the child is in the list store and open() can target it).
	* @param opts - source session id, the optional event seq anchoring the
	*   cut (the boundary is the first turn/end at or after it; an in-log
	*   anchor in an open turn is unavailable rather than clipped backward),
	*   and whether to increment an inherited durable title before resolving.
	*   A fractional anchor floors to a real event seq: the frozen nodes of an
	*   interrupted turn carry flow-ordering seqs between two events, and the
	*   wire takes integers only.
	* @returns the child session id.
	* @throws {SessionForkError} with the source id.
	* @throws {Error} when a requested child-title rename fails after creation.
	*/
	async fork(opts) {
		const sourceTitle = opts.increaseTitle ? this.list.getSnapshot().byId[opts.sessionId]?.title : void 0;
		const result = await this.manager.fork({
			sessionId: opts.sessionId,
			...opts.atSeq === void 0 ? {} : { atSeq: SessionSeq(Math.floor(opts.atSeq)) }
		});
		if (!result.ok) throw new SessionForkError(result.error, opts.sessionId);
		this.projectList();
		const childId = result.value.sessionId;
		if (sourceTitle !== void 0) {
			const child = this.binding(childId)?.session;
			if (child === void 0) throw new Error(`fork child "${childId}" is not locally addressable`);
			const renamed = await child.rename(increasedForkTitle(sourceTitle));
			if (!renamed.ok) throw new Error(`fork child rename failed: ${renamed.error.code}: ${renamed.error.message}`);
		}
		return childId;
	}
	/**
	* Resolve an Agent-scoped context view (use-and-discard).
	* @param id - session id (the agent identity — 1:1 same axis).
	* @returns scoped ctx, or undefined for a session neither listed nor already scoped.
	*/
	scope(id) {
		return this.resolve(id)?.ctx;
	}
	/**
	* Materialize the Agent scope named by a validated Host Remote Event.
	* The first successful Session-list baseline becomes authoritative for its
	* lifetime; until then, transport streams may address the scope in either
	* arrival order.
	* @param id - Host-projected Agent identity (the matching Session id).
	* @returns the identity-stable Agent Context.
	*/
	resolveAgentScope(id) {
		return (this.scopes.get(id) ?? this.materializeScope(id)).ctx;
	}
	/**
	* Read the Agent scope tag off a context. Service-method boundary: fetch
	* bundles must reach scope resolution through ctx.sessions — a cross-bundle
	* value import of the standalone helper would inline a second module
	* instance whose private tag Symbol never matches.
	* @param ctx - any client context.
	* @returns the session id, or undefined on root contexts.
	*/
	scopeOf(ctx) {
		return scopeOf(ctx);
	}
	/**
	* Resolve the business Session behind an Agent-scoped context — the one
	* hop every scoped consumer (event listeners, per-session controllers)
	* takes from ctx-space into object-space (the client mirror of host
	* `agent.session`). Same service-method boundary as
	* {@link ClientSessions.scopeOf}.
	* @param ctx - an Agent-scoped context.
	* @returns the session face, or undefined when the ctx is untagged or its scope was pruned.
	*/
	sessionOf(ctx) {
		const id = scopeOf(ctx);
		if (id === void 0) return void 0;
		return this.scopes.get(id)?.binding.session;
	}
	/**
	* Resolve the stable session binding (scope-addressed assembly feed). Pure
	* resolution — no staging, no window side effects.
	* @param id - session id.
	* @returns binding, or undefined for a session neither listed nor already scoped.
	*/
	binding(id) {
		return this.resolve(id)?.binding;
	}
	/**
	* Move the stage to the list's current session: sweep teardowns deferred
	* behind the previous occupant and pull the new occupant's history window.
	* Staging IS the open signal — the window opens ⟺ the session is on stage
	* — and open() is idempotent (an in-flight or completed open no-ops; a
	* failed one retries the next time current is touched).
	*/
	followCurrent() {
		const snapshot = this.list.getSnapshot();
		const current = snapshot.current;
		if (current === void 0 || snapshot.byId[current] === void 0 || current === this.watched) return;
		this.watched = current;
		this.sweepDeferred();
		const record = this.resolve(current);
		/* v8 ignore next 3 -- defensive: current is always a listed id (open()
		* validates and the projection masks absent selections), so resolve
		* cannot miss; kept so a future current writer cannot crash the notify. */
		if (record !== void 0) {
			record.session.open();
			this.manager.refreshSubagents(current);
		}
	}
	/**
	* Lazily mint the scope + binding for an eligible session. Eligibility and
	* prune share one predicate: listed on the host or selected
	* through a retained subagent address. Breadcrumb-only ancestors remain
	* summary data and do not keep scopes alive.
	*/
	resolve(id) {
		const existing = this.scopes.get(id);
		if (existing !== void 0) return existing;
		if (!this.eligible(id)) return void 0;
		return this.materializeScope(id);
	}
	/** Materialize one scope after its caller establishes that the id may be addressed. */
	materializeScope(id) {
		const { fiber, ctx } = createScope(this.rootCtx, id);
		const session = this.manager.get(id);
		session.bindScope(ctx);
		const record = {
			fiber,
			ctx,
			binding: {
				sessionId: id,
				session,
				eventSource: session.eventSource,
				ctx
			},
			session
		};
		this.scopes.set(id, record);
		return record;
	}
	/** The one aliveness predicate shared by scope mint and prune: host-listed or currently addressed. */
	eligible(id) {
		const { ids, current } = this.list.getSnapshot();
		return current === id || ids.includes(id);
	}
	/** Project the manager's list snapshot into the store (title derivation is display-only). */
	projectList() {
		const { items, current, phase, hasMore, loadingMore, subagentsByParent, jobsBySession, currentAddress } = this.manager.getListSnapshot();
		const ids = [];
		const byId = {};
		for (const entry of items) {
			ids.push(entry.sessionId);
			byId[entry.sessionId] = {
				id: entry.sessionId,
				displayTitle: displayTitleOf(entry.title, entry.cwd, entry.sessionId),
				running: entry.running,
				...entry.completed ? { completed: true } : {},
				blank: entry.blank,
				updatedAt: entry.updatedAt,
				...entry.projectionValues === void 0 ? {} : { projectionValues: entry.projectionValues },
				...entry.title !== void 0 ? { title: entry.title } : {},
				...entry.cwd !== void 0 ? { cwd: entry.cwd } : {},
				...entry.parentSessionId !== void 0 ? { parentId: entry.parentSessionId } : {},
				...entry.origin !== void 0 ? { origin: entry.origin } : {}
			};
		}
		if (current !== void 0 && currentAddress !== void 0) {
			const seen = /* @__PURE__ */ new Set();
			let address = currentAddress;
			while (address !== void 0 && !seen.has(address.childSessionId)) {
				const childId = address.childSessionId;
				seen.add(childId);
				const child = subagentsByParent[address.parentSessionId]?.entries.find((entry) => entry.kind === "child" && entry.id === childId);
				if (child?.kind !== "child") break;
				const displayTitle = child.label ?? childId;
				const summary = byId[childId];
				if (summary === void 0) byId[childId] = {
					id: childId,
					displayTitle,
					parentId: address.parentSessionId,
					origin: "subagent",
					running: child.activity === "running",
					blank: false,
					updatedAt: 0
				};
				else if (summary.displayTitle !== displayTitle) byId[childId] = {
					...summary,
					displayTitle
				};
				const parent = byId[address.parentSessionId];
				if (parent !== void 0 && parent.origin !== "subagent") break;
				address = this.manager.navigationAddress(address.parentSessionId);
			}
		}
		const persisted = this.selection.getSnapshot().sessionId;
		if (current === void 0) {
			if (persisted !== void 0) this.selection.set({});
		} else if (byId[current] !== void 0 && (persisted !== current || this.selection.getSnapshot().subagentAddress?.childSessionId !== currentAddress?.childSessionId || this.selection.getSnapshot().subagentAddress?.parentSessionId !== currentAddress?.parentSessionId || this.selection.getSnapshot().subagentAddress?.mode !== currentAddress?.mode)) this.selection.set({
			sessionId: current,
			...currentAddress === void 0 ? {} : { subagentAddress: currentAddress }
		});
		this.list.set({
			ids,
			byId,
			current,
			phase,
			hasMore,
			loadingMore,
			subagentsByParent,
			jobsBySession,
			currentAddress
		});
		this.pruneScopes();
	}
	/** Tear down scope + instance for no-longer-eligible sessions off stage; the staged one defers until the stage moves. */
	pruneScopes() {
		if (this.list.getSnapshot().phase === "pending") return;
		for (const [id, record] of this.scopes) {
			if (this.eligible(id)) continue;
			if (id === this.watched) {
				this.deferredRemovals.add(id);
				continue;
			}
			this.scopes.delete(id);
			this.deferredRemovals.delete(id);
			this.startScopeDrop(id, record);
		}
	}
	startScopeDrop(id, record) {
		const drop = this.dropScope(id, record);
		this.scopeDrops.add(drop);
		drop.then(() => {
			this.scopeDrops.delete(drop);
		}, () => {
			this.scopeDrops.delete(drop);
		});
	}
	async drainScopeDrops() {
		while (this.scopeDrops.size > 0) await Promise.allSettled([...this.scopeDrops]);
	}
	/**
	* One teardown for the whole per-session axis: the scope
	* fiber (cascading every actx-registered effect: input shell, slash
	* controller, popup, plugin stores, listeners), the session-keyed slot
	* registrations and the Session instance itself — the host session log is the
	* durable truth, a reopen lazily rebuilds and backfills via open().
	*/
	async dropScope(id, record) {
		record.session.unbindScope();
		await Promise.allSettled([record.fiber.dispose(), this.manager.drop(id)]);
	}
	/** Run deferred teardowns whose session is no longer staged (called when the stage moves). */
	sweepDeferred() {
		for (const id of [...this.deferredRemovals]) {
			/* v8 ignore next -- defensive: only the staged id ever defers, and every
			* stage move sweeps first, so the set cannot contain the id the stage just
			* moved to; kept as a guard against future extra sweep call sites. */
			if (id === this.watched) continue;
			if (this.eligible(id)) {
				this.deferredRemovals.delete(id);
				continue;
			}
			const record = this.scopes.get(id);
			this.deferredRemovals.delete(id);
			/* v8 ignore next -- defensive: prune deletes a scope and its deferral
			* together, so a deferred id always still owns its record; kept so a
			* future teardown path cannot double-dispose. */
			if (record !== void 0) {
				this.scopes.delete(id);
				this.startScopeDrop(id, record);
			}
		}
	}
};
//#endregion
//#region ../session-controller/lib/types/client/portable.js
/** Required Remote and Context projection services. */
const inject$2 = [
	"connection",
	"typert",
	"remote",
	"remote.commands",
	"remote.session",
	"remote.subagents"
];
/**
* Install Client Session state and its reconnecting control stream.
* @param ctx - Client Cordis context for one host.
* @param options - platform callbacks and hydrated host-specific navigation.
*/
function applySessions$1(ctx, options) {
	const remotes = ctx.remote;
	const sessions = new ClientSessions(ctx, remotes, options);
	ctx.remote.$on("api-session/added", (summary) => {
		sessions.handleSessionAdded(summary);
	});
	ctx.remote.$on("api-session/removed", (sessionId) => {
		sessions.handleSessionRemoved(sessionId);
	});
	ctx.remote.$on("api-session/status", (sessionId, running) => {
		sessions.handleSessionStatus(sessionId, running);
	});
	ctx.remote.$on("api-session/activity", (sessionId, updatedAt) => {
		sessions.handleSessionActivity(sessionId, updatedAt);
	});
	ctx.remote.$on("api-session/error", (sessionId, message) => {
		sessions.handleSessionError(sessionId, message);
	});
	const control = createSessionControlStream(remotes, {
		accept: (frame) => {
			sessions.handleControlFrame(frame);
		},
		failed: (error) => {
			console.error("[session-controller] control stream failed:", error);
		}
	});
	control.start();
	const connection = ctx.get("connection");
	ctx.effect(() => connection.generation.subscribe(() => {
		if (connection.generation.getSnapshot() === void 0) sessions.handleDisconnected();
	}), "session-controller.client.connection-loss");
	ctx.on("connection/reset", () => {
		sessions.handleConnected();
	});
	if (ctx.remote.$host.home !== void 0) sessions.handleConnected();
	ctx.typert.contexts.registerClient("agent", {
		identity: (candidate) => sessions.scopeOf(candidate),
		resolve: (sessionId) => sessions.resolveAgentScope(sessionId)
	});
	ctx.effect(() => async () => {
		await control.dispose();
	}, "session-controller.client.control");
}
[...inject$2];
//#endregion
//#region ../workspace-controller/lib/types/client/model.js
/** Client-side Workspace state model shared by Remote transport and UI projection. */
/**
* Owns the Client Workspace projection, mutation echoes, and stream/unary race resolution.
*/
var ClientWorkspaceModel = class {
	remote;
	items = [];
	archivedSessionIds = [];
	state = "loading";
	phase = "pending";
	error = null;
	/** Latest local reorder request; only its unary echo may install order. */
	orderRequestGeneration = 0;
	/** Increments on stream orders so a later remote commit outranks an older unary echo. */
	orderFrameGeneration = 0;
	/** Last complete order accepted from a baseline, increment, or current unary echo. */
	committedOrder = [];
	/** Host Workspace ids are never reused, so delayed data cannot resurrect a removed row. */
	removedIds = /* @__PURE__ */ new Set();
	listeners = /* @__PURE__ */ new Set();
	snapshotCache;
	snapshotDirty = false;
	notificationPending = false;
	notificationScheduled = false;
	notificationGeneration = 0;
	/** @param remote - generated Workspace Remote namespace. */
	constructor(remote) {
		this.remote = remote;
		this.snapshotCache = this.buildSnapshot();
	}
	/**
	* Create or resolve a Workspace and merge the unary result immediately.
	* @param input - existing absolute path to adopt.
	* @returns generated Remote result.
	*/
	async create(input) {
		const result = await this.remote.create(input);
		if (result.ok) this.upsert(result.value.workspace);
		return result;
	}
	/**
	* Rename a Workspace and merge the unary result immediately.
	* @param workspaceId - target Workspace.
	* @param title - new display title.
	* @returns generated Remote result.
	*/
	async rename(workspaceId, title) {
		const result = await this.remote.rename({
			workspaceId,
			title
		});
		if (result.ok) this.upsert(result.value.workspace);
		return result;
	}
	/**
	* Delete a Workspace and remove it from the local projection immediately.
	* @param workspaceId - target Workspace.
	* @returns generated Remote result.
	*/
	async delete(workspaceId) {
		const result = await this.remote.delete({ workspaceId });
		if (result.ok) this.remove(workspaceId, true);
		return result;
	}
	/**
	* Optimistically move a Workspace and reconcile the returned complete order.
	* @param workspaceId - Workspace to move.
	* @param beforeWorkspaceId - anchor Workspace; omitted appends.
	* @returns generated Remote result.
	*/
	async insertBefore(workspaceId, beforeWorkspaceId) {
		const requestGeneration = ++this.orderRequestGeneration;
		const frameGeneration = this.orderFrameGeneration;
		const localOrder = this.items.map((workspace) => workspace.workspaceId);
		this.installOrder(insertIdBefore(localOrder, workspaceId, beforeWorkspaceId));
		const result = await this.remote.insertBefore({
			workspaceId,
			...beforeWorkspaceId === void 0 ? {} : { beforeWorkspaceId }
		});
		if (requestGeneration === this.orderRequestGeneration && frameGeneration === this.orderFrameGeneration) this.installOrder(result.ok ? result.value.workspaceIds : this.committedOrder, result.ok);
		return result;
	}
	/**
	* Move a Session within its Workspace and merge the returned row.
	* @param workspaceId - owning Workspace.
	* @param sessionId - accounted Session to move.
	* @param beforeSessionId - accounted anchor; omitted appends.
	* @returns generated Remote result.
	*/
	async insertSessionBefore(workspaceId, sessionId, beforeSessionId) {
		const result = await this.remote.insertSessionBefore({
			workspaceId,
			sessionId,
			...beforeSessionId === void 0 ? {} : { beforeSessionId }
		});
		if (result.ok) this.upsert(result.value.workspace);
		return result;
	}
	/**
	* Archive one Session and install the returned complete archive set.
	* @param sessionId - Session to archive.
	* @returns generated Remote result.
	*/
	async archiveSession(sessionId) {
		const result = await this.remote.archiveSession({ sessionId });
		if (result.ok) this.installArchived(result.value.archivedSessionIds);
		return result;
	}
	/**
	* Replace the projection from one complete stream-generation baseline.
	* @param baseline - complete Workspace and archive projection.
	*/
	replaceBaseline(baseline) {
		this.orderFrameGeneration++;
		this.installViews(baseline.items);
		this.installArchived(baseline.archivedSessionIds);
		this.state = "idle";
		this.phase = "ready";
		this.error = null;
		this.invalidate();
	}
	/** Merge one decoded Workspace upsert from the current follow generation. */
	upsertView(workspace) {
		this.upsert(workspace);
	}
	/** Apply one decoded Workspace removal from the current follow generation. */
	removeView(workspaceId) {
		this.remove(workspaceId);
	}
	/** Replace Host-confirmed order from the current follow generation. */
	replaceOrder(workspaceIds) {
		this.orderFrameGeneration++;
		this.installOrder(workspaceIds, true);
	}
	/**
	* Replace the archived Session set from the current follow generation.
	* @param archivedSessionIds - complete Host-confirmed archive set.
	*/
	replaceArchived(archivedSessionIds) {
		this.installArchived(archivedSessionIds);
	}
	/** Keep the last complete projection visible while a lost carrier reconnects. */
	handleCarrierFailure() {
		this.state = "loading";
		this.error = null;
		this.invalidate();
	}
	/**
	* Publish a non-retryable stream or protocol failure.
	* @param error - terminal stream failure.
	*/
	handleStreamFailure(error) {
		if (!isRemoteFailure(error)) throw error;
		this.state = "error";
		this.error = error;
		this.invalidate();
	}
	/**
	* Subscribe to Workspace state invalidation.
	* @param listener - invalidation callback.
	* @returns unsubscribe function.
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	}
	/**
	* Read the cached state, rebuilding it first when necessary.
	* @returns the current stable Workspace list snapshot.
	*/
	getSnapshot() {
		this.refreshSnapshot();
		return this.snapshotCache;
	}
	buildSnapshot() {
		return {
			items: this.items,
			archivedSessionIds: this.archivedSessionIds,
			state: this.state,
			phase: this.phase,
			error: this.error
		};
	}
	installArchived(archivedSessionIds) {
		if (archivedSessionIds.length === this.archivedSessionIds.length && archivedSessionIds.every((id, index) => id === this.archivedSessionIds[index])) return;
		this.archivedSessionIds = [...archivedSessionIds];
		this.invalidate();
	}
	installOrder(workspaceIds, committed = false) {
		if (committed) this.committedOrder = [...workspaceIds];
		const rank = new Map(workspaceIds.map((id, index) => [id, index]));
		const items = [...this.items].sort((left, right) => (rank.get(left.workspaceId) ?? Number.MAX_SAFE_INTEGER) - (rank.get(right.workspaceId) ?? Number.MAX_SAFE_INTEGER));
		if (items.every((item, index) => item === this.items[index])) return;
		this.items = items;
		this.invalidate();
	}
	upsert(view) {
		if (this.removedIds.has(view.workspaceId)) return;
		const index = this.items.findIndex((item) => item.workspaceId === view.workspaceId);
		const installed = this.items[index];
		if (installed !== void 0 && Date.parse(view.updatedAt) < Date.parse(installed.updatedAt)) return;
		if (!this.committedOrder.includes(view.workspaceId)) this.committedOrder = [view.workspaceId, ...this.committedOrder];
		this.items = index === -1 ? [view, ...this.items] : this.items.map((item, position) => position === index ? view : item);
		this.invalidate();
	}
	remove(workspaceId, immediate = false) {
		this.removedIds.add(workspaceId);
		this.committedOrder = this.committedOrder.filter((id) => id !== workspaceId);
		const items = this.items.filter((item) => item.workspaceId !== workspaceId);
		if (items.length === this.items.length) {
			if (immediate) this.invalidate(true);
			return;
		}
		this.items = items;
		this.invalidate(immediate);
	}
	installViews(views) {
		const installed = /* @__PURE__ */ new Map();
		for (const view of views) if (!this.removedIds.has(view.workspaceId)) installed.set(view.workspaceId, view);
		this.items = [...installed.values()];
		this.committedOrder = views.map((view) => view.workspaceId);
	}
	invalidate(immediate = false) {
		this.snapshotDirty = true;
		this.notificationPending = true;
		if (immediate) {
			this.notificationGeneration++;
			this.notificationScheduled = false;
			this.flush();
			return;
		}
		if (this.notificationScheduled) return;
		this.notificationScheduled = true;
		const generation = ++this.notificationGeneration;
		queueMicrotask(() => {
			if (generation !== this.notificationGeneration) return;
			this.notificationScheduled = false;
			this.flush();
		});
	}
	flush() {
		if (!this.notificationPending || this.listeners.size === 0) return;
		this.notificationPending = false;
		this.refreshSnapshot();
		notifySubscribers(this.listeners, "[workspace-controller]");
	}
	refreshSnapshot() {
		if (!this.snapshotDirty) return;
		this.snapshotDirty = false;
		this.snapshotCache = this.buildSnapshot();
	}
};
function insertIdBefore(ids, id, beforeId) {
	if (!ids.includes(id) || beforeId !== void 0 && !ids.includes(beforeId) || beforeId === id) return [...ids];
	const without = ids.filter((candidate) => candidate !== id);
	const at = beforeId === void 0 ? without.length : without.indexOf(beforeId);
	return [
		...without.slice(0, at),
		id,
		...without.slice(at)
	];
}
//#endregion
//#region ../workspace-controller/lib/types/client/service.js
/** React-free Client Workspace service and command facade. */
/** Structured create failure for callers that distinguish Host business errors. */
var WorkspaceCreateError = class extends Error {
	rpcError;
	name = "WorkspaceCreateError";
	/** @param rpcError - Host business or folded carrier failure. */
	constructor(rpcError) {
		super(`workspace create failed: ${rpcError.code}: ${rpcError.message}`);
		this.rpcError = rpcError;
	}
};
/** Owns the bare Workspace snapshot and Workspace-only commands. */
var WorkspaceController = class extends Service {
	model;
	list;
	/**
	* @param ctx - Client root Context.
	* @param model - Remote-backed Workspace state model.
	*/
	constructor(ctx, model) {
		super(ctx, "workspaces");
		this.model = model;
		this.list = model;
	}
	async create(input) {
		const result = await this.model.create(input);
		if (!result.ok) throw new WorkspaceCreateError(result.error);
		return result.value.workspace;
	}
	async rename(workspaceId, title) {
		const result = await this.model.rename(workspaceId, title);
		if (!result.ok) throw commandError("rename", result.error);
		return result.value.workspace;
	}
	async delete(workspaceId) {
		const result = await this.model.delete(workspaceId);
		if (!result.ok) throw commandError("delete", result.error);
	}
	async insertBefore(workspaceId, beforeWorkspaceId) {
		const result = await this.model.insertBefore(workspaceId, beforeWorkspaceId);
		if (!result.ok) throw commandError("reorder", result.error);
	}
	async archiveSession(sessionId) {
		const result = await this.model.archiveSession(sessionId);
		if (!result.ok) throw commandError("session archive", result.error);
	}
	async insertSessionBefore(workspaceId, sessionId, beforeSessionId) {
		const result = await this.model.insertSessionBefore(workspaceId, sessionId, beforeSessionId);
		if (!result.ok) throw commandError("move", result.error);
		return result.value.workspace;
	}
};
function commandError(operation, failure) {
	return /* @__PURE__ */ new Error(`workspace ${operation} failed: ${failure.code}: ${failure.message}`);
}
//#endregion
//#region ../workspace-controller/lib/types/client/index.js
/** Workspace-specific adapter for the Gateway-owned snapshot stream lifecycle. */
/** Required Client Remote services. */
const inject$3 = ["remote", "remote.workspace"];
/**
* Install Client Workspace state, commands, and reconnecting follow control.
* @param ctx - Client root Context.
*/
function apply$3(ctx) {
	const model = new ClientWorkspaceModel(ctx.remote.workspace);
	new WorkspaceController(ctx, model);
	const control = createWorkspaceStateStream(ctx.remote, {
		accept: model,
		carrierFailed: () => {
			model.handleCarrierFailure();
		},
		failed: (error) => {
			model.handleStreamFailure(error);
		}
	});
	control.start();
	ctx.effect(() => async () => {
		await control.dispose();
	}, "workspace-controller.client.control");
}
/**
* Create the reconnecting Workspace state stream.
* @param remote - Client Remote face carrying the Workspace namespace and the stream factory.
* @param options - Workspace state destinations.
* @returns an unstarted stream owned by the Client Workspace runtime.
*/
function createWorkspaceStateStream(remote, options) {
	return new RemoteSnapshotStream(remote.$stream({
		name: "Workspace state stream",
		open: (signal) => remote.workspace.follow(signal),
		ended: (accepted) => accepted ? new RemoteStreamCarrierError("Workspace state stream ended without a terminal result") : /* @__PURE__ */ new Error("Workspace state stream ended before its opening snapshot"),
		...options.carrierFailed === void 0 ? {} : { carrierFailed: options.carrierFailed }
	}), {
		name: "Workspace state stream",
		isSnapshot: (frame) => frame.type === "baseline",
		replace: (frame) => {
			options.accept.replaceBaseline(frame.value);
		},
		update: (frame) => {
			acceptIncrement(options.accept, frame);
		},
		failed: options.failed
	});
}
function acceptIncrement(accept, frame) {
	switch (frame.type) {
		case "upsert":
			accept.upsertView(frame.workspace);
			return;
		case "remove":
			accept.removeView(frame.workspaceId);
			return;
		case "order":
			accept.replaceOrder(frame.workspaceIds);
			return;
		case "archived":
			accept.replaceArchived(frame.archivedSessionIds);
			return;
		/* v8 ignore next -- the generated Remote codec validates this closed union */
		default: return assertNever(frame);
	}
}
/* v8 ignore next 3 -- closed-union backstop after generated Remote validation */
function assertNever(value) {
	throw new Error(`unreachable Workspace increment: ${JSON.stringify(value)}`);
}
//#endregion
//#region ../../../vendor/cosmokit/lib/index.js
/** Return true when a value is `null` or `undefined`. */
function isNullable(value) {
	return value === null || value === void 0;
}
/** Return true for non-array object values. */
function isPlainObject(data) {
	return data && typeof data === "object" && !Array.isArray(data);
}
/** Filter object entries and return a new object. */
function filterKeys(object, filter) {
	return Object.fromEntries(Object.entries(object).filter(([key, value]) => filter(key, value)));
}
/** Map object values while preserving the original key set. */
function mapValues(object, transform) {
	return Object.fromEntries(Object.entries(object).map(([key, value]) => [key, transform(value, key)]));
}
/** Pick selected keys from an object, optionally including `undefined` values. */
function pick(source, keys, forced) {
	if (!keys) return { ...source };
	const result = {};
	for (const key of keys) if (forced || source[key] !== void 0) result[key] = source[key];
	return result;
}
/** Test values using `instanceof` with a `toStringTag` fallback. */
function is(type, value) {
	if (arguments.length === 1) return (value) => is(type, value);
	return type in globalThis && value instanceof globalThis[type] || Object.prototype.toString.call(value).slice(8, -1) === type;
}
function isArrayBufferLike(value) {
	return is("ArrayBuffer", value) || is("SharedArrayBuffer", value);
}
function isArrayBufferSource(value) {
	return isArrayBufferLike(value) || ArrayBuffer.isView(value);
}
/** Binary source detection and base64/hex conversion helpers. */
var Binary;
(function(Binary) {
	Binary.is = isArrayBufferLike;
	Binary.isSource = isArrayBufferSource;
	function fromSource(source) {
		if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
		else return source;
	}
	Binary.fromSource = fromSource;
	function toBase64(source) {
		source = fromSource(source);
		if (typeof Buffer !== "undefined") return Buffer.from(source).toString("base64");
		let binary = "";
		const bytes = new Uint8Array(source);
		for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
		return btoa(binary);
	}
	Binary.toBase64 = toBase64;
	function fromBase64(source) {
		if (typeof Buffer !== "undefined") return fromSource(Buffer.from(source, "base64"));
		return Uint8Array.from(atob(source), (c) => c.charCodeAt(0));
	}
	Binary.fromBase64 = fromBase64;
	function toHex(source) {
		source = fromSource(source);
		if (typeof Buffer !== "undefined") return Buffer.from(source).toString("hex");
		return Array.from(new Uint8Array(source), (byte) => byte.toString(16).padStart(2, "0")).join("");
	}
	Binary.toHex = toHex;
	function fromHex(source) {
		if (typeof Buffer !== "undefined") return fromSource(Buffer.from(source, "hex"));
		const hex = source.length % 2 === 0 ? source : source.slice(0, source.length - 1);
		const buffer = [];
		for (let i = 0; i < hex.length; i += 2) buffer.push(parseInt(`${hex[i]}${hex[i + 1]}`, 16));
		return Uint8Array.from(buffer).buffer;
	}
	Binary.fromHex = fromHex;
})(Binary || (Binary = {}));
Binary.fromBase64;
Binary.toBase64;
Binary.fromHex;
Binary.toHex;
/** Deep-clone common JavaScript values while preserving prototypes and cycles. */
function clone(source, refs = /* @__PURE__ */ new Map()) {
	if (!source || typeof source !== "object") return source;
	if (is("Date", source)) return new Date(source.valueOf());
	if (is("RegExp", source)) return new RegExp(source.source, source.flags);
	if (isArrayBufferLike(source)) return source.slice(0);
	if (ArrayBuffer.isView(source)) return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
	const cached = refs.get(source);
	if (cached) return cached;
	if (Array.isArray(source)) {
		const result = [];
		refs.set(source, result);
		source.forEach((value, index) => {
			result[index] = Reflect.apply(clone, null, [value, refs]);
		});
		return result;
	}
	const result = Object.create(Object.getPrototypeOf(source));
	refs.set(source, result);
	for (const key of Reflect.ownKeys(source)) {
		const descriptor = { ...Reflect.getOwnPropertyDescriptor(source, key) };
		if ("value" in descriptor) descriptor.value = Reflect.apply(clone, null, [descriptor.value, refs]);
		Reflect.defineProperty(result, key, descriptor);
	}
	return result;
}
/** Deeply compare arrays, dates, regexps, buffers, and plain object fields. */
function deepEqual(a, b, strict) {
	if (a === b) return true;
	if (!strict && isNullable(a) && isNullable(b)) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a !== "object") return false;
	if (!a || !b) return false;
	function check(test, then) {
		return test(a) ? test(b) ? then(a, b) : false : test(b) ? false : void 0;
	}
	return check(Array.isArray, (a, b) => a.length === b.length && a.every((item, index) => deepEqual(item, b[index]))) ?? check(is("Date"), (a, b) => a.valueOf() === b.valueOf()) ?? check(is("RegExp"), (a, b) => a.source === b.source && a.flags === b.flags) ?? check(isArrayBufferLike, (a, b) => {
		if (a.byteLength !== b.byteLength) return false;
		const viewA = new Uint8Array(a);
		const viewB = new Uint8Array(b);
		for (let i = 0; i < viewA.length; i++) if (viewA[i] !== viewB[i]) return false;
		return true;
	}) ?? Object.keys({
		...a,
		...b
	}).every((key) => deepEqual(a[key], b[key], strict));
}
/** Time constants plus parsing and formatting helpers. */
var Time;
(function(Time) {
	Time.millisecond = 1;
	Time.second = 1e3;
	Time.minute = Time.second * 60;
	Time.hour = Time.minute * 60;
	Time.day = Time.hour * 24;
	Time.week = Time.day * 7;
	let timezoneOffset = (/* @__PURE__ */ new Date()).getTimezoneOffset();
	function setTimezoneOffset(offset) {
		timezoneOffset = offset;
	}
	Time.setTimezoneOffset = setTimezoneOffset;
	function getTimezoneOffset() {
		return timezoneOffset;
	}
	Time.getTimezoneOffset = getTimezoneOffset;
	function getDateNumber(date = /* @__PURE__ */ new Date(), offset) {
		if (typeof date === "number") date = new Date(date);
		if (offset === void 0) offset = timezoneOffset;
		return Math.floor((date.valueOf() / Time.minute - offset) / 1440);
	}
	Time.getDateNumber = getDateNumber;
	function fromDateNumber(value, offset) {
		const date = new Date(value * Time.day);
		if (offset === void 0) offset = timezoneOffset;
		return new Date(+date + offset * Time.minute);
	}
	Time.fromDateNumber = fromDateNumber;
	const numeric = /\d+(?:\.\d+)?/.source;
	const timeRegExp = new RegExp(`^${[
		"w(?:eek(?:s)?)?",
		"d(?:ay(?:s)?)?",
		"h(?:our(?:s)?)?",
		"m(?:in(?:ute)?(?:s)?)?",
		"s(?:ec(?:ond)?(?:s)?)?"
	].map((unit) => `(${numeric}${unit})?`).join("")}$`);
	function parseTime(source) {
		const capture = timeRegExp.exec(source);
		if (!capture) return 0;
		return (parseFloat(capture[1]) * Time.week || 0) + (parseFloat(capture[2]) * Time.day || 0) + (parseFloat(capture[3]) * Time.hour || 0) + (parseFloat(capture[4]) * Time.minute || 0) + (parseFloat(capture[5]) * Time.second || 0);
	}
	Time.parseTime = parseTime;
	function parseDate(date) {
		const parsed = parseTime(date);
		if (parsed) date = Date.now() + parsed;
		else if (/^\d{1,2}(:\d{1,2}){1,2}$/.test(date)) date = `${(/* @__PURE__ */ new Date()).toLocaleDateString()}-${date}`;
		else if (/^\d{1,2}-\d{1,2}-\d{1,2}(:\d{1,2}){1,2}$/.test(date)) date = `${(/* @__PURE__ */ new Date()).getFullYear()}-${date}`;
		return date ? new Date(date) : /* @__PURE__ */ new Date();
	}
	Time.parseDate = parseDate;
	function format(ms) {
		const abs = Math.abs(ms);
		if (abs >= Time.day - Time.hour / 2) return Math.round(ms / Time.day) + "d";
		else if (abs >= Time.hour - Time.minute / 2) return Math.round(ms / Time.hour) + "h";
		else if (abs >= Time.minute - Time.second / 2) return Math.round(ms / Time.minute) + "m";
		else if (abs >= Time.second) return Math.round(ms / Time.second) + "s";
		return ms + "ms";
	}
	Time.format = format;
	function toDigits(source, length = 2) {
		return source.toString().padStart(length, "0");
	}
	Time.toDigits = toDigits;
	function template(template, time = /* @__PURE__ */ new Date()) {
		return template.replace("yyyy", time.getFullYear().toString()).replace("yy", time.getFullYear().toString().slice(2)).replace("MM", toDigits(time.getMonth() + 1)).replace("dd", toDigits(time.getDate())).replace("hh", toDigits(time.getHours())).replace("mm", toDigits(time.getMinutes())).replace("ss", toDigits(time.getSeconds())).replace("SSS", toDigits(time.getMilliseconds(), 3));
	}
	Time.template = template;
})(Time || (Time = {}));
//#endregion
//#region ../../../vendor/schemastery/lib/index.mjs
const kSchema = Symbol.for("schemastery");
const kValidationError = Symbol.for("ValidationError");
globalThis.__schemastery_index__ ??= 0;
globalThis.__schemastery_refs__ = void 0;
var ValidationError = class extends TypeError {
	options;
	name = "ValidationError";
	constructor(message, options) {
		let prefix = "$";
		for (const segment of options.path || []) if (typeof segment === "string") prefix += "." + segment;
		else if (typeof segment === "number") prefix += "[" + segment + "]";
		else if (typeof segment === "symbol") prefix += `[Symbol(${segment.toString()})]`;
		if (prefix.startsWith(".")) prefix = prefix.slice(1);
		super((prefix === "$" ? "" : `${prefix} `) + message);
		this.options = options;
	}
	static is(error) {
		return !!error?.[kValidationError];
	}
};
Object.defineProperty(ValidationError.prototype, kValidationError, { value: true });
const Schema = function(options) {
	const schema = function(data, options = {}) {
		return Schema.resolve(data, schema, options)[0];
	};
	if (options.refs) {
		const refs = mapValues(options.refs, (options) => new Schema(options));
		const getRef = (uid) => refs[uid];
		for (const key in refs) {
			const options = refs[key];
			options.sKey = getRef(options.sKey);
			options.inner = getRef(options.inner);
			options.list = options.list && options.list.map(getRef);
			options.dict = options.dict && mapValues(options.dict, getRef);
		}
		return refs[options.uid];
	}
	Object.assign(schema, options);
	if (typeof schema.callback === "string") try {
		schema.callback = new Function("return " + schema.callback)();
	} catch {}
	Object.defineProperty(schema, "uid", { value: globalThis.__schemastery_index__++ });
	Object.setPrototypeOf(schema, Schema.prototype);
	schema.meta ||= {};
	schema.toString = schema.toString.bind(schema);
	return schema;
};
Schema.prototype = Object.create(Function.prototype);
Schema.prototype[kSchema] = true;
Object.defineProperty(Schema.prototype, "~standard", { get() {
	return {
		version: 1,
		vendor: "schemastery",
		validate: (value) => {
			try {
				return { value: Schema.resolve(value, this, {})[0] };
			} catch (error) {
				if (ValidationError.is(error)) return { issues: [{
					message: error.message,
					path: error.options.path
				}] };
				throw error;
			}
		}
	};
} });
Schema.ValidationError = ValidationError;
Schema.prototype.toJSON = function toJSON() {
	if (globalThis.__schemastery_refs__) {
		globalThis.__schemastery_refs__[this.uid] ??= JSON.parse(JSON.stringify({ ...this }));
		return this.uid;
	}
	globalThis.__schemastery_refs__ = { [this.uid]: { ...this } };
	globalThis.__schemastery_refs__[this.uid] = JSON.parse(JSON.stringify({ ...this }));
	const result = {
		uid: this.uid,
		refs: globalThis.__schemastery_refs__
	};
	globalThis.__schemastery_refs__ = void 0;
	return result;
};
Schema.prototype.set = function set(key, value) {
	this.dict[key] = value;
	return this;
};
Schema.prototype.push = function push(value) {
	this.list.push(value);
	return this;
};
function mergeDesc(original, messages) {
	const result = typeof original === "string" ? { "": original } : { ...original };
	for (const locale in messages) {
		const value = messages[locale];
		if (value?.$description || value?.$desc) result[locale] = value.$description || value.$desc;
		else if (typeof value === "string") result[locale] = value;
	}
	return result;
}
function getInner(value) {
	return value?.$value ?? value?.$inner;
}
function extractKeys(data) {
	return filterKeys(data ?? {}, (key) => !key.startsWith("$"));
}
Schema.prototype.i18n = function i18n(messages) {
	const schema = Schema(this);
	const desc = mergeDesc(schema.meta.description, messages);
	if (Object.keys(desc).length) schema.meta.description = desc;
	if (schema.dict) schema.dict = mapValues(schema.dict, (inner, key) => {
		return inner.i18n(mapValues(messages, (data) => getInner(data)?.[key] ?? data?.[key]));
	});
	if (schema.list) schema.list = schema.list.map((inner, index) => {
		return inner.i18n(mapValues(messages, (data = {}) => {
			if (Array.isArray(getInner(data))) return getInner(data)[index];
			if (Array.isArray(data)) return data[index];
			return extractKeys(data);
		}));
	});
	if (schema.inner) schema.inner = schema.inner.i18n(mapValues(messages, (data) => {
		if (getInner(data)) return getInner(data);
		return extractKeys(data);
	}));
	if (schema.sKey) schema.sKey = schema.sKey.i18n(mapValues(messages, (data) => data?.$key));
	return schema;
};
Schema.prototype.extra = function extra(key, value) {
	const schema = Schema(this);
	schema.meta = {
		...schema.meta,
		[key]: value
	};
	return schema;
};
for (const key of [
	"required",
	"disabled",
	"collapse",
	"hidden",
	"loose"
]) Object.assign(Schema.prototype, { [key](value = true) {
	const schema = Schema(this);
	schema.meta = {
		...schema.meta,
		[key]: value
	};
	return schema;
} });
Schema.prototype.deprecated = function deprecated() {
	const schema = Schema(this);
	schema.meta.badges ||= [];
	schema.meta.badges.push({
		text: "deprecated",
		type: "danger"
	});
	return schema;
};
Schema.prototype.experimental = function experimental() {
	const schema = Schema(this);
	schema.meta.badges ||= [];
	schema.meta.badges.push({
		text: "experimental",
		type: "warning"
	});
	return schema;
};
Schema.prototype.pattern = function pattern(regexp) {
	const schema = Schema(this);
	const pattern = pick(regexp, ["source", "flags"]);
	schema.meta = {
		...schema.meta,
		pattern
	};
	return schema;
};
Schema.prototype.simplify = function simplify(value) {
	if (deepEqual(value, this.meta.default, this.type === "dict")) return null;
	if (isNullable(value)) return value;
	if (this.type === "object" || this.type === "dict") {
		const result = {};
		for (const key in value) {
			const item = (this.type === "object" ? this.dict[key] : this.inner)?.simplify(value[key]);
			if (this.type === "dict" || !isNullable(item)) result[key] = item;
		}
		if (deepEqual(result, this.meta.default, this.type === "dict")) return null;
		return result;
	} else if (this.type === "array" || this.type === "tuple") {
		const result = [];
		value.forEach((value, index) => {
			const schema = this.type === "array" ? this.inner : this.list[index];
			const item = schema ? schema.simplify(value) : value;
			result.push(item);
		});
		return result;
	} else if (this.type === "intersect") {
		const result = {};
		for (const item of this.list) Object.assign(result, item.simplify(value));
		return result;
	} else if (this.type === "union") for (const schema of this.list) try {
		Schema.resolve(value, schema, {});
		return schema.simplify(value);
	} catch {}
	return value;
};
Schema.prototype.toString = function toString(inline) {
	return formatters[this.type]?.(this, inline) ?? `Schema<${this.type}>`;
};
Schema.prototype.role = function role(role, extra) {
	const schema = Schema(this);
	schema.meta = {
		...schema.meta,
		role,
		extra
	};
	return schema;
};
for (const key of [
	"default",
	"link",
	"comment",
	"description",
	"max",
	"min",
	"step"
]) Object.assign(Schema.prototype, { [key](value) {
	const schema = Schema(this);
	schema.meta = {
		...schema.meta,
		[key]: value
	};
	return schema;
} });
const resolvers = {};
Schema.extend = function extend(type, resolve) {
	resolvers[type] = resolve;
};
Schema.resolve = function resolve(data, schema, options = {}, strict = false) {
	if (!schema) return [data];
	if (options.ignore?.(data, schema)) return [data];
	if (isNullable(data) && schema.type !== "lazy") {
		if (schema.meta.required) throw new ValidationError(`missing required value`, options);
		let current = schema;
		let fallback = schema.meta.default;
		while (current?.type === "intersect" && isNullable(fallback)) {
			current = current.list[0];
			fallback = current?.meta.default;
		}
		if (isNullable(fallback)) return [data];
		data = clone(fallback);
	}
	const callback = resolvers[schema.type];
	if (!callback) throw new ValidationError(`unsupported type "${schema.type}"`, options);
	try {
		return callback(data, schema, options, strict);
	} catch (error) {
		if (!schema.meta.loose) throw error;
		return [schema.meta.default];
	}
};
Schema.from = function from(source) {
	if (isNullable(source)) return Schema.any();
	else if ([
		"string",
		"number",
		"boolean"
	].includes(typeof source)) return Schema.const(source).required();
	else if (source[kSchema]) return source;
	else if (typeof source === "function") switch (source) {
		case String: return Schema.string().required();
		case Number: return Schema.number().required();
		case Boolean: return Schema.boolean().required();
		case Function: return Schema.function().required();
		default: return Schema.is(source).required();
	}
	else throw new TypeError(`cannot infer schema from ${source}`);
};
Schema.lazy = function lazy(builder) {
	const toJSON = () => {
		if (!schema.inner[kSchema]) {
			schema.inner = schema.builder();
			schema.inner.meta = {
				...schema.meta,
				...schema.inner.meta
			};
		}
		return schema.inner.toJSON();
	};
	const schema = new Schema({
		type: "lazy",
		builder,
		inner: { toJSON }
	});
	return schema;
};
Schema.natural = function natural() {
	return Schema.number().step(1).min(0);
};
Schema.percent = function percent() {
	return Schema.number().step(.01).min(0).max(1).role("slider");
};
Schema.date = function date() {
	return Schema.union([Schema.is(Date), Schema.transform(Schema.string().role("datetime"), (value, options) => {
		const date = new Date(value);
		if (isNaN(+date)) throw new ValidationError(`invalid date "${value}"`, options);
		return date;
	}, true)]);
};
Schema.regExp = function regExp(flag = "") {
	return Schema.union([Schema.is(RegExp), Schema.transform(Schema.string().role("regexp", { flag }), (value, options) => {
		try {
			return new RegExp(value, flag);
		} catch (e) {
			throw new ValidationError(e.message, options);
		}
	}, true)]);
};
Schema.arrayBuffer = function arrayBuffer(encoding) {
	return Schema.union([
		Schema.is(ArrayBuffer),
		Schema.is(SharedArrayBuffer),
		Schema.transform(Schema.any(), (value, options) => {
			if (Binary.isSource(value)) return Binary.fromSource(value);
			throw new ValidationError(`expected ArrayBufferSource but got ${value}`, options);
		}, true),
		...encoding ? [Schema.transform(Schema.string(), (value, options) => {
			try {
				return encoding === "base64" ? Binary.fromBase64(value) : Binary.fromHex(value);
			} catch (e) {
				throw new ValidationError(e.message, options);
			}
		}, true)] : []
	]);
};
Schema.extend("lazy", (data, schema, options, strict) => {
	if (!schema.inner[kSchema]) {
		schema.inner = schema.builder();
		schema.inner.meta = {
			...schema.meta,
			...schema.inner.meta
		};
	}
	return Schema.resolve(data, schema.inner, options, strict);
});
Schema.extend("any", (data) => {
	return [data];
});
Schema.extend("never", (data, _, options) => {
	throw new ValidationError(`expected nullable but got ${data}`, options);
});
Schema.extend("const", (data, { value }, options) => {
	if (deepEqual(data, value)) return [value];
	throw new ValidationError(`expected ${value} but got ${data}`, options);
});
function checkWithinRange(data, meta, description, options, skipMin = false) {
	const { max = Infinity, min = -Infinity } = meta;
	if (data > max) throw new ValidationError(`expected ${description} <= ${max} but got ${data}`, options);
	if (data < min && !skipMin) throw new ValidationError(`expected ${description} >= ${min} but got ${data}`, options);
}
Schema.extend("string", (data, { meta }, options) => {
	if (typeof data !== "string") throw new ValidationError(`expected string but got ${data}`, options);
	if (meta.pattern) {
		const regexp = new RegExp(meta.pattern.source, meta.pattern.flags);
		if (!regexp.test(data)) throw new ValidationError(`expect string to match regexp ${regexp}`, options);
	}
	checkWithinRange(data.length, meta, "string length", options);
	return [data];
});
function decimalShift(data, digits) {
	const str = data.toString();
	if (str.includes("e")) return data * Math.pow(10, digits);
	const index = str.indexOf(".");
	if (index === -1) return data * Math.pow(10, digits);
	const frac = str.slice(index + 1);
	const integer = str.slice(0, index);
	if (frac.length <= digits) return +(integer + frac.padEnd(digits, "0"));
	return +(integer + frac.slice(0, digits) + "." + frac.slice(digits));
}
function isMultipleOf(data, min, step) {
	step = Math.abs(step);
	if (!/^\d+\.\d+$/.test(step.toString())) return (data - min) % step === 0;
	const index = step.toString().indexOf(".");
	const digits = step.toString().slice(index + 1).length;
	return Math.abs(decimalShift(data, digits) - decimalShift(min, digits)) % decimalShift(step, digits) === 0;
}
Schema.extend("number", (data, { meta }, options) => {
	if (typeof data !== "number") throw new ValidationError(`expected number but got ${data}`, options);
	checkWithinRange(data, meta, "number", options);
	const { step } = meta;
	if (step && !isMultipleOf(data, meta.min ?? 0, step)) throw new ValidationError(`expected number multiple of ${step} but got ${data}`, options);
	return [data];
});
Schema.extend("boolean", (data, _, options) => {
	if (typeof data === "boolean") return [data];
	throw new ValidationError(`expected boolean but got ${data}`, options);
});
Schema.extend("bitset", (data, { bits, meta }, options) => {
	let value = 0, keys = [];
	if (typeof data === "number") {
		value = data;
		for (const key in bits) if (data & bits[key]) keys.push(key);
	} else if (Array.isArray(data)) {
		keys = data;
		for (const key of keys) {
			if (typeof key !== "string") throw new ValidationError(`expected string but got ${key}`, options);
			if (key in bits) value |= bits[key];
		}
	} else throw new ValidationError(`expected number or array but got ${data}`, options);
	if (value === meta.default) return [value];
	return [value, keys];
});
Schema.extend("function", (data, _, options) => {
	if (typeof data === "function") return [data];
	throw new ValidationError(`expected function but got ${data}`, options);
});
Schema.extend("is", (data, { constructor }, options) => {
	if (typeof constructor === "function") {
		if (data instanceof constructor) return [data];
		throw new ValidationError(`expected ${constructor.name} but got ${data}`, options);
	} else {
		if (isNullable(data)) throw new ValidationError(`expected ${constructor} but got ${data}`, options);
		let prototype = Object.getPrototypeOf(data);
		while (prototype) {
			if (prototype.constructor?.name === constructor) return [data];
			prototype = Object.getPrototypeOf(prototype);
		}
		throw new ValidationError(`expected ${constructor} but got ${data}`, options);
	}
});
function property(data, key, schema, options) {
	try {
		const [value, adapted] = Schema.resolve(data[key], schema, {
			...options,
			path: [...options.path || [], key]
		});
		if (adapted !== void 0) data[key] = adapted;
		return value;
	} catch (e) {
		if (!options?.autofix) throw e;
		delete data[key];
		return schema.meta.default;
	}
}
Schema.extend("array", (data, { inner, meta }, options) => {
	if (!Array.isArray(data)) throw new ValidationError(`expected array but got ${data}`, options);
	checkWithinRange(data.length, meta, "array length", options, !isNullable(inner.meta.default));
	return [data.map((_, index) => property(data, index, inner, options))];
});
Schema.extend("dict", (data, { inner, sKey }, options, strict) => {
	if (!isPlainObject(data)) throw new ValidationError(`expected object but got ${data}`, options);
	const result = {};
	for (const key in data) {
		let rKey;
		try {
			rKey = Schema.resolve(key, sKey, options)[0];
		} catch (error) {
			if (strict) continue;
			throw error;
		}
		result[rKey] = property(data, key, inner, options);
		data[rKey] = data[key];
		if (key !== rKey) delete data[key];
	}
	return [result];
});
Schema.extend("tuple", (data, { list }, options, strict) => {
	if (!Array.isArray(data)) throw new ValidationError(`expected array but got ${data}`, options);
	const result = list.map((inner, index) => property(data, index, inner, options));
	if (strict) return [result];
	result.push(...data.slice(list.length));
	return [result];
});
function merge(result, data) {
	for (const key in data) {
		if (key in result) continue;
		result[key] = data[key];
	}
}
Schema.extend("object", (data, { dict }, options, strict) => {
	if (!isPlainObject(data)) throw new ValidationError(`expected object but got ${data}`, options);
	const result = {};
	for (const key in dict) {
		const value = property(data, key, dict[key], options);
		if (!isNullable(value) || key in data) result[key] = value;
	}
	if (!strict) merge(result, data);
	return [result];
});
Schema.extend("union", (data, { list, toString }, options, strict) => {
	const messages = [];
	for (const inner of list) try {
		return Schema.resolve(data, inner, options, strict);
	} catch (error) {
		messages.push(error);
	}
	throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
});
Schema.extend("intersect", (data, { list, toString }, options, strict) => {
	if (!list.length) return [data];
	let result;
	for (const inner of list) {
		const value = Schema.resolve(data, inner, options, true)[0];
		if (isNullable(value)) continue;
		if (isNullable(result)) result = value;
		else if (typeof result !== typeof value) throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
		else if (typeof value === "object") merge(result ??= {}, value);
		else if (result !== value) throw new ValidationError(`expected ${toString()} but got ${JSON.stringify(data)}`, options);
	}
	if (!strict && isPlainObject(data)) merge(result, data);
	return [result];
});
Schema.extend("transform", (data, { inner, callback, preserve }, options) => {
	const [result, adapted = data] = Schema.resolve(data, inner, options, true);
	if (preserve) return [callback(result)];
	else return [callback(result), callback(adapted)];
});
const formatters = {};
function defineMethod(name, keys, format) {
	formatters[name] = format;
	Object.assign(Schema, { [name](...args) {
		const schema = new Schema({ type: name });
		keys.forEach((key, index) => {
			switch (key) {
				case "sKey":
					schema.sKey = args[index] ?? Schema.string();
					break;
				case "inner":
					schema.inner = Schema.from(args[index]);
					break;
				case "list":
					schema.list = args[index].map(Schema.from);
					break;
				case "dict":
					schema.dict = mapValues(args[index], Schema.from);
					break;
				case "bits":
					schema.bits = {};
					for (const key in args[index]) {
						if (typeof args[index][key] !== "number") continue;
						schema.bits[key] = args[index][key];
					}
					break;
				case "callback": {
					const callback = schema.callback = args[index];
					callback["toJSON"] ||= () => callback.toString();
					break;
				}
				case "constructor": {
					const constructor = schema.constructor = args[index];
					if (typeof constructor === "function") constructor["toJSON"] ||= () => constructor["name"];
					break;
				}
				default: schema[key] = args[index];
			}
		});
		if (name === "object" || name === "dict") schema.meta.default = {};
		else if (name === "array" || name === "tuple") schema.meta.default = [];
		else if (name === "bitset") schema.meta.default = 0;
		return schema;
	} });
}
defineMethod("is", ["constructor"], ({ constructor }) => {
	if (typeof constructor === "function") return constructor.name;
	else return constructor;
});
defineMethod("any", [], () => "any");
defineMethod("never", [], () => "never");
defineMethod("const", ["value"], ({ value }) => typeof value === "string" ? JSON.stringify(value) : value);
defineMethod("string", [], () => "string");
defineMethod("number", [], () => "number");
defineMethod("boolean", [], () => "boolean");
defineMethod("bitset", ["bits"], () => "bitset");
defineMethod("function", [], () => "function");
defineMethod("array", ["inner"], ({ inner }) => `${inner.toString(true)}[]`);
defineMethod("dict", ["inner", "sKey"], ({ inner, sKey }) => `{ [key: ${sKey.toString()}]: ${inner.toString()} }`);
defineMethod("tuple", ["list"], ({ list }) => `[${list.map((inner) => inner.toString()).join(", ")}]`);
defineMethod("object", ["dict"], ({ dict }) => {
	if (Object.keys(dict).length === 0) return "{}";
	return `{ ${Object.entries(dict).map(([key, inner]) => {
		return `${key}${inner.meta.required ? "" : "?"}: ${inner.toString()}`;
	}).join(", ")} }`;
});
defineMethod("union", ["list"], ({ list }, inline) => {
	const result = list.map(({ toString: format }) => format()).join(" | ");
	return inline ? `(${result})` : result;
});
defineMethod("intersect", ["list"], ({ list }) => {
	return `${list.map((inner) => inner.toString(true)).join(" & ")}`;
});
defineMethod("transform", [
	"inner",
	"callback",
	"preserve"
], ({ inner }, isInner) => inner.toString(isInner));
//#endregion
//#region ../../client/connection/lib/types/recovery-config.js
/** Shared validation for Host-configured and browser-local connection recovery. */
const MAX_TIMER_MS = 2147483647;
/** Schema shared by the Host plugin and the Client's recovery input parser. */
const ConnectionRecoveryConfigSchema = Schema.object({
	backoffBaseMs: Schema.natural().min(1).max(MAX_TIMER_MS).default(500),
	backoffFactor: Schema.number().min(1).max(Number.MAX_VALUE).default(2),
	backoffMaxMs: Schema.natural().min(1).max(MAX_TIMER_MS).default(1e4),
	generationReadyWarnMs: Schema.natural().min(1).max(MAX_TIMER_MS).default(3e3),
	generationReadyTimeoutMs: Schema.natural().min(1).max(MAX_TIMER_MS).default(15e3)
});
/**
* Validate recovery input and supply every timing default before starting work.
* @param config - Host configuration, page bootstrap data, or direct loop options.
* @returns validated, complete recovery timing.
*/
function resolveConnectionConfig(config = {}) {
	const resolved = ConnectionRecoveryConfigSchema(config);
	if (!Number.isFinite(resolved.backoffFactor)) throw new RangeError("connection recovery backoffFactor must be finite");
	return resolved;
}
//#endregion
//#region ../../client/connection/lib/types/client/connection.js
const MANUAL_RECONNECT = /* @__PURE__ */ new Error("connection: manual reconnect requested");
const NETWORK_STATE_CHANGED = /* @__PURE__ */ new Error("connection: browser network state changed");
function sleep(ms, signal) {
	return new Promise((resolve) => {
		const t = setTimeout(done, ms);
		signal.addEventListener("abort", done, { once: true });
		function done() {
			clearTimeout(t);
			signal.removeEventListener("abort", done);
			resolve();
		}
	});
}
function waitForAbort(signal) {
	if (signal.aborted) return Promise.resolve();
	return new Promise((resolve) => {
		signal.addEventListener("abort", () => {
			resolve();
		}, { once: true });
	});
}
/**
* Opens the registered generation source, reconnecting with exponential backoff on loss.
* State (generation/attempt) is instance-private, never in the store.
* Sink exceptions do not kill the generation loop.
*/
var ConnectionController = class {
	source;
	sinks;
	createAbortController;
	generation = 0;
	attempt = 0;
	current = null;
	retryDelay = null;
	running = false;
	immediateRetry = false;
	networkAvailable = true;
	lastState;
	config;
	constructor(source, sinks = {}, config = {}, createAbortController = () => new AbortController()) {
		this.source = source;
		this.sinks = sinks;
		this.createAbortController = createAbortController;
		this.config = resolveConnectionConfig(config);
	}
	/** Idempotent: begin the connect/pump/reconnect loop. */
	start() {
		if (this.running) return;
		this.running = true;
		this.loop();
	}
	/** Stop the loop and abort the current generation source. */
	stop() {
		this.running = false;
		this.current?.abort();
		this.current = null;
		this.retryDelay?.abort();
		this.retryDelay = null;
	}
	/** Reset the retry sequence and replace the current generation or retry delay immediately. */
	reconnect() {
		if (!this.running) return;
		this.attempt = 0;
		this.immediateRetry = true;
		this.emitState("connecting");
		if (!this.isRunning()) return;
		this.current?.abort(MANUAL_RECONNECT);
		this.retryDelay?.abort(MANUAL_RECONNECT);
	}
	/**
	* Suspend automatic retries while offline and restart backoff when the network returns.
	* @param available - whether the browser reports network access.
	*/
	setNetworkAvailable(available) {
		if (this.networkAvailable === available) return;
		this.networkAvailable = available;
		this.attempt = 0;
		this.immediateRetry = false;
		if (!this.running) return;
		this.emitState(available ? "connecting" : "disconnected");
		if (!this.isRunning()) return;
		this.current?.abort(NETWORK_STATE_CHANGED);
		this.retryDelay?.abort(NETWORK_STATE_CHANGED);
	}
	backoffCap(attempt) {
		const { backoffBaseMs, backoffFactor, backoffMaxMs } = this.config;
		return Math.min(backoffMaxMs, backoffBaseMs * backoffFactor ** Math.max(0, attempt - 1));
	}
	backoffDelay(attempt) {
		const cap = this.backoffCap(attempt);
		return cap / 2 + Math.random() * (cap / 2);
	}
	/** Re-read retry inputs after a potentially reentrant state sink. */
	isRetryInterrupted(immediate) {
		return this.immediateRetry || !this.networkAvailable && !immediate;
	}
	/** Read through a method: stop() flips the flag across awaits, so narrowing from the loop condition must not stick. */
	isRunning() {
		return this.running;
	}
	/** Re-read both mutable liveness guards after a potentially reentrant sink. */
	isGenerationActive(controller) {
		return this.isRunning() && !controller.signal.aborted;
	}
	async loop() {
		let retry = false;
		while (this.running) {
			if (!this.networkAvailable && !this.immediateRetry) {
				const retryDelay = this.createAbortController();
				this.retryDelay = retryDelay;
				this.emitState("disconnected");
				await waitForAbort(retryDelay.signal);
				if (this.retryDelay === retryDelay) this.retryDelay = null;
				if (!this.isRunning()) return;
				retry = true;
				continue;
			}
			let manualAttempt = false;
			if (retry) {
				const immediate = this.immediateRetry;
				this.immediateRetry = false;
				if (immediate) this.attempt = 0;
				manualAttempt = immediate;
				const attempt = ++this.attempt;
				this.emitState("connecting");
				if (!this.isRunning()) return;
				if (this.isRetryInterrupted(immediate)) continue;
				if (!immediate) {
					const retryDelay = this.createAbortController();
					this.retryDelay = retryDelay;
					await sleep(this.backoffDelay(attempt), retryDelay.signal);
					if (this.retryDelay === retryDelay) this.retryDelay = null;
					if (!this.isRunning()) return;
					if (retryDelay.signal.aborted) continue;
				}
				console.warn(`[connection] connection lost, retry #${String(attempt)}`);
				this.callSink(() => {
					this.sinks.onReconnectRequested?.();
				});
				if (!this.isRunning()) return;
			}
			const gen = ++this.generation;
			const ac = this.createAbortController();
			this.current = ac;
			let sourceReady = false;
			let resolveReady;
			let rejectReady;
			let rejectSourceLost;
			const ready = new Promise((resolve, reject) => {
				resolveReady = resolve;
				rejectReady = reject;
			});
			const sourceLost = new Promise((_resolve, reject) => {
				rejectSourceLost = reject;
			});
			const reportReady = (host) => {
				if (sourceReady || gen !== this.generation || !this.isGenerationActive(ac)) return;
				sourceReady = true;
				resolveReady(host);
			};
			const failed = new Promise((resolve) => {
				const settle = () => {
					if (gen === this.generation && !ac.signal.aborted) ac.abort();
					resolve();
				};
				Promise.resolve().then(() => this.source(ac.signal, reportReady)).then(() => {
					const error = /* @__PURE__ */ new Error("connection generation ended");
					if (!sourceReady) rejectReady(error);
					rejectSourceLost(error);
					settle();
				}, (error) => {
					const failure = error instanceof Error ? error : new Error("connection generation failed", { cause: error });
					if (!sourceReady) rejectReady(failure);
					rejectSourceLost(failure);
					settle();
				});
			});
			try {
				const host = await Promise.race([waitForReady(ready, this.config, ac.signal), sourceLost]);
				if (ac.signal.aborted) throw new Error("generation aborted during readiness handshake");
				this.attempt = 0;
				this.emitState("connected");
				if (this.isGenerationActive(ac)) this.callSink(() => {
					this.sinks.onConnected?.(host);
				});
			} catch (error) {
				if (!ac.signal.aborted) ac.abort(error);
			}
			await failed;
			if (!this.isRunning()) return;
			if (manualAttempt) this.attempt = 0;
			retry = true;
		}
	}
	/** Deduplicated state emission (sink isolation applies). */
	emitState(state) {
		if (this.lastState === state) return;
		this.lastState = state;
		this.callSink(() => this.sinks.onStateChange?.(state));
	}
	/** Sink exception isolation: a business-layer throw is logged only, never affecting pump or reconnect semantics. */
	callSink(fn) {
		try {
			fn();
		} catch (error) {
			console.error("[connection] connection sink threw:", error);
		}
	}
};
/** Report a slow handshake before the hard deadline ends its generation. */
function waitForReady(ready, config, signal) {
	return new Promise((resolve, reject) => {
		let settled = false;
		const warning = setTimeout(() => {
			console.warn(`[connection] generation is still not ready after ${String(config.generationReadyWarnMs)}ms`);
		}, config.generationReadyWarnMs);
		const timeout = setTimeout(() => {
			const error = /* @__PURE__ */ new Error(`connection generation was not ready within ${String(config.generationReadyTimeoutMs)}ms`);
			console.warn(`[connection] ${error.message}; cancelling generation`);
			finish({ error });
		}, config.generationReadyTimeoutMs);
		const aborted = () => {
			finish({ error: new Error("connection generation aborted", { cause: signal.reason }) });
		};
		const finish = (outcome) => {
			if (settled) return;
			settled = true;
			clearTimeout(warning);
			clearTimeout(timeout);
			signal.removeEventListener("abort", aborted);
			if ("error" in outcome) reject(outcome.error);
			else resolve(outcome.value);
		};
		signal.addEventListener("abort", aborted, { once: true });
		ready.then((value) => {
			finish({ value });
		}, (error) => {
			finish({ error });
		});
	});
}
//#endregion
//#region ../../client/connection/lib/types/client/handle.js
/** Per-host Connection ownership independent of page globals and UI frameworks. */
function watchNetwork(controller, network) {
	if (network === void 0) return () => {};
	const update = () => {
		controller.setNetworkAvailable(network.getSnapshot());
	};
	const stop = network.subscribe(update);
	update();
	return stop;
}
/**
* Create an independent Host connection using caller-owned transport and network state.
* @param options - explicit Host inputs; malformed recovery timing throws before ownership begins.
* @returns connection whose active loop and network subscription are released by its loop or source disposer.
*/
function createConnection(options) {
	const recovery = resolveConnectionConfig(options.recovery);
	const createAbortController = options.createAbortController ?? (() => new AbortController());
	let generationSource;
	let owner;
	let generationId = 0;
	let generation;
	let state;
	const generationListeners = /* @__PURE__ */ new Set();
	const stateListeners = /* @__PURE__ */ new Set();
	const publishGeneration = (next) => {
		if (Object.is(generation, next)) return;
		generation = next;
		for (const listener of [...generationListeners]) try {
			listener();
		} catch (error) {
			console.error("[connection] generation listener threw:", error);
		}
	};
	const publishState = (next) => {
		if (state === next) return;
		state = next;
		for (const listener of [...stateListeners]) try {
			listener();
		} catch (error) {
			console.error("[connection] state listener threw:", error);
		}
	};
	const releaseOwner = (current) => {
		if (owner !== current) return;
		owner = void 0;
		current.stopNetworkWatch();
		current.controller.stop();
		publishGeneration(void 0);
		publishState(void 0);
	};
	return {
		isLoopback: options.isLoopback,
		generation: {
			getSnapshot: () => generation,
			subscribe: (listener) => {
				generationListeners.add(listener);
				return () => {
					generationListeners.delete(listener);
				};
			}
		},
		state: {
			getSnapshot: () => state,
			subscribe: (listener) => {
				stateListeners.add(listener);
				return () => {
					stateListeners.delete(listener);
				};
			}
		},
		rpc: options.rpc,
		reconnect() {
			owner?.controller.reconnect();
		},
		registerGenerationSource(source) {
			if (generationSource !== void 0) throw new Error("connection: a generation source is already registered");
			generationSource = source;
			return () => {
				if (generationSource !== source) return;
				generationSource = void 0;
				const current = owner;
				if (current?.source === source) releaseOwner(current);
			};
		},
		start(sinks, config) {
			if (owner !== void 0) throw new Error("connection: the stream loop is already owned by another consumer");
			const source = generationSource;
			if (source === void 0) throw new Error("connection: no generation source is registered");
			const token = {};
			const ownsGeneration = () => owner?.token === token;
			const controller = new ConnectionController(source, {
				...sinks,
				onConnected: (host) => {
					const nextGeneration = {
						id: ++generationId,
						host
					};
					publishGeneration(nextGeneration);
					if (!ownsGeneration() || !Object.is(generation, nextGeneration)) return;
					sinks.onConnected?.(host);
				},
				onStateChange: (state) => {
					if (state !== "connected") publishGeneration(void 0);
					if (!ownsGeneration()) return;
					publishState(state);
					sinks.onStateChange?.(state);
				}
			}, {
				...recovery,
				...config
			}, createAbortController);
			const current = {
				token,
				source,
				controller,
				stopNetworkWatch: watchNetwork(controller, options.network)
			};
			owner = current;
			controller.start();
			return { stop: () => {
				releaseOwner(current);
			} };
		}
	};
}
//#endregion
//#region ../../client/connection/lib/types/rpc.js
/** Generic unary RPC contracts shared by the Host and Client Connection halves. */
/**
* Brand one validated string as a Connection correlation id.
* @param id - validated wire identity.
* @returns the same string with the correlation-id brand.
*/
function RpcId(id) {
	return id;
}
//#endregion
//#region ../../client/connection/lib/types/client/rpc-caller.js
/** Unary RPC envelopes over explicit per-host transports. */
const CHANNEL_PATTERN = /^\/[A-Za-z0-9._~-]+$/;
const ENDPOINT_SEGMENT_PATTERN = /^[A-Za-z0-9_$.-]+$/;
/**
* Create an RPC caller without reading browser, crypto, or transport globals.
* Requests are sent once; a rejected transport leaves command acceptance unknown.
* @param options - Host authority, transport, and correlation-id source.
* @returns caller validating targets, response envelopes, and correlation without retrying mutations.
*/
function createConnectionRpc(options) {
	const openStream = options.openStream;
	return {
		async call(channel, endpoint, payload, signal) {
			assertTarget(channel, endpoint);
			const rpcId = options.randomId();
			const message = {
				type: "client-request",
				rpcId,
				method: endpoint,
				payload
			};
			const response = await options.fetch(new URL(`${channel}/${endpoint}`, options.baseUrl), {
				method: "POST",
				headers: { "content-type": "application/json" },
				body: JSON.stringify(message),
				...signal === void 0 ? {} : { signal }
			});
			if (!response.ok) throw new Error(`transport failure for ${channel}/${endpoint}: HTTP ${response.status}`);
			const full = parseConnectionResponse(await response.json());
			if (full.rpcId !== rpcId) throw new Error(`rpcId mismatch for ${endpoint}: sent ${rpcId}, got ${full.rpcId}`);
			return full.result;
		},
		...openStream === void 0 ? {} : { open(channel, endpoint, payload, signal) {
			assertTarget(channel, endpoint);
			if (channel !== "/api") throw new Error(`connection: direct streams require the /api channel, got ${JSON.stringify(channel)}`);
			return openStream(endpoint, payload, signal);
		} }
	};
}
function parseConnectionResponse(value) {
	if (!isRecord(value) || value.type !== "server-response" || typeof value.rpcId !== "string") throw new TypeError("connection: invalid server-response envelope");
	const result = value.result;
	if (!isRecord(result)) throw new TypeError("connection: invalid server-response result");
	if (result.ok === true) return {
		rpcId: RpcId(value.rpcId),
		result: {
			ok: true,
			value: result.value
		}
	};
	if (result.ok !== false || !isRecord(result.error)) throw new TypeError("connection: invalid server-response result");
	const error = result.error;
	if (typeof error.code !== "string" || typeof error.message !== "string" || !isRecord(error.details)) throw new TypeError("connection: invalid server-response failure");
	return {
		rpcId: RpcId(value.rpcId),
		result: {
			ok: false,
			error: {
				code: error.code,
				message: error.message,
				details: error.details
			}
		}
	};
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function assertTarget(channel, endpoint) {
	const segments = endpoint.split("/");
	if (!CHANNEL_PATTERN.test(channel) || segments.some((segment) => segment === "" || segment === "." || segment === ".." || !ENDPOINT_SEGMENT_PATTERN.test(segment))) throw new Error(`connection: invalid RPC target ${JSON.stringify(`${channel}/${endpoint}`)}`);
}
//#endregion
//#region ../../client/connection/lib/types/api-path.js
/**
* The /api URL prefix — single source for both halves of the web transport.
* The node half registers this prefix on the web server.
*/
/** Route prefix owning every api request (`/api` and `/api/<anything>`). */
const API_PATH = "/api";
//#endregion
//#region ../../client/connection/lib/types/client/host-identity.js
/** Validated Host identity reads over an already authenticated RPC carrier. */
/**
* Read correlation facts without retrying or treating them as authorization.
* @param rpc - authenticated carrier for the selected Host.
* @param signal - caller lifetime forwarded to the transport.
* @returns validated identity or the Host failure; transport rejection propagates.
*/
async function readHostIdentity(rpc, signal) {
	const result = await rpc.call(API_PATH, CONNECTION_IDENTITY_ENDPOINT, {}, signal);
	if (!result.ok) return result;
	const parsed = connectionIdentitySchema.safeParse(result.value);
	if (!parsed.success) return {
		ok: false,
		error: {
			code: "connection/invalid-identity",
			message: "Invalid Host identity response",
			details: {}
		}
	};
	return {
		ok: true,
		value: parsed.data
	};
}
//#endregion
//#region ../../client/connection/lib/types/device-protocol.js
/** Versioned device enrollment payloads shared by Connection and portable clients. */
/** Exact Connection-owned HTTP routes; enrollment secrets travel only in JSON bodies. */
const DEVICE_ACCESS_PATHS = {
	enroll: "/api/connection/devices/enroll",
	claim: "/api/connection/devices/claim",
	list: "/api/connection/devices",
	revoke: "/api/connection/devices/revoke"
};
/** Validate an opaque device identity at wire and persistence boundaries. */
const connectionDeviceIdSchema = z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/).transform((value) => value);
/** Fixed 256-bit token encoding; equality checks still require the exact minted token. */
const enrollmentChallengeSchema = z.string().regex(/^[A-Za-z0-9_-]{43}$/);
/** A credential is never accepted from a URL or a cookie. */
const deviceCredentialSchema = z.string().regex(/^dsh-device-v1\.[0-9a-f-]{36}\.[A-Za-z0-9_-]{43}$/).refine((value) => connectionDeviceIdSchema.safeParse(value.split(".")[1]).success).transform((value) => value);
/** Bounded owner-visible metadata and persisted grant fields. */
const connectionDeviceInfoSchema = z.object({
	deviceId: connectionDeviceIdSchema,
	label: z.string().trim().min(1).max(80),
	createdAt: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
}).strict();
/** Validate owner-issued enrollment metadata before application QR consumption. */
const connectionDeviceEnrollmentSchema = z.object({
	version: z.literal(1),
	hostId: storedHostIdentitySchema.shape.hostId,
	challenge: enrollmentChallengeSchema,
	expiresAt: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
}).strict();
z.object({
	hostId: storedHostIdentitySchema.shape.hostId,
	challenge: enrollmentChallengeSchema,
	label: z.string().trim().min(1).max(80)
}).strict();
z.object({ deviceId: connectionDeviceIdSchema }).strict();
z.object({}).strict();
/** Validate the one-time credential result before a native caller stores it. */
const connectionDeviceGrantSchema = z.object({
	version: z.literal(1),
	hostId: storedHostIdentitySchema.shape.hostId,
	device: connectionDeviceInfoSchema,
	credential: deviceCredentialSchema
}).strict().refine((value) => value.credential.split(".")[1] === value.device.deviceId);
//#endregion
//#region ../../client/connection/lib/types/client/device-access.js
/** Portable enrollment claim against one explicitly selected Host origin. */
const claimResultSchema = z.discriminatedUnion("ok", [z.object({
	ok: z.literal(true),
	value: connectionDeviceGrantSchema
}).strict(), z.object({
	ok: z.literal(false),
	error: z.object({
		code: z.string(),
		message: z.string(),
		details: z.record(z.string(), z.unknown())
	}).strict()
}).strict()]);
/**
* Claim once without redirects, ambient cookies or automatic retry.
* @param options - selected Host, QR challenge and platform-owned cancellation and transport.
* @returns validated credential or a failure; cancellation and carrier rejection propagate.
*/
async function claimDeviceEnrollment(options) {
	options.signal.throwIfAborted();
	const url = new URL(DEVICE_ACCESS_PATHS.claim, options.baseUrl);
	if (url.protocol !== "http:" && url.protocol !== "https:" || url.username !== "" || url.password !== "") throw new TypeError("Device enrollment requires an HTTP(S) origin without URL credentials");
	const response = await options.fetch(url, {
		method: "POST",
		credentials: "omit",
		redirect: "error",
		headers: { "content-type": "application/json" },
		signal: options.signal,
		body: JSON.stringify({
			hostId: options.expectedHostId,
			challenge: options.challenge,
			label: options.label
		})
	});
	const parsed = claimResultSchema.safeParse(await response.json());
	options.signal.throwIfAborted();
	if (!parsed.success || parsed.data.ok !== response.ok) return {
		ok: false,
		error: {
			code: "connection/invalid-enrollment-response",
			message: "Invalid device enrollment response",
			details: {}
		}
	};
	if (parsed.data.ok && parsed.data.value.hostId !== options.expectedHostId) return {
		ok: false,
		error: {
			code: "connection/enrollment-host-mismatch",
			message: "Device grant belongs to another Host",
			details: {}
		}
	};
	return parsed.data;
}
//#endregion
//#region ../../typert/registry/lib/types/service.js
/**
* Runtime registry for generated Typert reflection, Remote invocations, and
* dependency-inverted lookup/Context providers. It performs no TypeScript
* analysis or schema generation.
* @module @deepseek-ai/dsh-typert-registry
*/
/**
* Compose the global key of one generated schema.
* @param packageName - contributing npm package.
* @param name - schema export name.
* @returns `<package>#<name>`.
*/
function typertKey(packageName, name) {
	return `${packageName}#${name}`;
}
/**
* Compose the identity of one package-face model.
* @param packageName - contributing npm package.
* @param face - independently compiled face.
* @returns `<package>#<face>`.
*/
function typertPackageKey(packageName, face) {
	return `${packageName}#${face}`;
}
/**
* Compose the endpoint key used by local and Remote invocation registries.
* @param descriptor - invocation whose namespace and method form the endpoint.
* @returns `<namespace>/<method>`.
*/
function typertEndpoint(descriptor) {
	return `${descriptor.namespace}/${descriptor.method}`;
}
var ChangeSource = class {
	report;
	listeners = /* @__PURE__ */ new Set();
	constructor(report) {
		this.report = report;
	}
	subscribe(ctx, listener) {
		const { listeners } = this;
		return ctx.effect(function* () {
			listeners.add(listener);
			yield () => {
				listeners.delete(listener);
			};
		}, "typert registry subscription");
	}
	emit(change) {
		for (const listener of [...this.listeners]) try {
			listener(change);
		} catch (error) {
			this.report(change, error);
		}
	}
};
var DescriptorStore = class {
	kind;
	entries = /* @__PURE__ */ new Map();
	ids = /* @__PURE__ */ new Map();
	history = /* @__PURE__ */ new Set();
	changes;
	constructor(kind, report) {
		this.kind = kind;
		this.changes = new ChangeSource(report);
	}
	validate(descriptors) {
		const endpoints = /* @__PURE__ */ new Set();
		const ids = /* @__PURE__ */ new Set();
		for (const descriptor of descriptors) {
			validateInvocation(descriptor);
			const endpoint = typertEndpoint(descriptor);
			if (endpoints.has(endpoint) || this.entries.has(endpoint)) throw new Error(`typert: ${this.kind} endpoint "${endpoint}" is already registered`);
			if (ids.has(descriptor.id) || this.ids.has(descriptor.id)) throw new Error(`typert: ${this.kind} invocation id "${descriptor.id}" is already registered`);
			endpoints.add(endpoint);
			ids.add(descriptor.id);
		}
	}
	commit(owner, descriptors) {
		for (const descriptor of descriptors) {
			const entry = {
				descriptor,
				owner
			};
			const endpoint = typertEndpoint(descriptor);
			this.entries.set(endpoint, entry);
			this.ids.set(descriptor.id, entry);
			this.history.add(endpoint);
		}
		for (const descriptor of descriptors) this.changes.emit({
			kind: this.kind,
			key: typertEndpoint(descriptor)
		});
	}
	withdraw(owner, descriptors) {
		const removed = [];
		for (const descriptor of descriptors) {
			const endpoint = typertEndpoint(descriptor);
			const entry = this.entries.get(endpoint);
			/* v8 ignore next -- duplicate registration is rejected, so no later owner can replace this entry before its effect disposes. */
			if (entry?.owner !== owner) continue;
			this.entries.delete(endpoint);
			/* v8 ignore next -- ids and endpoints are committed and withdrawn together under the same unique owner. */
			if (this.ids.get(descriptor.id) === entry) this.ids.delete(descriptor.id);
			removed.push(endpoint);
		}
		for (const endpoint of removed) this.changes.emit({
			kind: this.kind,
			key: endpoint
		});
	}
	get(endpoint) {
		return this.entries.get(endpoint)?.descriptor;
	}
	hasSeen(endpoint) {
		return this.history.has(endpoint);
	}
	list() {
		return [...this.entries.values()].map((entry) => entry.descriptor);
	}
	subscribe(ctx, listener) {
		return this.changes.subscribe(ctx, listener);
	}
};
var RemoteStore = class {
	descriptors;
	packages = /* @__PURE__ */ new Map();
	constructor(descriptors) {
		this.descriptors = descriptors;
	}
	view(ctx) {
		return {
			register: (contribution) => this.register(ctx, contribution),
			get: (endpoint) => this.descriptors.get(endpoint),
			list: () => this.descriptors.list(),
			subscribe: (listener) => this.descriptors.subscribe(ctx, listener)
		};
	}
	register(ctx, contribution) {
		validateSegment("Remote package name", contribution.package);
		if (this.packages.has(contribution.package)) throw new Error(`typert: Remote package "${contribution.package}" is already registered`);
		this.descriptors.validate(contribution.descriptors);
		const owner = {};
		const { packages, descriptors } = this;
		return ctx.effect(function* () {
			packages.set(contribution.package, owner);
			descriptors.commit(owner, contribution.descriptors);
			yield () => {
				/* v8 ignore else -- duplicate package registration is rejected, so this effect remains the package's unique owner. */
				if (packages.get(contribution.package) === owner) packages.delete(contribution.package);
				descriptors.withdraw(owner, contribution.descriptors);
			};
		}, `typert.remotes.register(${JSON.stringify(contribution.package)})`);
	}
};
var LookupStore = class {
	providers = /* @__PURE__ */ new Map();
	resolvers = /* @__PURE__ */ new Map();
	definitions = /* @__PURE__ */ new Map();
	changes;
	constructor(report) {
		this.changes = new ChangeSource(report);
	}
	view(ctx) {
		return {
			register: (key, provider) => this.register(ctx, key, provider),
			configure: (key, resolver) => this.configure(ctx, key, resolver),
			get: (key) => this.get(key),
			definitions: () => [...this.definitions.values()],
			keys: () => [...this.providers.keys()],
			subscribe: (listener) => this.changes.subscribe(ctx, listener)
		};
	}
	get(key) {
		const provider = this.providers.get(key)?.provider;
		if (provider === void 0) return void 0;
		const resolver = this.resolvers.get(key)?.provider;
		if (resolver === void 0) return provider;
		return {
			parameter: provider.parameter,
			wire: provider.wire,
			hostTypeSymbol: provider.hostTypeSymbol,
			wireTypeSymbol: provider.wireTypeSymbol,
			resolve: (id) => resolver.resolve(id)
		};
	}
	configure(ctx, key, resolver) {
		validateSegment("lookup key", key);
		if (this.resolvers.has(key)) throw new Error(`typert: lookup "${key}" resolver is already configured`);
		const entry = {
			provider: { resolve: async (id) => resolver(id) },
			owner: {}
		};
		const { resolvers, changes } = this;
		return ctx.effect(function* () {
			resolvers.set(key, entry);
			changes.emit({
				kind: "lookup",
				key
			});
			yield () => {
				/* v8 ignore next -- duplicate configuration is rejected, so this effect remains the key's unique owner. */
				if (resolvers.get(key) !== entry) return;
				resolvers.delete(key);
				changes.emit({
					kind: "lookup",
					key
				});
			};
		}, `typert.lookups.configure(${JSON.stringify(key)})`);
	}
	register(ctx, key, provider) {
		validateSegment("lookup key", key);
		validateSegment("lookup parameter", provider.parameter);
		validateWireName("lookup wire field", provider.wire);
		validateNonempty("lookup Host type symbol", provider.hostTypeSymbol);
		validateNonempty("lookup wire type symbol", provider.wireTypeSymbol);
		if (this.providers.has(key)) throw new Error(`typert: lookup "${key}" is already registered`);
		const definition = {
			key,
			parameter: provider.parameter,
			wire: provider.wire,
			hostTypeSymbol: provider.hostTypeSymbol,
			wireTypeSymbol: provider.wireTypeSymbol
		};
		const known = this.definitions.get(key);
		if (known !== void 0 && !lookupDefinitionEquals(known, definition)) throw new Error(`typert: lookup "${key}" changed its wire declaration during this registry lifetime`);
		const entry = {
			provider,
			owner: {}
		};
		const { definitions, providers, changes } = this;
		return ctx.effect(function* () {
			definitions.set(key, definition);
			providers.set(key, entry);
			changes.emit({
				kind: "lookup",
				key
			});
			yield () => {
				/* v8 ignore next -- duplicate registration is rejected, so this effect remains the key's unique owner. */
				if (providers.get(key) !== entry) return;
				providers.delete(key);
				changes.emit({
					kind: "lookup",
					key
				});
			};
		}, `typert.lookups.register(${JSON.stringify(key)})`);
	}
};
function lookupDefinitionEquals(left, right) {
	return left.parameter === right.parameter && left.wire === right.wire && left.hostTypeSymbol === right.hostTypeSymbol && left.wireTypeSymbol === right.wireTypeSymbol;
}
var ContextStore = class {
	hosts = /* @__PURE__ */ new Map();
	hostResolvers = /* @__PURE__ */ new Map();
	clients = /* @__PURE__ */ new Map();
	changes;
	constructor(report) {
		this.changes = new ChangeSource(report);
	}
	view(ctx) {
		return {
			registerHost: (key, adapter) => this.registerHost(ctx, key, adapter),
			configureHost: (key, resolver) => this.configureHost(ctx, key, resolver),
			registerClient: (key, adapter) => this.registerClient(ctx, key, adapter),
			getHost: (key) => this.getHost(key),
			getClient: (key) => this.clients.get(key)?.provider,
			subscribe: (listener) => this.changes.subscribe(ctx, listener)
		};
	}
	getHost(key) {
		const adapter = this.hosts.get(key)?.provider;
		if (adapter === void 0) return void 0;
		const resolver = this.hostResolvers.get(key)?.provider;
		if (resolver === void 0) return adapter;
		return {
			wire: adapter.wire,
			wireTypeSymbol: adapter.wireTypeSymbol,
			resolve: (id) => resolver.resolve(id)
		};
	}
	configureHost(ctx, key, resolver) {
		validateSegment("Context key", key);
		if (this.hostResolvers.has(key)) throw new Error(`typert: host-context "${key}" resolver is already configured`);
		const entry = {
			provider: { resolve: async (id) => resolver(id) },
			owner: {}
		};
		const { hostResolvers, changes } = this;
		return ctx.effect(function* () {
			hostResolvers.set(key, entry);
			changes.emit({
				kind: "host-context",
				key
			});
			yield () => {
				/* v8 ignore next -- duplicate configuration is rejected, so this effect remains the key's unique owner. */
				if (hostResolvers.get(key) !== entry) return;
				hostResolvers.delete(key);
				changes.emit({
					kind: "host-context",
					key
				});
			};
		}, `typert.contexts.configureHost(${JSON.stringify(key)})`);
	}
	registerHost(ctx, key, adapter) {
		validateSegment("Context key", key);
		validateWireName("Context wire field", adapter.wire);
		validateNonempty("Context wire type symbol", adapter.wireTypeSymbol);
		return this.registerProvider(ctx, this.hosts, "host-context", key, adapter);
	}
	registerClient(ctx, key, adapter) {
		validateSegment("Context key", key);
		return this.registerProvider(ctx, this.clients, "client-context", key, adapter);
	}
	registerProvider(ctx, table, kind, key, provider) {
		if (table.has(key)) throw new Error(`typert: ${kind} provider "${key}" is already registered`);
		const entry = {
			provider,
			owner: {}
		};
		const { changes } = this;
		return ctx.effect(function* () {
			table.set(key, entry);
			changes.emit({
				kind,
				key
			});
			yield () => {
				/* v8 ignore next -- duplicate registration is rejected, so this effect remains the key's unique owner. */
				if (table.get(key) !== entry) return;
				table.delete(key);
				changes.emit({
					kind,
					key
				});
			};
		}, `typert.contexts.register(${JSON.stringify(key)})`);
	}
};
/**
* Registry of generated schemas, package reflection, invocations, and Remote
* dependency providers.
* @typert service typert
*/
var TypertRegistry = class extends Service {
	schemas = /* @__PURE__ */ new Map();
	packages = /* @__PURE__ */ new Map();
	localStore;
	remoteStore;
	lookupStore;
	contextStore;
	constructor(ctx) {
		super(ctx, "typert");
		const report = (change, error) => {
			ctx.logger.warn(`typert: ${change.kind} observer for "${change.key}" failed`);
			ctx.logger.warn(error);
		};
		this.localStore = new DescriptorStore("local", report);
		this.remoteStore = new RemoteStore(new DescriptorStore("remote", report));
		this.lookupStore = new LookupStore(report);
		this.contextStore = new ContextStore(report);
	}
	/** Current-environment invocation definitions. */
	get local() {
		const ctx = this.ctx;
		return {
			get: (endpoint) => this.localStore.get(endpoint),
			hasSeen: (endpoint) => this.localStore.hasSeen(endpoint),
			list: () => this.localStore.list(),
			subscribe: (listener) => this.localStore.subscribe(ctx, listener)
		};
	}
	/** Consumer-selected Remote definitions. */
	get remotes() {
		return this.remoteStore.view(this.ctx);
	}
	/** Host object lookup providers. */
	get lookups() {
		return this.lookupStore.view(this.ctx);
	}
	/** Host and Client Context adapters. */
	get contexts() {
		return this.contextStore.view(this.ctx);
	}
	/**
	* Register one generated contribution atomically for the calling fiber.
	* Duplicate package-face identities, schemas, invocation ids, or endpoints
	* reject the whole batch.
	* @param contribution - generated schemas, reflection, and Host invocations.
	* @returns the exact effect disposer that removes this contribution.
	*/
	register(contribution) {
		const packageRecord = this.validatePackage(contribution);
		const schemaRecords = this.validateSchemas(contribution);
		const invocations = contribution.invocations;
		this.localStore.validate(invocations);
		const owner = {};
		const { schemas, packages, localStore } = this;
		return this.ctx.effect(function* () {
			packages.set(packageRecord.key, packageRecord);
			for (const record of schemaRecords) schemas.set(record.key, record);
			localStore.commit(owner, invocations);
			yield () => {
				/* v8 ignore else -- duplicate package-face registration is rejected, so this effect remains its unique owner. */
				if (packages.get(packageRecord.key) === packageRecord) packages.delete(packageRecord.key);
				for (const record of schemaRecords)
 /* v8 ignore else -- duplicate schema registration is rejected, so this contribution remains each record's unique owner. */
				if (schemas.get(record.key) === record) schemas.delete(record.key);
				localStore.withdraw(owner, invocations);
			};
		}, "typert.register()");
	}
	/**
	* Look up one schema by `<package>#<name>`.
	* @param key - global schema key.
	* @returns the live schema record, or `undefined` when absent.
	*/
	get(key) {
		return this.schemas.get(key);
	}
	/**
	* Resolve one required schema.
	* @param key - global schema key.
	* @returns the live schema record.
	* @throws when the key is malformed, the package face is absent, or the schema is not contributed.
	*/
	resolve(key) {
		const record = this.schemas.get(key);
		if (record !== void 0) return record;
		const hash = key.indexOf("#");
		if (hash <= 0 || hash === key.length - 1) throw new Error(`typert: invalid schema key "${key}" — expected "<package>#<name>"`);
		const packageName = key.slice(0, hash);
		if ([...this.packages.values()].some((candidate) => candidate.package === packageName)) throw new Error(`typert: cannot resolve "${key}" — package "${packageName}" is registered but contributes no schema named "${key.slice(hash + 1)}"`);
		throw new Error(`typert: cannot resolve "${key}" — package "${packageName}" has no registered contribution`);
	}
	/**
	* Enumerate live schemas in registration order.
	* @param filter - optional package and face restriction.
	* @returns matching schema records.
	*/
	list(filter = {}) {
		return [...this.schemas.values()].filter((record) => matches(record, filter));
	}
	/**
	* Look up generated reflection for one package face.
	* @param packageName - exact npm package name.
	* @param face - face to query; defaults to the host runtime.
	* @returns the live package record, or `undefined` when absent.
	*/
	getPackage(packageName, face = "host") {
		return this.packages.get(typertPackageKey(packageName, face));
	}
	/**
	* Enumerate generated package reflection in registration order.
	* @param filter - optional package and face restriction.
	* @returns matching package records.
	*/
	listPackages(filter = {}) {
		return [...this.packages.values()].filter((record) => matches(record, filter));
	}
	/**
	* Project a live Zod schema to JSON Schema without caching the result.
	* @param key - global schema key.
	* @param params - Zod projection parameters.
	* @returns a fresh JSON Schema document.
	*/
	toJSONSchema(key, params) {
		return z.toJSONSchema(this.resolve(key).schema, params);
	}
	validatePackage(contribution) {
		validateSegment("package name", contribution.package);
		const face = contribution.face;
		if (face !== "host" && face !== "client") throw new Error(`typert: invalid face ${JSON.stringify(face)} — expected "host" or "client"`);
		const key = typertPackageKey(contribution.package, contribution.face);
		if (this.packages.has(key)) throw new Error(`typert: package face "${key}" is already registered`);
		return {
			package: contribution.package,
			face,
			key,
			model: contribution.model
		};
	}
	validateSchemas(contribution) {
		const records = [];
		const batch = /* @__PURE__ */ new Set();
		for (const schema of contribution.schemas) {
			validateSegment("schema name", schema.name);
			const key = typertKey(contribution.package, schema.name);
			if (batch.has(key) || this.schemas.has(key)) throw new Error(`typert: schema "${key}" is already registered`);
			batch.add(key);
			records.push({
				...schema,
				package: contribution.package,
				face: contribution.face,
				key
			});
		}
		return records;
	}
};
function matches(record, filter) {
	return (filter.package === void 0 || record.package === filter.package) && (filter.face === void 0 || record.face === filter.face);
}
function validateInvocation(descriptor) {
	validateNonempty("invocation id", descriptor.id);
	validateSegment("invocation service key", descriptor.service);
	validateWireName("invocation namespace", descriptor.namespace);
	validateWireName("invocation method", descriptor.method);
	if (descriptor.implementation !== void 0) validateWireName("invocation implementation method", descriptor.implementation);
	validateCodec(descriptor.result, `${descriptor.id} result`);
	const wires = /* @__PURE__ */ new Set();
	for (const parameter of descriptor.parameters) {
		validateWireName("parameter name", parameter.name);
		validateWireName("parameter wire field", parameter.wire);
		if (wires.has(parameter.wire)) throw new Error(`typert: invocation "${descriptor.id}" repeats wire field "${parameter.wire}"`);
		wires.add(parameter.wire);
		if (parameter.source === "lookup") {
			if (parameter.acceptsUndefined !== void 0) throw new Error(`typert: invocation "${descriptor.id}" lookup parameter "${parameter.name}" cannot accept undefined`);
			if (parameter.lookup === void 0) throw new Error(`typert: invocation "${descriptor.id}" lookup parameter "${parameter.name}" has no lookup key`);
			validateSegment("lookup key", parameter.lookup);
		} else if (parameter.lookup !== void 0) throw new Error(`typert: invocation "${descriptor.id}" JSON parameter "${parameter.name}" declares a lookup key`);
		validateCodec(parameter.codec, `${descriptor.id} parameter ${parameter.name}`);
	}
	const cancellation = descriptor.cancellation;
	if (cancellation !== void 0 && cancellation.parameter !== "signal") throw new Error(`typert: invocation "${descriptor.id}" cancellation parameter must be "signal"`);
	if (descriptor.scope !== void 0) {
		if (descriptor.invocation.kind !== "direct") throw new Error(`typert: invocation "${descriptor.id}" Context receiver cannot declare a direct scope projection`);
		validateSegment("scope Context key", descriptor.scope.context);
		validateWireName("scope wire field", descriptor.scope.wire);
		const lookups = descriptor.parameters.filter((candidate) => candidate.source === "lookup");
		const parameter = lookups.length === 1 ? lookups[0] : void 0;
		if (parameter === void 0 || parameter.wire !== descriptor.scope.wire || parameter.lookup !== descriptor.scope.context) throw new Error(`typert: invocation "${descriptor.id}" scope wire "${descriptor.scope.wire}" must select its only lookup parameter`);
	}
	if (descriptor.invocation.kind === "context") {
		validateSegment("Context key", descriptor.invocation.context);
		validateWireName("Context wire field", descriptor.invocation.wire);
		if (wires.has(descriptor.invocation.wire)) throw new Error(`typert: invocation "${descriptor.id}" repeats wire field "${descriptor.invocation.wire}"`);
		validateCodec(descriptor.invocation.codec, `${descriptor.id} Context`);
	}
}
function validateCodec(codec, subject) {
	if (codec.mode === "src-json") return;
	validateNonempty(`${subject} type symbol`, codec.typeSymbol);
	if (typeof codec.schema.parse !== "function") throw new Error(`typert: ${subject} strict codec has no parse() method`);
}
function validateWireName(subject, value) {
	if (value === "." || value === ".." || !/^[A-Za-z0-9_$.-]+$/.test(value)) throw new Error(`typert: invalid ${subject} "${value}" — must contain only RPC endpoint segment characters`);
}
function validateSegment(subject, value) {
	if (value.length === 0 || value.includes("#")) throw new Error(`typert: invalid ${subject} "${value}" — must be nonempty and must not contain "#"`);
}
function validateNonempty(subject, value) {
	if (value.length === 0) throw new Error(`typert: invalid ${subject} — must be nonempty`);
}
//#endregion
//#region ../../typert/registry/lib/types/client/index.js
/** Browser face of the shared Typert runtime registry. */
/** Required services: none; this is the Client reflection root. */
const inject$1 = [];
/**
* Install the same registry implementation used by the Host face.
* @param ctx - Client Cordis root.
*/
function apply$2(ctx) {
	new TypertRegistry(ctx);
}
//#endregion
//#region ../../typert/registry/lib/types/client/portable.js
/** Normal ESM Client entry for portable Cordis compositions. */
/**
* Install the Client plugin through a callback Cordis invokes as a function.
* Binding prevents Cordis from treating a transpiled function as a constructor.
* @param ctx - Client Cordis root with this plugin's injected services.
* @returns nothing after the registry is installed.
*/
const apply$1 = apply$2.bind(void 0);
//#endregion
//#region lib/types/client/portable.js
/** Normal ESM Client entry for portable Cordis compositions. */
/**
* Install the Client plugin through a callback Cordis invokes as a function.
* Binding prevents Cordis from treating a transpiled function as a constructor.
* @param ctx - Client Cordis root with this plugin's injected services.
* @returns disposer once every generated namespace is ready.
*/
const apply = apply$4.bind(void 0);
/**
* Install the shared Workspace projection and reconnecting follow stream for one host.
* @param ctx - Client Cordis context with the generated Workspace Remote namespace.
*/
const applyWorkspaces = apply$3.bind(void 0);
/**
* Install shared Session state and reconnecting streams for one host.
* @param ctx - Client Cordis context with the generated Session Remotes.
* @param options - platform callbacks and hydrated host-specific navigation.
*/
const applySessions = applySessions$1.bind(void 0);
//#endregion
export { ClientWorkspaceModel, DEVICE_ACCESS_PATHS, MutableSessionEventSource, RemoteJournalStream, RemoteSnapshotStream, RemoteStream, RemoteStreamCarrierError, SessionCreateError, SessionEventStream, SessionForkError, WorkspaceController, WorkspaceCreateError, apply, apply$1 as applyRegistry, applyRemoteClient, applySessions, applyWorkspaces, claimDeviceEnrollment, connectionDeviceEnrollmentSchema, connectionDeviceGrantSchema, connectionHostIdSchema, createConnection, createConnectionRpc, createRemoteStreamMux, createSessionControlStream, createWorkspaceStateStream, inject, isRemoteFailure, readHostCapabilities, readHostIdentity, inject$1 as registryInject, scopeOf, selectRemoteCapabilities, inject$2 as sessionInject, inject$3 as workspaceInject };
