import { Context, Service } from "@deepseek-ai/cordis";
import { RemoteErrorCode, RemoteErrorDetailsMap, RemoteFailure, RemoteFailure as RemoteFailure$1, RemoteResult, RemoteResult as RemoteResult$1, TypertClientRemote, TypertContext, TypertLookup, TypertRemoteMap, TypertRemoteScopeApi, TypertRemoteService } from "@deepseek-ai/dsh-typert-protocol";
import { Branded, BrandedNumber } from "@deepseek-ai/dsh-brand";
import { z } from "zod";
import { JsonValue } from "@deepseek-ai/dsh-util-values";

//#region ../../client/connection/lib/types/host-identity-protocol.d.ts
/** Durable identity of one credential store; copying the store copies this id. */
type ConnectionHostId = Branded<'connection-host-id'>;
/** Identity of one application root, retained across Connection reloads. */
type ConnectionActivationId = Branded<'connection-activation-id'>;
/** Correlation facts only; version describes this envelope, not API compatibility. */
interface ConnectionIdentity {
  readonly version: 1;
  readonly hostId: ConnectionHostId;
  readonly activationId: ConnectionActivationId;
}
/** Validate a persisted or transferred Host reference without inventing an activation. */
declare const connectionHostIdSchema: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionHostId, string>>;
//#endregion
//#region ../../client/connection/lib/types/rpc.d.ts
/** Correlation id minted by a caller and echoed by the Connection response. */
type RpcId = Branded<'rpc-id'>;
/**
 * Brand one validated string as a Connection correlation id.
 * @param id - validated wire identity.
 * @returns the same string with the correlation-id brand.
 */
declare function RpcId(id: string): RpcId;
/** Carrier-neutral failure returned by one logical RPC endpoint. */
interface ConnectionRpcFailure {
  readonly code: string;
  readonly message: string;
  readonly details: object;
}
/** Carrier-neutral result returned by one logical RPC endpoint. */
type ConnectionRpcResult<T> = {
  readonly ok: true;
  readonly value: T;
} | {
  readonly ok: false;
  readonly error: ConnectionRpcFailure;
};
/** Historical short name for a generic Connection result. */
type RpcResult<T> = ConnectionRpcResult<T>;
/** Narrow request form used by direct fixture adapters. */
interface RpcRequest<P> {
  readonly rpcId: RpcId;
  readonly payload: P;
}
/** Narrow response form used by direct fixture adapters. */
interface RpcResponse<T> {
  readonly rpcId: RpcId;
  readonly result: RpcResult<T>;
}
/** Client caller for logical RPC channels carried by the current transport. */
interface ClientConnectionRpc {
  /**
   * Call one endpoint through an already registered logical channel.
   * @param channel - absolute logical channel such as `/api`.
   * @param endpoint - channel-relative endpoint such as `goals/create`.
   * @param payload - channel-owned request payload.
   * @param signal - optional caller cancellation.
   * @returns the endpoint-owned success/error result; correlation stays inside Connection.
   */
  call(channel: string, endpoint: string, payload: unknown, signal?: AbortSignal): Promise<ConnectionRpcResult<unknown>>;
  /**
   * Open an in-process logical stream when the selected carrier supplies one.
   * Browser transports omit this method; API Gateway owns their WebSocket mux.
   * @param channel - absolute logical channel such as `/api`.
   * @param endpoint - channel-relative endpoint such as `session/follow`.
   * @param payload - channel-owned request payload.
   * @param signal - caller cancellation for this logical stream.
   * @returns decoded stream values from the in-process carrier.
   */
  readonly open?: (channel: string, endpoint: string, payload: unknown, signal: AbortSignal) => AsyncIterable<unknown>;
}
//#endregion
//#region ../../client/connection/lib/types/client/rpc-caller.d.ts
/** HTTP and JSON facts consumed by Connection; browser Response objects satisfy this interface. */
interface RpcFetchResponse {
  readonly ok: boolean;
  readonly status: number;
  /** @returns decoded, still-unvalidated response body. */
  json(): Promise<unknown>;
}
/** Platform transport retaining cancellation ownership until response JSON decoding settles. */
type RpcFetch = (input: URL, init: RequestInit) => Promise<RpcFetchResponse>;
/** Transport-owned opener for decoded Gateway Remote streams. */
type RpcStreamOpen = (endpoint: string, payload: unknown, signal: AbortSignal) => AsyncIterable<unknown>;
/** Explicit transport inputs for one Host's RPC calls. */
interface ConnectionRpcOptions {
  /** Base authority used to resolve absolute RPC channel paths. */
  readonly baseUrl: string;
  /** Host-authenticated Fetch implementation; owns credentials and networking. */
  readonly fetch: RpcFetch;
  /** Mint a new correlation id for each request. */
  readonly randomId: () => RpcId;
  /** Optional carrier for decoded Gateway streams. */
  readonly openStream?: RpcStreamOpen;
}
/**
 * Create an RPC caller without reading browser, crypto, or transport globals.
 * Requests are sent once; a rejected transport leaves command acceptance unknown.
 * @param options - Host authority, transport, and correlation-id source.
 * @returns caller validating targets, response envelopes, and correlation without retrying mutations.
 */
declare function createConnectionRpc(options: ConnectionRpcOptions): ClientConnectionRpc;
//#endregion
//#region ../../attachment/attachment/lib/types/error.d.ts
declare const ATTACHMENT_ERROR_CODES: readonly ["TOO_MANY_IMAGES", "IMAGES_TOO_LARGE", "UNSUPPORTED_IMAGE_TYPE", "INVALID_IMAGE_BASE64", "INVALID_IMAGE", "IMAGE_TYPE_MISMATCH", "IMAGE_TOO_LARGE", "IMAGE_TOO_MANY_PIXELS", "IMAGE_DIMENSION_TOO_LARGE", "INVALID_FILE_BASE64", "INVALID_ATTACHMENT_REF", "ATTACHMENT_CORRUPT", "ATTACHMENT_WRITE_FAILED", "ATTACHMENT_NOT_FOUND", "ATTACHMENT_READ_FAILED", "ATTACHMENT_PROJECTION_UNSUPPORTED", "ATTACHMENT_FILES_UNSUPPORTED"];
/** Stable attachment failure codes used for protocol error routing. */
type AttachmentErrorCode = typeof ATTACHMENT_ERROR_CODES[number];
/**
 * Stable failures suitable for host RPC error mapping.
 *
 * Deliberately re-implements the `HarnessError` shape instead of extending it:
 * the base lives in `@deepseek-ai/dsh-llm`, which itself depends on this
 * package (`ImageBlock` references `ImageAttachmentRef`), so sharing the base
 * would create a dependency cycle. Consumers route on `code`, never on the
 * prototype chain, so the shapes stay interchangeable at the wire boundary.
 */
declare class AttachmentError extends Error {
  /** Stable machine-routing failure code. */
  readonly code: AttachmentErrorCode;
  /**
   * @param message - human-readable failure description without raw bytes or host paths.
   * @param code - stable machine-routing code.
   * @param options - optional chained cause.
   */
  constructor(message: string, code: AttachmentErrorCode, options?: ErrorOptions);
}
//#endregion
//#region ../../attachment/attachment/lib/types/brand.d.ts
/** Opaque content-addressed identifier for one immutable attachment object. */
type AttachmentId = Branded<'AttachmentId'>;
/**
 * Brand a validated storage identifier.
 * @param value - backend-produced opaque identifier.
 * @returns the branded identifier.
 */
declare function AttachmentId(value: string): AttachmentId;
/** Opaque deterministic identity for one request-image transformation. */
type ImageVariantId = Branded<'ImageVariantId'>;
/**
 * Brand a validated request-image transformation identifier.
 * @param value - attachment-provider-produced opaque identifier.
 * @returns the branded identifier.
 */
declare function ImageVariantId(value: string): ImageVariantId;
//#endregion
//#region ../../attachment/attachment/lib/types/types.d.ts
/** Raster image formats accepted by the version-one attachment path. */
type ImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
/** Durable, serializable reference to one immutable normalized image. */
interface ImageAttachmentRef {
  /** Opaque storage identifier; never a filesystem path or bearer URL. */
  attachmentId: AttachmentId;
  /** Media type verified from the stored bytes. */
  mediaType: ImageMediaType;
  /** Exact encoded byte length. */
  bytes: number;
  /** Intrinsic encoded width in pixels. */
  width: number;
  /** Intrinsic encoded height in pixels. */
  height: number;
  /** Optional display name stripped of local path information. */
  name?: string;
  /**
   * Input dimensions after applying EXIF orientation and before normalization
   * scaling. Present only when normalization reduced the image.
   */
  originalDimensions?: {
    width: number;
    height: number;
  };
}
/**
 * Durable, serializable reference to one verbatim stored file. Files are
 * stored byte-for-byte with no normalization; `attachmentId` is the sha256
 * digest of exactly those bytes.
 */
interface FileAttachmentRef {
  /** Opaque content-addressed storage identifier; never a filesystem path or bearer URL. */
  attachmentId: AttachmentId;
  /** Sanitized display filename, also the stored object's leaf name. */
  name: string;
  /** Exact byte length. */
  bytes: number;
}
/** Base64-encoded file upload accompanying one wire request. */
interface EncodedFileAttachment {
  /** Canonical base64 encoding of the file bytes. */
  data: string;
  /** Optional display name; it is never interpreted as a path. */
  name?: string;
}
/** Request to durably commit one file verbatim. */
interface SaveFileAttachment {
  data: Uint8Array;
  /** Optional browser/provider display name; it is never interpreted as a path. */
  name?: string;
}
/** Request to durably commit one file from bounded byte chunks. */
interface SaveFileStreamAttachment {
  /** Exact file bytes in order; providers must not retain the complete sequence in memory. */
  data: AsyncIterable<Uint8Array>;
  /** Optional cancellation for source reads and storage writes. */
  signal?: AbortSignal;
  /** Optional browser/provider display name; it is never interpreted as a path. */
  name?: string;
}
/** Deployment-resolved limits used by upload admission and request buffering. */
interface ImageAttachmentLimits {
  maxImageBytes: number;
  maxImagesPerMessage: number;
  maxMessageImageBytes: number;
  maxImagePixels: number;
  /** Maximum intrinsic width and maximum intrinsic height in pixels for one image. */
  maxImageDimension: number;
  mediaTypes: readonly ImageMediaType[];
}
/** Base64-encoded image upload accompanying one wire request. */
interface EncodedImageAttachment {
  /** Declared media type, verified against the decoded bytes during admission. */
  mediaType: ImageMediaType;
  /** Canonical base64 encoding of the image bytes. */
  data: string;
  /** Optional display name; it is never interpreted as a path. */
  name?: string;
}
/**
 * Browser-submitted prompt content accepted by Host prompt endpoints; the
 * accepting Host promotes image parts to durable references through
 * `ctx.attachments.admitPromptContent()` before any message is created, so a wire caller can
 * never cite an attachment it did not upload.
 */
type PromptContentPart$1 = {
  readonly type: 'text';
  readonly text: string;
} | {
  readonly type: 'image';
  readonly mediaType: ImageMediaType;
  readonly data: string;
  readonly name?: string;
};
/** Host prompt content whose file receipts are resolved and whose image bytes await admission. */
type AttachmentAdmissionPart = PromptContentPart$1 | {
  readonly type: 'file';
  readonly attachment: FileAttachmentRef;
};
/** Host-admitted prompt content with every attachment represented by its durable reference. */
type AdmittedPromptContentPart = {
  readonly type: 'text';
  readonly text: string;
} | {
  readonly type: 'image';
  readonly attachment: ImageAttachmentRef;
} | {
  readonly type: 'file';
  readonly attachment: FileAttachmentRef;
};
/** Request to validate and durably commit one image. */
interface SaveImageAttachment {
  data: Uint8Array;
  /** Caller-declared media type, checked against fully decoded bytes. */
  mediaType: ImageMediaType;
  /** Optional browser/provider display name; it is never interpreted as a path. */
  name?: string;
}
/** Stored image bytes returned after reference and digest verification. */
interface StoredImageAttachment {
  ref: ImageAttachmentRef;
  data: Uint8Array;
}
/** Deterministic request-image policy selected by one exact model route. */
interface ImageRequestPolicy {
  /** Maximum width multiplied by height after aspect-preserving projection. */
  maxPixels: number;
  /** Encoded-byte target before base64 expansion or Files API upload; the smallest quality-ladder output is kept when no quality fits. */
  maxBytes: number;
}
/** Cached request version derived from one provider-independent normalized attachment. */
interface RequestImageAttachment {
  /** Cache and upload-index key over the attachment id, policy, and fixed encoder parameters. */
  variantId: ImageVariantId;
  /** Durable normalized attachment from which this request version was derived. */
  attachment: ImageAttachmentRef;
  /** Encoded request bytes. */
  data: Uint8Array;
  mediaType: ImageMediaType;
  bytes: number;
  width: number;
  height: number;
  /** Provider-compatible sample depth proven after request encoding. */
  depth: 'uchar';
  /** Provider-compatible color space proven after request encoding. */
  space: 'srgb';
  /** Whether the encoded request version retains an alpha channel. */
  hasAlpha: boolean;
}
//#endregion
//#region ../../attachment/attachment/lib/types/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Context {
    attachments: AttachmentStore;
  }
}
/** Immutable binary attachment service. Implementations validate bytes before publishing a reference. */
declare abstract class AttachmentStore extends Service {
  constructor(ctx: Context);
  /** Deployment-resolved image policy used by authoritative and fast-path validation. */
  abstract readonly imageLimits: ImageAttachmentLimits;
  /**
   * Validate one image without persisting it.
   * Batch callers validate every member before saving any member.
   * @param input - encoded bytes, declared media type, and optional display name.
   * @returns completion after the encoded raster has been fully decoded.
   */
  abstract validateImage(input: SaveImageAttachment): Promise<void>;
  /**
   * Validate one ordered image batch before committing any member.
   * Validation failures start no writes; storage failures return no partial
   * references, although already published content-addressed objects may stay
   * unreachable until a future retention policy collects them.
   * @param inputs - encoded images in their owning message order.
   * @returns durable references in the exact input order.
   */
  protected validateImageBatch(inputs: readonly SaveImageAttachment[]): void;
  /**
   * Validate and durably commit one ordered image batch.
   * @param inputs - encoded images in owning-message order.
   * @returns durable normalized attachment references in the same order after every member succeeds.
   */
  saveImages(inputs: readonly SaveImageAttachment[]): Promise<readonly ImageAttachmentRef[]>;
  /**
   * Admit one Host prompt and replace each uploaded image with its durable reference.
   * Text and durable file references pass through unchanged. A prompt without image parts performs no storage operation.
   * @param content - prompt parts in message order after file receipt resolution.
   * @returns admitted prompt parts in the same order as `content`.
   * @throws AttachmentError when the image batch is refused.
   */
  admitPromptContent(content: readonly AttachmentAdmissionPart[]): Promise<AdmittedPromptContentPart[]>;
  /**
   * Decode and durably commit one canonical base64 file upload.
   * @param input - canonical base64 bytes and optional display name.
   * @returns the durable content-addressed file reference.
   * @throws AttachmentError when the encoding or storage operation is refused.
   */
  admitEncodedFile(input: EncodedFileAttachment): Promise<FileAttachmentRef>;
  /**
   * Identify a failure emitted by this attachment capability by its stable code.
   * @param error - value caught from an attachment operation.
   * @returns whether the value is an attachment failure.
   */
  isAttachmentError(error: unknown): error is AttachmentError;
  /**
   * Validate and durably commit one image before its owning session event is appended.
   * The returned reference describes the persisted normalized image. When
   * normalization reduces the raster, its `originalDimensions` records the
   * orientation-applied input dimensions.
   * @param input - encoded bytes, declared media type, and optional display name.
   * @returns the durable content-addressed normalized image reference.
   */
  abstract saveImage(input: SaveImageAttachment): Promise<ImageAttachmentRef>;
  /**
   * Read one image and verify that bytes still match the recorded reference.
   * @param ref - durable reference from the session log.
   * @param signal - optional cancellation for backend read and verification work.
   * @returns the verified bytes and normalized attachment reference.
   * @throws the signal reason when aborted, or a storage error when verification fails.
   */
  abstract readImage(ref: ImageAttachmentRef, signal?: AbortSignal): Promise<StoredImageAttachment>;
  /**
   * Locate the provider-owned normalized object in the harness host filesystem.
   * @param ref - durable normalized attachment reference.
   * @returns an absolute host path, or undefined when this backend is not host-file-backed.
   * @throws an AttachmentError when the durable reference is invalid.
   */
  imageHostPath(ref: ImageAttachmentRef): string | undefined;
  /**
   * Durably commit one file byte-for-byte before its owning session event is
   * appended. Files carry no admission limits: any byte content and length is
   * accepted, and the stored object is the exact submitted bytes. Backends
   * without verbatim file storage keep this default rejection.
   * @param input - exact bytes and optional display name.
   * @returns the durable content-addressed file reference.
   */
  saveFile(input: SaveFileAttachment): Promise<FileAttachmentRef>;
  /**
   * Durably commit one file byte-for-byte from bounded chunks. Providers must
   * apply backpressure and must not collect the complete file in memory.
   * Backends without streamed verbatim storage keep this default rejection.
   * @param input - ordered exact bytes, optional cancellation, and display name.
   * @returns the durable content-addressed file reference.
   */
  saveFileStream(input: SaveFileStreamAttachment): Promise<FileAttachmentRef>;
  /**
   * Read and verify one verbatim stored file as bounded chunks. Providers must
   * not collect the complete file in memory. Backends without verbatim file
   * reads keep this default rejection.
   * @param ref - durable reference from the session log.
   * @param signal - optional cancellation for backend reads and verification work.
   * @returns exact file bytes in order; integrity failures reject the iteration.
   */
  readFileStream(ref: FileAttachmentRef, signal?: AbortSignal): AsyncIterable<Uint8Array>;
  /**
   * Locate the verbatim stored file object in the harness host filesystem.
   * @param ref - durable file reference.
   * @returns an absolute host path, or undefined when this backend is not host-file-backed.
   * @throws an AttachmentError when the durable reference is invalid.
   */
  fileHostPath(ref: FileAttachmentRef): string | undefined;
  /**
   * Generate or read one deterministic model-request version from the stored normalized image.
   * @param ref - durable provider-independent normalized attachment reference.
   * @param policy - exact route pixel budget and encoded-byte target; a target no ladder quality meets yields the smallest ladder output.
   * @param signal - optional cancellation.
   * @returns request bytes and the cache/upload identity covering every transform input.
   */
  readImageRequest(ref: ImageAttachmentRef, policy: ImageRequestPolicy, signal?: AbortSignal): Promise<RequestImageAttachment>;
}
//#endregion
//#region ../../llm/llm/lib/types/brand.d.ts
/** Stable identity carried by one message across inbox, log, and model-request boundaries. */
type MessageId = Branded<'MessageId'>;
/**
 * Brand a message identifier.
 * @param id - the opaque message identifier.
 * @returns the same string with the message-id brand.
 */
declare function MessageId(id: string): MessageId;
/**
 * Correlates a model-issued tool call with its result. Provider-issued for
 * real adapters; synthesized by mocks/assembler fallbacks.
 */
type ToolCallId = Branded<'ToolCallId'>;
/**
 * Brand a string as a {@link ToolCallId}.
 * @param id - the provider-issued or synthesized call id.
 * @returns the same string with the tool-call-id brand.
 */
declare function ToolCallId(id: string): ToolCallId;
/** Provider-issued request identifier retained for diagnostics across package boundaries. */
type ProviderRequestId = Branded<'ProviderRequestId'>;
/**
 * Brand a provider-issued request identifier.
 * @param id - the opaque provider-issued string.
 * @returns the same string, branded; no validation is performed.
 */
declare function ProviderRequestId(id: string): ProviderRequestId;
/** Identity of one model streaming attempt, unique within one Agent lifecycle. */
type LlmAttemptId = Branded<'LlmAttemptId'>;
/**
 * Brand one loop-owned streaming attempt identifier.
 * @param id - the opaque Agent-lifecycle-local identifier.
 * @returns the same string with the attempt-id brand.
 */
declare function LlmAttemptId(id: string): LlmAttemptId;
/** Adapter-owned identifier for one model's selectable reasoning effort. */
type ReasoningEffortId = Branded<'ReasoningEffortId'>;
/**
 * Brand an adapter-owned reasoning-effort identifier.
 * @param id - the opaque identifier exposed by one model capability.
 * @returns the same string, branded; no validation is performed.
 */
declare function ReasoningEffortId(id: string): ReasoningEffortId;
//#endregion
//#region ../../llm/llm/lib/types/message.d.ts
/** Provider/model identity and adapter-private replay data for an assistant message. */
interface AssistantProvenance {
  /** Provider route that produced the message. */
  provider: string;
  /** Provider model id that produced the message. */
  model: string;
  /**
   * Lossless-JSON adapter state needed to replay the provider response.
   * `LlmRuntime` exposes it to a target adapter only when that adapter instance
   * currently owns both this historical provider and the target provider.
   */
  replayState?: unknown;
}
/** Required source of an assistant message produced by a routed model. */
interface ModelMessageSource extends AssistantProvenance {
  kind: 'model';
}
/** Required source of a user-role message carrying one tool result. */
interface ToolMessageSource {
  kind: 'tool';
  callId: ToolCallId;
}
/** One named contribution to a `snapshot`-form context, in assembly order. */
interface ContextSnapshotSection {
  /** The contributing subsystem's name. */
  readonly name: string;
  /** That contribution's model-facing text, exactly as assembled. */
  readonly text: string;
}
/**
 * Producer-declared {@link ContextForm} and the fields that form requires,
 * mixed into the source types that carry one.
 *
 * Discriminated by `form` so a producer cannot select a form without the
 * fields needed to present it: a `notice` must record its one-line
 * account, a `snapshot` its sections. Omitting `form` stays valid — an
 * undeclared context is the documented default.
 */
type ContextFormed = {
  readonly form?: never;
} | {
  readonly form: 'instructions';
} | {
  readonly form: 'catalog';
} | {
  readonly form: 'snapshot'; /** The named contributions this snapshot assembled, in order. */
  readonly sections: readonly ContextSnapshotSection[];
} | {
  readonly form: 'notice'; /** One-line account of what happened, shown without expanding the row. */
  readonly summary: string;
} | {
  readonly form: 'relay';
} | {
  readonly form: 'recall';
};
/**
 * Where a message (or injected content) came from.
 * Merge-extensible sum type — plugins add their own `kind`s.
 */
interface MessageSourceMap {
  user: {
    kind: 'user';
  };
  plugin: {
    kind: 'plugin';
    plugin: string;
  } & ContextFormed;
  model: ModelMessageSource;
  tool: ToolMessageSource;
}
/** Any known message source, derived from {@link MessageSourceMap}; switch on `kind` and fall through unknowns (merge-extensible). */
type MessageSource = MessageSourceMap[keyof MessageSourceMap];
/** One immutable message representation shared by delivery, durable history, and model requests. */
interface Message {
  /** Stable identity preserved across every representation boundary. */
  readonly id: MessageId;
  /** Provider-neutral conversation role. */
  readonly role: 'system' | 'user' | 'assistant';
  /** Exact model-facing blocks. */
  readonly content: ContentBlock[];
  /** Required source fields supplied by the producer. */
  readonly source: MessageSource;
}
/** A user-role specialization of the one shared message representation. */
interface UserMessage extends Message {
  readonly role: 'user';
}
/** A model-produced assistant specialization of the shared message representation. */
interface AssistantMessage extends Message {
  readonly role: 'assistant';
  readonly source: ModelMessageSource;
}
/**
 * A system-role specialization of the shared message representation: one
 * rendered system prompt attributed to the plugin that assembled it. Empty
 * `content` means "no system prompt" and projects to no wire message.
 */
interface SystemMessage extends Message {
  readonly role: 'system';
  readonly source: MessageSourceMap['plugin'];
}
/** A tool-result specialization whose model-facing block retains call correlation. */
interface ToolResultMessage extends Message {
  readonly role: 'user';
  readonly content: [ToolResultBlock];
  readonly source: ToolMessageSource;
}
//#endregion
//#region ../../llm/llm/lib/types/types.d.ts
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * The provider topology changed: an adapter registered or unregistered
     * routes, or the configurable-provider directory gained or lost entries.
     * This payload-free registry notification fires at each commit point
     * (including registration disposal); consumers re-read `listProviders()`,
     * `listModels()`, or `listConfigurableProviders()` for the new state.
     * Observer failures are contained and cannot veto the registry mutation.
     * @mode emit
     */
    'llm/adapters-updated'(): void;
  }
}
/** Serializable provider or transport failure facts; policy decides whether they are retryable. */
interface LlmFailure {
  /** Human-readable provider or transport failure. */
  readonly message: string;
  /** Stable provider-neutral machine-routing code. */
  readonly code: string;
  /** HTTP status returned by the provider, when available. */
  readonly status?: number;
  /** Provider-requested delay in milliseconds, when valid and available. */
  readonly providerRetryAfterMs?: number;
  /** Opaque provider-issued request identifier for diagnostics. */
  readonly requestId?: ProviderRequestId;
}
/** Plain text visible to the end user. */
interface TextBlock {
  type: 'text';
  text: string;
}
/** Reasoning / thinking content, distinct from visible text. */
interface ReasoningBlock {
  type: 'reasoning';
  text: string;
}
/**
 * A durable raster image reference, valid in user or assistant content. The
 * block is deliberately role-neutral; assistant-side rendering is forward
 * compatibility — the current production adapters declare text-only output,
 * so only user messages may carry images.
 */
interface ImageBlock {
  type: 'image';
  /** Immutable bytes and intrinsic display metadata owned by the attachment service. */
  attachment: ImageAttachmentRef;
}
/**
 * A durable verbatim file reference, valid in user content. Files never reach
 * a provider natively: request assembly projects every occurrence to
 * deterministic handle text (name, byte size, and the read-only saved path),
 * so adapters and providers see text in its place while the durable log keeps
 * the structured reference for presentation and authorization.
 */
interface FileBlock {
  type: 'file';
  /** Immutable verbatim bytes and display metadata owned by the attachment service. */
  attachment: FileAttachmentRef;
}
/** A tool invocation requested by the model. */
interface ToolCallBlock {
  type: 'tool-call';
  /** Provider-issued call id; correlates with the matching tool result. */
  id: ToolCallId;
  name: string;
  /** Raw JSON string as produced by the model. */
  arguments: string;
}
/** The result of a tool invocation, sent back to the model. */
interface ToolResultBlock {
  type: 'tool-result';
  toolCallId: ToolCallId;
  content: ContentBlock[];
  isError?: boolean;
}
/**
 * Merge-extensible content blocks keyed by `type`. New core blocks must land
 * with adapter, UI, and compaction support.
 */
interface ContentBlockMap {
  'text': TextBlock;
  'reasoning': ReasoningBlock;
  'image': ImageBlock;
  'file': FileBlock;
  'tool-call': ToolCallBlock;
  'tool-result': ToolResultBlock;
}
/** The block `type` tag vocabulary; widens as plugins add entries to {@link ContentBlockMap}. */
type ContentBlockType = keyof ContentBlockMap;
/** Any known content block, derived from {@link ContentBlockMap}; switch on `type` and fall through unknowns (merge-extensible). */
type ContentBlock = ContentBlockMap[ContentBlockType];
/**
 * Why a model response stopped.
 * Merge-extensible so adapters can surface provider-specific reasons.
 */
interface FinishReasonMap {
  'stop': {
    kind: 'stop';
  };
  'tool-calls': {
    kind: 'tool-calls';
  };
  'max-tokens': {
    kind: 'max-tokens';
  };
  'aborted': {
    kind: 'aborted';
    failure: LlmFailure;
  };
  'error': {
    kind: 'error';
    failure: LlmFailure;
  };
}
/** Any known finish reason, derived from {@link FinishReasonMap}; switch on `kind` and fall through unknowns (merge-extensible). */
type FinishReason = FinishReasonMap[keyof FinishReasonMap];
/**
 * Token accounting for one model call (cache fields are optional).
 *
 * Counts are DISJOINT: `inputTokens` is uncached input only; cached input is
 * reported separately as `cacheReadTokens`/`cacheWriteTokens` (billed input =
 * sum of the three). Adapters whose providers fold cache hits into a total
 * prompt count (DeepSeek's `prompt_tokens`) subtract them out.
 */
interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
  /**
   * Exact full-call total including aggregate prompt and output tokens.
   *
   * Adapters preserve a provider total or derive it from authoritative
   * aggregate prompt/output counters; they omit it when unavailable or
   * inconsistent.
   */
  totalTokens?: number;
  cacheReadTokens?: number;
  cacheWriteTokens?: number;
  reasoningTokens?: number;
}
/**
 * Request price of one ordered image occurrence under one exact model route's
 * request projection. Every occurrence resolves to the pair the wire actually
 * carries: provider visual tokens for a retained image, plus the model-visible
 * text sent with or instead of it (request-preview handle, offload placeholder,
 * or text-only substitution). The caller prices `text` with its own text
 * estimator so provider pricing never fixes a text tokenization.
 */
interface LlmImageRequestPrice {
  /** Provider visual tokens for the retained request image; 0 when only text represents this occurrence. */
  visualTokens: number;
  /** Model-visible text sent for this occurrence, to be priced by the caller's text estimator. */
  text: string;
}
/**
 * Provider-side request-image pricing for one exact model route. Implemented
 * by adapters whose provider charges visual tokens; consumers (the token
 * meter) resolve it synchronously per measurement, so implementations must not
 * perform I/O.
 */
interface LlmImageRequestPricing {
  /**
   * Price every image occurrence of one request projection.
   * @param images - durable image references in request order, one entry per occurrence.
   * @returns one price per occurrence, aligned by index with `images`.
   */
  priceImages(images: readonly ImageAttachmentRef[]): readonly LlmImageRequestPrice[];
}
/** Display metadata for one registered provider route. */
interface LlmProviderInfo {
  /** Provider route key used by {@link GenerateOptions.provider}. */
  id: string;
  /** Human-readable provider name for selectors and diagnostics. */
  name: string;
}
/** Merge-extensible provider model modality vocabulary. */
interface ModelModalityMap {
  text: 'text';
  image: 'image';
}
/** Any declared provider model modality. */
type ModelModality = ModelModalityMap[keyof ModelModalityMap];
/**
 * One provider route an adapter plugin can activate through configuration,
 * whether or not the route is currently registered. Configuration surfaces
 * merge this directory with `listProviders()` to offer every configurable
 * provider alongside its live/dormant state.
 */
interface LlmConfigurableProvider {
  /** Provider route key this entry activates when configured. */
  provider: string;
  /** Human-readable provider name for configuration surfaces. */
  displayName: string;
  /** User-settings namespace whose section configures this provider. */
  settingsNs: string;
  /**
   * Path from that namespace's section root to this provider's profile
   * object; empty when the whole section is the profile.
   */
  settingsPath: readonly string[];
  /**
   * Whether the owning adapter knows this route only because configuration
   * declared it — a gateway or self-hosted server it ships nothing about.
   * Absent means the adapter draws no such distinction; false means it does
   * and this route is one of its own. Only the adapter can answer: a stored
   * profile is how a user-added route AND a corrected shipped one both look
   * from outside.
   */
  declared?: boolean;
  /** Configuration diagnostic for repair; unaffected models may remain serviceable. */
  error?: string;
}
/**
 * One interrogation of a provider endpoint that configuration has not stored
 * yet. Configuration surfaces send the draft a user is still editing, so the
 * request carries the endpoint and credential directly instead of naming a
 * route: a provider being added has no route to name.
 */
interface LlmModelDiscoveryRequest {
  /**
   * Route the draft is editing, when it edits an existing one. A route whose
   * adapter already knows its models answers from that knowledge instead of
   * asking the endpoint — the adapter's own registry is the better answer, and
   * it costs no network call.
   */
  provider?: string;
  /**
   * Endpoint to interrogate. Optional because a route the adapter already
   * describes needs none; a route it does not must supply one.
   */
  baseURL?: string;
  /** Wire protocol the endpoint speaks, when the draft names one. */
  api?: string;
  /** Credential for this interrogation alone; the harness never stores it. */
  apiKey?: string;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** A draft provider interrogation refused or failed. */
    'llm/model-discovery-rejected': {
      readonly settingsNs: string;
      readonly baseURL?: string;
    };
  }
}
/**
 * One model an endpoint reports about itself. Every field but the id is
 * optional because most provider listings disclose an id and nothing else;
 * a surface adopting one of these still owes the capacities its adapter needs.
 */
interface LlmDiscoveredModel {
  /** Model id the endpoint accepts. */
  id: string;
  /** Human-readable name when the endpoint supplies one. */
  name?: string;
  /** Maximum combined request and response context, when disclosed. */
  contextWindow?: number;
  /** Maximum output tokens, when disclosed. */
  maxTokens?: number;
}
/** One adapter-discovered model; catalog membership is advisory, not request validation. */
interface LlmModelInfo {
  /** Provider route that owns this model entry. */
  provider: string;
  /** Model id passed to {@link GenerateOptions.model}. */
  id: string;
  /** Human-readable model name for selectors. */
  name: string;
  /** Optional user-facing distinction from otherwise similar models. */
  description?: string;
  /** Accepted request modalities; absent means unknown, while an explicit omission is negative capability. */
  inputModalities?: readonly ModelModality[];
}
/** Provider-owned context capacity for one exact provider/model route. */
interface LlmModelContext {
  /** Maximum combined request and response context in tokens. */
  contextWindow: number;
}
/** Display metadata for one adapter-owned reasoning effort. */
interface LlmReasoningEffortInfo {
  /** Opaque stable value accepted by {@link GenerateOptions.reasoningEffort}. */
  id: ReasoningEffortId;
  /** Human-readable effort name for selectors and diagnostics. */
  name: string;
  /** Optional user-facing distinction from otherwise similar efforts. */
  description?: string;
}
/** Selectable reasoning efforts for one exact provider/model route. */
interface LlmModelReasoningInfo {
  /** Supported efforts in adapter-preferred display order. */
  efforts: readonly LlmReasoningEffortInfo[];
  /**
   * Adapter-configured default materialized into requests when callers omit
   * an effort. Absence preserves the provider's own default.
   */
  defaultEffort?: ReasoningEffortId;
}
/**
 * How a model applies a system prompt that changes mid-conversation.
 * `'in-history'`: the model reads the latest `system` message at any position
 * of `messages` as the complete effective system prompt, so a changed prompt
 * can follow the cached history instead of rewriting message 0.
 */
type SystemPromptUpdate = 'in-history';
/** Exact-route model metadata resolved by its owning adapter. */
interface LlmResolvedModelInfo extends LlmModelInfo {
  /** Provider-owned context capacity when known. */
  context?: LlmModelContext;
  /** Adapter-configured per-request output cap materialized when callers omit one. */
  defaultMaxTokens?: number;
  /** Adapter-owned selectable reasoning levels when exposed. */
  reasoning?: LlmModelReasoningInfo;
  /** Declared mid-conversation system prompt handling; absent means only a leading system message is read. */
  systemPromptUpdate?: SystemPromptUpdate;
}
/**
 * Adapter-private lossless-JSON state for replaying a successful response,
 * carried by a terminal `finish` chunk and stored on the assembled assistant
 * message's model source. Both halves stay opaque to the harness; only the
 * split is shared vocabulary, so assembly can keep stored metadata aligned
 * with stored content without reading either half.
 */
interface ReplayEnvelope {
  /** Response-level adapter-private metadata (ids, native stop reason). */
  response: unknown;
  /**
   * Per-block adapter-private metadata, one entry per emitted block in
   * first-seen stream order. When assembly drops a block it drops the entry at
   * the same position; entries whose length does not match the emitted block
   * count discard the whole envelope. An adapter whose metadata is independent
   * of block structure omits this field and the envelope passes through
   * assembly unchanged.
   */
  blocks?: readonly unknown[];
}
/**
 * Raw streaming protocol emitted by adapters.
 * Block indexes correlate interleaved deltas, and `block-end` carries the
 * assembled block. Adapters emit usage before the terminal finish and nothing
 * afterward; tool arguments remain raw JSON strings. An adapter implementation
 * may throw, but `LlmRuntime.stream()` normalizes that failure to a terminal
 * `error` or `aborted` finish before exposing it to consumers.
 */
type StreamChunk = {
  type: 'block-start';
  index: number;
  blockType: ContentBlockType;
} | {
  type: 'text-delta';
  index: number;
  text: string;
} | {
  type: 'reasoning-delta';
  index: number;
  text: string;
} | {
  type: 'tool-call-delta';
  index: number;
  id: ToolCallId;
  name?: string;
  argumentsDelta: string;
} | {
  type: 'block-end';
  index: number;
  block: ContentBlock;
} | {
  type: 'usage';
  usage: TokenUsage;
} | {
  type: 'finish';
  reason: FinishReason; /** Replay metadata for a successful response; see {@link ReplayEnvelope}. */
  replayState?: ReplayEnvelope;
};
/**
 * JSON-schema description of a tool, as sent to the model.
 *
 * Declared here (not in dsh-tools) because it is part of {@link GenerateOptions};
 * dsh-tools' ToolDefinition and dsh-system-prompt's PromptAssembly both import
 * it from this package.
 */
interface ToolSchema {
  name: string;
  description: string;
  /** JSON Schema object for the arguments. */
  parameters: Record<string, unknown>;
}
/** A single model request, fully assembled. */
interface GenerateOptions {
  /** Registered provider route selecting the adapter instance. */
  provider: string;
  model: string;
  /** Adapter-owned reasoning effort selected for this exact model. */
  reasoningEffort?: ReasoningEffortId;
  /**
   * Ordered conversation messages, exactly as the provider sees them. A
   * loop-built request passes the derived history (dsh-agent-loop), whose
   * leading system-role message carries the system prompt; a hand-built
   * one-shot passes any list.
   */
  messages: Message[];
  /**
   * System prompt text for one-shot callers; adapters map it to the provider's
   * system slot ahead of `messages`. Loop-built requests leave it undefined.
   */
  system?: string;
  /** Tool schemas (adapters map to the provider's `tools` field). */
  tools?: ToolSchema[];
  temperature?: number;
  maxTokens?: number;
  /**
   * Stop sequences: generation halts as soon as the model produces any one of
   * these strings (adapters map to the provider's stop field, e.g. OpenAI
   * `stop`). The stop string itself is not included in the output.
   */
  stop?: string[];
  signal?: AbortSignal;
  /**
   * Session identity stamped by the loop for request routing. Replay uses it
   * to separate cursors; adapters may map it to model-hidden transport metadata.
   */
  sessionId?: Branded<'SessionId'>;
  /**
   * Provider-neutral classification for an auxiliary model call. Adapters may
   * map the purpose to model-hidden transport metadata or purpose-specific
   * generation policy. Ordinary conversation requests leave it unset.
   */
  purpose?: 'compaction' | 'session-title';
}
//#endregion
//#region ../../../vendor/cosmokit/lib/types/types.d.ts
declare function isArrayBufferLike(value: any): value is ArrayBufferLike;
declare function isArrayBufferSource(value: any): value is Binary.Source;
/** Binary source detection and base64/hex conversion helpers. */
declare namespace Binary {
  type Source<T extends ArrayBufferLike = ArrayBufferLike> = T | ArrayBufferView<T>;
  const is: typeof isArrayBufferLike;
  const isSource: typeof isArrayBufferSource;
  function fromSource<T extends ArrayBufferLike>(source: Source<T>): T;
  function toBase64(source: Source): string;
  function fromBase64(source: string): ArrayBuffer | Uint8Array<ArrayBuffer>;
  function toHex(source: Source): string;
  function fromHex(source: string): ArrayBuffer;
}
//#endregion
//#region ../../../vendor/cosmokit/lib/types/misc.d.ts
/** String/symbol keyed dictionary type. */
type Dict<T = any, K extends string | symbol = string> = { [key in K]: T };
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/@standard-schema+spec@1.1.0/node_modules/@standard-schema/spec/dist/index.d.ts
/** The Standard Typed interface. This is a base type extended by other specs. */
interface StandardTypedV1<Input = unknown, Output = Input> {
  /** The Standard properties. */
  readonly "~standard": StandardTypedV1.Props<Input, Output>;
}
declare namespace StandardTypedV1 {
  /** The Standard Typed properties interface. */
  interface Props<Input = unknown, Output = Input> {
    /** The version number of the standard. */
    readonly version: 1;
    /** The vendor name of the schema library. */
    readonly vendor: string;
    /** Inferred types associated with the schema. */
    readonly types?: Types<Input, Output> | undefined;
  }
  /** The Standard Typed types interface. */
  interface Types<Input = unknown, Output = Input> {
    /** The input type of the schema. */
    readonly input: Input;
    /** The output type of the schema. */
    readonly output: Output;
  }
  /** Infers the input type of a Standard Typed. */
  type InferInput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["input"];
  /** Infers the output type of a Standard Typed. */
  type InferOutput<Schema extends StandardTypedV1> = NonNullable<Schema["~standard"]["types"]>["output"];
}
/** The Standard Schema interface. */
interface StandardSchemaV1<Input = unknown, Output = Input> {
  /** The Standard Schema properties. */
  readonly "~standard": StandardSchemaV1.Props<Input, Output>;
}
declare namespace StandardSchemaV1 {
  /** The Standard Schema properties interface. */
  interface Props<Input = unknown, Output = Input> extends StandardTypedV1.Props<Input, Output> {
    /** Validates unknown input values. */
    readonly validate: (value: unknown, options?: StandardSchemaV1.Options | undefined) => Result<Output> | Promise<Result<Output>>;
  }
  /** The result interface of the validate function. */
  type Result<Output> = SuccessResult<Output> | FailureResult;
  /** The result interface if validation succeeds. */
  interface SuccessResult<Output> {
    /** The typed output value. */
    readonly value: Output;
    /** A falsy value for `issues` indicates success. */
    readonly issues?: undefined;
  }
  interface Options {
    /** Explicit support for additional vendor-specific parameters, if needed. */
    readonly libraryOptions?: Record<string, unknown> | undefined;
  }
  /** The result interface if validation fails. */
  interface FailureResult {
    /** The issues of failed validation. */
    readonly issues: ReadonlyArray<Issue>;
  }
  /** The issue interface of the failure output. */
  interface Issue {
    /** The error message of the issue. */
    readonly message: string;
    /** The path of the issue, if any. */
    readonly path?: ReadonlyArray<PropertyKey | PathSegment> | undefined;
  }
  /** The path segment interface of the issue. */
  interface PathSegment {
    /** The key representing a path segment. */
    readonly key: PropertyKey;
  }
  /** The Standard types interface. */
  interface Types<Input = unknown, Output = Input> extends StandardTypedV1.Types<Input, Output> {}
  /** Infers the input type of a Standard. */
  type InferInput<Schema extends StandardTypedV1> = StandardTypedV1.InferInput<Schema>;
  /** Infers the output type of a Standard. */
  type InferOutput<Schema extends StandardTypedV1> = StandardTypedV1.InferOutput<Schema>;
}
/** The Standard JSON Schema interface. */
//#endregion
//#region ../../../vendor/schemastery/lib/types/index.d.ts
declare const kSchema: unique symbol;
declare global {
  namespace Schemastery {
    /** Convert primitive constructors, constants, and existing schemas into a schema type. */
    type From<X> = X extends string | number | boolean ? Schema<X> : X extends Schema ? X : X extends typeof String ? Schema<string> : X extends typeof Number ? Schema<number> : X extends typeof Boolean ? Schema<boolean> : X extends typeof Function ? Schema<Function, (...args: any[]) => any> : X extends Constructor<infer S> ? Schema<S> : never;
    type TypeS1<X> = X extends Schema<infer S, unknown> ? S : never;
    type Inverse<X> = X extends Schema<any, infer Y> ? (arg: Y) => void : never;
    /** Input type accepted by a schema-like value. */
    type TypeS<X> = TypeS1<From<X>>;
    /** Output type returned by a schema-like value after validation. */
    type TypeT<X> = ReturnType<From<X>>;
    /** Resolver callback used by custom schema types registered with `Schema.extend()`. */
    type Resolve = (data: any, schema: Schema, options: Options, strict?: boolean) => [any, any?];
    /** Input type accepted by one schema in an intersection. */
    type IntersectS<X> = From<X> extends Schema<infer S, unknown> ? S : never;
    /** Output type returned by one schema in an intersection. */
    type IntersectT<X> = Inverse<From<X>> extends ((arg: infer T) => void) ? T : never;
    type TupleS<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeS<L>?, ...TupleS<R>] : any[];
    type TupleT<X extends readonly any[]> = X extends readonly [infer L, ...infer R] ? [TypeT<L>?, ...TupleT<R>] : any[];
    type ObjectS<X extends Dict> = { [K in keyof X]?: TypeS<X[K]> | null } & Dict;
    type ObjectT<X extends Dict> = { [K in keyof X]: TypeT<X[K]> } & Dict;
    type Constructor<T = any> = new (...args: any[]) => T;
    /** Static constructor and factory methods exposed by the default `Schema` export. */
    interface Static {
      <T = any>(options: Partial<Schema<T>>): Schema<T>;
      new <T = any>(options: Partial<Schema<T>>): Schema<T>;
      prototype: Schema;
      /** Validate a value against a schema node and return `[output, adaptedInput?]`. */
      resolve: Resolve;
      /** Infer a schema from a primitive value, constructor, or existing schema. */
      from<X = any>(source?: X): From<X>;
      /** Register a resolver for a custom schema `type`. */
      extend(type: string, resolve: Resolve): void;
      /** Accept any value without validation. */
      any<T = any>(): Schema<T>;
      /** Accept only nullable input. */
      never(): Schema<never>;
      /** Accept exactly one constant value. */
      const<const T>(value: T): Schema<T>;
      /** Accept strings, with optional metadata constraints added by instance methods. */
      string(): Schema<string>;
      /** Accept numbers, with optional range and step constraints. */
      number(): Schema<number>;
      /** Accept non-negative integer numbers. */
      natural(): Schema<number>;
      /** Accept a number between 0 and 1 and mark it as a slider. */
      percent(): Schema<number>;
      /** Accept booleans. */
      boolean(): Schema<boolean>;
      /** Accept `Date` instances or parse datetime strings into `Date` objects. */
      date(): Schema<string | Date, Date>;
      /** Accept `RegExp` instances or parse strings into regular expressions. */
      regExp(flag?: string): Schema<string | RegExp, RegExp>;
      /** Accept binary sources and normalize them to `ArrayBufferLike`. */
      arrayBuffer(): Schema<Binary.Source, ArrayBufferLike>;
      arrayBuffer(encoding: 'hex' | 'base64'): Schema<Binary.Source | string, ArrayBufferLike>;
      /** Accept a numeric bitset or string keys and normalize to a number. */
      bitset<K extends string>(bits: Partial<Record<K, number>>): Schema<number | readonly K[], number>;
      /** Accept functions. */
      function(): Schema<Function, (...args: any[]) => any>;
      /** Accept instances of a constructor or objects whose constructor name matches. */
      is(constructor: string): Schema;
      is<T>(constructor: Constructor<T>): Schema<T>;
      /** Accept arrays whose elements match `inner`. */
      array<X>(inner: X): Schema<TypeS<X>[], TypeT<X>[]>;
      /** Accept plain objects with values matching `inner` and optional key schema. */
      dict<X, Y extends Schema<any, string> = Schema<string>>(inner: X, sKey?: Y): Schema<Dict<TypeS<X>, TypeS<Y>>, Dict<TypeT<X>, TypeT<Y>>>;
      /** Accept tuple arrays where each index matches the corresponding schema. */
      tuple<const X extends readonly any[]>(list: X): Schema<TupleS<X>, TupleT<X>>;
      /** Accept plain objects whose declared properties match the schema dictionary. */
      object<X extends Dict>(dict: X): Schema<ObjectS<X>, ObjectT<X>>;
      /** Accept values matching at least one schema in `list`. */
      union<const X>(list: readonly X[]): Schema<TypeS<X>, TypeT<X>>;
      /** Accept values matching every schema in `list`, merging object outputs. */
      intersect<const X>(list: readonly X[]): Schema<IntersectS<X>, IntersectT<X>>;
      /** Validate with `inner`, then convert the result with `callback`. */
      transform<X, T>(inner: X, callback: (value: TypeS<X>, options: Schemastery.Options) => T, preserve?: boolean): Schema<TypeS<X>, T>;
      /** Defer construction of a recursive schema until validation or serialization. */
      lazy<X extends Schema>(callback: () => X): X;
      ValidationError: typeof ValidationError;
    }
    /** Runtime validation options shared by all schema calls. */
    interface Options {
      /** Remove invalid object properties instead of throwing when possible. */
      autofix?: boolean;
      /** Skip validation for selected values and schema nodes. */
      ignore?(data: any, schema: Schema): boolean;
      /** Path used to format nested validation errors. */
      path?: (keyof any)[];
    }
    /** UI and validation metadata attached by schema builder methods. */
    interface Meta<T = any> {
      default?: T extends {} ? Partial<T> : T;
      required?: boolean;
      disabled?: boolean;
      collapse?: boolean;
      badges?: {
        text: string;
        type: string;
      }[];
      hidden?: boolean;
      loose?: boolean;
      role?: string;
      extra?: any;
      link?: string;
      description?: string | Dict<string>;
      comment?: string;
      pattern?: {
        source: string;
        flags?: string;
      };
      max?: number;
      min?: number;
      step?: number;
    }
  }
  /** Callable schema instance that validates input and returns normalized output. */
  interface Schemastery<S = any, T = S> {
    (data?: S | null, options?: Schemastery.Options): T;
    new (data?: S | null, options?: Schemastery.Options): T;
    [kSchema]: true;
    uid: number;
    meta: Schemastery.Meta<T>;
    type: string;
    sKey?: Schema;
    inner?: Schema;
    list?: Schema[];
    dict?: Dict<Schema>;
    bits?: Dict<number>;
    callback?: Function;
    constructor?: string | Function;
    builder?: Function;
    value?: T;
    refs?: Dict<Schema>;
    preserve?: boolean;
    '~standard': StandardSchemaV1.Props;
    /** Format this schema as a compact TypeScript-like type string. */
    toString(inline?: boolean): string;
    /** Serialize this schema, preserving shared and recursive references. */
    toJSON(): Schema<S, T>;
    /** Mark nullable input as invalid unless a default supplies a fallback. */
    required(value?: boolean): Schema<S, T>;
    /** Hide this schema node from UI renderers. */
    hidden(value?: boolean): Schema<S, T>;
    /** Return the default value instead of throwing when validation fails. */
    loose(value?: boolean): Schema<S, T>;
    /** Attach a renderer role and optional role-specific metadata. */
    role(text: string, extra?: any): Schema<S, T>;
    /** Attach an external documentation link. */
    link(link: string): Schema<S, T>;
    /** Set the fallback value used for nullable input. */
    default(value: T): Schema<S, T>;
    /** Attach an auxiliary comment for documentation or form UIs. */
    comment(text: string): Schema<S, T>;
    /** Attach a localized or plain description for documentation or form UIs. */
    description(text: string): Schema<S, T>;
    /** Mark this schema node as disabled for form UIs. */
    disabled(value?: boolean): Schema<S, T>;
    /** Request collapsed rendering for nested form UIs. */
    collapse(value?: boolean): Schema<S, T>;
    /** Add a deprecated badge to this schema node. */
    deprecated(): Schema<S, T>;
    /** Add an experimental badge to this schema node. */
    experimental(): Schema<S, T>;
    /** Require strings to match a regular expression. */
    pattern(regexp: RegExp): Schema<S, T>;
    /** Set an inclusive maximum for numbers or collection lengths. */
    max(value: number): Schema<S, T>;
    /** Set an inclusive minimum for numbers or collection lengths. */
    min(value: number): Schema<S, T>;
    /** Set the numeric increment constraint. */
    step(value: number): Schema<S, T>;
    /** Add or replace an object property schema. */
    set(key: string, value: Schema): Schema<S, T>;
    /** Append a tuple, union, or intersection member schema. */
    push(value: Schema): Schema<S, T>;
    /** Remove values equal to schema defaults from normalized output. */
    simplify(value?: any): any;
    /** Return a schema clone with descriptions merged from locale messages. */
    i18n(messages: Dict): Schema<S, T>;
    /** Attach arbitrary metadata consumed by form renderers and downstream tools. */
    extra<K extends keyof Schemastery.Meta>(key: K, value: Schemastery.Meta[K]): Schema<S, T>;
  }
}
declare class ValidationError extends TypeError {
  options: Schemastery.Options;
  name: string;
  constructor(message: string, options: Schemastery.Options);
  static is(error: any): error is ValidationError;
}
type Schema<S = any, T = S> = Schemastery<S, T>;
declare const Schema: Schemastery.Static;
//#endregion
//#region ../../llm/llm/lib/types/retry-policy.d.ts
/** Fully resolved backoff shared by both retry modes. */
interface ResolvedRetryBackoff {
  readonly initialDelayMs: number;
  readonly maxDelayMs: number;
  readonly jitterRatio: number;
}
/** Fully resolved bounded transient retry policy. */
interface ResolvedNormalRetryPolicy extends ResolvedRetryBackoff {
  readonly mode: 'normal';
  readonly maxRetries: number;
  readonly retryableCodes: readonly string[];
}
/** Fully resolved unbounded retry policy. */
interface ResolvedAlwaysRetryPolicy extends ResolvedRetryBackoff {
  readonly mode: 'always';
}
/** Immutable provider policy captured when its adapter route is registered. */
type ResolvedRetryPolicy = ResolvedNormalRetryPolicy | ResolvedAlwaysRetryPolicy;
//#endregion
//#region ../../llm/llm/lib/types/call-config.d.ts
/**
 * Provider, model, reasoning effort, and sampling scalars of one conversation's
 * requests. Every field maps 1:1 onto the same-named `GenerateOptions` field;
 * the loop builds requests from the logged header rather than accepting these
 * per call.
 */
interface LlmCallConfig {
  provider: string;
  model: string;
  reasoningEffort?: ReasoningEffortId;
  temperature?: number;
  maxTokens?: number;
  stop?: string[];
}
/**
 * Effective config fields supplied by exact-model adapter resolution rather
 * than by the caller's request proposal.
 */
interface LlmCallConfigAdapterDefaults {
  reasoningEffort?: true;
  maxTokens?: true;
}
//#endregion
//#region ../../llm/llm/lib/types/assistant-stream.d.ts
/** Lossless compact records embedded in durable Assistant attempt events. */
type AssistantStreamRecord = {
  readonly type: 'text-chunks';
  readonly time0: number;
  readonly index: number;
  readonly dt: readonly number[];
  readonly texts: readonly string[];
} | {
  readonly type: 'reasoning-chunks';
  readonly time0: number;
  readonly index: number;
  readonly dt: readonly number[];
  readonly texts: readonly string[];
} | {
  readonly type: 'tool-call-chunks';
  readonly time0: number;
  readonly index: number;
  readonly dt: readonly number[];
  readonly id: ToolCallId;
  readonly name?: string;
  readonly args: readonly string[];
} | {
  readonly type: 'chunk';
  readonly time: number;
  readonly chunk: StreamChunk;
};
//#endregion
//#region ../../llm/llm/lib/types/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Context {
    llm: LlmRuntime;
  }
  interface Events {
    /**
     * Waterfall around every streaming model call (retry, replay, routing).
     * Bound to the {@link LlmRuntime}; call `next()` to reach the resolved
     * adapter's stream, or yield your own chunks to short-circuit.
     * @param options - the full request. A LOOP-built request carries the
     *   process-local {@link markAgentLoopRequest} identity and arrives deep-frozen
     *   (mutation throws): its content is a pure function of the session log (the
     *   reconstructability Agent Note), so listeners read it, never rewrite it.
     *   Hand-built calls do not carry that marker; their messages already obey
     *   the immutable creation contract.
     * @mode waterfall
     */
    'llm/stream'(this: LlmRuntime, options: GenerateOptions, next: () => AsyncIterable<StreamChunk>): AsyncIterable<StreamChunk>;
  }
}
/** Structured provider facts and cause accepted by {@link LlmError}. */
/** One model call whose config and adapter registration were resolved together. */
interface PreparedLlmCall {
  /** Detached, deep-frozen config with any adapter-owned default materialized. */
  readonly config: LlmCallConfig;
  /** Immutable retry policy captured with the adapter registration. */
  readonly retryPolicy: ResolvedRetryPolicy;
  /** Detached context metadata resolved with the registration-bound call. */
  readonly context?: LlmModelContext;
  /** Exact model modalities captured with the adapter dispatch generation. */
  readonly inputModalities?: readonly ModelModality[];
  /** Exact model system prompt update mode captured with the adapter dispatch generation. */
  readonly systemPromptUpdate?: SystemPromptUpdate;
  /** Config fields materialized by the captured adapter rather than proposed by the caller. */
  readonly adapterDefaults: LlmCallConfigAdapterDefaults;
  /**
   * Dispatch this call once through the registration captured during
   * preparation. The request's call-config fields must match {@link config};
   * reuse or mismatch fails with `INVALID_PREPARED_CALL`.
   * @param options - fully assembled request carrying the prepared config.
   * @returns the chunk stream, including the `llm/stream` waterfall.
   */
  stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
/** One adapter-owned model-resolution generation bound to its eventual stream call. */
interface PreparedAdapterCall {
  /** Exact model metadata from the same adapter generation as {@link stream}. */
  readonly model: LlmResolvedModelInfo;
  /** Dispatch through that generation without re-reading dynamic connection facts. */
  stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
/**
 * Provider-wire adapter for the harness message and stream vocabulary. Register implementations
 * with `ctx.llm.registerAdapter(providers, adapter)`. Every provider HTTP request must include
 * `attributionHeaders()`; prove the headers are added in the wire request or library header hook. The direct-fetch
 * DeepSeek and library-backed pi-ai adapters meet this contract through different internals.
 */
declare abstract class LlmAdapter {
  /**
   * Describe one provider route owned by this adapter.
   * @param provider - a route passed to `registerAdapter()` for this instance.
   * @returns detached display metadata whose id must equal `provider`.
   */
  providerInfo(provider: string): LlmProviderInfo;
  /**
   * Return the provider-owned retry policy captured with this route.
   * @param _provider - a route passed to `registerAdapter()` for this instance.
   * @returns a resolved policy, or `undefined` to use the normal defaults.
   */
  providerRetryPolicy(_provider: string): ResolvedRetryPolicy | undefined;
  /**
   * Resolve provider-side request-image pricing for one exact model route.
   * The default declares none, so consumers fall back to their own neutral
   * estimate. Implementations must answer synchronously without I/O; the
   * token meter resolves this per measurement.
   * @param _provider - a route passed to `registerAdapter()` for this instance.
   * @param _model - exact model id passed to {@link GenerateOptions.model}.
   * @returns route-owned image pricing, or `undefined` when the route declares none.
   */
  imageRequestPricing(_provider: string, _model: string): LlmImageRequestPricing | undefined;
  /**
   * List models this adapter can currently advertise for one owned provider.
   * The result is advisory: an adapter may accept unlisted model ids, and
   * consumers must not turn absence into request rejection.
   * @param _provider - one provider route owned by this adapter.
   * @returns discoverable models in adapter-preferred order.
   */
  listModels(_provider: string): Promise<readonly LlmModelInfo[]>;
  /**
   * Resolve all metadata available for one exact model. This query is
   * independent of the advisory catalog and does not validate request routing.
   * @param provider - one provider route owned by this adapter.
   * @param model - exact model id passed to {@link GenerateOptions.model}.
   * @param _signal - cancellation for this exact-model lookup; asynchronous
   *   implementations must settle promptly after it aborts.
   * @returns provider/model identity plus any context, call-default, and reasoning metadata.
   */
  resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
  /**
   * Bind exact model metadata and the eventual request dispatch to one adapter generation.
   * Dynamic adapters override this so settings changes between preparation and
   * dispatch cannot combine one generation's capabilities with another's endpoint.
   * @param provider - registered provider route.
   * @param model - exact model id.
   * @param signal - cancellation for model resolution.
   * @returns model metadata and a one-generation stream entry point.
   */
  prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<PreparedAdapterCall>;
  /**
   * Stream one model call as raw chunks. The only required method.
   * @param options - the fully-assembled request; implementations must honor `options.signal`.
   * @returns the chunk stream, obeying the adapter contract documented on `StreamChunk`.
   */
  abstract stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
/**
 * What {@link LlmRuntime.registerAdapter} returns: the disposer, plus an
 * atomic route replacement for the same adapter instance.
 */
interface AdapterRegistrationHandle {
  /** Release every route this registration currently holds. */
  (): void;
  /**
   * Replace this registration's routes with `providers`, keeping the same
   * adapter instance. The candidate set is validated in full first — a
   * conflict with another adapter, an invalid name, or bad provider metadata
   * throws and leaves the current routes untouched — and the swap itself is
   * one synchronous section, so no request can observe a gap. An empty array
   * is legal here (a settings section that emptied holds zero routes while
   * staying registered), unlike an empty initial registration.
   *
   * Throws `LlmError` with code `REGISTRATION_DISPOSED` once the registration
   * has been released: its routes are gone and its disposer has already run,
   * so anything registered afterwards would have no owner left to release it.
   * @param providers - the complete next route set for this registration.
   */
  replace(providers: string[]): void;
}
/**
 * A live configurable-provider registration, disposable and atomically
 * replaceable — the directory counterpart of {@link AdapterRegistrationHandle}.
 */
interface DirectoryRegistrationHandle {
  /** Withdraw every entry this registration currently holds. */
  (): void;
  /**
   * Replace this registration's entries with `entries`. The candidate set is
   * validated in full first — an entry another registration already declares,
   * a duplicate within the set, or invalid metadata throws and leaves the
   * current entries untouched — and the swap is one synchronous section, so no
   * reader observes a gap. An empty array is legal here, unlike an empty
   * initial registration.
   *
   * Throws `LlmError` with code `REGISTRATION_DISPOSED` once the registration
   * has been disposed.
   */
  replace(entries: readonly LlmConfigurableProvider[]): void;
}
/**
 * The abstract `llm` service: an adapter registry plus a streaming model-call
 * API, interceptable via the `llm/stream` waterfall.
 */
declare class LlmRuntime extends TypertRemoteService {
  private adapters;
  private directory;
  private discoveries;
  constructor(ctx: Context);
  /** Notify topology observers without letting one broken listener veto the commit. */
  private emitAdaptersUpdated;
  /** Contained-listener diagnostic shared by the sync and async failure paths. */
  private warnAdaptersListenerFailure;
  /**
   * Register an adapter for the given provider routes. Throws `LlmError` with code
   * `DUPLICATE_ADAPTER` if any provider already has an adapter (all-or-nothing).
   * Disposed with the fiber.
   * @param providers - every provider route this adapter should serve.
   * @param adapter - the adapter that streams calls for those providers.
   * @returns the disposer, carrying {@link AdapterRegistrationHandle.replace}.
   */
  registerAdapter(providers: string[], adapter: LlmAdapter): AdapterRegistrationHandle;
  /**
   * Validate one candidate route set for `adapter`, treating routes this
   * registration already holds as available. Nothing is mutated: a rejected
   * candidate leaves the registry exactly as it was.
   */
  private prepareRoutes;
  /**
   * Swap this registration's routes for the prepared ones in one synchronous
   * section, so no observer can see the registry between the release and the
   * re-registration. The route set's one mutation point is also where
   * `llm/adapters-updated` is published, so a `replace` announces itself
   * exactly like a first registration.
   */
  private commitRoutes;
  /**
   * Describe provider routes with a registered adapter.
   * @returns detached provider metadata in registration order.
   */
  listProviders(): LlmProviderInfo[];
  /**
   * Declare provider routes an adapter plugin can activate through
   * configuration. Registration is all-or-nothing: an empty list, invalid
   * entry, or a provider already declared by any registration throws
   * `LlmError` without registering the rest. Disposed with the fiber.
   * @param entries - every configurable provider this plugin owns.
   * @returns a handle that withdraws all of them, and can atomically replace them.
   */
  registerConfigurableProviders(entries: readonly LlmConfigurableProvider[]): DirectoryRegistrationHandle;
  /**
   * List every declared configurable provider, registered or dormant.
   * @returns detached directory entries in declaration order.
   */
  listConfigurableProviders(): LlmConfigurableProvider[];
  /**
   * Offer to interrogate provider endpoints on behalf of the settings
   * namespace this plugin owns. The namespace is the key because that is what
   * a configuration surface already holds from the configurable-provider
   * directory, and because a provider being *added* has no route to name yet.
   * Disposed with the fiber.
   * @param settingsNs - the namespace whose profiles this discovery serves.
   * @param discover - interrogates one endpoint and must honor the supplied signal.
   * @returns the disposer that withdraws the offer.
   */
  registerModelDiscovery(settingsNs: string, discover: (request: LlmModelDiscoveryRequest, signal?: AbortSignal) => Promise<readonly LlmDiscoveredModel[]>): () => void;
  /**
   * Interrogate one provider endpoint for the models it advertises. The
   * request describes a draft, not a stored route, so nothing here reads or
   * writes settings or credentials — the caller owns both, and the reply is
   * candidate metadata a surface may offer for adoption.
   * @param settingsNs - namespace whose registered discovery serves this draft.
   * @param request - the endpoint, protocol, and one-shot credential to use.
   * @param signal - caller cancellation.
   * @returns the advertised models, deduplicated in endpoint order.
   */
  discoverModels(settingsNs: string, request: LlmModelDiscoveryRequest, signal?: AbortSignal): Promise<LlmDiscoveredModel[]>;
  /**
   * Remote adapter for one draft provider interrogation.
   * @param settingsNs - namespace whose registered discovery serves this draft.
   * @param request - endpoint, protocol, and one-shot credential to use.
   * @param signal - caller cancellation supplied by the Remote carrier.
   * @returns advertised models in endpoint order.
   * @throws RemoteError with `llm/model-discovery-rejected` when discovery refuses or fails.
   */
  remoteDiscoverModels(settingsNs: string, request: LlmModelDiscoveryRequest, signal: AbortSignal): Promise<LlmDiscoveredModel[]>;
  /**
   * Resolve the retry policy captured when one provider route was registered.
   * @param provider - registered provider route to inspect.
   * @returns the provider-owned policy, with normal defaults already resolved.
   */
  providerRetryPolicy(provider: string): ResolvedRetryPolicy;
  /**
   * Resolve provider-side request-image pricing for one exact route, or
   * `undefined` when the provider is unregistered or declares none. Unknown
   * providers degrade to `undefined` rather than throwing because callers
   * price durable history whose route may no longer be mounted.
   * @param provider - provider route named by a request header.
   * @param model - exact model id named by the same header.
   * @returns the owning adapter's image pricing for the route, when declared.
   */
  imageRequestPricing(provider: string, model: string): LlmImageRequestPricing | undefined;
  /**
   * Resolve the exact text one durable file occurrence contributes to every
   * provider request in the current execution environment.
   * @param ref - durable verbatim file reference from model history.
   * @returns the same deterministic handle text used at adapter dispatch.
   */
  fileRequestText(ref: FileAttachmentRef): string;
  /** Detach typed adapter-owned modality metadata. */
  private detachedModalities;
  /**
   * Discover models advertised by one registered provider. Catalog membership
   * is advisory and never changes routing or request validation.
   * @param provider - registered provider route to inspect.
   * @returns detached model metadata in adapter-preferred order.
   */
  listModels(provider: string): Promise<LlmModelInfo[]>;
  /**
   * Resolve and validate all metadata from the adapter that owns one exact
   * route. The result is detached from adapter-owned objects; catalog
   * membership remains advisory and does not control request routing.
   * @param provider - registered provider route to inspect.
   * @param model - exact model id passed to the adapter.
   * @param signal - optional cancellation for adapter-owned asynchronous lookup.
   * @returns exact model identity plus available context and reasoning metadata.
   */
  resolveModelInfo(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
  private resolveModelInfoFor;
  /** Validate and detach one adapter-returned exact model result. */
  private normalizeModelInfo;
  /**
   * Validate a conversation call config against its exact model capability and
   * materialize adapter-configured defaults. Unsupported explicit efforts
   * reject before provider I/O; no clamping or aliasing is performed. This
   * standalone query does not bind a later dispatch; use {@link prepareCall}
   * when logging and streaming must share one adapter registration.
   * @param config - provider/model route and optional request controls.
   * @param signal - optional cancellation for adapter-owned capability lookup.
   * @returns a detached config only when a default must be materialized.
   */
  resolveCallConfig(config: LlmCallConfig, signal?: AbortSignal): Promise<LlmCallConfig>;
  private resolveCallFor;
  /** Validate request controls against one already-bound exact model result. */
  private resolveCallWithInfo;
  /**
   * Resolve one call under its current adapter registration. The returned
   * one-shot handle keeps that registration across header logging and dispatch,
   * so HMR cannot combine one adapter's capability result with another adapter.
   * @param config - provider/model route and optional request controls.
   * @param signal - optional cancellation for adapter-owned capability lookup.
   * @returns a prepared config and its registration-bound stream entry point.
   */
  prepareCall(config: LlmCallConfig, signal?: AbortSignal): Promise<PreparedLlmCall>;
  private registration;
  /** Remove replay state whose historical route is owned by another adapter. */
  private forAdapter;
  /**
   * Resolve the current execution-world read path of one durable file
   * reference through the mounted attachment and filesystem providers.
   */
  private fileReadPath;
  /**
   * Final adapter boundary. Adapter selection, dispatch, iterator construction,
   * and iteration failures become one terminal failure chunk. Middleware and
   * downstream consumer failures remain thrown plugin or consumer errors.
   */
  private adapterStream;
  /**
   * Stream one model call as raw chunks (token-level deltas). Replay state is
   * retained only when the same adapter instance owns its historical provider
   * and the target provider. Final adapter selection remains fixed through
   * asynchronous exact-model resolution and dispatch. Adapter selection,
   * dispatch, and iteration failures become terminal `error` or `aborted`
   * finish chunks; middleware, nested-call, cleanup, and consumer failures
   * remain thrown.
   * @param options - the full request; `options.provider` selects the adapter.
   * @returns the chunk stream, possibly wrapped by `llm/stream` listeners.
   */
  stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
  private streamWithRegistration;
}
//#endregion
//#region ../../util/values/lib/types/index.d.ts
/** Duplicate-install-safe JSON and immutable-value helpers. @module @deepseek-ai/dsh-util-values */
/** A value that round-trips through JSON without loss. */
type JsonValue$1 = null | boolean | number | string | JsonValue$1[] | {
  [key: string]: JsonValue$1;
};
//#endregion
//#region ../../core/session/lib/types/types.d.ts
/** Identifies one session in the store (and its persistence artifacts). */
type SessionId = Branded<'SessionId'>;
/**
 * Brand a string as a {@link SessionId}.
 * @param id - the raw session id string.
 * @returns the same string with the session-id brand.
 */
declare function SessionId(id: string): SessionId;
/** Sequence number of one existing event in a Session log. */
type SessionSeq = BrandedNumber<'SessionSeq'>;
/**
 * Admit a numeric value as an existing Session event position.
 * @param value - non-negative safe integer admitted by the owning log operation.
 * @returns the same number with the Session-sequence brand.
 */
declare function SessionSeq(value: number): SessionSeq;
/** Inclusive Session event watermark, or `-1` before any event exists. */
type SessionSeqCursor = SessionSeq | -1;
/** One existing Session event position, or explicit absence. */
type OptionalSessionSeq = SessionSeq | null;
/** Why an active agent driver was cancelled. */
type AgentCancelCause = {
  readonly kind: 'user';
} | {
  readonly kind: 'parent';
} | {
  readonly kind: 'hook';
  readonly reason: string;
} | {
  readonly kind: 'disposed';
};
/** Durable cancellation cause, including imports whose original coarse record carried no cause. */
type TurnEndCancelCause = AgentCancelCause | {
  readonly kind: 'legacy';
};
/**
 * Why a turn ended. Merge-extensible sum type.
 */
interface TurnEndReasonMap {
  completed: {
    kind: 'completed';
  };
  /** A cancellation request interrupted the live turn. */
  aborted: {
    kind: 'aborted';
    reason: TurnEndCancelCause;
  };
  blocked: {
    kind: 'blocked';
  };
  /**
   * The turn failed. `error` is always a structured failure: the `LlmError`
   * facts verbatim, or `{ message: errorChain(error), code: 'UNKNOWN' }`
   * flattened from any other error.
   */
  error: {
    kind: 'error';
    error: LlmFailure;
  };
  /** At least one step reached its output-token ceiling, even if a plugin continued the turn. */
  'max-tokens': {
    kind: 'max-tokens';
  };
  /**
   * A crash-orphaned turn was closed after the fact: agent-loop resume appends
   * this closer for a stored log whose last turn never ended, and session-query
   * synthesizes it on cold reads. The loop never emits this marker live, and
   * the events recorded before the crash remain intact.
   */
  interrupted: {
    kind: 'interrupted';
  };
}
/** The union over {@link TurnEndReasonMap} — why a turn ended; plugins extend it by merging variants into the map. */
type TurnEndReason = TurnEndReasonMap[keyof TurnEndReasonMap];
/**
 * Logged request state outside derived history: call config and tools. The
 * system prompt is derived history — surface node 0, a `system/message` event.
 * The latest full `request/header` snapshot reconstructs the header; canonical
 * empty optional fields are absent.
 */
interface EpochHeader {
  /** The conversation's call configuration (provider, model, reasoning effort, and sampling scalars). */
  config: LlmCallConfig;
  /** Effective config fields materialized from the exact adapter rather than proposed by a caller. */
  adapterDefaults?: LlmCallConfigAdapterDefaults;
  /** Assembled tool schemas; absent for a tool-less request. */
  tools?: ToolSchema[];
}
/** Registration-bound metadata for one resolved model route. */
interface RequestContext {
  /** Registered provider route the metadata belongs to. */
  provider: string;
  /** Provider-owned model id the metadata belongs to. */
  model: string;
  /** Maximum combined request and response context in tokens, when advertised. */
  contextWindow?: number;
  /** `'in-history'` when the route reads the latest `system` message at any position as the effective system prompt. */
  systemPromptUpdate?: SystemPromptUpdate;
}
/**
 * Why a `request/header` snapshot was appended: `'initial'` — the log's first
 * header (a new conversation); `'resume'` — a loop instance's first request
 * over a log that already has header events (process restart, fork seed);
 * `'change'` — a later request used a different header, with `startsSeries`
 * preserving a coincident series boundary; `'series'` — an unchanged header
 * began an explicitly distinct message series or followed a surface replacement.
 */
type RequestHeaderReason = 'initial' | 'resume' | 'change' | 'series';
/**
 * The merge-extensible, append-only source of truth for an agent interaction.
 * Message history is derived from this log. Every event is lossless JSON and
 * sequence numbers stay contiguous. Assistant attempt events embed their exact
 * compact raw streams so persistence stores one durable settlement per attempt.
 */
interface SessionEventMap {
  /**
   * Opens turn `turn` before the loop claims queued input or runs pre-step.
   * Rejection, empty input, cancellation, or failure may close it with no
   * step; otherwise the following identified `user/message` event or batch
   * records the messages entering the step.
   */
  'turn/start': {
    turn: number;
  };
  /**
   * Closes turn `turn` with the {@link TurnEndReason} that ended it. A turn
   * with no entered step has no `step/start` or `step/end`. The loop does not await a
   * flush at turn boundaries: `dsh-session-checkpoint-policy` owns the
   * per-request durability checkpoint, and consumers that read storage after
   * `whenIdle()` flush themselves. Success commits the turn; rejection is
   * reported live and does not prevent later work.
   */
  'turn/end': {
    turn: number;
    reason: TurnEndReason;
  };
  /** Opens step `step` of turn `turn` — one model call plus the tool executions it requested. */
  'step/start': {
    turn: number;
    step: number;
  };
  /** Closes step `step` of turn `turn`. */
  'step/end': {
    turn: number;
    step: number;
  };
  /**
   * A user-role message on the model-visible surface: a direct human prompt
   * (the queued message claimed for this turn), a synthetic `agent.inject()`
   * context (file-change notices, subdir AGENTS.md, skill content, cron
   * notifications, …), or an entered goal continuation round. All three
   * project their `content` verbatim; `source` tells them apart.
   */
  'user/message': UserMessage;
  /**
   * The rendered system prompt on the model-visible surface. The loop appends
   * the first one as surface node 0 before the step's first `user/message`.
   * A prepared in-history route can append nonempty changes in a continuing
   * series. An incapable route or new series normalizes text to the first system
   * node. Normalization empties nonempty later nodes, then rewrites the head if
   * needed, through logged per-node replacements. An empty rendering always
   * clears all active system nodes, leaving no older instructions model-visible.
   * Empty later nodes are dormant and project to no message; an empty head with
   * no active later node records "no system prompt". Restored nonempty text follows
   * the same route and series rule; empty nodes never restore older text.
   */
  'system/message': {
    turn: number;
    step: number;
    message: SystemMessage;
  };
  /**
   * Assembled assistant message for one step (derived history uses this).
   * Carries the step's `usage` when the adapter reported token accounting, so
   * the model output and its accounting travel together (there is no separate
   * usage record). `usage` is absent when the adapter reported none. A turn
   * cancelled mid-stream finalizes its delivered text/reasoning prefix as this
   * event with `interrupted: true`; undispatched tool calls are absent. The
   * marker distinguishes that prefix without re-deriving interruption from turn
   * boundaries. An aborted turn with no such event streamed no visible content.
   */
  'assistant/message': {
    turn: number;
    step: number;
    message: AssistantMessage; /** Exact timed model stream, compacted without joining delta boundaries. */
    stream: AssistantStreamRecord[];
    usage?: TokenUsage;
    interrupted?: true;
  };
  /**
   * One model attempt that committed no surface message. The embedded stream
   * preserves a failed, retried, cancelled, or stream-error attempt that
   * reached settlement without fabricating model-visible history.
   */
  'assistant/attempt': {
    turn: number;
    step: number;
    stream: AssistantStreamRecord[];
  };
  /**
   * The model requested one tool invocation: `name` with the raw `arguments`
   * JSON string exactly as the model produced it (unparsed). `callId` pairs the
   * call with its `tool/result`.
   */
  'tool/call': {
    turn: number;
    step: number;
    callId: ToolCallId;
    name: string;
    arguments: string;
  };
  /**
   * A completed tool call's model-facing result, optional internal failure
   * identity, and optional tool-private `meta` presentation payload. `meta` is
   * opaque to the core (the producing tool owns its shape and reads it back in
   * `presentResult`) but MUST be JSON-serializable: `Session.append`
   * runtime-validates all event data with `isJsonValue`, so a non-serializable
   * `meta` is rejected at the source, and the durable log reproduces the
   * identical card on replay. Absent
   * unless the tool attaches one (e.g. `dsh-tool-fs` carries its result-time
   * contextual diff here).
   */
  'tool/result': {
    turn: number;
    step: number;
    message: ToolResultMessage; /** Optional failure identity; allowed only when the tool-result block has `isError: true`. */
    error?: {
      name: string;
      code: string;
    };
    meta?: JsonValue$1;
  };
  /**
   * Full header for the next request, appended inside its step before dispatch.
   * It is log-only; the latest snapshot reconstructs the request header.
   */
  'request/header': {
    header: EpochHeader;
    reason: RequestHeaderReason; /** A changed header also begins a distinct model-message series. */
    startsSeries?: true;
  };
  /**
   * Route metadata for the next request, logged only when the route, capacity,
   * or system prompt update mode changes. It does not participate in request
   * reconstruction or header equality. Prompt admission uses the bound prepared
   * call's capability, not this snapshot from an earlier request.
   */
  'request/context': RequestContext;
  /**
   * Marks the end of a constructor seed. Events before it have smaller seq
   * values and came from the seed (resume, fork, or replay); this lifecycle
   * produced none of them. This log-only event is the durable projection of
   * {@link Session.firstLiveSeq}.
   *
   * A fresh fork child owns one `{ inherited: true }` marker at its exact
   * inherited-prefix cut, even when that prefix ends in an ancestor marker.
   * The last tagged marker is the current Session's cut; untagged markers keep
   * ordinary restore and replay lifecycle boundaries.
   *
   * `Session`'s constructor is the only legitimate writer. The invariant
   * companion deliberately constrains nothing here, so a plugin appending one
   * would silently classify every live bracket before it as seed history.
   *
   * An owner of a standalone open/close bracket (`compaction/start` …
   * `compaction/end`) reads it because seed history and live work are otherwise
   * byte-identical: an unmatched opening marker before this event belongs to
   * an ended lifecycle, whatever ended it. NOT a liveness signal about other
   * writers — a concurrently live session holds its own boundary elsewhere,
   * so tolerating concurrent writers needs a signal beyond the log.
   */
  'session/end-seed': {
    inherited?: true;
  };
}
/** The appendable event-type keys of {@link SessionEventMap}, plugin-merged extensions included. */
type SessionEventType = keyof SessionEventMap;
/**
 * The subset of {@link SessionEventType} values whose events produce LLM
 * messages and are eligible to appear on the ordered surface. Only these
 * event types may carry {@link SurfaceOp}; system, user, and tool events may also cite
 * earlier sources through {@link SessionEvent.sourceEventSeqs}.
 */
type SurfaceEventType = 'system/message' | 'user/message' | 'assistant/message' | 'tool/result';
/**
 * How a session event entered the ordered surface. Only valid on
 * {@link SurfaceEventType} events.
 *
 * - `'append'`: added to the tail — normal path for user/assistant/tool
 *   messages.
 * - `{ op: 'replace', startSeq, endSeq }`: replaces surface nodes from `startSeq`
 *   (inclusive) through `endSeq` (inclusive) with this node. Both must exist as
 *   surface nodes in the current surface. `startSeq === endSeq` replaces a single
 *   node. The node's {@link SessionEvent.sourceEventSeqs} must include every
 *   shadowed surface node. Used by compaction; any surface-replacing producer
 *   may use it.
 */
type SurfaceOp = 'append' | {
  op: 'replace';
  startSeq: SessionSeq;
  endSeq: SessionSeq;
};
/**
 * Surface placement and cited source-event seqs for {@link Session.append}. Required on
 * message-producing events and forbidden on log-only events.
 */
type SurfaceIntent<T extends SurfaceEventType = SurfaceEventType> = {
  surfaceOp: SurfaceOp;
} & (T extends 'assistant/message' ? {
  /** Assistant messages embed their provider stream instead of citing source events. */sourceEventSeqs?: never;
} : {
  /** Complete non-empty set of known earlier source-event seqs. */sourceEventSeqs?: SessionSeq[];
});
/**
 * One immutable entry in the session log.
 *
 * A proper discriminated union over `type` (not independent `type`/`data`
 * unions), so `switch (event.type)` narrows `event.data` without casts.
 *
 * The {@link sourceEventSeqs} and {@link surfaceOp} fields are conditional:
 * they only exist on {@link SurfaceEventType} variants (`system/message`, `user/message`,
 * `assistant/message`, `tool/result`).
 * Non-surface events (boundary markers, attempts, errors) never carry
 * surface metadata — the compiler enforces this at `Session.append()`
 * call sites.
 */
type SessionEvent<T extends SessionEventType = SessionEventType> = { [K in SessionEventType]: {
  type: K; /** Monotonic sequence number within the session. */
  seq: SessionSeq; /** Unix epoch milliseconds. */
  time: number;
  data: SessionEventMap[K];
  /**
   * Marks an event a reader may safely skip when it does not recognize
   * `type`. Absent means required: a reader meeting an unrecognized type
   * without this marker MUST refuse to reconstruct the session instead of
   * silently dropping the event, because an unrecognized required event may
   * change how the rest of the log is interpreted. A writer sets `true` only
   * on purely informational records whose loss cannot affect reconstruction;
   * defaulting to required means a forgotten marker over-refuses (an
   * inconvenience) rather than silently resuming a gutted session.
   */
  ignorable?: true;
} & (K extends SurfaceEventType ? SurfaceIntent<K> : {
  surfaceOp?: never;
  sourceEventSeqs?: never;
}) }[T];
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** The named Session does not exist; produced by every layer that resolves a SessionId. */
    'session/not-found': {
      readonly sessionId: SessionId;
    };
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../client/connection/lib/types/recovery-config.d.ts
/** Timing for generation readiness and automatic reconnection. */
interface ConnectionRecoveryConfig {
  /** First-retry delay cap in ms; actual delay is 50–100% of the cap. Default: 500. */
  backoffBaseMs?: number;
  /** Finite growth factor of at least 1 per failed attempt; 1 keeps a fixed cap. Default: 2. */
  backoffFactor?: number;
  /** Maximum retry delay cap in ms; retries continue at this cap. Default: 10000. */
  backoffMaxMs?: number;
  /**
   * Delay before reporting a slow handshake, without cancelling it. Default: 3000.
   * Omitted when readiness, failure, cancellation, or the hard deadline occurs first.
   */
  generationReadyWarnMs?: number;
  /** Deadline in ms for readiness, including physical connection setup. Default: 15000. */
  generationReadyTimeoutMs?: number;
}
//#endregion
//#region ../../client/connection/lib/types/client/connection.d.ts
/** Stable Host facts delivered by one established Remote event generation. */
interface ConnectionHostInfo {
  /** Validated identity on Gateway generations; synthetic sources may omit it. */
  readonly identity?: ConnectionIdentity;
  /** Host account home used only to abbreviate displayed filesystem paths. */
  readonly home: string;
}
/** One successfully established Host generation. */
interface ConnectionGeneration {
  /** Monotone generation number within this Client runtime. */
  readonly id: number;
  /** Host facts carried by this generation's opening frame. */
  readonly host: ConnectionHostInfo;
}
/** Connection lifecycle state published after the first attempt has an outcome. */
type ConnectionState = 'connected' | 'disconnected' | 'connecting';
/** Connection-generation callbacks owned by API Gateway. */
interface ConnectionSinks {
  /** After the generation source reports ready, first connect included. */
  onConnected?: (host: ConnectionHostInfo) => void;
  /** State transitions after the initial attempt has an outcome. Equivalent states are deduplicated. */
  onStateChange?: (state: ConnectionState) => void;
  /** Start one fresh physical-carrier attempt before each logical retry. */
  onReconnectRequested?: () => void;
}
/**
 * One long-lived source defining a Connection generation. The source must
 * attach its incremental listeners before calling `ready`, then remain pending
 * until the generation is lost or `signal` aborts. On abort it must stop
 * delivery, release its resources, and settle before a replacement can start.
 * @param signal - cancellation for the current generation.
 * @param ready - one-shot report that incremental delivery is attached.
 * @returns a promise settling only when this generation ends or fails.
 */
type ConnectionGenerationSource = (signal: AbortSignal, ready: (host: ConnectionHostInfo) => void) => Promise<void>;
//#endregion
//#region ../../client/connection/lib/types/client/handle.d.ts
/** Observable identity and Host facts for the active connection generation. */
interface ConnectionGenerationState {
  /** Active generation, or undefined before readiness and while reconnecting. */
  getSnapshot(): ConnectionGeneration | undefined;
  /** Subscribe to generation establishment, replacement, and loss. */
  subscribe(listener: () => void): () => void;
}
/** Observable recovery lifecycle of the owned Connection loop. */
interface ConnectionStateSource {
  /** Current state, or undefined before the first connection outcome. */
  getSnapshot(): ConnectionState | undefined;
  /** Subscribe to state changes. */
  subscribe(listener: () => void): () => void;
}
/**
 * The ctx.connection service API. API Gateway supplies generation readiness
 * and reset callbacks; Connection stays independent of downstream domain state.
 */
interface ConnectionHandle {
  /**
   * Whether the caller declares a local or shell-owned Host. This is a
   * presentation hint; the Host authenticates and authorizes every operation.
   */
  readonly isLoopback: boolean;
  /** Current Remote event generation and the Host facts carried by its opening frame. */
  readonly generation: ConnectionGenerationState;
  /** Current recovery lifecycle for connection-specific consumers. */
  readonly state: ConnectionStateSource;
  /** Generic logical RPC channels over the same Connection transport. */
  readonly rpc: ClientConnectionRpc;
  /** Reset retry progression and replace the current attempt immediately. */
  reconnect(): void;
  /**
   * Register the sole source defining Host generations. The source reports
   * ready only after its incremental listeners are attached.
   * @param source - long-lived generation source owned by the push carrier.
   * @returns disposer withdrawing the source and stopping an active loop.
   */
  registerGenerationSource(source: ConnectionGenerationSource): () => void;
  /**
   * Start the connect/reconnect loop with the consumer's state callbacks.
   * API Gateway owns the loop; a second call throws.
   * @param sinks - connection-state callbacks.
   * @param config - explicit timing overrides; omitted fields use Host bootstrap timing.
   * @returns lifecycle controls for the loop.
   */
  start(sinks: ConnectionSinks, config?: ConnectionRecoveryConfig): ConnectionLoop;
}
/** Controls retained by the sole owner of a running connection loop. */
interface ConnectionLoop {
  /** Stop the loop and withdraw its active generation. */
  stop(): void;
}
/** Network availability supplied by the transport owner. */
interface ConnectionNetworkSource {
  /** Whether another transport attempt can currently reach a network. */
  getSnapshot(): boolean;
  /** Subscribe to availability changes; the disposer releases the subscription. */
  subscribe(listener: () => void): () => void;
}
/** Inputs owned by one Host connection, never read from page globals. */
interface ConnectionOptions {
  /** Authenticated unary and optional stream transport for this Host. */
  readonly rpc: ClientConnectionRpc;
  /** Explicit local-Host presentation hint; does not grant server privileges. */
  readonly isLoopback: boolean;
  /** Validated timing overrides for this Host. */
  readonly recovery?: ConnectionRecoveryConfig;
  /** Availability observer; omit for carriers without network suspension. */
  readonly network?: ConnectionNetworkSource;
  /** Controller factory preserving abort reasons; defaults to the platform AbortController. */
  readonly createAbortController?: () => AbortController;
}
/**
 * Create an independent Host connection using caller-owned transport and network state.
 * @param options - explicit Host inputs; malformed recovery timing throws before ownership begins.
 * @returns connection whose active loop and network subscription are released by its loop or source disposer.
 */
declare function createConnection(options: ConnectionOptions): ConnectionHandle;
//#endregion
//#region ../../client/connection/lib/types/client/host-identity.d.ts
/**
 * Read correlation facts without retrying or treating them as authorization.
 * @param rpc - authenticated carrier for the selected Host.
 * @param signal - caller lifetime forwarded to the transport.
 * @returns validated identity or the Host failure; transport rejection propagates.
 */
declare function readHostIdentity(rpc: ClientConnectionRpc, signal?: AbortSignal): Promise<ConnectionRpcResult<ConnectionIdentity>>;
//#endregion
//#region ../../client/connection/lib/types/device-protocol.d.ts
/** Identity of one independently revocable device grant. */
type ConnectionDeviceId = Branded<'connection-device-id'>;
/** Device bearer secret returned only by a successful enrollment claim. */
type ConnectionDeviceCredential = Branded<'connection-device-credential'>;
/** Exact Connection-owned HTTP routes; enrollment secrets travel only in JSON bodies. */
declare const DEVICE_ACCESS_PATHS: {
  readonly enroll: "/api/connection/devices/enroll";
  readonly claim: "/api/connection/devices/claim";
  readonly list: "/api/connection/devices";
  readonly revoke: "/api/connection/devices/revoke";
};
/** Public device metadata; neither token digests nor provider credentials are exposed. */
interface ConnectionDeviceInfo {
  readonly deviceId: ConnectionDeviceId;
  readonly label: string;
  readonly createdAt: number;
}
/** Short-lived, single-use enrollment issued to an authenticated owner. */
interface ConnectionDeviceEnrollment {
  readonly version: 1;
  readonly hostId: ConnectionHostId;
  readonly challenge: string;
  readonly expiresAt: number;
}
/** Validate owner-issued enrollment metadata before application QR consumption. */
declare const connectionDeviceEnrollmentSchema: z.ZodType<ConnectionDeviceEnrollment>;
/** Successful claim, persisted before its secret is returned. */
interface ConnectionDeviceGrant {
  readonly version: 1;
  readonly hostId: ConnectionHostId;
  readonly device: ConnectionDeviceInfo;
  readonly credential: ConnectionDeviceCredential;
}
/** Validate the one-time credential result before a native caller stores it. */
declare const connectionDeviceGrantSchema: z.ZodType<ConnectionDeviceGrant>;
//#endregion
//#region ../../client/connection/lib/types/client/device-access.d.ts
/** Platform inputs for a single enrollment claim; no ambient device credential is used. */
interface DeviceEnrollmentClaimOptions {
  readonly baseUrl: string;
  readonly expectedHostId: ConnectionHostId;
  readonly challenge: string;
  readonly label: string;
  /** Dedicated unauthenticated fetch; must not add another Host's credentials. */
  readonly fetch: RpcFetch;
  readonly signal: AbortSignal;
}
/**
 * Claim once without redirects, ambient cookies or automatic retry.
 * @param options - selected Host, QR challenge and platform-owned cancellation and transport.
 * @returns validated credential or a failure; cancellation and carrier rejection propagate.
 */
declare function claimDeviceEnrollment(options: DeviceEnrollmentClaimOptions): Promise<ConnectionRpcResult<ConnectionDeviceGrant>>;
//#endregion
//#region ../../client/connection/lib/types/client/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * A connection generation was established. Wire-derived caches must
     * repull; long-lived streams own their own resume and baseline lifecycle.
     * @mode emit
     */
    'connection/reset'(): void;
  }
}
//#endregion
//#region ../gateway/lib/types/capabilities-protocol.d.ts
/** One strict endpoint's current prerequisites; availability grants no authority. */
type HostCapability = {
  readonly endpoint: string;
  readonly mode: 'unary' | 'stream'; /** Generated schema evidence; absence does not establish compatibility. */
  readonly wireFingerprint?: string | undefined; /** Authored business revision, independent of codec equivalence. */
  readonly semanticRevision?: number | undefined;
} & ({
  readonly availability: 'available';
} | {
  readonly availability: 'context-required';
} | {
  readonly availability: 'unavailable';
  readonly reason: 'service' | 'binding' | 'method' | 'lookup' | 'context';
});
/** Snapshot for one Host activation; version describes metadata, not domain schemas. */
interface HostCapabilities {
  readonly version: 3;
  readonly identity: ConnectionIdentity;
  readonly capabilities: readonly HostCapability[];
}
//#endregion
//#region ../gateway/lib/types/client/host-capabilities.d.ts
/**
 * Read advisory Host dispatch facts without retries or implicit generation recovery.
 * @param rpc - authenticated carrier for the selected Host.
 * @param expectedIdentity - validated event-stream identity; both Host and activation must match.
 * @param signal - caller-owned lifetime, cancelled when its generation ends.
 * @returns validated facts or a failure; carrier rejection and cancellation propagate.
 */
declare function readHostCapabilities(rpc: ClientConnectionRpc, expectedIdentity: ConnectionIdentity, signal?: AbortSignal): Promise<ConnectionRpcResult<HostCapabilities>>;
/** One Client-owned requirement selected from its generated Remote descriptors. */
interface RemoteCapabilityRequirement {
  readonly endpoint: string;
  readonly mode: 'unary' | 'stream';
  readonly wireFingerprint: string;
  readonly semanticRevision: number;
}
/** Paired identity and explicit requirements fixed for a native Client composition. */
interface RemoteClientAdmission {
  readonly expectedHostId: ConnectionHostId;
  /** An empty list admits a metadata-only composition. */
  readonly requiredCapabilities: readonly RemoteCapabilityRequirement[];
}
//#endregion
//#region ../gateway/lib/types/remote-error-codes.d.ts
/**
 * Gateway infrastructure failure codes merged into the shared Remote failure
 * vocabulary. Face-neutral: the Host face and the Client face each import this
 * module so both programs see the same map entries.
 */
/** Wire details every Gateway infrastructure failure carries. */
interface TypertGatewayFaultDetails {
  /** Canonical `<namespace>/<method>` endpoint. */
  readonly endpoint: string;
  /** Affected wire field when the failure is field-specific. */
  readonly field?: string;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    'gateway/api-incompatible': TypertGatewayFaultDetails;
    'gateway/ambiguous-endpoint': TypertGatewayFaultDetails;
    'gateway/arguments-invalid': TypertGatewayFaultDetails;
    'gateway/binding-invalid': TypertGatewayFaultDetails;
    'gateway/context-failed': TypertGatewayFaultDetails;
    'gateway/context-not-found': TypertGatewayFaultDetails;
    'gateway/context-unavailable': TypertGatewayFaultDetails;
    'gateway/definition-unavailable': TypertGatewayFaultDetails;
    'gateway/input-invalid': TypertGatewayFaultDetails;
    'gateway/invocation-unavailable': TypertGatewayFaultDetails;
    'gateway/lookup-failed': TypertGatewayFaultDetails;
    'gateway/lookup-not-found': TypertGatewayFaultDetails;
    'gateway/lookup-unavailable': TypertGatewayFaultDetails;
    'gateway/method-unavailable': TypertGatewayFaultDetails;
    'gateway/provider-mismatch': TypertGatewayFaultDetails;
    'gateway/result-invalid': TypertGatewayFaultDetails;
    'gateway/service-unavailable': TypertGatewayFaultDetails;
    'gateway/signature-invalid': TypertGatewayFaultDetails;
  }
} //# sourceMappingURL=remote-error-codes.d.ts.map
//#endregion
//#region ../gateway/lib/types/client/stream-client.d.ts
/** Socket operations required by the multiplexed stream carrier. */
interface RemoteStreamSocket {
  readonly readyState: number;
  /** @param data - one encoded client frame. */
  send(data: string): void;
  /**
   * @param code - protocol close code.
   * @param reason - close description.
   */
  close(code?: number, reason?: string): void;
  /**
   * @param type - lifecycle event.
   * @param listener - callback.
   * @param options - once-only delivery.
   */
  addEventListener(type: 'open' | 'error' | 'close', listener: () => void, options?: {
    once?: boolean;
  }): void;
  /**
   * @param type - message event.
   * @param listener - incoming frame callback.
   */
  addEventListener(type: 'message', listener: (event: {
    readonly data: unknown;
  }) => void): void;
  /**
   * @param type - lifecycle event.
   * @param listener - registered callback.
   */
  removeEventListener(type: 'open' | 'error' | 'close', listener: () => void): void;
  /**
   * @param type - message event.
   * @param listener - registered callback.
   */
  removeEventListener(type: 'message', listener: (event: {
    readonly data: unknown;
  }) => void): void;
}
/** Cancellation subset supported by browser and native platform signals. */
interface RemoteStreamSignal {
  readonly aborted: boolean;
  readonly reason?: unknown;
  /**
   * @param type - abort event.
   * @param listener - cancellation callback.
   * @param options - once-only delivery.
   */
  addEventListener(type: 'abort', listener: () => void, options?: {
    once?: boolean;
  }): void;
  /**
   * @param type - abort event.
   * @param listener - registered callback.
   */
  removeEventListener(type: 'abort', listener: () => void): void;
}
/** Physical socket and correlation identity supplied by the transport owner. */
interface RemoteStreamTransport {
  /** @returns a fresh socket for one physical connection attempt. */
  createSocket(): RemoteStreamSocket;
  /** @returns a new wire identity for each logical stream, including after reconnect. */
  randomId(): string;
}
/** Physical Remote stream socket failure that may be retried by a domain transport. */
declare class RemoteStreamCarrierError extends Error {
  /**
   * @param message - physical carrier failure description.
   * @param options - optional causal error.
   */
  constructor(message: string, options?: ErrorOptions);
}
/** Keep one physical WebSocket and share it among independently cancellable Remote streams. */
declare class RemoteStreamMuxClient {
  private readonly transport;
  private socket;
  private cancelCandidate;
  private keepAlive;
  private revision;
  private readonly streams;
  private readonly waiters;
  private running;
  private disposed;
  /** @param transport - per-owner socket creation and logical stream identity. */
  constructor(transport: RemoteStreamTransport);
  /** Ensure a physical attempt exists, following the current attempt once if needed. */
  start(): void;
  /** Cancel the current socket or retry wait and start a fresh attempt immediately. */
  reconnect(): void;
  /**
   * Open one logical stream on the persistent physical connection.
   * If no physical attempt is active, opening waits for Connection to request
   * one or for the signal to abort.
   * @param endpoint - Typert Remote stream endpoint.
   * @param payload - endpoint request encoded on the wire.
   * @param signal - cancellation for this logical stream.
   * @returns Host items until completion, cancellation, or failure.
   */
  open(endpoint: string, payload: unknown, signal: RemoteStreamSignal): AsyncGenerator;
  /**
   * Permanently stop the carrier, close the physical socket, and fail every
   * active logical stream.
   * @returns once the active connection attempt has stopped.
   */
  close(): Promise<void>;
  private connect;
  private waitForSocket;
  private receive;
  private lost;
  private maintain;
  private failAll;
  private send;
}
//#endregion
//#region ../gateway/lib/types/client/remote-stream.d.ts
/** One item annotated with the physical Remote-stream generation that delivered it. */
interface RemoteStreamItem<Item> {
  /** Monotone physical generation number within this logical stream. */
  readonly generation: number;
  /** Decoded item yielded by the generated Remote method. */
  readonly value: Item;
  /** Cancellation lifetime of the generation that delivered this item. */
  readonly signal: AbortSignal;
  /** Mark this generation's opening baseline or cursor as accepted. */
  accept(): void;
}
/** Domain-owned operations used by {@link RemoteStream}. */
interface RemoteStreamOptions<Item> {
  /** Diagnostic owner name used for cancellation failures. */
  readonly name: string;
  /** Open one physical generation of the logical stream. */
  readonly open: (signal: AbortSignal) => AsyncIterable<Item>;
  /** Classify a normal generation end after or before its opening item was accepted. */
  readonly ended: (accepted: boolean) => Error;
  /** Observe a retryable carrier loss before the supervisor waits or reopens. */
  readonly carrierFailed?: (error: RemoteStreamCarrierError) => void;
}
/**
 * Reopens one logical Remote stream across carrier generations.
 *
 * Connection owns physical retry timing; Gateway performs each requested
 * replacement. The domain consumer owns its opening item and every later
 * item, and calls {@link RemoteStreamItem.accept} only after validating the
 * opening baseline or cursor.
 */
declare class RemoteStream<Item> implements AsyncIterable<RemoteStreamItem<Item>> {
  private readonly connection;
  private readonly options;
  private readonly createController;
  private readonly lifetime;
  private generationAbort;
  private iterator;
  private closing;
  private revision;
  private taken;
  /**
   * @param connection - observable Host generation source used to pace retries.
   * @param options - domain stream opener, end classification, and diagnostics.
   * @param createController - controller factory; defaults to the platform AbortController.
   */
  constructor(connection: Pick<ConnectionHandle, 'generation'>, options: RemoteStreamOptions<Item>, createController?: () => AbortController);
  /** Cancellation lifetime shared by the stream and sibling page requests. */
  get signal(): AbortSignal;
  /** Interrupt the current generation and immediately request a replacement. */
  restart(): void;
  /**
   * Permanently stop this stream and wait for its iterator to close.
   * @returns when the active generation and consumer iterator are quiescent.
   */
  dispose(): Promise<void>;
  /** @inheritdoc */
  [Symbol.asyncIterator](): AsyncIterator<RemoteStreamItem<Item>>;
  private read;
}
//#endregion
//#region ../gateway/lib/types/client/journal-stream.d.ts
/** Transport-neutral opening snapshot, durable entry, or cursorless notification. */
type RemoteJournalFrame<Entry, Cursor, Page, Notification = never> = {
  readonly type: 'opened';
  readonly cursor: Cursor;
  readonly page: Page;
} | {
  readonly type: 'entry';
  readonly entry: Entry;
} | ([Notification] extends [never] ? never : {
  readonly type: 'notification';
  readonly notification: Notification;
});
/** One journal-window update or cursorless domain notification. */
type RemoteJournalChange<Page, Entry, Notification = never> = {
  readonly type: 'replace';
  readonly page: Page;
  readonly entries: readonly Entry[];
  readonly hasMore: boolean;
} | {
  readonly type: 'prepend';
  readonly page: Page;
  readonly entries: readonly Entry[];
  readonly hasMore: boolean;
} | {
  readonly type: 'append';
  readonly entry: Entry;
} | ([Notification] extends [never] ? never : {
  readonly type: 'notification';
  readonly notification: Notification;
});
/** Gateway capability used to create one reconnecting Remote stream. */
interface RemoteStreamFactory {
  /**
   * Create one independently cancellable logical stream.
   * @param options - domain-owned opener and generation-end classification.
   * @returns a reconnecting single-consumer stream.
   */
  $stream<Item>(options: RemoteStreamOptions<Item>): RemoteStream<Item>;
}
/** Domain publication and cursor operations for one addressed journal stream. */
interface RemoteJournalStreamOptions<Page, Entry, Cursor, Notification = never> {
  /** Diagnostic stream name used in protocol failures. */
  readonly name: string;
  /** Cursor representing a journal with no entries. */
  readonly emptyCursor: Cursor;
  /** Read the ordered entries carried by a page. */
  readonly entries: (page: Page) => readonly Entry[];
  /** Read whether an older page exists. */
  readonly hasMore: (page: Page) => boolean;
  /** Read the inclusive first durable cursor covered by one entry. */
  readonly first: (entry: Entry) => Cursor;
  /** Read the inclusive final cursor, which must not precede the first. */
  readonly last: (entry: Entry) => Cursor;
  /** Compare two cursors. */
  readonly compare: (left: Cursor, right: Cursor) => number;
  /** Test whether the right cursor immediately follows the left cursor. */
  readonly follows: (left: Cursor, right: Cursor) => boolean;
  /** Apply one complete journal-window change or cursorless notification. */
  readonly publish: (change: RemoteJournalChange<Page, Entry, Notification>) => void;
  /** Observe a retryable carrier loss before reconnection. */
  readonly carrierFailed?: (error: RemoteStreamCarrierError) => void;
  /** Publish a terminal stream, page, or protocol failure after opening. */
  readonly failed: (error: unknown) => void;
}
/**
 * Owns snapshot-first opening, ordered live delivery, pagination, and repair.
 *
 * The domain retains its published window during reconnection. A replacement is
 * published only after the opening page reaches the generation's cursor.
 * Notifications never change a cursor and wait behind an in-flight gap repair.
 */
declare abstract class RemoteJournalStream<Page, Entry, Cursor, PageRequest = void, Notification = never> {
  private readonly options;
  private readonly stream;
  private initialRequest;
  private resumeCursor;
  private hasResumeCursor;
  private generation;
  private firstCursor;
  private lastCursor;
  private started;
  private opened;
  private disposed;
  private done;
  private closing;
  private pendingNext;
  /**
   * @param remote - Gateway factory for the reconnecting physical-generation stream.
   * @param options - cursor algebra and domain publication sinks.
   */
  protected constructor(remote: RemoteStreamFactory, options: RemoteJournalStreamOptions<Page, Entry, Cursor, Notification>);
  /**
   * Open one physical journal generation with a complete current snapshot.
   * @param request - opening-window request retained for later repair.
   * @param signal - cancellation lifetime of the physical generation.
   * @returns opening cursor followed by live entries.
   */
  protected abstract follow(request: PageRequest, signal: AbortSignal): AsyncIterable<RemoteJournalFrame<Entry, Cursor, Page, Notification>>;
  /**
   * Read one journal page through the addressed domain source.
   * @param request - domain page request.
   * @param through - inclusive journal cursor that fixes the source read.
   * @param signal - cancellation lifetime shared with the logical stream.
   * @returns the requested page, whose tail equals `through` unless the domain request selects older entries.
   */
  protected abstract readPage(request: PageRequest, through: Cursor, signal: AbortSignal): Promise<Page>;
  /**
   * Derive an unbounded-tail request from the initial page request.
   * @param initial - request used to open the journal window.
   * @returns request suitable for reconnect and gap repair.
   */
  protected abstract repairRequest(initial: PageRequest): PageRequest;
  /** Cancellation lifetime shared by follow and page calls. */
  get signal(): AbortSignal;
  /**
   * Establish follow and publish the opening snapshot carried by its first frame.
   * @param request - initial tail-page request.
   * @returns after the first complete window is published.
   */
  open(request: PageRequest): Promise<void>;
  /**
   * Read and prepend one older page after a successful open.
   * @param request - domain page request bound to this stream's address.
   * @returns after the page is applied or rejected as discontinuous.
   */
  prepend(request: PageRequest): Promise<void>;
  /** Replace the active physical generation while retaining the published window. */
  restart(): void;
  /**
   * Permanently stop follow, page requests, and the background consumer.
   * @returns when no stream work or publication callback can still run.
   */
  dispose(): Promise<void>;
  private consume;
  private replaceGeneration;
  private opening;
  /** Publish a generation's opening page without issuing a second Remote call. */
  private replaceFromOpening;
  private acceptEntry;
  private replaceThrough;
  private readPageWhileFollowing;
  private awaitReplacementGeneration;
  private mergeReplacement;
  private maxCursor;
  private nextResult;
  private takeNext;
  private releaseNext;
  private publishNotification;
  private repairPageRequest;
  private setResumeCursor;
  private currentCursor;
  private tailCursor;
  private assertPage;
  private entryRange;
  private assertPageThrough;
}
//#endregion
//#region ../gateway/lib/types/client/snapshot-stream.d.ts
/** Domain operations for one snapshot stream. */
interface RemoteSnapshotStreamOptions<Snapshot, Delta> {
  /** Diagnostic stream name used in protocol failures. */
  readonly name: string;
  /** Distinguish the opening snapshot from later deltas. */
  readonly isSnapshot: (value: Snapshot | Delta) => value is Snapshot;
  /** Atomically replace the domain model from a complete snapshot. */
  readonly replace: (snapshot: Snapshot) => void;
  /** Apply one incremental update after the generation snapshot. */
  readonly update: (delta: Delta) => void;
  /** Publish a terminal business or protocol failure. */
  readonly failed: (error: unknown) => void;
}
/**
 * Consumes generations that each contain exactly one opening snapshot followed by deltas.
 *
 * The previous domain snapshot remains published while the underlying stream retries. A
 * replacement becomes accepted only after the domain owner applies it successfully.
 */
declare class RemoteSnapshotStream<Snapshot, Delta> {
  private readonly stream;
  private readonly options;
  private started;
  private disposed;
  private done;
  /**
   * @param stream - reconnecting physical-generation stream.
   * @param options - frame discriminator and domain state destinations.
   */
  constructor(stream: RemoteStream<Snapshot | Delta>, options: RemoteSnapshotStreamOptions<Snapshot, Delta>);
  /** Start the single consumer; repeated calls are inert. */
  start(): void;
  /** Replace the active physical generation without discarding the published snapshot. */
  restart(): void;
  /**
   * Permanently stop the stream and wait for its consumer to become quiescent.
   * @returns when no generation or callback can still run.
   */
  dispose(): Promise<void>;
  private consume;
}
//#endregion
//#region ../gateway/lib/types/client/service.d.ts
/** Typed Remote service augmented by generated direct namespaces and Gateway stream supervision. */
interface ClientRemote extends TypertClientRemote {
  /**
   * Create one independently cancellable, reconnecting logical stream.
   * @param options - domain-owned opener and generation-end classification.
   * @returns a single-consumer stream annotated with physical generation ids.
   */
  $stream<Item>(options: RemoteStreamOptions<Item>): RemoteStream<Item>;
  /**
   * Active Host facts as plain reads. Subscribe to Connection generation changes
   * to observe readiness and loss; disconnected facts remain undefined.
   */
  readonly $host: RemoteHostFacts;
}
/** The active Host facts exposed on `ctx.remote.$host`. */
interface RemoteHostFacts {
  /** Identity validated on the active Gateway stream, undefined while disconnected. */
  readonly identity: ConnectionIdentity | undefined;
  /** Capability metadata admitted for the active native generation, otherwise undefined. */
  readonly capabilities: HostCapabilities | undefined;
  /** Host home directory from the ready frame, undefined before it. */
  readonly home: string | undefined;
  /** Whether the carrier connects to the local Host. */
  readonly isLoopback: boolean;
}
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Generated Remote namespaces selected by the Client assembly. */
    remote: ClientRemote;
  }
}
/** Required Client services: the Typert registry and the existing Connection carrier. */
/**
 * Whether a caught value is a Remote failure this face delivered or threw.
 * The one consumer-facing discrimination point: marked instances carry their
 * Host code; anything else is a local fault the caller should let crash.
 * @param error - a caught value.
 * @returns true when the value narrows to RemoteFailure.
 */
declare function isRemoteFailure(error: unknown): error is RemoteFailure$1;
//#endregion
//#region ../../host/plugin-inventory/lib/types/types.d.ts
/** Stable Loader-tree identity of one configured plugin entry. */
type PluginEntryId = Branded<'PluginEntryId'>;
/** Lifecycle state of an entry's root Fiber, or null when it has no live root Fiber. */
type PluginFiberPhase = 'pending' | 'loading' | 'active' | 'failed' | 'unloading' | null;
/** Display metadata read from the package manifest that owns a Loader entry. */
interface PluginPackageMetadata {
  /** Declared package author, or null when the manifest provides none. */
  readonly author: string | null;
  /** Declared package description, or null when the manifest provides none. */
  readonly description: string | null;
  /** Declared package version, or null when the manifest provides none. */
  readonly version: string | null;
}
/** One non-group Loader entry exposed to trusted clients. */
interface PluginInventoryEntry extends PluginPackageMetadata {
  readonly entryId: PluginEntryId;
  /** Exact module specifier imported by the Loader entry. */
  readonly moduleName: string;
  /** Effective Loader enablement, including disabled ancestor groups. */
  readonly enabled: boolean;
  readonly fiberPhase: PluginFiberPhase;
}
/** Effective enablement of one preset composition row. */
type PresetPluginEnablement = boolean | 'conditional';
/** One plugin row an agent preset's composition names. */
interface AgentPresetPluginRow extends PluginPackageMetadata {
  /** Composition row id, or null when the row declares none. */
  readonly entryId: string | null;
  /** Module specifier the row names. */
  readonly moduleName: string;
  /** Literal composition-row description, preferred over the package description for display. */
  readonly purpose?: string;
  /**
   * Effective enablement, including disabled ancestor groups. `'conditional'`
   * marks a `!!js` disabled expression on a composition no session has
   * mounted, which only a Loader context can decide.
   */
  readonly enabled: PresetPluginEnablement;
  /** The row's own `!!js` disabled expression, when it carries one. */
  readonly condition?: string;
  /** Root-fiber phase when the composition is live; null otherwise. */
  readonly fiberPhase: PluginFiberPhase;
}
/** One agent preset's identity and flattened composition in the inventory. */
interface AgentPresetPluginGroup {
  /** Stable preset id. */
  readonly id: string;
  /** Whether the deployment ships the preset or the user owns it. */
  readonly trust: 'system' | 'user';
  /** Display name the preset published; a reader falls back to the id. */
  readonly name?: string;
  /** Whether a session naming no preset composes this one. */
  readonly isDefault: boolean;
  /** Why this preset's composition cannot be read; absent when rows answer. */
  readonly broken?: string;
  /** Plugin rows in composition order; empty when the preset is broken. */
  readonly rows: readonly AgentPresetPluginRow[];
}
/** Point-in-time inventory returned by the plugin inventory Remote. */
interface PluginInventorySnapshot {
  readonly entries: readonly PluginInventoryEntry[];
  /**
   * Per-preset compositions, present only when an agent-preset roster is
   * composed in this deployment.
   */
  readonly agentPresets?: readonly AgentPresetPluginGroup[];
}
//#endregion
//#region ../../core/agent-default-model/lib/types/types.d.ts
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * The live Agent-model role directory gained or lost a visible target.
     * Consumers re-read the directory after this post-commit notification;
     * equivalent reference-count changes do not emit. Observer failures are
     * contained and cannot veto the registry mutation.
     * @mode emit
     */
    'agent-models/directory-updated'(): void;
  }
}
/** Stable identity of one configurable Agent role. */
type AgentModelTargetId = Branded<'AgentModelTargetId'>;
/** Stored selection under one target's deployment-fixed provider route. */
interface StoredAgentModelSelection {
  /** Provider-owned model id. */
  model: string;
  /** Adapter-owned reasoning effort, or provider/default behavior when absent. */
  reasoningEffort?: string;
}
/** One graphical model option under a deployment-fixed provider. */
interface AgentModelOption {
  /** Exact provider request id. */
  readonly id: string;
  /** Human-facing model name. */
  readonly name: string;
  /** Optional model distinction. */
  readonly description?: string;
  /** Adapter-supported reasoning efforts in display order. */
  readonly reasoningEfforts: readonly {
    /** Exact effort id accepted by the adapter. */readonly id: string; /** Human-facing effort name. */
    readonly name: string; /** Optional effort distinction. */
    readonly description?: string;
  }[];
  /** Adapter-configured default effort, or provider behavior when absent. */
  readonly defaultReasoningEffort?: string;
}
/** One Agent row exposed to graphical configuration. */
interface AgentModelTargetView {
  /** Stable Agent role identity. */
  readonly id: AgentModelTargetId;
  /** Human-facing Agent role name. */
  readonly label: string;
  /** Deployment-fixed provider route for this target. */
  readonly provider: string;
  /** Effective selection for the next Agent start. */
  readonly selection: StoredAgentModelSelection;
  /** Deployment selection restored by reset. */
  readonly defaultSelection: StoredAgentModelSelection;
  /** Whether the user settings layer owns this target's current selection. */
  readonly overridden: boolean;
}
/** One provider catalog required by the visible Agent targets. */
interface AgentModelCatalogView {
  /** Exact deployment provider route. */
  readonly provider: string;
  /** Models currently served by this provider route. */
  readonly models: readonly AgentModelOption[];
}
/** Point-in-time Agent model directory and its provider catalogs. */
interface AgentModelsSnapshot {
  /** Whether the current settings provider accepts writes. */
  readonly writable: boolean;
  /** Monotonic revision of the raw Agent-model settings section. */
  readonly revision: number;
  /** Main Agent first, then named contributions by label and id. */
  readonly targets: readonly AgentModelTargetView[];
  /** Distinct provider catalogs required by the visible targets. */
  readonly catalogs: readonly AgentModelCatalogView[];
}
//#endregion
//#region ../../core/agent-default-model/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$6167656e744d6f64656c73 {
    list: () => Promise<RemoteResult$1<AgentModelsSnapshot>>;
    reset: (id: AgentModelTargetId, expectedRevision: number) => Promise<RemoteResult$1<AgentModelsSnapshot>>;
    save: (id: AgentModelTargetId, model: string, reasoningEffort: string | undefined, expectedRevision: number) => Promise<RemoteResult$1<AgentModelsSnapshot>>;
  }
  interface TypertRemoteMap {
    'agentModels/list': () => Promise<RemoteResult$1<AgentModelsSnapshot>>;
    'agentModels/reset': (id: AgentModelTargetId, expectedRevision: number) => Promise<RemoteResult$1<AgentModelsSnapshot>>;
    'agentModels/save': (id: AgentModelTargetId, model: string, reasoningEffort: string | undefined, expectedRevision: number) => Promise<RemoteResult$1<AgentModelsSnapshot>>;
  }
  interface TypertRemoteNamespaceMap {
    'agentModels': TypertRemoteNamespace$6167656e744d6f64656c73;
  }
}
//#endregion
//#region ../../preset/agent-presets/lib/types/preset.d.ts
/** Agent-preset vocabulary shared by discovery, mounting, and consumers. */
/**
 * Where a preset's composition came from. A `system` preset ships with the
 * deployment; a `user` preset was authored locally, by a person or by an
 * agent, and therefore carries the same trust as shell access.
 */
type PresetTrust = 'system' | 'user';
//#endregion
//#region ../../preset/agent-presets/lib/types/types.d.ts
/**
 * One roster row as a client reads it. Path-free: a preset is addressed by id
 * everywhere off the Host, and the composition's location is the Host's own.
 */
interface AgentPresetRow {
  /** Stable identifier; also the label's fallback. */
  readonly id: string;
  /** Trust of the root this preset was discovered under. */
  readonly trust: PresetTrust;
  /** Whether a session naming no preset composes this one. */
  readonly isDefault: boolean;
  /** Display name the preset published. */
  readonly name?: string;
  /** One sentence on what this preset is for. */
  readonly description?: string;
  /** Why this preset cannot compose a session; absent when it can. */
  readonly broken?: string;
}
/** The roster one deployment currently supplies, with its authoring capability. */
interface AgentPresetRoster {
  /** Every preset the configured roots supply, first-root-wins per id. */
  readonly presets: readonly AgentPresetRow[];
  /** Whether this deployment has a root locally authored presets go to. */
  readonly authorable: boolean;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** No configured root supplies the requested id. */
    'agent-preset/not-found': {
      readonly agentPreset: string;
      readonly available: readonly string[];
    };
    /** The id is unusable, already taken, or its composition cannot be installed. */
    'agent-preset/invalid': {
      readonly agentPreset: string;
      readonly reason: string;
    };
    /** The preset ships with the deployment and is not the user's to change. */
    'agent-preset/read-only': {
      readonly agentPreset: string;
      readonly reason: string;
    };
    /** The session's conversation has started, so its composition is fixed. */
    'agent-preset/locked': {
      readonly sessionId: SessionId;
      readonly agentPreset: string;
    };
  }
}
/** One preset's composition text beside the row it belongs to. */
interface AgentPresetDocument {
  /** The preset the composition belongs to. */
  readonly agentPreset: string;
  /** Trust of the root this preset was discovered under. */
  readonly trust: PresetTrust;
  /** The composition exactly as stored. */
  readonly content: string;
  /** Display name the preset published. */
  readonly name?: string;
  /** One sentence on what this preset is for. */
  readonly description?: string;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    agentPreset: string | null;
  }
  interface SessionProjectionMap {
    /** Preset the Session runs, or null when the deployment composes none. */
    agentPreset: string | null;
  }
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * One session committed a different agent preset to its durable log.
     * Consumers invalidate only state derived from that session's composition.
     * @mode emit
     * @param sessionId - the session whose composition changed.
     * @param agentPreset - the preset recorded by the committed selection.
     */
    'agent-preset/selected'(sessionId: SessionId, agentPreset: string): void;
  }
}
//#endregion
//#region ../../preset/agent-presets/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$6167656e7450726573657473 {
    copy: (from: string, id: string, name?: string) => Promise<RemoteResult$1<void>>;
    deletePreset: (id: string) => Promise<RemoteResult$1<void>>;
    list: () => Promise<RemoteResult$1<AgentPresetRoster>>;
    read: (agentPreset: string) => Promise<RemoteResult$1<AgentPresetDocument>>;
    select: (agentId: SessionId, agentPreset: string) => Promise<RemoteResult$1<string>>;
  }
  interface TypertRemoteMap {
    'agentPresets/copy': (from: string, id: string, name?: string) => Promise<RemoteResult$1<void>>;
    'agentPresets/deletePreset': (id: string) => Promise<RemoteResult$1<void>>;
    'agentPresets/list': () => Promise<RemoteResult$1<AgentPresetRoster>>;
    'agentPresets/read': (agentPreset: string) => Promise<RemoteResult$1<AgentPresetDocument>>;
    'agentPresets/select': (agentId: SessionId, agentPreset: string) => Promise<RemoteResult$1<string>>;
  }
  interface TypertRemoteNamespaceMap {
    'agentPresets': TypertRemoteNamespace$6167656e7450726573657473;
  }
  interface TypertRemoteScopeMap {
    'agent:agentPresets/select': (agentPreset: string) => Promise<RemoteResult$1<string>>;
  }
}
//#endregion
//#region ../../interaction/commands/lib/types/brand.d.ts
/**
 * Pairs one command execution's `command/run`/`command/done` lifecycle
 * records with each other and with the `command.execute` admission response.
 * Minted by the executor, monotonic per service instance.
 */
type CommandId = Branded<'CommandId'>;
/**
 * Brand a string as a {@link CommandId}.
 * @param id - the executor-minted pairing id.
 * @returns the same string, branded; no validation is performed.
 */
declare function CommandId(id: string): CommandId;
//#endregion
//#region ../../interaction/commands/lib/types/types.d.ts
/** One browser-submitted command attachment: encoded image input or a staged file receipt. */
type CommandSubmitAttachment = ({
  readonly type: 'image';
} & EncodedImageAttachment) | {
  readonly type: 'file';
  readonly receiptId: string;
};
/** Immutable metadata for a command's optional unstructured input. */
interface CommandInputDescriptor {
  /** Placeholder shown before the user supplies free-form input. */
  readonly hint: string;
  /**
   * Whether composer attachments may accompany an invocation. Absent or
   * false = the executor rejects an invocation carrying attachments and capable
   * composers refuse the submission before dispatch. A declaring command's
   * handler receives the admitted durable blocks and owns every further
   * grammar decision, including rejecting sub-commands that cannot use them.
   */
  readonly attachments?: boolean;
}
/** Expected command outcome rendered directly by the dispatching UI. */
type CommandResult = {
  readonly kind: 'success';
  readonly text?: string; /** Earlier authoritative domain event that owns a richer presentation. */
  readonly sourceEventSeq?: SessionSeq;
} | {
  readonly kind: 'error';
  readonly text: string;
};
/**
 * One settled command execution: the handler's normalized result plus the
 * lifecycle pairing id minted for its `command/run`/`command/done` records,
 * so a dispatching surface can correlate the Remote acknowledgment with the
 * flow node those events produce.
 */
interface CommandExecution {
  /** Pairing id carried by this execution's lifecycle events. */
  readonly commandId: CommandId;
  /** The handler's normalized outcome. */
  readonly result: CommandResult;
}
/** Handler-free immutable command view returned to UI adapters. */
interface CommandDescriptor {
  /** Lowercase command name without the leading slash. */
  readonly name: string;
  /** Human-readable summary used in discovery UI. */
  readonly description: string;
  /** Optional free-form input hint advertised to capable clients. */
  readonly input?: CommandInputDescriptor;
}
/**
 * Producer record for one command invocation (the `command/run` event's
 * source slot). Merge-extensible sum type mirroring `MessageSourceMap`'s
 * shape; minimal because every executor caller is a human-facing UI
 * surface dispatching a human-typed line, so the sole variant is `user`.
 */
interface CommandSourceMap {
  user: {
    kind: 'user';
  };
}
/** The union over {@link CommandSourceMap} — who issued a command line. */
type CommandSource = CommandSourceMap[keyof CommandSourceMap];
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * A command was registered or unregistered. This is an unfiltered registry
     * notification because a global or scoped change may affect any UI view.
     * Observer failures are contained and cannot veto the registry mutation.
     * @mode emit
     */
    'commands/change'(): void;
  }
}
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * A resolved slash command entered its handler. Log-only (never model
     * surface); paired with `command/done` by `commandId`, mirroring the
     * `tool/call`↔`tool/result` pairing. The payload is structured — `name`
     * and `args` are `parseCommand`'s own split (name and verbatim rawInput,
     * separator whitespace included), so a consumer (a projection unit
     * folding its own command records, a rich command card) never re-parses
     * a line. `args` is absent when the definition sets `recordInput: false`
     * because an authoritative domain event owns the input payload.
     */
    'command/run': {
      commandId: CommandId;
      name: string;
      args?: string;
      source: CommandSource;
    };
    /**
     * The paired command settled. `kind`/`text` carry the handler's verbatim
     * outcome (a thrown/aborted handler settles as `kind: 'error'` with the
     * rendered failure). A successful command may identify the earlier
     * authoritative domain event for a richer client-computed presentation.
     */
    'command/done': {
      commandId: CommandId;
      kind: 'success' | 'error';
      text?: string;
      sourceEventSeq?: SessionSeq;
    };
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../interaction/commands/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$636f6d6d616e6473 {
    execute: (agentId: SessionId, line: string, submittedAttachments: readonly CommandSubmitAttachment[], signal?: AbortSignal) => Promise<RemoteResult$1<CommandExecution | undefined>>;
    list: (agentId: SessionId) => Promise<RemoteResult$1<readonly CommandDescriptor[]>>;
  }
  interface TypertRemoteMap {
    'commands/execute': (agentId: SessionId, line: string, submittedAttachments: readonly CommandSubmitAttachment[], signal?: AbortSignal) => Promise<RemoteResult$1<CommandExecution | undefined>>;
    'commands/list': (agentId: SessionId) => Promise<RemoteResult$1<readonly CommandDescriptor[]>>;
  }
  interface TypertRemoteNamespaceMap {
    'commands': TypertRemoteNamespace$636f6d6d616e6473;
  }
  interface TypertRemoteScopeMap {
    'agent:commands/execute': (line: string, submittedAttachments: readonly CommandSubmitAttachment[], signal?: AbortSignal) => Promise<RemoteResult$1<CommandExecution | undefined>>;
    'agent:commands/list': () => Promise<RemoteResult$1<readonly CommandDescriptor[]>>;
  }
}
//#endregion
//#region ../../credentials/credentials/lib/types/types.d.ts
/** Nominal reference to one credential: a POSIX-style environment-variable name. */
type CredentialRef = Branded<'CredentialRef'>;
/**
 * Nominal address of one stored credential record: `<scope>/<id>`, where
 * `scope` is the registered name of the plugin that owns the record and `id`
 * is that plugin's own addressing unit (an LLM adapter uses its provider route
 * key).
 *
 * The scope is the owner rather than the domain because a record's payload is
 * written in its owner's format: two plugins serving the same provider name
 * would otherwise read each other's payload, and a record left behind by an
 * uninstalled plugin could not be told apart from a live one. The `/` also
 * keeps this grammar disjoint from {@link CredentialRef}, so the two key
 * spaces can never collide.
 */
type CredentialKey = Branded<'CredentialKey'>;
/**
 * Source and writability facts for one reference, safe for configuration UIs —
 * never the value. The view has no slot a value could ride in, which is what
 * lets the whole read half cross the Remote wire.
 */
interface CredentialInfo {
  /** Whether resolving the reference would currently return a value. */
  configured: boolean;
  /** Source layer currently supplying the value; absent while unconfigured. */
  source?: string;
  /** Whether the active provider can write this reference. */
  writable: boolean;
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * Committed change to a provider-managed credential source: a `set`, an
     * `unset`, or an external edit observed in storage. Ambient
     * process-environment changes are not observable and never emit. Listener
     * failures are contained and logged — a sync throw and an async rejection
     * alike — without changing the committed operation's outcome, except
     * `INVARIANT`-coded failures, which rethrow after every listener ran;
     * that rethrow reaches the emitter only from synchronous listeners, so
     * invariant checks on this event must not be async functions.
     * @param ref - the reference whose stored value changed.
     * @mode emit
     */
    'credentials/reference-updated'(ref: CredentialRef): void;
    /**
     * Committed change to a stored credential record: a `modifyRecord` that
     * wrote, a `deleteRecord` that removed, or an external edit observed in
     * storage. Separate from `credentials/reference-updated` because the two key
     * grammars are disjoint — a listener that received both on one event could
     * not tell which space a subject belongs to. Listener failures are
     * contained on the same terms as `credentials/reference-updated`.
     * @param key - the record whose stored value changed.
     * @mode emit
     */
    'credentials/record-updated'(key: CredentialKey): void;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../settings-controller/lib/types/types.d.ts
/** Identity of one browser account sign-in. */
type AccountAttemptId = Branded<'AccountAttemptId'>;
/** Identity of one question within an account sign-in. */
type AccountPromptId = Branded<'AccountPromptId'>;
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /**
     * Every seam refusal that is not a stale write: an unregistered or malformed
     * namespace, a read-only provider, schema validation, storage.
     */
    'settings/rejected': {
      readonly ns: string;
    };
    /**
     * The stored revision moved after the caller read it. Its own outcome rather
     * than an invalid request: the caller must re-read and re-apply.
     */
    'settings/conflict': {
      readonly ns: string;
      readonly expected: number;
      readonly actual: number;
    };
    /**
     * The provider refused a valid credential write, for example because a
     * read-only source shadows the reference. The details name only the
     * reference, never the value.
     */
    'credential/rejected': {
      readonly ref: string;
    };
  }
}
/** Confirmation that the settings document was handed to the native editor. */
interface SettingsDocumentOpenValue {
  readonly opened: true;
}
/** Result of opening or revealing one locally authored Agent preset directory. */
type AgentPresetDirectoryOpenValue = {
  readonly opened: true;
} | {
  readonly opened: false;
  readonly path: string;
};
/** One provider account, with credential presence but no credential values. */
interface ProviderAccount {
  readonly key: CredentialKey;
  readonly label: string;
  readonly methods: readonly {
    readonly id: string;
    readonly label: string;
  }[];
  readonly configured: boolean;
  readonly inFlight: boolean;
}
/** One question presented during provider sign-in. Answers are write-only. */
interface ProviderAccountPrompt {
  readonly id: AccountPromptId;
  readonly kind: 'text' | 'secret' | 'select';
  readonly message: string;
  readonly placeholder?: string;
  readonly options?: readonly {
    readonly id: string;
    readonly label: string;
    readonly description?: string;
  }[];
}
/** Redacted sign-in progress carried by a cancellable Remote stream. */
interface ProviderAccountUpdate {
  readonly id: AccountAttemptId;
  readonly status: 'pending' | 'authorized' | 'cancelled' | 'failed';
  readonly message?: string;
  readonly url?: string | undefined;
  readonly code?: string;
  readonly prompt?: ProviderAccountPrompt | undefined;
}
//#endregion
//#region ../../settings/settings/lib/types/types.d.ts
/** Nominal id of one registered settings namespace. */
type SettingsNamespace = Branded<'SettingsNamespace'>;
/** Origin of one committed settings change. */
type SettingsUpdateSource = 'update' | 'provider';
/** One schema-declared secret slot inside a redacted namespace value. */
interface SettingsSecretView {
  /** Path from the section root to the removed field. */
  path: string[];
  /** Whether the slot currently holds a value; the value itself never rides. */
  set: boolean;
}
/**
 * Wire view of one registered namespace, always read under `redactSecrets`. The
 * JSON-valued fields are `JsonValue` rather than the descriptor's `unknown`
 * because the Remote boundary admits no unconstrained data.
 */
interface SettingsNamespaceView {
  /** Namespace key (`llm-deepseek`, `llm-pi-ai`, …). */
  ns: string;
  /** Serialized schemastery schema envelope (`schema.toJSON()`); rehydrate with `new Schema(json)`. */
  schema: JsonValue$1;
  /** Redacted resolved value (schema defaults → composition base → user layer). */
  value: JsonValue$1;
  /** Redacted composition base layer, when the registrant declared one. */
  base?: JsonValue$1;
  /** Redacted raw user section, when one exists; a field's presence here marks it user-overridden. */
  user?: JsonValue$1;
  /** When the owner applies changes. */
  applies: 'live' | 'restart';
  /** Every schema-declared secret slot with its configured state. */
  secrets: SettingsSecretView[];
  /**
   * Monotonic revision of the raw user section this view was read at. Send it
   * back as `expectedRevision` on a write so a stale editor is refused rather
   * than silently overwriting a concurrent change.
   */
  revision: number;
}
/**
 * One path-addressed edit carried by a remote settings write. `set` writes the
 * value at the path, creating intermediate objects; `unset` removes it. The
 * empty path addresses the section root.
 */
type SettingsPathOpView = {
  op: 'set';
  path: string[];
  value: JsonValue$1;
} | {
  op: 'unset';
  path: string[];
};
/** Every registered namespace with the deployment facts a configuration page renders around them. */
interface SettingsDescribeValue {
  /** Whether the provider accepts writes; `false` disables every write control. */
  writable: boolean;
  /** Whether a file-backed provider owns a local document, without exposing its Host path. */
  hasDocument: boolean;
  /** One view per registered namespace. */
  namespaces: SettingsNamespaceView[];
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * Committed change to one registered namespace's resolved value. Emitted
     * after the provider persisted (for `update`) or published (`provider`)
     * the change; never emitted when the resolved value is deep-equal.
     * Listener failures are contained and logged — a sync throw and an async
     * rejection alike — except `INVARIANT`-coded failures, which rethrow
     * after every listener ran; that rethrow reaches the emitter only from
     * synchronous listeners, so invariant checks on this event must not be
     * async functions.
     * @param ns - the namespace whose resolved value changed.
     * @param next - the new resolved value.
     * @param prev - the previous resolved value.
     * @param source - whether the change entered through `update()` or the provider.
     * @mode emit
     */
    'settings/updated'(ns: SettingsNamespace, next: unknown, prev: unknown, source: SettingsUpdateSource): void;
    /**
     * One registered namespace's RAW user section changed, whether or not the
     * resolved value did. `settings/updated` is the consumer-facing event and
     * stays deep-equal-gated; this one exists for configuration surfaces,
     * which must learn that a field went from inherited to overridden (same
     * resolved value, different meaning) and that their held revision is
     * stale. Listener containment matches `settings/updated`.
     * @param ns - the namespace whose stored section changed.
     * @param revision - the namespace's new revision.
     * @mode emit
     */
    'settings/document-updated'(ns: SettingsNamespace, revision: number): void;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../settings-controller/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$617574686f72697a6174696f6e {
    answer: (id: AccountAttemptId, promptId: AccountPromptId, value: string) => Promise<RemoteResult$1<void>>;
    cancel: (id: AccountAttemptId) => Promise<RemoteResult$1<void>>;
    list: () => Promise<RemoteResult$1<ProviderAccount[]>>;
    signIn: (key: string, method: string, signal?: AbortSignal) => AsyncIterable<ProviderAccountUpdate>;
    signOut: (key: string) => Promise<RemoteResult$1<void>>;
  }
  interface TypertRemoteNamespace$63726564656e7469616c73 {
    describe: (refs: string[]) => Promise<RemoteResult$1<Record<string, CredentialInfo>>>;
    set: (ref: string, value: string) => Promise<RemoteResult$1<void>>;
    unset: (ref: string) => Promise<RemoteResult$1<void>>;
  }
  interface TypertRemoteNamespace$73657474696e6773 {
    canOpenAgentPresetDirectory: () => Promise<RemoteResult$1<boolean>>;
    describe: () => Promise<RemoteResult$1<SettingsDescribeValue>>;
    mutate: (ns: string, ops: SettingsPathOpView[], expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
    openAgentPresetDirectory: (agentPreset: string, signal?: AbortSignal) => Promise<RemoteResult$1<AgentPresetDirectoryOpenValue>>;
    openSettingsDocument: (signal?: AbortSignal) => Promise<RemoteResult$1<SettingsDocumentOpenValue>>;
    replace: (ns: string, section: Record<string, JsonValue>, expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
    update: (ns: string, patch: Record<string, JsonValue>, expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
  }
  interface TypertRemoteMap {
    'authorization/answer': (id: AccountAttemptId, promptId: AccountPromptId, value: string) => Promise<RemoteResult$1<void>>;
    'authorization/cancel': (id: AccountAttemptId) => Promise<RemoteResult$1<void>>;
    'authorization/list': () => Promise<RemoteResult$1<ProviderAccount[]>>;
    'authorization/signIn': (key: string, method: string, signal?: AbortSignal) => AsyncIterable<ProviderAccountUpdate>;
    'authorization/signOut': (key: string) => Promise<RemoteResult$1<void>>;
    'credentials/describe': (refs: string[]) => Promise<RemoteResult$1<Record<string, CredentialInfo>>>;
    'credentials/set': (ref: string, value: string) => Promise<RemoteResult$1<void>>;
    'credentials/unset': (ref: string) => Promise<RemoteResult$1<void>>;
    'settings/canOpenAgentPresetDirectory': () => Promise<RemoteResult$1<boolean>>;
    'settings/describe': () => Promise<RemoteResult$1<SettingsDescribeValue>>;
    'settings/mutate': (ns: string, ops: SettingsPathOpView[], expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
    'settings/openAgentPresetDirectory': (agentPreset: string, signal?: AbortSignal) => Promise<RemoteResult$1<AgentPresetDirectoryOpenValue>>;
    'settings/openSettingsDocument': (signal?: AbortSignal) => Promise<RemoteResult$1<SettingsDocumentOpenValue>>;
    'settings/replace': (ns: string, section: Record<string, JsonValue>, expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
    'settings/update': (ns: string, patch: Record<string, JsonValue>, expectedRevision: number | undefined) => Promise<RemoteResult$1<SettingsNamespaceView>>;
  }
  interface TypertRemoteNamespaceMap {
    'authorization': TypertRemoteNamespace$617574686f72697a6174696f6e;
    'credentials': TypertRemoteNamespace$63726564656e7469616c73;
    'settings': TypertRemoteNamespace$73657474696e6773;
  }
}
//#endregion
//#region ../../goal/goal/lib/types/types.d.ts
/** Identifies one goal across its durable revisions. */
type GoalId = Branded<'GoalId'>;
/** Compare-and-set identity for one exact goal revision. */
interface GoalRef {
  /** Stable goal identity. */
  readonly id: GoalId;
  /** Positive revision; every durable mutation increments it. */
  readonly revision: number;
}
/** Input whose omitted round cap is resolved by the service configuration. */
interface CreateGoalRequest {
  readonly objective: string;
  readonly maxGoalRounds?: number;
}
/** Wire-safe acknowledgement of one created goal. */
interface CreateGoalResult {
  readonly ref: GoalRef;
}
/** Fields changed by an edit; at least one must be present. */
interface EditGoalRequest {
  readonly objective?: string;
  readonly maxGoalRounds?: number;
}
/** Durable continuation phase. Activation is process-local and separate. */
type GoalPhase = 'active' | 'paused' | 'blocked' | 'complete';
/** Machine-routable and human-readable explanation for a blocked goal. */
interface GoalBlockReason {
  /** Stable lower-kebab-case classification chosen by the blocking policy. */
  readonly code: string;
  /** Non-empty explanation shown to humans and models. */
  readonly message: string;
}
/** Full durable state written by every non-clear goal mutation. */
interface GoalSnapshot extends GoalRef {
  /** Human-requested completion objective. */
  readonly objective: string;
  /** Durable lifecycle phase. */
  readonly phase: GoalPhase;
  /** Present exactly while `phase` is `blocked`. */
  readonly blockedReason?: GoalBlockReason;
  /** Total admitted goal-round cap. */
  readonly maxGoalRounds: number;
}
/** Whether this live process may automatically continue an active goal. */
type GoalActivation = 'armed' | 'disarmed';
/** Live process-local activation update forwarded to UI clients. */
interface GoalActivationChanged {
  /** Session whose live goal activation changed. */
  readonly sessionId: SessionId;
  /** Current exact activation, absent when no goal is current. */
  readonly goal?: {
    /** Exact current goal identity. */readonly id: GoalId; /** Exact current goal revision. */
    readonly revision: number; /** Current process-local continuation state. */
    readonly activation: GoalActivation;
  };
}
/** Current goal projection, including values derived from the session log. */
interface GoalView extends GoalSnapshot {
  /** Highest admitted round number for this goal. */
  readonly roundsStarted: number;
  /** Epoch milliseconds of the create mutation. */
  readonly createdAt: number;
  /** Epoch milliseconds of the latest mutation. */
  readonly updatedAt: number;
  /** Process-local continuation eligibility; never persisted. */
  readonly activation: GoalActivation;
}
/**
 * The `goal` projection value: the current durable goal with its replay
 * counters, including admitted goal rounds.
 * Activation is process-local (never persisted) and deliberately absent —
 * the projection reflects durable phase only.
 */
interface GoalProjection {
  /** Current durable goal snapshot (the CAS ref for mutations rides on it). */
  readonly goal: GoalSnapshot;
  /** Highest admitted round number for this goal. */
  readonly roundsStarted: number;
  /** Epoch milliseconds of the create mutation. */
  readonly createdAt: number;
  /** Epoch milliseconds of the latest mutation. */
  readonly updatedAt: number;
}
/** Strict checkpoint state used to derive the current goal client value. */
interface GoalProjectionState {
  /** Latest valid current goal, or null before creation and after clear. */
  readonly current: GoalProjection | null;
  /** Goal identities already created in this Session, retained to reject reuse. */
  readonly seenGoalIds: GoalId[];
  /** First strict replay failure, or null while the durable stream is valid. */
  readonly failure: string | null;
}
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    goal: GoalProjectionState;
  }
  interface SessionProjectionMap {
    /**
     * The session's current goal and admitted-round count, or
     * `null` before the first create and after a clear tombstone.
     * `goal/change` supplies the whole lifecycle value; matching admitted
     * `user/message` events advance `roundsStarted`.
     */
    goal: GoalProjection | null;
  }
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * Process-local goal activation changed for one session.
     * @mode emit
     * @param payload - session id and the exact current goal activation, or no goal after a clear.
     */
    'goal/activation-changed'(payload: GoalActivationChanged): void;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../goal/goal/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$676f616c73 {
    clear: (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalRef>>;
    complete: (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    create: (agentId: SessionId, request: CreateGoalRequest) => Promise<RemoteResult$1<CreateGoalResult>>;
    edit: (agentId: SessionId, ref: GoalRef, request: EditGoalRequest) => Promise<RemoteResult$1<GoalView>>;
    get: (agentId: SessionId) => Promise<RemoteResult$1<GoalView | undefined>>;
    pause: (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    resume: (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
  }
  interface TypertRemoteMap {
    'goals/clear': (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalRef>>;
    'goals/complete': (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    'goals/create': (agentId: SessionId, request: CreateGoalRequest) => Promise<RemoteResult$1<CreateGoalResult>>;
    'goals/edit': (agentId: SessionId, ref: GoalRef, request: EditGoalRequest) => Promise<RemoteResult$1<GoalView>>;
    'goals/get': (agentId: SessionId) => Promise<RemoteResult$1<GoalView | undefined>>;
    'goals/pause': (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    'goals/resume': (agentId: SessionId, ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
  }
  interface TypertRemoteNamespaceMap {
    'goals': TypertRemoteNamespace$676f616c73;
  }
  interface TypertRemoteScopeMap {
    'agent:goals/clear': (ref: GoalRef) => Promise<RemoteResult$1<GoalRef>>;
    'agent:goals/complete': (ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    'agent:goals/create': (request: CreateGoalRequest) => Promise<RemoteResult$1<CreateGoalResult>>;
    'agent:goals/edit': (ref: GoalRef, request: EditGoalRequest) => Promise<RemoteResult$1<GoalView>>;
    'agent:goals/get': () => Promise<RemoteResult$1<GoalView | undefined>>;
    'agent:goals/pause': (ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
    'agent:goals/resume': (ref: GoalRef) => Promise<RemoteResult$1<GoalView>>;
  }
}
//#endregion
//#region ../../llm/llm/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$6c6c6d {
    discoverModels: (settingsNs: string, request: LlmModelDiscoveryRequest, signal?: AbortSignal) => Promise<RemoteResult$1<LlmDiscoveredModel[]>>;
    listConfigurableProviders: () => Promise<RemoteResult$1<LlmConfigurableProvider[]>>;
    listProviders: () => Promise<RemoteResult$1<LlmProviderInfo[]>>;
  }
  interface TypertRemoteMap {
    'llm/discoverModels': (settingsNs: string, request: LlmModelDiscoveryRequest, signal?: AbortSignal) => Promise<RemoteResult$1<LlmDiscoveredModel[]>>;
    'llm/listConfigurableProviders': () => Promise<RemoteResult$1<LlmConfigurableProvider[]>>;
    'llm/listProviders': () => Promise<RemoteResult$1<LlmProviderInfo[]>>;
  }
  interface TypertRemoteNamespaceMap {
    'llm': TypertRemoteNamespace$6c6c6d;
  }
}
//#endregion
//#region ../../host/plugin-inventory/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$706c7567696e496e76656e746f7279 {
    list: () => Promise<RemoteResult$1<PluginInventorySnapshot>>;
  }
  interface TypertRemoteMap {
    'pluginInventory/list': () => Promise<RemoteResult$1<PluginInventorySnapshot>>;
  }
  interface TypertRemoteNamespaceMap {
    'pluginInventory': TypertRemoteNamespace$706c7567696e496e76656e746f7279;
  }
}
//#endregion
//#region ../../feedback/command-feedback/lib/types/types.d.ts
/** One of the fixed feedback categories; the ids are durable log vocabulary. */
type FeedbackCategory = 'task-result' | 'instruction-following' | 'product-interaction' | 'service-stability' | 'resource-cost' | 'security-privacy-permission' | 'other';
/**
 * One recorded human remark about a Session. Both members are optional: a
 * submission with neither still records that the human asked for the
 * Session to be reviewed, which is what authorizes log delivery.
 */
interface FeedbackRecord {
  /** Free-text remark with surrounding whitespace removed; never empty when present. */
  readonly text?: string;
  /** Category the human filed the remark under. */
  readonly category?: FeedbackCategory;
}
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * One recorded human remark about this session. Log-only and independent
     * of its trigger; it never enters model context or derived history.
     */
    'feedback/record': FeedbackRecord;
  }
}
/** Record one Session-level remark through the Host Remote. */
interface SessionFeedbackRecordRequest {
  /** Live Session the remark describes. */
  readonly sessionId: SessionId;
  /** Free-text remark; blank text is recorded as absent. */
  readonly text?: string;
  /** Category the human filed the remark under. */
  readonly category?: FeedbackCategory;
}
/** Stable postcondition of a recorded remark. */
interface SessionFeedbackRecordValue {
  /** The remark is appended to the Session log; flushing follows the Session's own schedule. */
  readonly recorded: true;
}
/** No live Session carries the requested id. */
interface SessionFeedbackSessionNotFound {
  readonly code: 'session-not-found';
  readonly sessionId: SessionId;
}
/** Result returned by the `sessionFeedback.record` operation. */
type SessionFeedbackRecordResult = {
  readonly ok: true;
  readonly value: SessionFeedbackRecordValue;
} | {
  readonly ok: false;
  readonly error: SessionFeedbackSessionNotFound;
};
//#endregion
//#region ../../feedback/message-feedback/lib/types/types.d.ts
/** Opaque compare-and-set token for one exact feedback item revision. */
type MessageFeedbackVersion = Branded<'MessageFeedbackVersion'>;
/** The human's overall judgment of one assistant message. */
type MessageFeedbackRating = 'positive' | 'negative';
/** One current feedback value and its opaque mutation token. */
interface MessageFeedbackItem {
  /** Stable identity of the assistant message inside the owning Session. */
  readonly messageId: MessageId;
  /** Overall positive or negative judgment. */
  readonly rating: MessageFeedbackRating;
  /** Optional explanation, preserved verbatim after validation. */
  readonly note?: string;
  /** Category the human filed a negative judgment under. */
  readonly category?: FeedbackCategory;
  /** Equality-only token replaced by every material create or update. */
  readonly version: MessageFeedbackVersion;
  /** Host-assigned creation time in Unix epoch milliseconds. */
  readonly createdAt: number;
  /** Host-assigned time of the most recent material update. */
  readonly updatedAt: number;
}
/** A material creation or edit, retaining its complete current value. */
interface MessageFeedbackPut {
  /** Owning Session; inherited feedback in a fork belongs to its parent. */
  readonly sessionId: SessionId;
  /** Value after this mutation, including the original creation time. */
  readonly item: MessageFeedbackItem;
}
/** A material deletion of one current feedback item. */
interface MessageFeedbackDelete {
  /** Session that owns the deleted feedback. */
  readonly sessionId: SessionId;
  /** Message whose feedback was removed. */
  readonly messageId: MessageId;
}
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /** Log-only human feedback; never enters model history. */
    'feedback/message-put': MessageFeedbackPut;
    /** Log-only deletion; earlier ratings and notes remain in the log. */
    'feedback/message-delete': MessageFeedbackDelete;
  }
}
/** Read all message feedback belonging to one persisted Session lifecycle. */
interface MessageFeedbackListRequest {
  /** Session whose feedback events should be read. */
  readonly sessionId: SessionId;
}
/** Current feedback values for one Session, in first-creation order. */
interface MessageFeedbackListValue {
  /** Fresh immutable item snapshots. */
  readonly items: readonly MessageFeedbackItem[];
}
/** Create or replace feedback for one assistant message. */
interface MessageFeedbackPutRequest {
  /** Persisted Session that owns the target message. */
  readonly sessionId: SessionId;
  /** Target assistant-message identity. */
  readonly messageId: MessageId;
  /** Desired overall judgment. */
  readonly rating: MessageFeedbackRating;
  /** Optional non-blank explanation. */
  readonly note?: string;
  /** Optional category; absent keeps the item uncategorized. */
  readonly category?: FeedbackCategory;
  /** Observed item version, or `null` to require that no item exists. */
  readonly ifVersion: MessageFeedbackVersion | null;
}
/** Delete feedback for one message after observing its current version. */
interface MessageFeedbackDeleteRequest {
  /** Session that owns the feedback. */
  readonly sessionId: SessionId;
  /** Message whose feedback should be absent after this operation. */
  readonly messageId: MessageId;
  /** Observed item version; ignored when the item is already absent. */
  readonly ifVersion: MessageFeedbackVersion;
}
/** Idempotent deletion acknowledgement. */
interface MessageFeedbackDeleteValue {
  /** Stable postcondition shared by the first deletion and every retry. */
  readonly absent: true;
}
/** No persisted Session header exists for the requested id. */
interface MessageFeedbackSessionNotFound {
  readonly code: 'session-not-found';
  readonly sessionId: SessionId;
}
/** The id does not name a derived, append-origin assistant message. */
interface MessageFeedbackTargetNotFound {
  readonly code: 'target-not-found';
  readonly sessionId: SessionId;
  readonly messageId: MessageId;
}
/** A material mutation did not match the addressed item's current version. */
interface MessageFeedbackVersionConflict {
  readonly code: 'version-conflict';
  /** Authoritative current item, or `null` when it does not exist. */
  readonly current: MessageFeedbackItem | null;
}
/** A supplied note contains no non-whitespace character. */
interface MessageFeedbackNoteBlank {
  readonly code: 'note-blank';
}
/** A supplied note exceeds the configured UTF-8 byte limit. */
interface MessageFeedbackNoteTooLarge {
  readonly code: 'note-too-large';
  readonly maxBytes: number;
  readonly actualBytes: number;
}
/** Failures shared by the public message-feedback operations. */
type MessageFeedbackFailure = MessageFeedbackSessionNotFound | MessageFeedbackTargetNotFound | MessageFeedbackVersionConflict | MessageFeedbackNoteBlank | MessageFeedbackNoteTooLarge;
/** Successful public operation result. */
interface MessageFeedbackSuccess<T> {
  readonly ok: true;
  readonly value: T;
}
/** Rejected public operation result with a stable business failure. */
interface MessageFeedbackRejected<E extends MessageFeedbackFailure> {
  readonly ok: false;
  readonly error: E;
}
/** Result returned by the message-feedback `list` operation. */
type MessageFeedbackListResult = MessageFeedbackSuccess<MessageFeedbackListValue> | MessageFeedbackRejected<MessageFeedbackSessionNotFound>;
/** Result returned by the message-feedback `put` operation. */
type MessageFeedbackPutResult = MessageFeedbackSuccess<MessageFeedbackItem> | MessageFeedbackRejected<MessageFeedbackSessionNotFound | MessageFeedbackTargetNotFound | MessageFeedbackVersionConflict | MessageFeedbackNoteBlank | MessageFeedbackNoteTooLarge>;
/** Result returned by the message-feedback `delete` operation. */
type MessageFeedbackDeleteResult = MessageFeedbackSuccess<MessageFeedbackDeleteValue> | MessageFeedbackRejected<MessageFeedbackSessionNotFound | MessageFeedbackVersionConflict>;
//#endregion
//#region ../../feedback/message-feedback/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$6d657373616765466565646261636b {
    delete: (request: MessageFeedbackDeleteRequest) => Promise<RemoteResult$1<MessageFeedbackDeleteResult>>;
    list: (request: MessageFeedbackListRequest) => Promise<RemoteResult$1<MessageFeedbackListResult>>;
    put: (request: MessageFeedbackPutRequest) => Promise<RemoteResult$1<MessageFeedbackPutResult>>;
  }
  interface TypertRemoteMap {
    'messageFeedback/delete': (request: MessageFeedbackDeleteRequest) => Promise<RemoteResult$1<MessageFeedbackDeleteResult>>;
    'messageFeedback/list': (request: MessageFeedbackListRequest) => Promise<RemoteResult$1<MessageFeedbackListResult>>;
    'messageFeedback/put': (request: MessageFeedbackPutRequest) => Promise<RemoteResult$1<MessageFeedbackPutResult>>;
  }
  interface TypertRemoteNamespaceMap {
    'messageFeedback': TypertRemoteNamespace$6d657373616765466565646261636b;
  }
}
//#endregion
//#region ../../feedback/command-feedback/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$73657373696f6e466565646261636b {
    record: (request: SessionFeedbackRecordRequest) => Promise<RemoteResult$1<SessionFeedbackRecordResult>>;
  }
  interface TypertRemoteMap {
    'sessionFeedback/record': (request: SessionFeedbackRecordRequest) => Promise<RemoteResult$1<SessionFeedbackRecordResult>>;
  }
  interface TypertRemoteNamespaceMap {
    'sessionFeedback': TypertRemoteNamespace$73657373696f6e466565646261636b;
  }
}
//#endregion
//#region ../../client/file-upload/lib/types/types.d.ts
/** Canonical encoded upload accepted by the Remote fallback. */
interface EncodedFileUploadRequest {
  /** Canonical base64 encoding of the exact file bytes. */
  readonly data: string;
  /** Optional display name; the Host sanitizes it into the stored leaf name. */
  readonly name?: string;
}
/** Durable receipt for one staged file upload. */
interface FileUploadValue {
  /** Per-upload authority accepted only inside the receiving Agent scope. */
  readonly receiptId: FileUploadReceiptId;
  readonly file: FileAttachmentRef;
}
/** Host-minted authority for one staged file upload in one Agent scope. */
type FileUploadReceiptId = Branded<'file-upload-receipt-id'>;
//#endregion
//#region ../../client/file-upload/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$66696c6555706c6f616473 {
    upload: (agentId: SessionId, request: EncodedFileUploadRequest, signal?: AbortSignal) => Promise<RemoteResult$1<FileUploadValue>>;
  }
  interface TypertRemoteMap {
    'fileUploads/upload': (agentId: SessionId, request: EncodedFileUploadRequest, signal?: AbortSignal) => Promise<RemoteResult$1<FileUploadValue>>;
  }
  interface TypertRemoteNamespaceMap {
    'fileUploads': TypertRemoteNamespace$66696c6555706c6f616473;
  }
  interface TypertRemoteScopeMap {
    'agent:fileUploads/upload': (request: EncodedFileUploadRequest, signal?: AbortSignal) => Promise<RemoteResult$1<FileUploadValue>>;
  }
}
//#endregion
//#region ../../context/session-reference/lib/types/types.d.ts
/** Durable source session, cited event seqs, and snapshot facts for prepared cross-session context. */
interface SessionReferenceSource {
  kind: 'session-reference';
  /** Material lifted out of another session's log (`recall` context form). */
  form: 'recall';
  version: 1;
  references: {
    sessionId: string;
    label: string; /** Source Session format generation; absence identifies version 0. */
    capturedFormatVersion?: number;
    capturedThroughSeq: OptionalSessionSeq;
    compacted: boolean;
    originalMessages: number;
    retainedMessages: number;
    omittedMessages: number;
    omittedBytes: number;
    truncated: boolean;
    inputIndex: number;
  }[];
}
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'session-reference': SessionReferenceSource;
  }
}
/** One source session selected by a host. */
/** One host-facing candidate from exact session metadata. */
interface SessionReferenceCandidate {
  /** Opaque source session identity. */
  sessionId: SessionId;
  /** Latest log-backed title, falling back to the opaque session id. */
  label: string;
  /** Source session working directory, when recorded. */
  cwd?: string;
  /**
   * True when {@link SessionReferenceCandidate.cwd} is recorded and equals the
   * requesting agent's. Hosts that only surface a distinguishing location
   * read this instead of comparing paths they never received.
   */
  sameWorkspace: boolean;
  /** Source session creation time in Unix epoch milliseconds. */
  createdAt: number;
}
/** One discovery candidate carrying its canonical prompt mention. */
interface SessionReferenceMentionCandidate extends SessionReferenceCandidate {
  /** Canonical `@[label](dsh-session:…)` mention serialized into the prompt draft. */
  mention: string;
}
//#endregion
//#region ../../context/session-reference/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$73657373696f6e5265666572656e63655265736f6c766572 {
    candidates: (agentId: SessionId, query: string, signal?: AbortSignal) => Promise<RemoteResult$1<SessionReferenceMentionCandidate[]>>;
  }
  interface TypertRemoteMap {
    'sessionReferenceResolver/candidates': (agentId: SessionId, query: string, signal?: AbortSignal) => Promise<RemoteResult$1<SessionReferenceMentionCandidate[]>>;
  }
  interface TypertRemoteNamespaceMap {
    'sessionReferenceResolver': TypertRemoteNamespace$73657373696f6e5265666572656e63655265736f6c766572;
  }
  interface TypertRemoteScopeMap {
    'agent:sessionReferenceResolver/candidates': (query: string, signal?: AbortSignal) => Promise<RemoteResult$1<SessionReferenceMentionCandidate[]>>;
  }
}
//#endregion
//#region ../../subagent/subagent/lib/types/control-types.d.ts
/**
 * Client-minted identity of one browser prompt, persisted on the exact accepted
 * message. It carries the Session Controller's `session-request-id` brand so a
 * subagent prompt and an ordinary Session prompt share one identity
 * vocabulary; that package depends on this one, so the brand is spelled here
 * rather than imported.
 */
type SubagentPromptRequestId = Branded<'session-request-id'>;
/**
 * One durable direct-child row, ordered by header `createdAt` with ties broken
 * on id. Only a candidate whose durable header has `origin: 'subagent'` is
 * interpreted. A served `subagent` projection value produces a `child`; a
 * settled candidate whose fold served no identity produces a `diagnostic`; a
 * running candidate without one is omitted — its descriptor may not be
 * appended yet (the creation window). Diagnostics relay the projection fold's
 * outcome or a failed read, never a per-child event scan, and never expose
 * model-hidden descriptor content.
 */
type SubagentListEntry = {
  readonly kind: 'child'; /** The durable child session id, stable across Activations. */
  readonly id: SessionId;
  /**
   * Whether the child is live at the moment its reader sampled it: the
   * durable listing reads the Session store (`running` means the logical
   * record is resident, `inactive` that it exists only in persistence),
   * while the browser catalog re-samples the child's Agent driver. Neither
   * encodes a durable outcome, and a continuable child may still reject
   * delivery as an ownership conflict.
   */
  readonly activity: 'running' | 'inactive'; /** Whether a direct descendant has durable `origin: 'subagent'`. */
  readonly hasChildren: boolean;
} & ({
  /** A terminal one-shot child. */readonly mode: 'one-shot'; /** Optional durable creation label from the child's descriptor. */
  readonly label?: string;
} | {
  /** A resumable conversation. */readonly mode: 'continuable'; /** Durable creation label from the child's descriptor. */
  readonly label: string;
}) | {
  readonly kind: 'diagnostic'; /** The candidate's session id. */
  readonly id: SessionId;
  /**
   * Why the candidate has no `child` row: `corrupt` for a settled candidate
   * whose projection fold served no identity (a missing, malformed, or
   * unrecognized-version descriptor — deliberately undistinguished), and
   * for any candidate whose log makes a registered unit's fold or schema
   * throw (deterministic data damage, contained per child); `unavailable`
   * when the candidate's Session observation was absent or transiently
   * unreadable (retried on the next listing). `unsupported` is never produced; it remains in the
   * union for consumers that route on it.
   */
  readonly reason: 'corrupt' | 'unsupported' | 'unavailable';
};
/** Complete direct-child catalog plus the delivery-time parent availability hint. */
interface SubagentCatalog {
  readonly entries: readonly SubagentListEntry[];
  readonly parentAvailable: boolean;
}
/** Durable parent/child address that selects subagent transport in the client. */
type SubagentAddress = {
  readonly parentSessionId: SessionId;
  readonly childSessionId: SessionId;
} & ({
  readonly mode: 'one-shot';
} | {
  readonly mode: 'continuable';
});
/** One human message addressed to a continuable direct child. */
interface SubagentPromptRequest {
  /** Identity persisted on the accepted message, minted before the call. */
  readonly requestId: SubagentPromptRequestId;
  readonly parentSessionId: SessionId;
  readonly childSessionId: SessionId;
  /** Required discriminator retained from the browser control address. */
  readonly mode: 'continuable';
  /** Whether this message queues a later turn or targets the nearest step. */
  readonly delivery: 'queue' | 'steer';
  /**
   * Browser prompt parts delivered as the child's user message. The Host
   * admits and persists image parts before delivery, so the wire never
   * carries a durable attachment reference the caller could fabricate.
   */
  readonly content: readonly PromptContentPart$1[];
  /** Optional browser zone sampled for this exact human prompt. */
  readonly clientTimeZone?: string;
}
/** Inbox identity returned once the continuation accepts one human message. */
interface SubagentPromptReceipt {
  readonly messageId: MessageId;
}
/** Uniform acknowledgement that one interrupt request was admitted. */
interface SubagentInterruptReceipt {
  readonly accepted: true;
}
/**
 * Failure details the control surface answers with. Catalog reads, prompts,
 * and interrupts share this vocabulary with the Client Remote result.
 */
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** A browser-supplied zone is neither UTC nor a canonical IANA name. */
    'subagent/invalid-time-zone': {
      readonly value: string;
    };
    /** No live Agent carries the addressed parent session. */
    'subagent/parent-unavailable': {
      readonly parentSessionId: SessionId;
    };
    /** The addressed child cannot take a continuation. */
    'subagent/not-resumable': {
      readonly childSessionId: SessionId;
    };
    /** The claimed parent does not own the addressed child. */
    'subagent/unauthorized': {
      readonly childSessionId: SessionId;
    };
    /** Image admission or model image-capability refusal. */
    'subagent/attachment-invalid': {
      readonly reason: string;
    };
    /** The child exists but its inbox cannot admit the message now. */
    'subagent/delivery-unavailable': {
      readonly childSessionId: SessionId;
    };
    /** The deployment mounts no session-projection registry. */
    'subagent/projections-unavailable': {};
  }
} //# sourceMappingURL=control-types.d.ts.map
//#endregion
//#region ../../subagent/subagent/lib/types/projection-types.d.ts
/** One current direct-child discovery row materialized from parent facts. */
type SubagentCatalogEntry = {
  readonly id: SessionId;
  readonly createdAt: number;
} & ({
  readonly mode: 'one-shot';
  readonly label?: string;
} | {
  readonly mode: 'continuable';
  readonly label: string;
});
/** Durable active-turn timing for one descriptor-backed child session. */
interface SubagentTimingProjection {
  /** Milliseconds accumulated across completed turns after the child's own descriptor. */
  settledMs: number;
  /** Same-cut bounds of the currently open turn, when one has not reached `turn/end`. */
  active?: {
    /** Start of the open turn. */since: number; /** Latest event time folded into this projection cut. */
    through: number;
  };
}
/**
 * Durable identity of one descriptor-backed subagent session: lifecycle mode
 * plus creation label, folded last-wins from `subagent/descriptor` events.
 * Label strength follows the descriptor schema: a continuable child always
 * carries one, a one-shot child may omit it.
 */
type SubagentIdentityProjection = {
  /** A terminal one-shot child. */mode: 'one-shot'; /** Optional durable creation label from the child's descriptor. */
  label?: string;
  /**
   * Seq of the `subagent/descriptor` event this identity was folded from.
   * `session.isOwnSeq(seq)` proves the identity comes from the child's
   * OWN log suffix — where a descriptor is immutable once appended — and
   * not from a fork seed's replayed ancestor descriptor.
   */
  seq: SessionSeq;
} | {
  /** A resumable conversation. */mode: 'continuable'; /** Durable creation label from the child's descriptor. */
  label: string; /** Seq of the folded descriptor event; see the one-shot arm for the own-suffix proof. */
  seq: SessionSeq;
};
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionMap {
    /** Direct children in parent catalog event order, excluding fork-inherited facts. */
    subagentCatalog: SubagentCatalogEntry[];
    /** Active-turn duration for a descriptor-backed subagent session. */
    subagentTiming: SubagentTimingProjection;
    /**
     * Identity of a descriptor-backed subagent session. `null` ⟺ no valid
     * descriptor (missing, malformed, or unrecognized-version — deliberately
     * undistinguished). The sentinel is deliberately serializable: a
     * value pushed over JSON transports must survive `JSON.stringify`
     * losslessly, where an `undefined` field would be dropped and a stale
     * identity would survive on the receiving side. The entry itself stays
     * non-optional.
     */
    subagent: SubagentIdentityProjection | null;
  }
} //# sourceMappingURL=projection-types.d.ts.map
//#endregion
//#region ../../subagent/subagent/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$7375626167656e7473 {
    interruptByParent: (childSessionId: SessionId, parentSessionId: SessionId, mode: 'continuable') => Promise<RemoteResult$1<SubagentInterruptReceipt>>;
    list: (parentSessionId: SessionId, signal?: AbortSignal) => Promise<RemoteResult$1<SubagentCatalog>>;
    prompt: (request: SubagentPromptRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SubagentPromptReceipt>>;
  }
  interface TypertRemoteMap {
    'subagents/interruptByParent': (childSessionId: SessionId, parentSessionId: SessionId, mode: 'continuable') => Promise<RemoteResult$1<SubagentInterruptReceipt>>;
    'subagents/list': (parentSessionId: SessionId, signal?: AbortSignal) => Promise<RemoteResult$1<SubagentCatalog>>;
    'subagents/prompt': (request: SubagentPromptRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SubagentPromptReceipt>>;
  }
  interface TypertRemoteNamespaceMap {
    'subagents': TypertRemoteNamespace$7375626167656e7473;
  }
}
//#endregion
//#region ../../session/session-projection/lib/types/types.d.ts
/**
 * Pure-type outlet of the session-projection Service Definition: the one projection type
 * table, importable from client aggregates without dragging the host-side
 * cordis Context merges of the package root (dsh-agent → dsh-session). Domain
 * packages may declare-merge through either the package root or this outlet —
 * re-export preserves symbol identity, so both land on the same table.
 *
 * @module @deepseek-ai/dsh-session-projection/types
 */
/**
 * The merge-extensible client projection table shared by wire blocks, client
 * cells, and React hooks. Domain packages merge their client-visible key here;
 * values are wire-JSON whole values. How a value is rendered is the slot
 * system's business, never this layer's.
 */
interface SessionProjectionMap {}
//#endregion
//#region ../../jobs/jobs/lib/types/brand.d.ts
/**
 * Identifies a background job. The registry generates `<kind>-N`; predictable
 * ids rely on owner authorization rather than secrecy.
 */
type JobId = Branded<'JobId'>;
/**
 * Brand a string as a {@link JobId}.
 * @param id - the raw job-id string (the registry generates `<kind>-N`).
 * @returns the same string, branded; no validation is performed.
 */
declare function JobId(id: string): JobId;
//#endregion
//#region ../../workspace/workspace/lib/types/types.d.ts
/**
 * Identifies one workspace record. A generated uuid, never the path: path
 * normalization rewrites paths, and a reference anchor must stay stable.
 */
type WorkspaceId = Branded<'WorkspaceId'>;
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** No registration carries that Workspace identity. */
    'workspace/not-found': {
      readonly workspaceId: WorkspaceId;
    };
  }
}
/**
 * One workspace: a stable id over an existing directory, a display title, and
 * an ordered candidate account of sessions. Membership requires both an id in
 * that account and a session header whose canonical cwd equals the workspace
 * path. Consumers only see this interface; the implementation stays private.
 */
//#endregion
//#region ../session-controller/lib/types/types.d.ts
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    /** Host state persisted for cold Session list summaries. */
    sessionListMetadata: SessionListMetadata;
    /** Host state for the boot-constant image-limit view. */
    imageLimits: null;
    /** Durable model selection already used by a request and still pending for a later request. */
    modelSelection: ModelSelectionProjectionState;
  }
  interface SessionProjectionMap {
    /** Persisted facts used to summarize a Session without activating it. */
    sessionListMetadata: SessionListMetadata;
    /** Image-intake limits enforced by the Session prompt endpoint. */
    imageLimits: ImageAttachmentLimits;
    /** Durable model selection already used and selected for the next request. */
    modelSelection: ModelSelectionProjection;
  }
}
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * Complete validated model selection requested for subsequent prompt
     * assembly. Log-only: it never enters derived model history.
     */
    'model/selection': ModelSelection;
  }
}
/** Persisted hints used to summarize a cold Session. */
interface SessionListMetadata {
  /** Whether the folded prefix contains no turn. */
  readonly blank: boolean;
  /** Latest human-authored prompt time in the folded prefix. */
  readonly lastPromptAt: number | null;
}
/** Every available cached wire value used as partial, possibly stale Session-list hints. */
interface SessionProjectionHints {
  readonly asOfSeq: number;
  /** Provider-validated values present in the cache; omitted keys remain unknown. */
  readonly values: SessionProjectionValues;
}
/** Complete projection values at an exact Session event cursor. */
interface SessionProjectionBaseline {
  readonly asOfSeq: number;
  /** Provider-validated values; omitted keys are absent capabilities at this cut. */
  readonly values: SessionProjectionValues;
}
/** Typed known projections plus JSON-safe values contributed outside this compilation face. */
type SessionProjectionValues = Partial<SessionProjectionMap> & Readonly<Record<string, SessionProjectionValue>>;
/**
 * Browser-submitted prompt content; the Host promotes image bytes to durable
 * references. File parts carry the opaque receipt returned by a preceding
 * `uploadFile` call on the same Session.
 */
type PromptContentPart = {
  readonly type: 'text';
  readonly text: string;
} | {
  readonly type: 'image';
  readonly mediaType: ImageMediaType;
  readonly data: string;
  readonly name?: string;
} | {
  readonly type: 'file';
  readonly receiptId: Branded<'file-upload-receipt-id'>;
};
/** Complete model selection for one Session. */
interface ModelSelection {
  readonly provider: string;
  readonly model: string;
  readonly reasoningEffort?: string;
}
/** Host fold state for durable model selection. */
interface ModelSelectionProjectionState {
  /** Selection consumed by the latest recorded model request. */
  readonly lastUsed: ModelSelection | null;
  /** Later user selection not yet consumed by a matching model request. */
  readonly pending: ModelSelection | null;
}
/** Client view of the durable model-selection fold. */
interface ModelSelectionProjection {
  /** Selection consumed by the latest recorded model request. */
  readonly lastUsed: ModelSelection | null;
  /** Selection the next request should use, falling back to {@link lastUsed}. */
  readonly next: ModelSelection | null;
}
/** One adapter-owned reasoning effort for an exact model route. */
interface ModelReasoningEffort {
  readonly id: string;
  readonly name: string;
  readonly description?: string;
}
/** Selectable reasoning metadata for one exact model route. */
interface ModelReasoning {
  readonly efforts: readonly ModelReasoningEffort[];
  readonly defaultEffort?: string;
}
/** One model displayed inside its provider group. */
interface ModelCatalogModel {
  readonly id: string;
  readonly name: string;
  readonly description?: string;
  readonly reasoning?: ModelReasoning;
}
/** One provider and its successfully loaded model catalog. */
interface ModelProviderGroup {
  readonly id: string;
  readonly name: string;
  readonly models: readonly ModelCatalogModel[];
}
/** One provider whose model catalog lookup failed. */
interface ModelCatalogFailure {
  readonly id: string;
  readonly name: string;
  readonly message: string;
}
/** Host-generation model catalog and the default used by unconfigured Sessions. */
interface ModelCatalog {
  readonly default: ModelSelection;
  /** Provider routes currently able to serve a request, including empty catalogs. */
  readonly routableProviders: readonly string[];
  readonly groups: readonly ModelProviderGroup[];
  readonly failures: readonly ModelCatalogFailure[];
}
/** One client-requested mutation of a still-pending queue item. */
type QueueAction = {
  readonly kind: 'edit'; /** Non-empty text-only replacement content. */
  readonly content: readonly ContentBlock[];
} | {
  readonly kind: 'remove';
} | {
  readonly kind: 'steer';
};
/** One Session list entry. */
interface SessionSummary {
  readonly sessionId: SessionId;
  readonly updatedAt: number;
  readonly running: boolean;
  readonly blank: boolean;
  readonly parentSessionId?: SessionId;
  readonly origin?: 'subagent';
  readonly cwd?: string;
  readonly projections?: SessionProjectionHints;
}
/** One session-content search result. */
interface SessionSearchItem {
  readonly sessionId: SessionId;
  readonly snippet: string;
}
/** Maximum number of Sessions returned by one search. */
declare const SESSION_SEARCH_RESULT_LIMIT = 20;
/** Maximum search snippet length in Unicode code points. */
declare const SESSION_SEARCH_SNIPPET_MAX_CODE_POINTS = 240;
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** The requested sequence does not contain a deferred tool result. */
    'session/history-detail-not-found': {
      readonly seq: SessionSeq;
    };
    'session/model-unavailable': {
      readonly provider: string;
      readonly model: string;
    };
    'session/conflict': {
      readonly sessionId: SessionId;
      readonly requestedCwd: string;
      readonly existingCwd?: string;
    };
    'session/agent-busy': {
      readonly reason: string;
    };
    'session/invalid-time-zone': {
      readonly value: string;
    };
    'session/workspace-attach-failed': {
      readonly sessionId: SessionId;
      readonly workspaceId: string;
    };
    'agent-preset/conflict': {
      readonly sessionId: SessionId;
      readonly requestedPreset: string;
      readonly existingPreset?: string;
    };
    'session/attachment-invalid': {
      readonly reason: string;
    };
    'session/queue-item-not-found': {
      readonly itemId: MessageId;
    };
    'session/steer-unavailable': {
      readonly itemId: MessageId;
    };
    'session/title-invalid': {
      readonly sessionId: SessionId;
    };
    'session/fork-unavailable': {
      readonly sessionId: SessionId;
    };
    'subagent/not-found': {
      readonly parentSessionId: SessionId;
      readonly childSessionId: SessionId;
    };
    'subagent/catalog-diagnostic': {
      readonly parentSessionId: SessionId;
      readonly childSessionId: SessionId;
      readonly reason: 'corrupt' | 'unsupported' | 'unavailable';
    };
  }
}
/** Session-addressed request for the human-invocable skill catalog. */
interface SkillListRequest {
  readonly sessionId: SessionId;
}
/** One skill available to the Session's human-facing composer. */
interface SkillEntry {
  /** Kebab-case identifier referenced as `/name`. */
  readonly name: string;
  /** Short routing description. */
  readonly description: string;
  /** Optional extra routing guidance. */
  readonly whenToUse?: string;
  /** Whether the same skill is also advertised to the model. */
  readonly modelInvocable: boolean;
}
/** Human-invocable skills visible through one Session's composition. */
interface SkillListValue {
  readonly skills: readonly SkillEntry[];
}
/** Opaque cursor in stable Session recency order. */
type SessionListCursor = import('@deepseek-ai/dsh-brand').Branded<'session-list-cursor'>;
/** Session list request. */
interface SessionListRequest {
  readonly cursor?: SessionListCursor;
  readonly includeSessionId?: SessionId;
}
/** Session list response value. */
interface SessionListValue {
  readonly items: readonly SessionSummary[];
  readonly hasMore: boolean;
  readonly nextCursor?: SessionListCursor;
}
/** Session search request. */
interface SessionSearchRequest {
  readonly query: string;
}
/** Session search response value. */
interface SessionSearchValue {
  readonly items: readonly SessionSearchItem[];
  readonly hasMore: boolean;
}
/** Session creation or explicit-id adoption request. */
interface SessionCreateRequest {
  readonly workspaceId?: WorkspaceId;
  readonly cwd?: string;
  readonly sessionId?: SessionId;
  readonly agentPreset?: string;
}
/** Session creation response value. */
interface SessionCreateValue {
  readonly sessionId: SessionId;
  readonly agentPreset?: string;
}
/** Session model-selection request. */
interface SessionSelectModelRequest extends ModelSelection {
  readonly sessionId: SessionId;
}
/** Accepted model selection after Host resolution. */
interface SessionSelectModelValue {
  readonly selected: ModelSelection;
}
/** Session rename request. */
interface SessionRenameRequest {
  readonly sessionId: SessionId;
  readonly title: string;
}
/** Normalized title and the durable event position that committed it. */
interface SessionRenameValue {
  readonly title: string;
  readonly seq: number;
}
/** Session fork request. */
interface SessionForkRequest {
  readonly sessionId: SessionId;
  readonly atSeq?: number;
}
/** Identity of a newly forked Session. */
interface SessionForkValue {
  readonly sessionId: SessionId;
}
/** Session prompt request. */
interface SessionPromptRequest {
  /** Client-minted identity persisted on the exact accepted user message. */
  readonly requestId: SessionRequestId;
  readonly sessionId: SessionId;
  readonly mode: 'queue' | 'steer';
  /** At least one non-whitespace text part or attachment. */
  readonly content: readonly PromptContentPart[];
  readonly clientTimeZone?: string;
}
/** Receipt after one prompt enters the target Agent inbox. */
interface SessionPromptValue {
  readonly accepted: true;
}
/** Durable image read request. */
interface SessionAttachmentRequest {
  readonly sessionId: SessionId;
  readonly attachmentId: AttachmentId;
}
/** Durable image read response value. */
interface SessionAttachmentValue {
  readonly attachment: ImageAttachmentRef;
  readonly data: string;
}
/** Pending queue mutation request. */
interface SessionUpdateQueueRequest {
  readonly sessionId: SessionId;
  readonly itemId: MessageId;
  readonly action: QueueAction;
}
/** Receipt after one pending queue mutation commits. */
interface SessionUpdateQueueValue {
  readonly accepted: true;
}
/** Active-turn cancellation request. */
interface SessionCancelRequest {
  readonly sessionId: SessionId;
}
/** Receipt after cancellation is admitted to the live Agent. */
interface SessionCancelValue {
  readonly accepted: true;
}
/** Request to open one path prepared by a Session-aware caller on the Host desktop. */
interface SessionOpenWorkspacePathRequest {
  /** File-manager navigation when requested; omission uses the default application. */
  readonly action?: 'reveal';
  /** Path after best-effort Session workspace resolution, in Host filesystem syntax. */
  readonly path: string;
}
/** Confirmation that the Host handed a workspace path to its native opener. */
interface SessionOpenWorkspacePathValue {
  readonly opened: true;
}
/** Client-minted prompt identity used to reconcile optimistic and durable messages. */
type SessionRequestId = Branded<'session-request-id'>;
declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    /** Browser prompt correlation and optional Host-validated time zone. */
    'user-rpc': {
      kind: 'user';
      rpcId: SessionRequestId;
      clientTimeZone?: string;
    };
  }
}
/** Durable identity selecting an ordinary Session or one direct subagent child. */
type SessionAddress = {
  readonly kind: 'session';
  readonly sessionId: SessionId;
} | {
  readonly kind: 'subagent';
  readonly parentSessionId: SessionId;
  readonly childSessionId: SessionId;
  readonly mode: 'one-shot' | 'continuable';
};
/** One raw Session event in the Remote journal. */
interface SessionEventEntry {
  readonly type: 'event';
  readonly event: SessionWireEvent;
  /** The original result is fetched on demand through historyDetail. */
  readonly detail?: {
    readonly kind: 'tool-result';
    readonly bytes: number;
  };
}
/** Current logical Session metadata carried on the browser wire. */
interface SessionWireHeader {
  readonly version: number;
  readonly id: SessionId;
  readonly createdAt: number;
  readonly cwd?: string;
  readonly parentSession?: SessionId;
  /** Whether the Session contains a fork-inherited prefix. */
  readonly isSeeded: boolean;
  readonly origin?: 'subagent';
  readonly delegationDepth?: number;
  readonly agentPreset?: string;
}
/** Browser wire surface operation; replacement endpoints are earlier event seqs in surface order. */
type SessionWireSurfaceOp = 'append' | {
  readonly op: 'replace';
  readonly startSeq: number;
  readonly endSeq: number;
};
/** One history-page record with compact Assistant streams embedded inside events. */
type SessionHistoryRecord = SessionEventEntry;
/**
 * Exact Session event envelope accepted by the Client journal adapter.
 * Surface events require surfaceOp; only non-Assistant surface events may cite earlier sources.
 * Durable readers own recognition of merge-extensible event names.
 */
interface SessionWireEvent {
  readonly type: string;
  readonly seq: number;
  readonly time: number;
  readonly data: JsonValue$1;
  readonly ignorable?: true;
  /** Earlier sources on current surface events; opaque JSON on unknown ignorable events. */
  readonly sourceEventSeqs?: JsonValue$1;
  /** Canonical placement on current surface events; opaque JSON on unknown ignorable events. */
  readonly surfaceOp?: JsonValue$1;
}
/** Exact deferred result request; the address preserves child authorization. */
interface SessionHistoryDetailRequest {
  readonly address: SessionAddress;
  readonly seq: number;
}
/** One message-aligned backwards-history request. */
interface SessionPageRequest {
  readonly address: SessionAddress;
  /** Inclusive log cut obtained from the corresponding follow opening frame. */
  readonly throughSeq: number;
  readonly beforeSeq?: number;
  readonly maxMessages?: number;
}
/** One live event request for a durable Session address. */
interface SessionFollowRequest {
  readonly address: SessionAddress;
  readonly maxMessages?: number;
  /** Include process-local assistant presentation frames for the Web client. */
  readonly assistantStream?: true;
}
/** One active assistant attempt in a reconnect opening snapshot. */
interface SessionAssistantStreamAttempt {
  readonly attemptId: LlmAttemptId;
  /** Last durable Session seq observed when this attempt started. */
  readonly startedAfterSeq: SessionSeqCursor;
  readonly turn: number;
  readonly step: number;
  /** Dense position expected for the next live chunk frame. */
  readonly nextIndex: number;
  /** Compact detached stream accumulated at this opening revision. */
  readonly stream: readonly JsonValue$1[];
}
/** Complete process-local assistant state at one follow opening. */
interface SessionAssistantStreamBaseline {
  readonly revision: number;
  readonly activeAttempt?: SessionAssistantStreamAttempt;
}
/** Browser wire form of one process-local assistant frame. */
type SessionAssistantStreamFrame = {
  readonly type: 'start';
  readonly attemptId: LlmAttemptId;
  readonly revision: number;
  readonly startedAfterSeq: SessionSeqCursor;
  readonly turn: number;
  readonly step: number;
} | {
  readonly type: 'chunk';
  readonly attemptId: LlmAttemptId;
  readonly revision: number;
  readonly index: number;
  readonly time: number;
  readonly chunk: JsonValue$1;
} | {
  readonly type: 'end';
  readonly attemptId: LlmAttemptId;
  readonly revision: number; /** Number of chunk frames represented by this terminal marker. */
  readonly index: number;
  readonly outcome: {
    readonly kind: 'committed';
    readonly eventType: 'assistant/message' | 'assistant/attempt';
    readonly seq: number;
  } | {
    readonly kind: 'abandoned';
  };
};
/** One contiguous backwards page of a Session log. */
interface SessionPage {
  readonly records: readonly SessionHistoryRecord[];
  readonly hasMore: boolean;
  /** One complete message group exceeds the configured byte limit. */
  readonly oversized?: {
    readonly bytes: number;
  };
}
/** Complete opening window followed by ordered durable events and opted-in assistant frames. */
type SessionFollowFrame = {
  readonly type: 'snapshot';
  readonly header: SessionWireHeader;
  readonly cursor: number;
  readonly records: readonly SessionHistoryRecord[];
  readonly hasMore: boolean;
  readonly oversized?: {
    readonly bytes: number;
  };
  readonly projections: SessionProjectionBaseline;
  readonly assistantStream?: SessionAssistantStreamBaseline;
} | SessionEventEntry | {
  readonly type: 'assistant-stream';
  readonly frame: SessionAssistantStreamFrame;
};
/** One pending inbox occurrence in the authoritative queue snapshot. */
interface SessionQueuedItem {
  readonly id: MessageId;
  readonly placement: 'queued' | 'steering' | 'context';
  /** Prompt-RPC identity from the queued message's user source; clients retire the matching local submission echo on it. */
  readonly rpcId?: SessionRequestId;
  /** JSON-safe message fields consumed by pending-queue presentation. */
  readonly message: {
    readonly id: MessageId;
    readonly content: readonly JsonValue$1[];
  };
}
/** Browser-safe background-job row. */
interface SessionJob {
  readonly id: JobId;
  readonly kind: string;
  readonly label: string;
  readonly status: 'running' | 'stopping' | 'completed' | 'killed' | 'failed';
  readonly detail?: string;
  readonly startedAt: number;
  readonly finishedAt?: number;
}
/** Complete live control baseline emitted once per control stream generation. */
interface SessionControlBaseline {
  readonly queues: Readonly<Record<SessionId, readonly SessionQueuedItem[]>>;
  readonly jobs: Readonly<Record<SessionId, readonly SessionJob[]>>;
  readonly projections: Readonly<Record<SessionId, SessionProjectionBaseline>>;
}
/** One finished projection value and its durable watermark. */
interface SessionProjectionUpdate {
  readonly sessionId: SessionId;
  readonly key: string;
  readonly value: JsonValue$1;
  readonly seq: number;
}
/** Host-wide live state stream. Each generation starts with exactly one baseline. */
type SessionControlFrame = {
  readonly type: 'baseline';
  readonly value: SessionControlBaseline;
} | {
  readonly type: 'queue';
  readonly sessionId: SessionId;
  readonly items: readonly SessionQueuedItem[];
} | {
  readonly type: 'jobs';
  readonly sessionId: SessionId;
  readonly jobs: readonly SessionJob[];
} | ({
  readonly type: 'projection';
} & SessionProjectionUpdate);
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * A Session became visible to Session list consumers.
     * @mode emit
     * @param summary - initial list row for the Session.
     */
    'api-session/added'(summary: SessionSummary): void;
    /**
     * A Session left the live Host registry.
     * @mode emit
     * @param sessionId - removed Session identity.
     */
    'api-session/removed'(sessionId: SessionId): void;
    /**
     * One Agent changed running state.
     * @mode emit
     * @param sessionId - Agent and Session identity.
     * @param running - whether the Agent is running.
     */
    'api-session/status'(sessionId: SessionId, running: boolean): void;
    /**
     * One user-authored durable message advanced Session list activity.
     * @mode emit
     * @param sessionId - addressed Session identity.
     * @param updatedAt - durable message time used for list ordering.
     */
    'api-session/activity'(sessionId: SessionId, updatedAt: number): void;
    /**
     * One Agent failed outside a durable turn position.
     * @mode emit
     * @param sessionId - Agent and Session identity.
     * @param message - user-safe failure chain.
     */
    'api-session/error'(sessionId: SessionId, message: string): void;
  }
}
/** JSON-compatible projection value accepted by list consumers. */
type SessionProjectionValue = JsonValue$1;
//#endregion
//#region ../../context/file-reference/lib/types/types.d.ts
/**
 * Public file-reference discovery records. This module contains types only so
 * generated Remote clients can consume it without Host runtime code.
 * @module @deepseek-ai/dsh-file-reference/types
 */
/** One path-only completion candidate inside the target session cwd. */
interface FileReferenceCandidate {
  /** User-facing path accepted by normal prompts and filesystem tools. */
  path: string;
  /** Directories keep completion open; files finish the mention. */
  kind: 'file' | 'directory';
}
//#endregion
//#region ../session-controller/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$66696c655265666572656e636573 {
    list: (agentId: SessionId, query: string, signal?: AbortSignal) => Promise<RemoteResult$1<FileReferenceCandidate[]>>;
  }
  interface TypertRemoteNamespace$73657373696f6e {
    attachment: (request: SessionAttachmentRequest) => Promise<RemoteResult$1<SessionAttachmentValue>>;
    cancel: (request: SessionCancelRequest) => Promise<RemoteResult$1<SessionCancelValue>>;
    canOpenWorkspacePath: () => Promise<RemoteResult$1<boolean>>;
    control: (signal?: AbortSignal) => AsyncIterable<SessionControlFrame>;
    create: (request: SessionCreateRequest) => Promise<RemoteResult$1<SessionCreateValue>>;
    follow: (request: SessionFollowRequest, signal?: AbortSignal) => AsyncIterable<SessionFollowFrame>;
    fork: (request: SessionForkRequest) => Promise<RemoteResult$1<SessionForkValue>>;
    historyDetail: (request: SessionHistoryDetailRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionEventEntry>>;
    list: (request: SessionListRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionListValue>>;
    modelCatalog: () => Promise<RemoteResult$1<ModelCatalog>>;
    openWorkspacePath: (request: SessionOpenWorkspacePathRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionOpenWorkspacePathValue>>;
    page: (request: SessionPageRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionPage>>;
    prompt: (request: SessionPromptRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionPromptValue>>;
    rename: (request: SessionRenameRequest) => Promise<RemoteResult$1<SessionRenameValue>>;
    search: (request: SessionSearchRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionSearchValue>>;
    selectModel: (request: SessionSelectModelRequest) => Promise<RemoteResult$1<SessionSelectModelValue>>;
    updateQueue: (request: SessionUpdateQueueRequest) => Promise<RemoteResult$1<SessionUpdateQueueValue>>;
  }
  interface TypertRemoteNamespace$736b696c6c73 {
    list: (request: SkillListRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SkillListValue>>;
  }
  interface TypertRemoteMap {
    'fileReferences/list': (agentId: SessionId, query: string, signal?: AbortSignal) => Promise<RemoteResult$1<FileReferenceCandidate[]>>;
    'session/attachment': (request: SessionAttachmentRequest) => Promise<RemoteResult$1<SessionAttachmentValue>>;
    'session/cancel': (request: SessionCancelRequest) => Promise<RemoteResult$1<SessionCancelValue>>;
    'session/canOpenWorkspacePath': () => Promise<RemoteResult$1<boolean>>;
    'session/control': (signal?: AbortSignal) => AsyncIterable<SessionControlFrame>;
    'session/create': (request: SessionCreateRequest) => Promise<RemoteResult$1<SessionCreateValue>>;
    'session/follow': (request: SessionFollowRequest, signal?: AbortSignal) => AsyncIterable<SessionFollowFrame>;
    'session/fork': (request: SessionForkRequest) => Promise<RemoteResult$1<SessionForkValue>>;
    'session/historyDetail': (request: SessionHistoryDetailRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionEventEntry>>;
    'session/list': (request: SessionListRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionListValue>>;
    'session/modelCatalog': () => Promise<RemoteResult$1<ModelCatalog>>;
    'session/openWorkspacePath': (request: SessionOpenWorkspacePathRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionOpenWorkspacePathValue>>;
    'session/page': (request: SessionPageRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionPage>>;
    'session/prompt': (request: SessionPromptRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionPromptValue>>;
    'session/rename': (request: SessionRenameRequest) => Promise<RemoteResult$1<SessionRenameValue>>;
    'session/search': (request: SessionSearchRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SessionSearchValue>>;
    'session/selectModel': (request: SessionSelectModelRequest) => Promise<RemoteResult$1<SessionSelectModelValue>>;
    'session/updateQueue': (request: SessionUpdateQueueRequest) => Promise<RemoteResult$1<SessionUpdateQueueValue>>;
    'skills/list': (request: SkillListRequest, signal?: AbortSignal) => Promise<RemoteResult$1<SkillListValue>>;
  }
  interface TypertRemoteNamespaceMap {
    'fileReferences': TypertRemoteNamespace$66696c655265666572656e636573;
    'session': TypertRemoteNamespace$73657373696f6e;
    'skills': TypertRemoteNamespace$736b696c6c73;
  }
  interface TypertRemoteScopeMap {
    'agent:fileReferences/list': (query: string, signal?: AbortSignal) => Promise<RemoteResult$1<FileReferenceCandidate[]>>;
  }
}
//#endregion
//#region ../../host/directory-picker/lib/types/types.d.ts
/**
 * Client-safe type surface of the directory-picking seam: what one browse level
 * looks like to a caller. Types only — no runtime code, and nothing here reaches
 * a Host-only symbol, so a Client compilation face reads exactly the signatures
 * the Host emits.
 *
 * @module @deepseek-ai/dsh-host-directory-picker/types
 */
/** One directory row: a listing child or a breadcrumb ancestor. */
interface DirectoryEntry {
  /** Base name shown in a browser row (a root crumb carries its full path). */
  name: string;
  /** Absolute host path — clients never join path segments themselves. */
  path: string;
  /** Hidden by the host platform's convention (dot-prefixed on POSIX); the client owns whether to show it. */
  hidden: boolean;
}
/** One directory level plus its ancestry, as a browse backend reports it. */
interface DirectoryListing {
  /** Absolute path of the listed directory. */
  path: string;
  /** The host account's home directory (breadcrumb "Home" rooting). */
  home: string;
  /**
   * Ancestor chain from the filesystem root to the listed directory
   * inclusive; every crumb is a jump target (crumb `hidden` is always false).
   */
  crumbs: DirectoryEntry[];
  /** Direct child directories, name-sorted; symlinks to directories included. */
  entries: DirectoryEntry[];
  /**
   * True when the backend cut `entries` at its complete-result bound: the
   * level has more child directories than reported, and the missing rows are
   * the name-sorted tail (hidden rows count toward the bound).
   */
  truncated: boolean;
}
//#endregion
//#region ../workspace-controller/lib/types/types.d.ts
/** One durable Workspace projected for browser consumers. */
interface WorkspaceView {
  readonly workspaceId: WorkspaceId;
  /** Canonical host directory path. */
  readonly path: string;
  /** User-visible title. */
  readonly title: string;
  /** Sessions accounted to this Workspace in manual order. */
  readonly sessionIds: readonly SessionId[];
  /** ISO-8601 creation instant. */
  readonly createdAt: string;
  /** ISO-8601 last-mutation instant. */
  readonly updatedAt: string;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** The requested directory cannot back a Workspace. */
    'workspace/invalid-path': {
      readonly path: string;
    };
    /** Another Workspace already uses the requested name. */
    'workspace/name-conflict': {
      readonly name: string;
    };
    /** The Session or its anchor is not in the Workspace's manual order. */
    'workspace/move-invalid': {
      readonly workspaceId: WorkspaceId;
      readonly sessionId: SessionId;
      readonly beforeSessionId?: SessionId;
    };
    /** The verb needs an interaction the composed backend does not serve. */
    'directory-picker/unavailable': {
      readonly capability: string;
    };
    /** The target is not fully qualified, or the backend cannot list it. */
    'directory-picker/unreadable': {
      readonly path: string;
    };
    /** A child of that name is already there. */
    'directory-picker/exists': {
      readonly path: string;
    };
    /** The parent is not fully qualified, the name is not one segment, or creation failed. */
    'directory-picker/create-failed': {
      readonly path: string;
    };
  }
}
/** Existing directory requested for Workspace adoption. */
interface WorkspaceCreateRequest {
  readonly path: string;
}
/** Created or previously registered Workspace. */
interface WorkspaceCreateValue {
  readonly workspace: WorkspaceView;
  readonly created: boolean;
}
/** Workspace title mutation. */
interface WorkspaceRenameRequest {
  readonly workspaceId: WorkspaceId;
  readonly title: string;
}
/** Workspace mutation returning the complete changed row. */
interface WorkspaceValue {
  readonly workspace: WorkspaceView;
}
/** Workspace registration deletion. */
interface WorkspaceDeleteRequest {
  readonly workspaceId: WorkspaceId;
}
/** Receipt after one Workspace registration is deleted. */
interface WorkspaceDeleteValue {
  readonly deleted: true;
}
/** DOM-insertBefore-like Workspace order mutation. */
interface WorkspaceInsertBeforeRequest {
  readonly workspaceId: WorkspaceId;
  readonly beforeWorkspaceId?: WorkspaceId;
}
/** Complete Workspace registry order after a mutation. */
interface WorkspaceOrderValue {
  readonly workspaceIds: readonly WorkspaceId[];
}
/** DOM-insertBefore-like Session membership order mutation. */
interface WorkspaceInsertSessionBeforeRequest {
  readonly workspaceId: WorkspaceId;
  readonly sessionId: SessionId;
  readonly beforeSessionId?: SessionId;
}
/** Session requested for archival from Workspace grouping surfaces. */
interface WorkspaceArchiveSessionRequest {
  readonly sessionId: SessionId;
}
/** Complete archived Session set after a mutation. */
interface WorkspaceArchiveValue {
  readonly archivedSessionIds: readonly SessionId[];
}
/** Complete reconnect baseline for Workspace browser state. */
interface WorkspaceBaseline {
  readonly items: readonly WorkspaceView[];
  readonly archivedSessionIds: readonly SessionId[];
}
/** One ordered Workspace change after a generation's baseline. */
type WorkspaceFollowIncrement = {
  readonly type: 'upsert';
  readonly workspace: WorkspaceView;
} | {
  readonly type: 'remove';
  readonly workspaceId: WorkspaceId;
} | {
  readonly type: 'order';
  readonly workspaceIds: readonly WorkspaceId[];
} | {
  readonly type: 'archived';
  readonly archivedSessionIds: readonly SessionId[];
};
/** Workspace state stream; every generation starts with exactly one baseline. */
type WorkspaceFollowFrame = {
  readonly type: 'baseline';
  readonly value: WorkspaceBaseline;
} | WorkspaceFollowIncrement;
//#endregion
//#region ../workspace-controller/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$6469726563746f72795069636b6572 {
    createDirectory: (path: string, name: string) => Promise<RemoteResult$1<string>>;
    list: (path: string | undefined, signal?: AbortSignal) => Promise<RemoteResult$1<DirectoryListing>>;
    pick: (signal?: AbortSignal) => Promise<RemoteResult$1<string | null>>;
  }
  interface TypertRemoteNamespace$776f726b7370616365 {
    archiveSession: (request: WorkspaceArchiveSessionRequest) => Promise<RemoteResult$1<WorkspaceArchiveValue>>;
    create: (request: WorkspaceCreateRequest) => Promise<RemoteResult$1<WorkspaceCreateValue>>;
    delete: (request: WorkspaceDeleteRequest) => Promise<RemoteResult$1<WorkspaceDeleteValue>>;
    follow: (signal?: AbortSignal) => AsyncIterable<WorkspaceFollowFrame>;
    insertBefore: (request: WorkspaceInsertBeforeRequest) => Promise<RemoteResult$1<WorkspaceOrderValue>>;
    insertSessionBefore: (request: WorkspaceInsertSessionBeforeRequest) => Promise<RemoteResult$1<WorkspaceValue>>;
    rename: (request: WorkspaceRenameRequest) => Promise<RemoteResult$1<WorkspaceValue>>;
  }
  interface TypertRemoteMap {
    'directoryPicker/createDirectory': (path: string, name: string) => Promise<RemoteResult$1<string>>;
    'directoryPicker/list': (path: string | undefined, signal?: AbortSignal) => Promise<RemoteResult$1<DirectoryListing>>;
    'directoryPicker/pick': (signal?: AbortSignal) => Promise<RemoteResult$1<string | null>>;
    'workspace/archiveSession': (request: WorkspaceArchiveSessionRequest) => Promise<RemoteResult$1<WorkspaceArchiveValue>>;
    'workspace/create': (request: WorkspaceCreateRequest) => Promise<RemoteResult$1<WorkspaceCreateValue>>;
    'workspace/delete': (request: WorkspaceDeleteRequest) => Promise<RemoteResult$1<WorkspaceDeleteValue>>;
    'workspace/follow': (signal?: AbortSignal) => AsyncIterable<WorkspaceFollowFrame>;
    'workspace/insertBefore': (request: WorkspaceInsertBeforeRequest) => Promise<RemoteResult$1<WorkspaceOrderValue>>;
    'workspace/insertSessionBefore': (request: WorkspaceInsertSessionBeforeRequest) => Promise<RemoteResult$1<WorkspaceValue>>;
    'workspace/rename': (request: WorkspaceRenameRequest) => Promise<RemoteResult$1<WorkspaceValue>>;
  }
  interface TypertRemoteNamespaceMap {
    'directoryPicker': TypertRemoteNamespace$6469726563746f72795069636b6572;
    'workspace': TypertRemoteNamespace$776f726b7370616365;
  }
}
//#endregion
//#region ../workspace-files/lib/types/types.d.ts
/**
 * Wire types of the `workspaceFiles` Remote namespace. Types only: generated
 * Remote clients consume this module without Host runtime code.
 *
 * Two path vocabularies leave here, and each method uses exactly one:
 *
 * - `read`, `readBytes`, `stat`, and `changes` name a file by its absolute path in the
 *   filesystem's execution world, because their consumer is the Client
 *   resource system, whose `dsh-resource://file/session/<id>/<path>` address carries that
 *   same path.
 * - `list` speaks workspace paths — the same syntax its `path` argument accepts —
 *   because its consumer is a tree rooted at the workspace root.
 *
 * @module @deepseek-ai/dsh-api-workspace-files/types
 */
/** Identity and freshness of one workspace file, without its content. */
interface WorkspaceFileStat {
  /**
   * Absolute path of the file in the filesystem's execution world, symlinks
   * resolved: `/`-separated on POSIX, drive-rooted with the platform separator
   * on Windows. What a `dsh-resource://file/absolute/…` address carries, and
   * what a `dsh-resource://file/session/<sessionId>/…` address's
   * workspace-relative path resolves to against that Session's root.
   */
  readonly absolutePath: string;
  /** Opaque freshness token at the time of the stat; never parsed. */
  readonly version: string;
  /** Byte size of the complete file, when the backend reports it. */
  readonly bytes?: number;
}
/**
 * The line window one `read` returns. Lines are 1-based and end at `\n`; a
 * final `\n` terminates the last line rather than starting an empty one.
 */
interface WorkspaceFileRange {
  /** First line of the page. Defaults to 1. */
  readonly offset?: number;
  /** Largest number of lines on the page. Defaults to, and may not exceed, the configured `maxLines`. */
  readonly limit?: number;
}
/** One page of a workspace text file as a Client reads it. */
interface WorkspaceFileText extends WorkspaceFileStat {
  /** First line of the page, as requested. */
  readonly offset: number;
  /**
   * The page's lines joined by `\n`, without a terminator after the last one.
   * Empty for a page past the file's last line and for a page holding one
   * empty line; `lines` tells them apart.
   */
  readonly text: string;
  /** How many lines the page holds; `0` when `offset` lies past the file's last line. */
  readonly lines: number;
  /** Whether the page includes the file's last line. */
  readonly eof: boolean;
}
/** The byte window one `readBytes` returns. Offsets are 0-based. */
interface WorkspaceByteRange {
  /** First byte of the window. Defaults to 0. */
  readonly offset?: number;
  /** Largest number of bytes in the window. Defaults to, and may not exceed, the configured `maxBytes`. */
  readonly length?: number;
}
/**
 * One byte window of a workspace file as a Client reads it: raw bytes, no text
 * decoding and no binary rejection. `bytes` is the complete file's size.
 */
interface WorkspaceFileBytes extends WorkspaceFileStat {
  /** First byte of the window, as requested. */
  readonly offset: number;
  /** The window's bytes in base64; empty when `offset` lies at or past the file's end. */
  readonly data: string;
  /** Whether the window includes the file's last byte. */
  readonly eof: boolean;
}
/** One direct child of a listed workspace directory. */
interface WorkspaceDirectoryEntry {
  /** Basename inside the listed directory. */
  readonly name: string;
  /**
   * What the child resolves to. A symlink reports the type of its destination,
   * and `other` covers everything that is neither a regular file nor a
   * directory; `read` still refuses a symlink, so `file` here is a listing fact,
   * not a promise that the content is readable.
   */
  readonly type: 'file' | 'directory' | 'other';
  /** Byte size, present only for a regular file whose backend reports it. */
  readonly size?: number;
}
/** Direct children of one workspace directory. */
interface WorkspaceDirectoryListing {
  /**
   * The listed directory as a workspace path, relative to the workspace root
   * and empty for the root itself. A child's path is this value joined with
   * {@link WorkspaceDirectoryEntry.name} by `/`.
   */
  readonly path: string;
  /**
   * Direct children in the backend's stable name order, cut to the configured
   * entry cap. Presentation order is the caller's choice.
   */
  readonly entries: readonly WorkspaceDirectoryEntry[];
  /** Whether the entry cap dropped children from {@link entries}. */
  readonly truncated: boolean;
}
/**
 * One observation of a workspace file made by an instrumented filesystem
 * operation. Frames report observations, not deltas: a consumer already
 * holding `version` learns nothing new from the frame and can ignore it.
 */
type WorkspaceFileChange = {
  /** Absolute path of the observed file, in the same form as {@link WorkspaceFileStat.absolutePath}. */readonly absolutePath: string; /** Opaque freshness token after the observed operation; never parsed. */
  readonly version: string;
} | {
  /** Absolute path of the observed file, in the same form as {@link WorkspaceFileStat.absolutePath}. */readonly absolutePath: string; /** The file was observed to be gone. */
  readonly absent: true;
};
/**
 * One frame of a workspace file watch generation. `ready` confirms that the
 * Host is observing filesystem operations and has resolved the workspace
 * root; observations queued during that resolution follow as `change` frames.
 */
type WorkspaceFileWatchFrame = {
  readonly kind: 'ready';
} | {
  readonly kind: 'change';
  readonly change: WorkspaceFileChange;
};
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface RemoteErrorDetailsMap {
    /** No entry exists at that path inside the workspace. */
    'workspace-file/not-found': {
      readonly path: string;
    };
    /** The directory listing path resolves outside the session's workspace root. */
    'workspace-file/outside-workspace': {
      readonly path: string;
    };
    /** The requested page exceeds the configured byte cap; nothing is returned. */
    'workspace-file/too-large': {
      readonly path: string;
      readonly limit: number;
    };
    /** The content read so far is not decodable UTF-8 text, or the page carries NUL bytes. */
    'workspace-file/not-text': {
      readonly path: string;
    };
    /** The path is not a regular file, so it has no text to read. */
    'workspace-file/not-regular-file': {
      readonly path: string;
      readonly kind: 'directory' | 'symlink' | 'other';
    };
    /** The path is not a directory, so it has no children to list. */
    'workspace-file/not-directory': {
      readonly path: string;
      readonly kind: 'file' | 'symlink' | 'other';
    };
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../workspace-files/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$776f726b737061636546696c6573 {
    changes: (workspaceFileScopeId: SessionId, signal?: AbortSignal) => AsyncIterable<WorkspaceFileWatchFrame>;
    list: (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceDirectoryListing>>;
    read: (workspaceFileScopeId: SessionId, path: string, range: WorkspaceFileRange, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileText>>;
    readAll: (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    readBytes: (workspaceFileScopeId: SessionId, path: string, range: WorkspaceByteRange, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    readRelated: (workspaceFileScopeId: SessionId, path: string, relativePath: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    stat: (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileStat>>;
  }
  interface TypertRemoteMap {
    'workspaceFiles/changes': (workspaceFileScopeId: SessionId, signal?: AbortSignal) => AsyncIterable<WorkspaceFileWatchFrame>;
    'workspaceFiles/list': (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceDirectoryListing>>;
    'workspaceFiles/read': (workspaceFileScopeId: SessionId, path: string, range: WorkspaceFileRange, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileText>>;
    'workspaceFiles/readAll': (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    'workspaceFiles/readBytes': (workspaceFileScopeId: SessionId, path: string, range: WorkspaceByteRange, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    'workspaceFiles/readRelated': (workspaceFileScopeId: SessionId, path: string, relativePath: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileBytes>>;
    'workspaceFiles/stat': (workspaceFileScopeId: SessionId, path: string, signal?: AbortSignal) => Promise<RemoteResult$1<WorkspaceFileStat>>;
  }
  interface TypertRemoteNamespaceMap {
    'workspaceFiles': TypertRemoteNamespace$776f726b737061636546696c6573;
  }
}
//#endregion
//#region lib/types/remote-events.d.ts
/**
 * The one home of this application's forwarded-Host-event allowlist. Both
 * compiler faces list this file, so the Host forwarding loop and the consumer
 * `ctx.remote.$on` key face read one declaration instead of two copies that
 * could drift; `./types.ts` derives the type projection from it and stays
 * type-only.
 */
/**
 * Host events this application forwards without renaming. The explicit mode is
 * both the Host dispatch strategy and the legal key set of `ctx.remote.$on`.
 */
declare const API_REMOTE_FORWARDED_EVENTS: readonly [{
  readonly event: "agent-preset/selected";
  readonly mode: "emit";
}, {
  readonly event: "agent-models/directory-updated";
  readonly mode: "emit";
}, {
  readonly event: "approval/request";
  readonly mode: "waterfall";
}, {
  readonly event: "api-session/activity";
  readonly mode: "emit";
}, {
  readonly event: "api-session/added";
  readonly mode: "emit";
}, {
  readonly event: "api-session/error";
  readonly mode: "emit";
}, {
  readonly event: "api-session/removed";
  readonly mode: "emit";
}, {
  readonly event: "api-session/status";
  readonly mode: "emit";
}, {
  readonly event: "commands/change";
  readonly mode: "emit";
}, {
  readonly event: "credentials/reference-updated";
  readonly mode: "emit";
}, {
  readonly event: "credentials/record-updated";
  readonly mode: "emit";
}, {
  readonly event: "goal/activation-changed";
  readonly mode: "emit";
}, {
  readonly event: "cordis/request-run";
  readonly mode: "emit";
}, {
  readonly event: "cordis/request-run-resolved";
  readonly mode: "emit";
}, {
  readonly event: "cordis/dynamic-package";
  readonly mode: "emit";
}, {
  readonly event: "cordis/dynamic-retract";
  readonly mode: "emit";
}, {
  readonly event: "cordis/inspect-query";
  readonly mode: "emit";
}, {
  readonly event: "cordis/inspect-query-resolved";
  readonly mode: "emit";
}, {
  readonly event: "llm/adapters-updated";
  readonly mode: "emit";
}, {
  readonly event: "settings/document-updated";
  readonly mode: "emit";
}, {
  readonly event: "user-questions/request";
  readonly mode: "waterfall";
}];
//#endregion
//#region lib/types/types.d.ts
/** Type projection of the allowlist; the consumer and the Host read this one. */
type ApiRemoteForwardedEvent = typeof API_REMOTE_FORWARDED_EVENTS[number]['event'];
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteEventSelection extends Record<ApiRemoteForwardedEvent, true> {}
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../extensions/cordis-host-runner/lib/types/types.d.ts
/** Stable identity of one dynamic plugin instance. */
type CordisDynamicPluginId = Branded<'CordisDynamicPluginId'>;
/** Identity of one immutable package version belonging to a dynamic plugin. */
type CordisDynamicPackageId = Branded<'CordisDynamicPackageId'>;
/** Identity of one successful activation attempt. */
type CordisDynamicPluginRunId = Branded<'CordisDynamicPluginRunId'>;
/** Identity of one human approval request. */
type ApprovalRequestId = Branded<'ApprovalRequestId'>;
/** Identity of one cross-page inspect query. */
type CordisInspectRequestId = Branded<'CordisInspectRequestId'>;
/** Runtime plane that owns an inspect provider. */
type CordisInspectPlatform = 'host' | 'client';
/** One model-callable read-only query exposed by an inspect provider. */
interface CordisInspectMethodManifest {
  /** Method name, unique within its provider. */
  name: string;
  /** What the query returns and when to use it. */
  description: string;
  /** JSON Schema accepted by the query. */
  inputSchema: JsonValue$1;
  /** JSON Schema produced by the query. */
  outputSchema: JsonValue$1;
}
/** Serializable directory entry for one inspect provider. */
interface CordisInspectProviderManifest {
  /** Provider identity, unique within one platform. */
  id: string;
  /** Capability described by this provider. */
  description: string;
  /** Explicit read-only queries. */
  methods: readonly CordisInspectMethodManifest[];
}
/** Provider directory row returned by `cordis_inspect_list`. */
interface CordisInspectProviderView extends CordisInspectProviderManifest {
  /** Runtime plane that executes these methods. */
  platform: CordisInspectPlatform;
}
/** Host broadcast requesting one live Client inspect result. */
interface CordisInspectQueryRequest {
  /** Correlation identity. */
  requestId: CordisInspectRequestId;
  /** Session whose model requested the query. */
  agentId: SessionId;
  /** Provider selected from the Client manifest. */
  provider: string;
  /** Method selected from the provider manifest. */
  method: string;
  /** JSON query input, omitted when the method has no fields. */
  input?: JsonValue$1;
}
/** Result sent from a Client provider to the waiting Host query. */
type CordisInspectQueryResolution = {
  ok: true;
  data: JsonValue$1;
} | {
  ok: false;
  reason: 'provider-missing' | 'method-missing' | 'invalid-input' | 'provider-error' | 'cancelled';
  message: string;
};
/** Notification that a Client inspect request can no longer be answered. */
interface CordisInspectQueryResolved {
  /** Query that left the pending state. */
  requestId: CordisInspectRequestId;
}
/** Whether a Client answer claimed the still-pending query. */
interface CordisInspectResolveAck {
  /** False for unknown, cancelled, stale, or late answers. */
  accepted: boolean;
}
/** Whether a package starts the current version or replaces it. */
type CordisDynamicRunMode = 'run' | 'update';
/** How a model-driven Client activation request left the pending state. */
type RequestRunOutcome = 'approved' | 'completed' | 'rejected' | 'cancelled' | 'failed';
/** Error fields preserved across the Host/Client transport. */
interface CordisErrorDetails {
  /** Original error message. */
  message: string;
  /** Original stack when the thrown value supplied one. */
  stack?: string;
}
/** Persisted state of the latest activation attempt. */
type CordisRunStatus = 'awaiting-approval' | 'starting-host' | 'client-pending' | 'running' | 'waiting' | 'rejected' | 'failed' | 'cancelled' | 'stopped';
/** One platform half within an activation attempt. */
interface CordisHalfState {
  /** Lifecycle state of this half. */
  status: 'absent' | 'pending' | 'stopped' | 'running' | 'waiting' | 'failed';
  /** Services still needed by a successfully created Fiber. */
  waitingFor: readonly string[];
  /** Failure text for this half. */
  error?: string;
}
/** Structured failure associated with an exact activation attempt. */
interface CordisRunDiagnostic {
  /** Stage that failed. */
  phase: 'approval' | 'host-load' | 'host-apply' | 'client-load' | 'client-apply' | 'client-render';
  /** Original failure text. */
  message: string;
  /** Original failure stack when available. */
  stack?: string;
  /** Stable Plugin identity. */
  pluginId: CordisDynamicPluginId;
  /** Immutable Package identity. */
  packageId: CordisDynamicPackageId;
  /** Exact attempt identity. */
  pluginRunId: CordisDynamicPluginRunId;
}
/** Latest activation attempt retained independently from the physical run. */
interface DynamicCordisRunAttempt {
  /** Exact attempt identity. */
  pluginRunId: CordisDynamicPluginRunId;
  /** Target Package. */
  packageId: CordisDynamicPackageId;
  /** Explicit run/update intent. */
  mode: CordisDynamicRunMode;
  /** Current attempt state. */
  status: CordisRunStatus;
  /** Pending Client activation request; it represents approval only when `requiresApproval` is true. */
  approvalRequestId?: ApprovalRequestId;
  /** Whether the pending Client activation requires a user decision. */
  requiresApproval?: boolean;
  /** Host-half state. */
  host: CordisHalfState;
  /** Client-half state. */
  client: CordisHalfState;
  /** Most recent failure. */
  error?: CordisRunDiagnostic;
}
/** One running package announced to browser pages. */
interface DynamicCordisPackage {
  /** Stable plugin instance. */
  pluginId: CordisDynamicPluginId;
  /** Immutable package version currently active. */
  packageId: CordisDynamicPackageId;
  /** This activation's identity. */
  pluginRunId: CordisDynamicPluginRunId;
  /** Package label. */
  name: string;
}
/** One pending model-driven Client activation forwarded to browser pages. */
interface DynamicCordisRunRequest {
  /** Correlation identity of the activation request. */
  requestId: ApprovalRequestId;
  /** Session whose plugin and tool call own the request. */
  agentId: SessionId;
  /** Stable plugin instance being acted on. */
  pluginId: CordisDynamicPluginId;
  /** Package version the request will activate. */
  packageId: CordisDynamicPackageId;
  /** Explicit lifecycle intent. */
  mode: CordisDynamicRunMode;
  /** Package label. */
  name: string;
  /** User-facing reason supplied at define time. */
  purpose: string;
  /** Whether a page must wait for an explicit user decision before activation. */
  requiresApproval: boolean;
}
/** One settled model-driven Client activation request broadcast to all pages. */
interface DynamicCordisRequestResolved {
  /** Request that left the pending state. */
  requestId: ApprovalRequestId;
  /** How the request settled. */
  outcome: RequestRunOutcome;
}
/** One activation withdrawn from every page. */
interface DynamicCordisRetracted {
  /** Stable plugin instance. */
  pluginId: CordisDynamicPluginId;
  /** Package version that was active. */
  packageId: CordisDynamicPackageId;
  /** Exact activation being withdrawn. */
  pluginRunId: CordisDynamicPluginRunId;
}
/** Package metadata exposed by the inventory without source code. */
interface DynamicCordisInventoryPackage {
  /** Immutable package version. */
  packageId: CordisDynamicPackageId;
  /** Package label. */
  name: string;
  /** User-facing purpose. */
  purpose: string;
  /** Whether this version contains Host code. */
  hasHostHalf: boolean;
  /** Whether this version contains Client code. */
  hasClientHalf: boolean;
}
/** One stable plugin row in the frame-wide inventory. */
interface DynamicCordisInventoryRow {
  /** Stable plugin instance. */
  pluginId: CordisDynamicPluginId;
  /** Session that owns this plugin. */
  agentId: SessionId;
  /** Immutable versions in define order. */
  packages: readonly DynamicCordisInventoryPackage[];
  /** Last package that completed activation successfully. */
  currentPackageId?: CordisDynamicPackageId;
  /** Package selected for a failed or in-progress transition. */
  nextPackageId?: CordisDynamicPackageId;
  /** Current activation, absent while stopped. */
  activeRun?: {
    pluginRunId: CordisDynamicPluginRunId;
    packageId: CordisDynamicPackageId;
  };
  /** Latest activation attempt, including pending approval and diagnostics. */
  latestRun?: DynamicCordisRunAttempt;
}
/** Answer to removing a plugin and all of its package versions. */
type DynamicCordisUndefineReceipt = {
  ok: true;
  wasRunning: boolean;
} | {
  ok: false;
  reason: 'plugin-missing';
  message: string;
};
/** One render failure observed after a Client half loaded. */
interface DynamicCordisRenderFailure {
  /** Slot whose component failed. */
  slot: string;
  /** Render failure text. */
  message: string;
  /** Original render failure stack when available. */
  stack?: string;
  /** Whether the failing contribution relinquished its slot. */
  abdicated: boolean;
}
/** Result shared by model-driven and panel-driven activation. */
type DynamicCordisRunResponse = {
  ok: true; /** Whether activation completed synchronously, is starting in a Client, or awaits user approval. */
  status: 'awaiting-approval' | 'starting' | 'running';
  pluginId: CordisDynamicPluginId;
  packageId: CordisDynamicPackageId;
  pluginRunId: CordisDynamicPluginRunId; /** Missing Host services; a parked Fiber is a successful activation. */
  waitingFor: readonly string[]; /** Missing Client services reported by the approving page. */
  clientWaitingFor?: readonly string[]; /** Last fully successful Package. */
  currentPackageId?: CordisDynamicPackageId; /** Selected transition target. */
  nextPackageId?: CordisDynamicPackageId; /** Explicit lifecycle intent. */
  mode: CordisDynamicRunMode;
} | {
  ok: false;
  reason: 'plugin-missing' | 'package-missing' | 'invalid-mode' | 'transition-in-flight' | 'host-half-failed' | 'client-half-failed' | 'rejected' | 'cancelled' | 'not-running';
  message: string; /** Original failure stack when available. */
  stack?: string;
};
/** Result of stopping a Plugin without deleting its Packages. */
type DynamicCordisStopResponse = {
  ok: true;
} | {
  ok: false;
  reason: 'plugin-missing' | 'not-running';
  message: string;
};
/** Result of bringing up the Host half before loading the Client half. */
type DynamicCordisHostHalfResult = {
  ok: true;
  pluginId: CordisDynamicPluginId;
  packageId: CordisDynamicPackageId;
  pluginRunId: CordisDynamicPluginRunId;
  waitingFor: readonly string[]; /** False when a panel merely attaches this page to an already active run. */
  startedHere: boolean;
} | ({
  ok: false;
} & CordisErrorDetails);
/** Client-half source for one exact activation. */
interface DynamicCordisClientSource {
  /** Browser JavaScript body. */
  code: string;
  /** Package label. */
  name: string;
  /** Stable plugin instance. */
  pluginId: CordisDynamicPluginId;
  /** Immutable source version. */
  packageId: CordisDynamicPackageId;
  /** Exact activation the source belongs to. */
  pluginRunId: CordisDynamicPluginRunId;
}
/** Browser verdict used for both approved tool runs and panel runs. */
type DynamicCordisRunResolution = {
  ok: true;
  pluginRunId: CordisDynamicPluginRunId;
  waitingFor?: readonly string[];
} | {
  ok: false;
  reason: 'rejected' | 'host-half-failed' | 'client-half-failed'; /** Activation that failed; absent for a refusal before activation. */
  pluginRunId?: CordisDynamicPluginRunId; /** Whether this page created the failed activation instead of attaching to it. */
  startedHere?: boolean;
  message?: string;
  stack?: string;
};
/** Whether a Client activation resolution reached the still-pending request. */
interface DynamicCordisResolveAck {
  /** False for late, unknown, or stale answers. */
  accepted: boolean;
}
/** Result of routing one Client call to the active Host half. */
type DynamicCordisInvokeResult = {
  ok: true;
  value: JsonValue$1;
} | ({
  ok: false;
  code: 'plugin-not-running' | 'stale-run' | 'method-not-found' | 'handler-error';
} & CordisErrorDetails);
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * A Client-bearing activation needs a browser page, and may require a user decision.
     * @param request - correlation identity, owner, target version, mode, and approval requirement.
     * @mode emit
     */
    'cordis/request-run'(request: DynamicCordisRunRequest): void;
    /**
     * A pending Client activation request left the answerable state.
     * @param resolved - request identity and outcome.
     * @mode emit
     */
    'cordis/request-run-resolved'(resolved: DynamicCordisRequestResolved): void;
    /**
     * One exact Plugin/Package activation is now live in the Host.
     * @param pkg - stable plugin, immutable package, run identity, and label.
     * @mode emit
     */
    'cordis/dynamic-package'(pkg: DynamicCordisPackage): void;
    /**
     * One exact activation was withdrawn.
     * @param retracted - plugin, package, and run identity.
     * @mode emit
     */
    'cordis/dynamic-retract'(retracted: DynamicCordisRetracted): void;
    /**
     * Request a live read-only query from the Client inspect registry.
     * @param request - correlation, Session, provider, method, and JSON input.
     * @mode emit
     */
    'cordis/inspect-query'(request: CordisInspectQueryRequest): void;
    /**
     * Notify every Client that an inspect query has settled or been cancelled.
     * @param resolved - exact query identity that is no longer answerable.
     * @mode emit
     */
    'cordis/inspect-query-resolved'(resolved: CordisInspectQueryResolved): void;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../core/scope/lib/types/index.d.ts
declare const ScopedBrand: unique symbol;
/**
 * A routing-only event receiver built by {@link scopeTarget}. The type
 * parameter records the subject type for dispatch checking; the carrier does
 * not expose the subject's properties. Event payloads carry the real subject.
 */
type Scoped<T extends object> = object & {
  readonly [ScopedBrand]: T;
};
//#endregion
//#region ../../core/agent/lib/types/types.d.ts
/** Public live-agent handle; the runtime face augments its live capabilities. */
interface Agent {
  /** Session-backed Agent identity. */
  readonly id: SessionId;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertLookupMap {
    agent: TypertLookup<Agent, SessionId>;
  }
  interface TypertContextMap {
    /** Agent Context identity shared by Host and Client adapters. */
    agent: TypertContext<SessionId>;
  }
}
/** One of the two ordered pending-message lists owned by an agent. */
type InboxTarget = 'next-turn' | 'next-step';
/** Complete pending Inbox value reconstructed from durable splices. */
interface InboxState {
  readonly 'next-turn': readonly UserMessage[];
  readonly 'next-step': readonly UserMessage[];
}
/**
 * Wire-JSON pending Inbox value. Each message round-trips the session log
 * losslessly, but the fold state's full `UserMessage` type cannot cross a
 * typert Remote boundary (its source union carries an `unknown` replay
 * field), so the typed projection table keeps this JSON-safe form.
 */
interface InboxWireState {
  readonly 'next-turn': readonly JsonValue$1[];
  readonly 'next-step': readonly JsonValue$1[];
}
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    /** Pending agent input reconstructed from durable inbox splices. */
    inbox: InboxState;
  }
  interface SessionProjectionMap {
    /** Pending agent input reconstructed from durable inbox splices. */
    inbox: InboxWireState;
  }
}
/**
 * Turn and step boundaries folded from one agent session log.
 *
 * Reader contract: the key is registered by `dsh-agent-loop` and absent
 * otherwise. Without agent-loop no turn events exist, so readers treat an
 * absent key as "no open turn / no boundaries" — capability absence, not a
 * corrupt state. A reader whose behavior has no safe fallback for that
 * absence (the step-open decision, for example) may fail loud instead.
 */
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * One normalized mutation of an agent's durable pending-message lists.
     * The session-projection registry applies the committed event before
     * `Session.append()` returns; Inbox live notifications follow that commit.
     */
    'agent/inbox/spliced': {
      target: InboxTarget;
      start: number;
      removedCount?: number;
      inserted: UserMessage[];
      outcome?: 'canceled';
    };
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../interaction/user-approval/lib/types/types.d.ts
/**
 * Pairs one `approval/asked` audit event with its `approval/decided`.
 * Service-issued (one fresh id per {@link ApprovalService.request} call).
 */
type ApprovalRequestId$1 = Branded<'ApprovalRequestId'>;
/**
 * Brand a string as an {@link ApprovalRequestId}.
 * @param id - the raw id string to brand.
 * @returns the same string carrying the brand.
 */
declare function ApprovalRequestId$1(id: string): ApprovalRequestId$1;
/**
 * Closed approval outcomes: a one-shot grant, explicit rejection, withdrawn
 * request, or unavailable answerer. Callers fail closed on `unavailable`.
 */
type ApprovalOutcome = 'allowed-once' | 'rejected' | 'cancelled' | 'unavailable';
declare module '@deepseek-ai/dsh-session/types' {
  interface SessionEventMap {
    /**
     * An approval question was put to the answerer chain — log-only audit
     * (like `hook/*`; NOT a surface event, carries no `surfaceOp`). `id` pairs
     * it with the `approval/decided` that always follows; `toolName` is the
     * tool the question is about, `callId` the exact tool call when the asker
     * had one, `reason` the asker's human-readable explanation (e.g. a hook's
     * permission-decision reason).
     */
    'approval/asked': {
      id: ApprovalRequestId$1;
      toolName: string;
      callId?: ToolCallId;
      reason?: string;
    };
    /**
     * The outcome of a prior `approval/asked` (same `id`) — log-only audit.
     * Exactly one per ask, appended when the outcome is known: a decision, a
     * cancellation, or the fail-closed `'unavailable'`.
     */
    'approval/decided': {
      id: ApprovalRequestId$1;
      outcome: ApprovalOutcome;
    };
  }
}
/** Client-safe payload declared for the approval answerer waterfall. */
interface ApprovalRequestEvent {
  /** Agent identity projected to the corresponding Client Context in transit. */
  readonly agent: Agent;
  /** Tool whose operation requires a decision. */
  readonly toolName: string;
  /** Exact tool call being decided, when available. */
  readonly callId?: ToolCallId;
  /** Human-readable reason supplied by the asker. */
  readonly reason?: string;
  /** Cancellation lifetime of the pending request. */
  readonly signal?: AbortSignal;
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * Ask composed answerers for one decision. Return an outcome to claim the
     * request or call `next()` to delegate. Scope-filtered dispatch
     * (`@deepseek-ai/dsh-scope`): agent-scoped listeners receive only that agent.
     * @param req - pending approval request.
     * @mode waterfall
     */
    'approval/request'(this: Scoped<Agent>, req: ApprovalRequestEvent, next: () => Promise<ApprovalOutcome>): Promise<ApprovalOutcome>;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../interaction/user-questions/lib/types/types.d.ts
/** One selectable answer offered to the user. */
interface AskUserQuestionOption {
  /** User-facing label. */
  label: string;
  /** Optional extra context rendered by capable UIs. */
  description?: string;
}
/**
 * A caller-declared presentation intent: the question IS this kind of
 * decision, so a UI that recognises the tag may present it as such instead of as a
 * generic option list. Tagged so further intents can be added; a UI that does
 * not know a tag renders the generic flow, and the answer encoding is identical
 * either way — an intent changes presentation only, never the protocol.
 */
type AskUserQuestionIntent = {
  /** A plan submitted for review: `detail` is the plan markdown `ask()` requires, and the decision approves or declines it. */kind: 'plan-review';
  /**
   * The option label that approves the plan; every other option declines it.
   * Named rather than positional so no UI infers the verdict from option order.
   * An `approve` naming no option of its own question is rejected at `ask()`.
   */
  approve: string;
};
/** One question in a user-questions request. */
interface AskUserQuestionItem {
  /** Stable caller-provided question id, echoed in the answer. */
  id: string;
  /** The question to display. */
  question: string;
  /** Optional supporting detail rendered with the question but kept out of option labels. */
  detail?: string;
  /** Optional short heading/group label. */
  header?: string;
  /** Optional choices the UI can render as a menu. */
  options?: AskUserQuestionOption[];
  /** Whether more than one option may be selected. Defaults to single-select. */
  multiSelect?: boolean;
  /** Optional presentation intent for capable UIs; absent asks for the generic option list. */
  intent?: AskUserQuestionIntent;
}
/** Answer to one question. */
interface AskUserQuestionAnswerItem {
  /** The answered question id. */
  id: string;
  /** Selected option labels. May accompany custom text for a multi-select question. */
  selected: string[];
  /** Optional free-text "Other" answer. */
  custom?: string;
}
/** The human's answer. */
interface AskUserQuestionAnswer {
  /** Structured answers keyed by question id. */
  answers: AskUserQuestionAnswerItem[];
}
/** Client-safe payload declared for the user-question answerer waterfall. */
interface AskUserQuestionRequestEvent {
  /** Questions to display. */
  questions: AskUserQuestionItem[];
  /** Agent identity projected to the corresponding Client Context in transit. */
  agent?: Agent;
  /** Cancellation lifetime of the pending request. */
  signal?: AbortSignal;
}
declare module '@deepseek-ai/cordis' {
  interface Events {
    /**
     * Ask composed answerers for structured user input. Return an answer to
     * claim the request or call `next()` to delegate. Scope-filtered dispatch
     * (`@deepseek-ai/dsh-scope`): agent-scoped listeners receive only that agent.
     * @param request - pending user-question request.
     * @mode waterfall
     */
    'user-questions/request'(this: Scoped<Agent>, request: AskUserQuestionRequestEvent, next: () => Promise<AskUserQuestionAnswer>): Promise<AskUserQuestionAnswer>;
  }
} //# sourceMappingURL=types.d.ts.map
//#endregion
//#region ../../extensions/cordis-host-runner/lib/typert.remote-client.d.ts
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespace$64796e616d6963436f7264697352756e6e6572 {
    getClientCode: (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId) => Promise<RemoteResult$1<DynamicCordisClientSource>>;
    inventory: () => Promise<RemoteResult$1<DynamicCordisInventoryRow[]>>;
    invoke: (pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, method: string, args: JsonValue$1) => Promise<RemoteResult$1<DynamicCordisInvokeResult>>;
    reportClientGuardFailure: (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: CordisErrorDetails) => Promise<RemoteResult$1<null>>;
    reportRenderFailure: (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: DynamicCordisRenderFailure) => Promise<RemoteResult$1<null>>;
    resolveInspectQuery: (agentId: SessionId, requestId: CordisInspectRequestId, resolution: CordisInspectQueryResolution) => Promise<RemoteResult$1<CordisInspectResolveAck>>;
    resolveRequestRun: (requestId: ApprovalRequestId, resolution: DynamicCordisRunResolution) => Promise<RemoteResult$1<DynamicCordisResolveAck>>;
    runHostHalf: (agentId: SessionId, pluginId: CordisDynamicPluginId, packageId: CordisDynamicPackageId, mode: CordisDynamicRunMode, requestId: ApprovalRequestId | null, approveFutureVersions: boolean) => Promise<RemoteResult$1<DynamicCordisHostHalfResult>>;
    settleUserRun: (agentId: SessionId, pluginId: CordisDynamicPluginId, resolution: DynamicCordisRunResolution) => Promise<RemoteResult$1<DynamicCordisRunResponse>>;
    stopFromPanel: (agentId: SessionId, pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisStopResponse>>;
    syncInspectManifest: (providers: readonly CordisInspectProviderManifest[]) => Promise<RemoteResult$1<null>>;
    undefineFromPanel: (agentId: SessionId, pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisUndefineReceipt>>;
  }
  interface TypertRemoteMap {
    'dynamicCordisRunner/getClientCode': (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId) => Promise<RemoteResult$1<DynamicCordisClientSource>>;
    'dynamicCordisRunner/inventory': () => Promise<RemoteResult$1<DynamicCordisInventoryRow[]>>;
    'dynamicCordisRunner/invoke': (pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, method: string, args: JsonValue$1) => Promise<RemoteResult$1<DynamicCordisInvokeResult>>;
    'dynamicCordisRunner/reportClientGuardFailure': (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: CordisErrorDetails) => Promise<RemoteResult$1<null>>;
    'dynamicCordisRunner/reportRenderFailure': (agentId: SessionId, pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: DynamicCordisRenderFailure) => Promise<RemoteResult$1<null>>;
    'dynamicCordisRunner/resolveInspectQuery': (agentId: SessionId, requestId: CordisInspectRequestId, resolution: CordisInspectQueryResolution) => Promise<RemoteResult$1<CordisInspectResolveAck>>;
    'dynamicCordisRunner/resolveRequestRun': (requestId: ApprovalRequestId, resolution: DynamicCordisRunResolution) => Promise<RemoteResult$1<DynamicCordisResolveAck>>;
    'dynamicCordisRunner/runHostHalf': (agentId: SessionId, pluginId: CordisDynamicPluginId, packageId: CordisDynamicPackageId, mode: CordisDynamicRunMode, requestId: ApprovalRequestId | null, approveFutureVersions: boolean) => Promise<RemoteResult$1<DynamicCordisHostHalfResult>>;
    'dynamicCordisRunner/settleUserRun': (agentId: SessionId, pluginId: CordisDynamicPluginId, resolution: DynamicCordisRunResolution) => Promise<RemoteResult$1<DynamicCordisRunResponse>>;
    'dynamicCordisRunner/stopFromPanel': (agentId: SessionId, pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisStopResponse>>;
    'dynamicCordisRunner/syncInspectManifest': (providers: readonly CordisInspectProviderManifest[]) => Promise<RemoteResult$1<null>>;
    'dynamicCordisRunner/undefineFromPanel': (agentId: SessionId, pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisUndefineReceipt>>;
  }
  interface TypertRemoteNamespaceMap {
    'dynamicCordisRunner': TypertRemoteNamespace$64796e616d6963436f7264697352756e6e6572;
  }
  interface TypertRemoteScopeMap {
    'agent:dynamicCordisRunner/getClientCode': (pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId) => Promise<RemoteResult$1<DynamicCordisClientSource>>;
    'agent:dynamicCordisRunner/reportClientGuardFailure': (pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: CordisErrorDetails) => Promise<RemoteResult$1<null>>;
    'agent:dynamicCordisRunner/reportRenderFailure': (pluginId: CordisDynamicPluginId, pluginRunId: CordisDynamicPluginRunId, failure: DynamicCordisRenderFailure) => Promise<RemoteResult$1<null>>;
    'agent:dynamicCordisRunner/resolveInspectQuery': (requestId: CordisInspectRequestId, resolution: CordisInspectQueryResolution) => Promise<RemoteResult$1<CordisInspectResolveAck>>;
    'agent:dynamicCordisRunner/runHostHalf': (pluginId: CordisDynamicPluginId, packageId: CordisDynamicPackageId, mode: CordisDynamicRunMode, requestId: ApprovalRequestId | null, approveFutureVersions: boolean) => Promise<RemoteResult$1<DynamicCordisHostHalfResult>>;
    'agent:dynamicCordisRunner/settleUserRun': (pluginId: CordisDynamicPluginId, resolution: DynamicCordisRunResolution) => Promise<RemoteResult$1<DynamicCordisRunResponse>>;
    'agent:dynamicCordisRunner/stopFromPanel': (pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisStopResponse>>;
    'agent:dynamicCordisRunner/undefineFromPanel': (pluginId: CordisDynamicPluginId) => Promise<RemoteResult$1<DynamicCordisUndefineReceipt>>;
  }
}
//#endregion
//#region lib/types/client/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Generated Remote namespaces selected by this Client assembly. */
    remote: ClientRemote;
  }
}
/**
 * Select admission requirements from the exact generated descriptors this assembly mounts.
 * @param endpoints - required endpoints; duplicates collapse and an empty selection admits metadata only.
 * @returns requirements sorted by endpoint, ready before any Client plugin mounts.
 * @throws when an endpoint is absent from this assembly or lacks generated compatibility evidence.
 */
declare function selectRemoteCapabilities(endpoints: readonly (keyof TypertRemoteMap)[]): readonly RemoteCapabilityRequirement[];
/** Required service: the typed Client Remote contribution mount. */
declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
declare function apply$4(ctx: Context): Promise<() => Promise<void>>;
//#endregion
//#region ../session-controller/lib/types/client/scope.d.ts
/** Client Cordis Context carrying one Agent identity and its scoped Remote namespaces. */
type AgentContext = Omit<Context, 'remote'> & {
  readonly remote: ClientRemote & TypertRemoteScopeApi<'agent'>;
};
/**
 * Read the nearest agent tag inherited by a context.
 * @param ctx - any client context.
 * @returns its agent identity (the session id), or undefined for root contexts.
 */
declare function scopeOf(ctx: Context): SessionId | undefined;
//#endregion
//#region ../../client/store/lib/types/contract.d.ts
/** Framework-neutral snapshot and store contracts. */
/** Minimal observable snapshot source shared by controllers, stores, and render adapters. */
interface ObservableSnapshot<T> {
  /** Read the cached snapshot reference. */
  getSnapshot(): T;
  /**
   * Subscribe to snapshot invalidation.
   * @param fn - invalidation callback.
   * @returns unsubscribe function.
   */
  subscribe(fn: () => void): () => void;
}
//#endregion
//#region ../session-controller/lib/types/client/contract/snapshot.d.ts
/** One transient inbox occurrence from the authoritative queue snapshot. */
interface QueuedMessage {
  readonly id: MessageId;
  readonly messageId: MessageId;
  readonly placement: 'queued' | 'steering' | 'context';
  /** Prompt-RPC identity of a browser-submitted occurrence; correlates the local submission echo. */
  readonly rpcId?: SessionRequestId;
  readonly content: readonly ContentBlock[];
  readonly preview: string;
  readonly text: string | null;
}
/** One image displayed by a local submission echo before durable admission. */
interface PendingSubmissionImage {
  /** Browser-owned preview URL; its lifecycle belongs to the submitter, never this snapshot. */
  readonly previewUrl: string;
  /** Browser file name, when the file had one. */
  readonly name?: string;
  /** Intrinsic pixel width, when the submitter has probed it. */
  readonly width?: number;
  /** Intrinsic pixel height, when the submitter has probed it. */
  readonly height?: number;
}
/** Image branch of a local submission echo attachment. */
interface PendingSubmissionImageAttachment {
  readonly type: 'image';
  readonly value: PendingSubmissionImage;
}
/** File branch of a local submission echo attachment. */
interface PendingSubmissionFileAttachment {
  readonly type: 'file';
  readonly value: FileAttachmentRef;
}
/** One attachment displayed by a local submission echo, in prompt order. */
type PendingSubmissionAttachment = PendingSubmissionImageAttachment | PendingSubmissionFileAttachment;
/** Client surface selected when a local submission begins. */
type PendingSubmissionPlacement = 'transcript' | 'queued' | 'steering';
/**
 * One local prompt-submission echo: inserted synchronously when a submission
 * begins, so the conversation can show the message before serialization,
 * transport, and durable admission complete. Client-memory only — reload and
 * reconnect rebuild the conversation from durable events alone.
 */
interface PendingSubmission {
  /** The prompt RPC identity; the durable `user/message` source echoes it as `rpcId`. */
  readonly requestId: SessionRequestId;
  /** Expected surface until the Host reports the admitted queue or durable occurrence. */
  readonly placement: PendingSubmissionPlacement;
  /** Client wall-clock ms when the submission began. */
  readonly time: number;
  /** Prompt text exactly as it will be sent (one text block). */
  readonly text: string;
  /** Ordered image previews and durable file metadata matching the prompt attachments. */
  readonly attachments: readonly PendingSubmissionAttachment[];
}
/** History-open lifecycle of a Session event window. */
type OpenState = 'cold' | 'loading' | 'open' | 'error';
/** Send/stop failure surfaced by Session consumers. */
interface PromptError {
  readonly op: 'send' | 'stop';
  readonly error: RemoteFailure$1;
}
/** Immutable Session lifecycle and control snapshot. */
interface SessionSnapshot {
  readonly sessionId: SessionId;
  readonly queue: readonly QueuedMessage[];
  /** Local prompt-submission echoes not yet observed as durable events or queue occurrences. */
  readonly pendingSubmissions: readonly PendingSubmission[];
  readonly running: boolean;
  readonly subagent: {
    readonly address: SubagentAddress; /** Absent until the direct-parent catalog resolves. */
    readonly parentAvailable?: boolean;
  } | null;
  readonly removed: boolean;
  /** Last loaded transcript remains readable during carrier recovery. */
  readonly syncing?: boolean;
  readonly openState: OpenState;
  readonly openError: RemoteFailure$1 | null;
  readonly hasMore: boolean;
  readonly loadingOlder: boolean;
  readonly promptError: PromptError | null;
  readonly blank: boolean;
  readonly lastAgentError: string | null;
  /** A prompt call has begun on this Client Session object. */
  readonly promptAttempted: boolean;
  /** The first accepted prompt has not reached a durable `turn/start` event. */
  readonly awaitingFirstTurn: boolean;
}
//#endregion
//#region ../session-controller/lib/types/client/contract/session.d.ts
/**
 * Why a local submission echo left the snapshot: `observed` when its durable
 * `user/message` event or host queue occurrence arrived (with the admitted
 * attachment references in prompt order), `failed` when the prompt was rejected,
 * threw, or was aborted before acceptance.
 */
type PendingSubmissionRetirement = {
  readonly reason: 'observed';
  readonly attachments: readonly (ImageAttachmentRef | FileAttachmentRef)[];
} | {
  readonly reason: 'failed';
};
/** Input registering one local submission echo ahead of its prompt call. */
interface BeginSubmissionInput {
  /** Delivery mode used with the upcoming prompt. */
  readonly mode: 'queue' | 'steer';
  /** Prompt text exactly as the upcoming prompt will send it. */
  readonly text: string;
  /** Ordered image previews and durable file metadata matching the upcoming prompt attachments. */
  readonly attachments: readonly PendingSubmissionAttachment[];
  /** Settlement callback fired exactly once when the echo retires. */
  readonly onRetire?: (retirement: PendingSubmissionRetirement) => void;
}
/** One registered submission echo: the identity its prompt must carry, and the pre-prompt escape hatch. */
interface SubmissionHandle {
  /** The prompt RPC identity; pass it to {@link ISession.prompt}. */
  readonly requestId: SessionRequestId;
  /** Retire the echo as failed when the caller cannot reach prompt() (serialization failure); no-op after any other settlement. */
  abandon(): void;
}
/** Key-addressed projection read face (the useProjection resolution path; see ProjectionValueStore). */
interface ProjectionsFace {
  /**
   * The identity-stable bare observable for one projection key (absence is
   * an `undefined` snapshot, never a missing face).
   * @param key - projection key.
   * @returns the key's value face.
   */
  faceOf(key: string): ObservableSnapshot<unknown>;
}
/** Identity plus the behavior verbs features may invoke on a session. */
interface ISession {
  /** The session's host identity (agent id — same axis). */
  readonly sessionId: SessionId;
  /** Host-computed projection values by key (the useProjection seat). */
  readonly projections: ProjectionsFace;
  /**
   * Register one local submission echo in `snapshot.pendingSubmissions`,
   * synchronously, before the caller serializes and sends the prompt. The
   * echo retires when a durable `user/message` event or queue occurrence
   * carrying the returned identity arrives, or when the identified prompt
   * call fails.
   * @param input - echo content and the optional settlement callback.
   * @returns the minted identity for {@link prompt} plus the pre-prompt abandon path.
   */
  beginSubmission(input: BeginSubmissionInput): SubmissionHandle;
  /**
   * Send a prompt into the session.
   * @param content - text plus browser-owned temporary image uploads.
   * @param mode - 'queue' appends a turn; 'steer' interrupts the running one.
   * @param signal - optional caller cancellation for the complete admission round-trip.
   * @param requestId - identity from {@link beginSubmission}; a failed identified prompt retires its echo.
   * @returns acceptance, or the business error (also mirrored into snapshot.promptError).
   */
  prompt(content: PromptContentPart[], mode: 'queue' | 'steer', signal?: AbortSignal, requestId?: SessionRequestId): Promise<RemoteResult$1<{
    accepted: true;
  }>>;
  /**
   * Resolve one durable image referenced by this session.
   * @param attachmentId - opaque id found in the folded session log.
   * @returns the authenticated reference and decoded bytes.
   */
  readAttachment(attachmentId: AttachmentId): Promise<RemoteResult$1<{
    attachment: ImageAttachmentRef;
    data: Uint8Array;
  }>>;
  /**
   * Apply one edit, remove, or Steer action to a still-pending queue occurrence.
   * @param itemId - agent-owned inbox occurrence identity.
   * @param action - requested queue operation.
   * @returns acceptance, or a business/transport error.
   */
  updateQueue(itemId: MessageId, action: QueueAction): Promise<RemoteResult$1<{
    accepted: true;
  }>>;
  /**
   * Cancel the running turn. Pending queued work remains and resumes in FIFO
   * order after the Host reaches cancellation quiescence.
   * @returns acceptance, or the business error.
   */
  cancel(): Promise<RemoteResult$1<{
    accepted: true;
  }>>;
  /**
   * Rename this session (explicit user title; pins it against automatic
   * regeneration).
   * @param title - raw title text (the host normalizes acceptance).
   * @returns the normalized accepted title and its event seq, or the business error.
   */
  rename(title: string): Promise<RemoteResult$1<{
    title: string;
    seq: SessionSeq;
  }>>;
  /**
   * Extend the history window backwards (older messages pagination).
   * @returns completion; failures land in snapshot.openState/loadingOlder.
   */
  loadOlder(): Promise<void>;
  /** Retry a failed history load. @returns completion of the new load. */
  retryOpen(): Promise<void>;
  /** Fetch one exact deferred result. @param seq - result sequence. @returns completion of the window update. */
  loadHistoryDetail(seq: number): Promise<void>;
  /**
   * Page history backwards until the window covers `seq` (inclusive) — the
   * turn-jump loader. Repeated calls while a jump is paging lower its shared
   * target and return the in-flight completion; `snapshot.loadingOlder` is
   * the busy signal for the whole jump.
   * @param seq - durable event seq the window must reach (a turn's `turn/start` seq).
   * @returns completion once covered, exhausted, superseded, or failed soft.
   */
  loadThrough(seq: SessionSeq): Promise<void>;
  /**
   * Execute one slash-command line against this session's agent — pure
   * admission semantics (the host executor durably logs the lifecycle).
   * @param line - the full command line, leading slash included.
   * @returns the admission result, or the Remote face's error branch.
   */
  command(line: string): Promise<RemoteResult$1<{
    matched: boolean;
  }>>;
}
/**
 * The full outward face: behavior verbs plus the Session lifecycle read side
 * (the `useSession` hook source). This is the type carried by
 * `SessionBinding.session` and the provide channel.
 */
type SessionFace = ISession & ObservableSnapshot<SessionSnapshot>;
//#endregion
//#region ../session-controller/lib/types/client/contract/events.d.ts
/** Client-only live chunk presentation; `seq` orders the transient row between durable Session seqs. */
interface AssistantLiveChunkEvent {
  readonly type: 'assistant/live-chunk';
  readonly seq: number;
  readonly time: number;
  readonly data: {
    readonly attemptId: LlmAttemptId;
    readonly turn: number;
    readonly step: number;
    readonly chunk: StreamChunk;
  };
}
/** Client history entry retaining its coarse transport discriminator. */
type SessionEventLikeEntry = {
  readonly type: 'event';
  readonly event: SessionEvent;
  readonly detail?: {
    readonly kind: 'tool-result';
    readonly bytes: number;
  };
} | {
  readonly type: 'transient';
  readonly event: AssistantLiveChunkEvent;
};
/** Scalar live entry accepted by append-only Client paths. */
type SessionLiveEventEntry = Extract<SessionEventLikeEntry, {
  readonly type: 'event';
}>;
/** Durable Assistant event that atomically supersedes one attempt's transient rows. */
interface SessionAssistantSettlementEntry {
  readonly type: 'event';
  readonly event: SessionEvent<'assistant/message'> | SessionEvent<'assistant/attempt'>;
}
/** Exact delta that produced the latest event-window revision. */
type SessionEventChange = {
  readonly kind: 'replace';
  readonly entries: readonly SessionEventLikeEntry[];
} | {
  readonly kind: 'prepend';
  readonly entries: readonly SessionEventLikeEntry[];
} | {
  readonly kind: 'append';
  readonly entries: readonly SessionEventLikeEntry[];
} | {
  readonly kind: 'settle-assistant';
  readonly attemptId: LlmAttemptId;
  readonly entry?: SessionAssistantSettlementEntry;
};
/** Current contiguous event window and its latest synchronous delta. */
interface SessionEventWindow {
  readonly entries: readonly SessionEventLikeEntry[];
  readonly hasMore: boolean;
  readonly revision: number;
  readonly change: SessionEventChange;
}
/** Conversation-facing event source exposed by one Session binding. */
type SessionEventSource = ObservableSnapshot<SessionEventWindow>;
/** Session-owned event feed; every accepted window mutation publishes synchronously. */
declare class MutableSessionEventSource implements SessionEventSource {
  private readonly listeners;
  private window;
  private snapshot;
  /** @returns the cached event-window snapshot. */
  getSnapshot(): SessionEventWindow;
  /**
   * Subscribe to synchronous window publication.
   * @param listener - invalidation callback.
   * @returns unsubscribe function.
   */
  subscribe(listener: () => void): () => void;
  /**
   * Replace the complete contiguous window.
   * @param entries - complete window.
   * @param hasMore - whether older history remains.
   */
  replace(entries: readonly SessionEventLikeEntry[], hasMore: boolean): void;
  /**
   * Prepend one older contiguous page.
   * @param entries - newly loaded older entries.
   * @param hasMore - whether still older history remains.
   */
  prepend(entries: readonly SessionEventLikeEntry[], hasMore: boolean): void;
  /**
   * Append one contiguous live entry.
   * @param entry - live tail entry.
   */
  append(entry: SessionEventLikeEntry): void;
  /**
   * Replace one attempt's transient rows with its committed durable settlement.
   * @param attemptId - process-local attempt whose live rows are now redundant.
   * @param entry - durable settlement committed for that attempt.
   */
  settleAssistant(attemptId: LlmAttemptId, entry?: SessionAssistantSettlementEntry): void;
  private publish;
}
//#endregion
//#region ../session-controller/lib/types/client/transport.d.ts
/** Pagination fields bound to an already-addressed Session journal. */
type ClientSessionPageRequest = Omit<SessionPageRequest, 'address' | 'throughSeq'>;
/** Complete generated `ctx.remote.session` namespace. */
type SessionRemote = ClientRemote['session'];
/** Opening metadata carried only by a follow snapshot, never by loadOlder pages. */
interface SessionJournalPage extends SessionPage {
  readonly projections?: SessionProjectionBaseline;
  readonly assistantStream?: SessionAssistantStreamBaseline;
}
/** One complete publication from the Session journal stream. */
type SessionJournalChange = {
  readonly type: 'replace' | 'prepend';
  readonly page: SessionJournalPage;
  readonly entries: readonly SessionEventLikeEntry[];
  readonly hasMore: boolean;
} | {
  readonly type: 'append';
  readonly entry: SessionLiveEventEntry;
} | {
  readonly type: 'assistant-stream';
  readonly frame: SessionAssistantStreamFrame;
};
type SessionControlBaselineFrame = Extract<SessionControlFrame, {
  type: 'baseline';
}>;
type SessionControlDeltaFrame = Exclude<SessionControlFrame, SessionControlBaselineFrame>;
/** Gateway-owned control snapshot stream configured for Session frames. */
type SessionControlStream = RemoteSnapshotStream<SessionControlBaselineFrame, SessionControlDeltaFrame>;
/** Domain sinks used by the Host-wide Session control stream. */
interface SessionControlStreamOptions {
  /** Apply a complete baseline or one later update. */
  readonly accept: (frame: SessionControlFrame) => void;
  /** Observe a retryable carrier loss before reconnection. */
  readonly carrierFailed?: (error: RemoteStreamCarrierError) => void;
  /** Publish a terminal business or protocol failure. */
  readonly failed: (error: unknown) => void;
}
/** Domain sinks used by one addressed Session event journal. */
interface SessionEventStreamOptions {
  /** Apply one complete event-window change. */
  readonly publish: (change: SessionJournalChange) => void;
  /** Observe a retryable carrier loss before reconnection. */
  readonly carrierFailed?: (error: RemoteStreamCarrierError) => void;
  /** Publish a terminal stream, page, or protocol failure after opening. */
  readonly failed: (error: unknown) => void;
}
/**
 * Create the Host-wide Session control snapshot stream.
 * @param remote - generated Session namespace and Gateway stream factory.
 * @param options - Session state destinations.
 * @returns an unstarted stream owned by the Client Session runtime.
 */
declare function createSessionControlStream(remote: SessionRemotes, options: SessionControlStreamOptions): SessionControlStream;
/** Gateway-owned event journal bound to one ordinary or direct-subagent Session address. */
declare class SessionEventStream extends RemoteJournalStream<SessionJournalPage, SessionHistoryRecord, number, ClientSessionPageRequest, SessionAssistantStreamFrame> {
  private readonly remote;
  private readonly address;
  /**
   * @param remote - generated Session namespace and Gateway stream factory.
   * @param address - durable ordinary-Session or direct-subagent address.
   * @param options - Session event-window destinations.
   */
  constructor(remote: SessionRemotes, address: SessionAddress, options: SessionEventStreamOptions);
  /** @inheritdoc */
  protected follow(request: ClientSessionPageRequest, signal: AbortSignal): AsyncIterable<RemoteJournalFrame<SessionHistoryRecord, number, SessionJournalPage, SessionAssistantStreamFrame>>;
  /** @inheritdoc */
  protected readPage(request: ClientSessionPageRequest, throughSeq: number, signal: AbortSignal): Promise<SessionJournalPage>;
  /** @inheritdoc */
  protected repairRequest(request: ClientSessionPageRequest): ClientSessionPageRequest;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/remotes.d.ts
/** Narrow Commands namespace consumed by a Client Session. */
interface SessionCommandsRemote {
  execute(agentId: SessionId, line: string, attachments: readonly CommandSubmitAttachment[], signal?: AbortSignal): Promise<RemoteResult$1<object | undefined>>;
}
/** Narrow subagent namespace consumed by a Client Session and its manager. */
interface SessionSubagentsRemote {
  list(parentSessionId: SessionId, signal?: AbortSignal): Promise<RemoteResult$1<SubagentCatalog>>;
  prompt(request: SubagentPromptRequest, signal?: AbortSignal): Promise<RemoteResult$1<SubagentPromptReceipt>>;
  interruptByParent(childSessionId: SessionId, parentSessionId: SessionId, mode: 'continuable'): Promise<RemoteResult$1<SubagentInterruptReceipt>>;
}
/** Generated Remote namespaces consumed by the Client Session object layer. */
interface SessionRemotes {
  readonly $stream: ClientRemote['$stream'];
  readonly commands: SessionCommandsRemote;
  readonly session: SessionRemote;
  readonly subagents: SessionSubagentsRemote;
}
//#endregion
//#region ../session-controller/lib/types/client/platform.d.ts
/** Request identity and device time zone sampled by Session commands. */
interface SessionPlatform {
  /** @returns a fresh, collision-resistant identity for one submitted command. */
  createRequestId(): SessionRequestId;
  /** @returns the current device IANA time zone to record with a prompt. */
  timeZone(): string;
}
/** Navigation restored only for the host that owns these Session identities. */
interface SessionSelection {
  sessionId?: SessionId;
  subagentAddress?: SubagentAddress;
}
/** Caller-owned preferences, hydrated and validated before Session installation. */
interface SessionSelectionStore {
  /** @returns the current selection for this host. */
  getSnapshot(): SessionSelection;
  /**
   * Replace this host's selection; asynchronous persistence stays caller-owned.
   * @param selection - validated navigation projected by the Session service.
   */
  set(selection: SessionSelection): void;
}
/** Inputs owned by one host connection, never shared between independent hosts. */
interface SessionClientOptions {
  platform: SessionPlatform;
  /** Persistence failures must not throw through a Session state notification. */
  selection: SessionSelectionStore;
}
//#endregion
//#region ../session-controller/lib/types/client/sessions/manager.d.ts
/**
 * List arrival lifecycle, orthogonal to the pull-activity `state` axis:
 * `pending` (no successful pull yet — an empty items array means "nothing
 * arrived", not "nothing exists") → `ready` (at least one pull landed).
 * Monotone: `ready` never steps back — later pull failures and reconnect
 * re-pulls ride the `state`/`error` axis, which is where failure is modeled
 * (no `error` phase here; that would duplicate `state`).
 */
type SessionListPhase = 'pending' | 'ready';
/** Request-local content hit returned to sidebar search consumers. */
interface SessionSearchResultItem {
  sessionId: SessionId;
  snippet: string;
}
/** One parent-addressed durable catalog projected through the sessions snapshot. */
type SubagentCatalogSnapshot = Omit<SubagentCatalog, 'parentAvailable'> & {
  /** Absent until the first successful catalog read. */readonly parentAvailable?: boolean;
  state: 'loading' | 'ready' | 'error';
  error: RemoteFailure$1 | null;
};
//#endregion
//#region ../session-controller/lib/types/client/sessions/service.d.ts
/** Session list row projected from the host list RPC plus live stream increments. */
interface SessionSummary$1 {
  id: SessionId;
  /** Latest durable log-backed title, absent until the host projects one. */
  title?: string;
  /** Human-facing label: durable title, project basename, then session id. */
  displayTitle: string;
  cwd?: string;
  parentId?: SessionId;
  /** Coarse durable origin for navigation filtering; not a continuation capability. */
  origin?: 'subagent';
  running: boolean;
  /** Finished while not selected and not yet opened — the sidebar's green "done" reminder. Absent = false. */
  completed?: boolean;
  /**
   * Empty-log bit (host summary derivation mirror). New Session reuses a blank
   * one targeting the same workspace. Filtering stays with the consumer: the
   * store carries every row, while the Workspace browser shows only the
   * selected blank entry.
   */
  blank: boolean;
  updatedAt: number;
  /** Current host-computed projection values retained by the object layer. */
  projectionValues?: Readonly<Partial<SessionProjectionMap>>;
}
/**
 * Session list store shape. `current` rides the same snapshot (arbitrated:
 * the single useSessions standard hook reads list and selection together —
 * sidebar highlighting and current-session consumers share one fact source).
 */
interface SessionListState {
  /** Host-list order; addressed breadcrumb-only rows are excluded. */
  ids: SessionId[];
  /** Host rows plus the current addressed subagent route used by navigation. */
  byId: Record<SessionId, SessionSummary$1>;
  current: SessionId | undefined;
  /** Arrival lifecycle projected 1:1 from the manager snapshot (see SessionListPhase): empty-with-ready means "truly no sessions". */
  phase: SessionListPhase;
  hasMore?: boolean;
  loadingMore?: boolean;
  /** Direct durable catalogs keyed by their selected parent address. */
  subagentsByParent: Readonly<Record<SessionId, SubagentCatalogSnapshot>>;
  /**
   * Background jobs each session can see, mirrored last-wins from Session
   * Controller's control baseline and `jobs` frames. A missing key is an empty
   * set, so consumers read absence rather than a sentinel.
   */
  jobsBySession: Readonly<Record<SessionId, readonly SessionJob[]>>;
  /** Current session's catalog-derived address, absent on ordinary navigation. */
  currentAddress: SubagentAddress | undefined;
}
/** Structured session-create failure. */
declare class SessionCreateError extends Error {
  readonly rpcError: RemoteFailure$1;
  readonly requestedSessionId: SessionId | undefined;
  readonly name = "SessionCreateError";
  /**
   * @param rpcError - Host business or folded transport error.
   * @param requestedSessionId - caller-preallocated id used for later stream/list reconciliation.
   */
  constructor(rpcError: RemoteFailure$1, requestedSessionId: SessionId | undefined);
}
/** Structured session-fork failure. */
declare class SessionForkError extends Error {
  readonly rpcError: RemoteFailure$1;
  readonly sourceSessionId: SessionId;
  readonly name = "SessionForkError";
  /**
   * @param rpcError - Host business or folded transport error.
   * @param sourceSessionId - the session the fork was cut from.
   */
  constructor(rpcError: RemoteFailure$1, sourceSessionId: SessionId);
}
/** Identity-stable logical binding for one materialized Client Session. */
interface SessionBinding {
  readonly sessionId: SessionId;
  /** The outward session face only — feature code never sees the concrete class. */
  readonly session: SessionFace;
  /** Contiguous event window reserved for Conversation assembly. */
  readonly eventSource: SessionEventSource;
  readonly ctx: AgentContext;
}
//#endregion
//#region ../session-controller/lib/types/client/contract/sessions.d.ts
/** The sessions-service face injected as `ctx.sessions`. */
interface ISessions {
  /** The useSessions standard feed (list rows + current selection; read face — writes stay inside the domain). */
  readonly list: ObservableSnapshot<SessionListState>;
  /**
   * The `session.search` result bound the wire schema fixes, exposed to
   * presentation as injected data. Not per-connection state: every transport
   * (fixture included) reports the same number.
   */
  readonly searchResultLimit: number;
  /** Fetch the next session-list continuation page. */
  loadMore(): Promise<void>;
  /**
   * Create or adopt a Session on the Host.
   * @param opts - target workspace, directory, and optional preallocated identity.
   * @returns the Session identity after its local binding is addressable.
   */
  create(opts?: {
    workspaceId?: WorkspaceId;
    cwd?: string;
    sessionId?: SessionId;
  }): Promise<SessionId>;
  /**
   * Select a session as current.
   * @param id - session id (must exist in the list; unknown ids fail loud).
   */
  open(id: SessionId): void;
  /**
   * Open a healthy catalog child through its exact direct-parent address.
   * @param address - catalog-derived parent and child ids.
   */
  openSubagent(address: SubagentAddress): void;
  /**
   * Resolve an already discovered direct-parent address without opening it.
   * @param id - possible addressed child id.
   * @returns the retained address, when present.
   */
  subagentAddress(id: SessionId): SubagentAddress | undefined;
  /**
   * Mark whether a catalog menu is consuming live membership updates.
   * @param parentSessionId - catalog owner.
   * @param open - current menu state.
   */
  setSubagentCatalogOpen(parentSessionId: SessionId, open: boolean): void;
  /**
   * Refresh one direct-child catalog.
   * @param parentSessionId - catalog owner.
   * @returns completion of the current or newly started refresh.
   */
  refreshSubagents(parentSessionId: SessionId): Promise<void>;
  /** Clear the current selection into the no-session view state. */
  clear(): void;
  /**
   * Refresh the Host-authoritative Session list.
   * @returns completion of the current or newly started Session-list refresh.
   */
  refresh(): Promise<void>;
  /**
   * Search the Host's visible message-content index. Results stay
   * request-local; the list snapshot remains the metadata authority.
   * @param query - non-blank literal phrase.
   * @param signal - cancellation for a superseded search.
   * @returns bounded results, or a business/transport error.
   */
  search(query: string, signal: AbortSignal): Promise<RemoteResult$1<{
    items: SessionSearchResultItem[];
    hasMore: boolean;
  }>>;
  /**
   * Fork a session from a completed-turn prefix of the source; on resolution
   * the child is in the list store and `open()` can target it.
   * @param opts - source session id, the optional event seq anchoring the
   *   cut (the boundary is the first turn/end at or after it; an in-log
   *   anchor in an open turn is unavailable rather than clipped backward),
   *   and whether to increment an inherited durable title before resolving.
   * @returns the child session id.
   * @throws when the fork fails, or when a requested child-title rename fails after creation.
   */
  fork(opts: {
    sessionId: SessionId;
    atSeq?: number;
    increaseTitle?: boolean;
  }): Promise<SessionId>;
  /**
   * Resolve an Agent-scoped context view (use-and-discard).
   * @param id - session id.
   * @returns scoped ctx, or undefined for a session neither listed nor already scoped.
   */
  scope(id: SessionId): AgentContext | undefined;
  /**
   * Read the Agent scope tag off a context (service-method boundary: fetch
   * bundles must reach scope resolution through ctx.sessions).
   * @param ctx - any client context.
   * @returns the session id, or undefined on root contexts.
   */
  scopeOf(ctx: Context): SessionId | undefined;
  /**
   * Resolve the session face behind an Agent-scoped context.
   * @param ctx - an Agent-scoped context.
   * @returns the session face, or undefined when the ctx is untagged or its scope was pruned.
   */
  sessionOf(ctx: Context): SessionFace | undefined;
  /**
   * Resolve the stable session binding (scope-addressed assembly feed).
   * @param id - session id.
   * @returns binding, or undefined for a session neither listed nor already scoped.
   */
  binding(id: SessionId): SessionBinding | undefined;
}
//#endregion
//#region ../session-controller/lib/types/client/portable.d.ts
/** Required Remote and Context projection services. */
declare const inject$2: string[];
/**
 * Install Client Session state and its reconnecting control stream.
 * @param ctx - Client Cordis context for one host.
 * @param options - platform callbacks and hydrated host-specific navigation.
 */
declare function applySessions$1(ctx: Context, options: SessionClientOptions): void;
//#endregion
//#region ../session-controller/lib/types/client/index.d.ts
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Client Session object layer and Agent scope owner. */
    sessions: ISessions;
  }
}
/** Required services for the browser Session and attachment composition. */
//#endregion
//#region ../workspace-controller/lib/types/client/model.d.ts
/** Complete generated `ctx.remote.workspace` namespace. */
type WorkspaceRemote = TypertClientRemote['workspace'];
/** Monotone Workspace-list arrival lifecycle. */
type WorkspaceListPhase = 'pending' | 'ready';
/** Immutable Client Workspace state. */
interface WorkspaceSnapshot {
  readonly items: readonly WorkspaceView[];
  /** Complete registry-global archive set in Host order. */
  readonly archivedSessionIds: WorkspaceArchiveValue['archivedSessionIds'];
  readonly state: 'idle' | 'loading' | 'error';
  readonly phase: WorkspaceListPhase;
  readonly error: RemoteFailure$1 | null;
}
/** State operations emitted by a decoded Workspace follow generation. */
interface WorkspaceFollowSink {
  /** Replace all state from the generation baseline. */
  replaceBaseline(value: WorkspaceBaseline): void;
  /** Merge one Workspace row. */
  upsertView(workspace: WorkspaceView): void;
  /** Remove one Workspace row. */
  removeView(workspaceId: WorkspaceId): void;
  /** Replace the Host-confirmed Workspace order. */
  replaceOrder(workspaceIds: readonly WorkspaceId[]): void;
  /** Replace the complete archived Session set. */
  replaceArchived(sessionIds: WorkspaceArchiveValue['archivedSessionIds']): void;
}
/**
 * Owns the Client Workspace projection, mutation echoes, and stream/unary race resolution.
 */
declare class ClientWorkspaceModel implements WorkspaceFollowSink {
  private readonly remote;
  private items;
  private archivedSessionIds;
  private state;
  private phase;
  private error;
  /** Latest local reorder request; only its unary echo may install order. */
  private orderRequestGeneration;
  /** Increments on stream orders so a later remote commit outranks an older unary echo. */
  private orderFrameGeneration;
  /** Last complete order accepted from a baseline, increment, or current unary echo. */
  private committedOrder;
  /** Host Workspace ids are never reused, so delayed data cannot resurrect a removed row. */
  private readonly removedIds;
  private readonly listeners;
  private snapshotCache;
  private snapshotDirty;
  private notificationPending;
  private notificationScheduled;
  private notificationGeneration;
  /** @param remote - generated Workspace Remote namespace. */
  constructor(remote: WorkspaceRemote);
  /**
   * Create or resolve a Workspace and merge the unary result immediately.
   * @param input - existing absolute path to adopt.
   * @returns generated Remote result.
   */
  create(input: WorkspaceCreateRequest): Promise<RemoteResult$1<WorkspaceCreateValue>>;
  /**
   * Rename a Workspace and merge the unary result immediately.
   * @param workspaceId - target Workspace.
   * @param title - new display title.
   * @returns generated Remote result.
   */
  rename(workspaceId: WorkspaceId, title: string): Promise<RemoteResult$1<WorkspaceValue>>;
  /**
   * Delete a Workspace and remove it from the local projection immediately.
   * @param workspaceId - target Workspace.
   * @returns generated Remote result.
   */
  delete(workspaceId: WorkspaceId): Promise<RemoteResult$1<WorkspaceDeleteValue>>;
  /**
   * Optimistically move a Workspace and reconcile the returned complete order.
   * @param workspaceId - Workspace to move.
   * @param beforeWorkspaceId - anchor Workspace; omitted appends.
   * @returns generated Remote result.
   */
  insertBefore(workspaceId: WorkspaceId, beforeWorkspaceId?: WorkspaceId): Promise<RemoteResult$1<WorkspaceOrderValue>>;
  /**
   * Move a Session within its Workspace and merge the returned row.
   * @param workspaceId - owning Workspace.
   * @param sessionId - accounted Session to move.
   * @param beforeSessionId - accounted anchor; omitted appends.
   * @returns generated Remote result.
   */
  insertSessionBefore(workspaceId: WorkspaceInsertSessionBeforeRequest['workspaceId'], sessionId: WorkspaceInsertSessionBeforeRequest['sessionId'], beforeSessionId?: WorkspaceInsertSessionBeforeRequest['beforeSessionId']): Promise<RemoteResult$1<WorkspaceValue>>;
  /**
   * Archive one Session and install the returned complete archive set.
   * @param sessionId - Session to archive.
   * @returns generated Remote result.
   */
  archiveSession(sessionId: WorkspaceArchiveSessionRequest['sessionId']): Promise<RemoteResult$1<WorkspaceArchiveValue>>;
  /**
   * Replace the projection from one complete stream-generation baseline.
   * @param baseline - complete Workspace and archive projection.
   */
  replaceBaseline(baseline: WorkspaceBaseline): void;
  /** Merge one decoded Workspace upsert from the current follow generation. */
  upsertView(workspace: WorkspaceView): void;
  /** Apply one decoded Workspace removal from the current follow generation. */
  removeView(workspaceId: WorkspaceId): void;
  /** Replace Host-confirmed order from the current follow generation. */
  replaceOrder(workspaceIds: readonly WorkspaceId[]): void;
  /**
   * Replace the archived Session set from the current follow generation.
   * @param archivedSessionIds - complete Host-confirmed archive set.
   */
  replaceArchived(archivedSessionIds: WorkspaceArchiveValue['archivedSessionIds']): void;
  /** Keep the last complete projection visible while a lost carrier reconnects. */
  handleCarrierFailure(): void;
  /**
   * Publish a non-retryable stream or protocol failure.
   * @param error - terminal stream failure.
   */
  handleStreamFailure(error: unknown): void;
  /**
   * Subscribe to Workspace state invalidation.
   * @param listener - invalidation callback.
   * @returns unsubscribe function.
   */
  subscribe(listener: () => void): () => void;
  /**
   * Read the cached state, rebuilding it first when necessary.
   * @returns the current stable Workspace list snapshot.
   */
  getSnapshot(): WorkspaceSnapshot;
  private buildSnapshot;
  private installArchived;
  private installOrder;
  private upsert;
  private remove;
  private installViews;
  private invalidate;
  private flush;
  private refreshSnapshot;
}
//#endregion
//#region ../workspace-controller/lib/types/client/service.d.ts
/** Structured create failure for callers that distinguish Host business errors. */
declare class WorkspaceCreateError extends Error {
  readonly rpcError: RemoteFailure$1;
  readonly name = "WorkspaceCreateError";
  /** @param rpcError - Host business or folded carrier failure. */
  constructor(rpcError: RemoteFailure$1);
}
/** Bare observable source for the Workspace Controller snapshot. */
interface WorkspaceSource {
  /** Read the identity-stable current snapshot. */
  getSnapshot(): WorkspaceSnapshot;
  /**
   * Subscribe to snapshot changes.
   * @param listener - invalidation callback.
   * @returns unsubscribe function.
   */
  subscribe(listener: () => void): () => void;
}
/** Workspace Controller's Client service face. */
interface IWorkspaces {
  /** Host-authoritative Workspace rows, order, archive set, and follow lifecycle. */
  readonly list: WorkspaceSource;
  /**
   * Register an existing path as a Workspace.
   * @param input - Host create payload.
   * @returns the created or idempotently resolved Workspace.
   */
  create(input: {
    path: string;
  }): Promise<WorkspaceView>;
  /**
   * Rename a Workspace.
   * @param workspaceId - target Workspace.
   * @param title - new display title.
   * @returns the renamed Workspace.
   */
  rename(workspaceId: WorkspaceId, title: string): Promise<WorkspaceView>;
  /**
   * Delete a Workspace registration without deleting Sessions or files.
   * @param workspaceId - target Workspace.
   */
  delete(workspaceId: WorkspaceId): Promise<void>;
  /**
   * Move a Workspace within the Host registry order.
   * @param workspaceId - Workspace to move.
   * @param beforeWorkspaceId - anchor Workspace; omitted appends.
   */
  insertBefore(workspaceId: WorkspaceId, beforeWorkspaceId?: WorkspaceId): Promise<void>;
  /**
   * Archive a Session from Workspace grouping surfaces.
   * @param sessionId - Session to archive.
   */
  archiveSession(sessionId: SessionId): Promise<void>;
  /**
   * Move a Session within one Workspace account.
   * @param workspaceId - owning Workspace.
   * @param sessionId - Session to move.
   * @param beforeSessionId - anchor Session; omitted appends.
   * @returns the changed Workspace.
   */
  insertSessionBefore(workspaceId: WorkspaceId, sessionId: SessionId, beforeSessionId?: SessionId): Promise<WorkspaceView>;
}
/** Owns the bare Workspace snapshot and Workspace-only commands. */
declare class WorkspaceController extends Service implements IWorkspaces {
  private readonly model;
  readonly list: WorkspaceSource;
  /**
   * @param ctx - Client root Context.
   * @param model - Remote-backed Workspace state model.
   */
  constructor(ctx: Context, model: ClientWorkspaceModel);
  create(input: {
    path: string;
  }): Promise<WorkspaceView>;
  rename(workspaceId: WorkspaceId, title: string): Promise<WorkspaceView>;
  delete(workspaceId: WorkspaceId): Promise<void>;
  insertBefore(workspaceId: WorkspaceId, beforeWorkspaceId?: WorkspaceId): Promise<void>;
  archiveSession(sessionId: SessionId): Promise<void>;
  insertSessionBefore(workspaceId: WorkspaceId, sessionId: SessionId, beforeSessionId?: SessionId): Promise<WorkspaceView>;
}
//#endregion
//#region ../workspace-controller/lib/types/client/index.d.ts
type WorkspaceBaselineFrame = Extract<WorkspaceFollowFrame, {
  type: 'baseline';
}>;
/** Gateway-owned snapshot stream configured for Workspace state. */
type WorkspaceStateStream = RemoteSnapshotStream<WorkspaceBaselineFrame, WorkspaceFollowIncrement>;
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** React-free Client Workspace state and commands. */
    workspaces: IWorkspaces;
  }
}
/** Required Client Remote services. */
declare const inject$3: string[];
/**
 * Install Client Workspace state, commands, and reconnecting follow control.
 * @param ctx - Client root Context.
 */
declare function apply$3(ctx: Context): void;
/** Domain sinks used by the Workspace state stream. */
interface WorkspaceStateStreamOptions {
  /** Destinations for decoded Workspace state operations. */
  readonly accept: WorkspaceFollowSink;
  /** Observe a retryable carrier loss before reconnection. */
  readonly carrierFailed?: (error: RemoteStreamCarrierError) => void;
  /** Publish a terminal business or protocol failure. */
  readonly failed: (error: unknown) => void;
}
/**
 * Create the reconnecting Workspace state stream.
 * @param remote - Client Remote face carrying the Workspace namespace and the stream factory.
 * @param options - Workspace state destinations.
 * @returns an unstarted stream owned by the Client Workspace runtime.
 */
declare function createWorkspaceStateStream(remote: ClientRemote, options: WorkspaceStateStreamOptions): WorkspaceStateStream;
//#endregion
//#region ../gateway/lib/types/client/portable.d.ts
/** Explicit host and platform inputs for a multiplexed Remote stream carrier. */
interface RemoteStreamMuxOptions {
  /** HTTP(S) host origin; the Gateway route is absolute within this origin. */
  readonly baseUrl: string;
  /**
   * Create an authenticated socket for the selected host. Credential handling belongs to the adapter.
   * @param url - complete ws(s) Gateway URL.
   * @returns a fresh socket whose lifecycle events begin after this call returns.
   */
  createSocket(url: string): RemoteStreamSocket;
  /** @returns a unique identity for each logical stream, including after reconnect. */
  randomId(): string;
}
/**
 * Create one host's stream carrier without browser globals. Start/reconnect belongs to Connection;
 * streams never replay themselves. Close permanently releases this instance's transport.
 * @param options - host URL, authenticated socket adapter and correlation identity generator.
 * @returns an independent multiplexed carrier; invalid host URLs throw before any socket is opened.
 */
declare function createRemoteStreamMux(options: RemoteStreamMuxOptions): RemoteStreamMuxClient;
/** Platform inputs for the complete Remote service. */
interface RemoteClientOptions extends RemoteStreamMuxOptions, RemoteClientAdmission {
  /** Creates fresh controllers with abort reasons and throwIfAborted support. */
  readonly createAbortController: () => AbortController;
}
/**
 * Install typed Remote calls, streams and forwarded events for one HTTP(S) host.
 * The owning Cordis fiber disposes the transport and registrations together.
 * @param ctx - Client Cordis root with Typert and Connection services.
 * @param options - authenticated socket adapter, host URL and identity generator.
 */
declare function applyRemoteClient(ctx: Context, options: RemoteClientOptions): void;
//#endregion
//#region ../../typert/registry/lib/types/client/index.d.ts
/** Required services: none; this is the Client reflection root. */
declare const inject$1: string[];
/**
 * Install the same registry implementation used by the Host face.
 * @param ctx - Client Cordis root.
 */
declare function apply$2(ctx: Context): void;
//#endregion
//#region ../../typert/registry/lib/types/client/portable.d.ts
/**
 * Install the Client plugin through a callback Cordis invokes as a function.
 * Binding prevents Cordis from treating a transpiled function as a constructor.
 * @param ctx - Client Cordis root with this plugin's injected services.
 * @returns nothing after the registry is installed.
 */
declare const apply$1: (ctx: Parameters<typeof apply$2>[0]) => void;
//#endregion
//#region lib/types/client/portable.d.ts
/**
 * Install the Client plugin through a callback Cordis invokes as a function.
 * Binding prevents Cordis from treating a transpiled function as a constructor.
 * @param ctx - Client Cordis root with this plugin's injected services.
 * @returns disposer once every generated namespace is ready.
 */
declare const apply: (ctx: Parameters<typeof apply$4>[0]) => Promise<() => Promise<void>>;
/**
 * Install the shared Workspace projection and reconnecting follow stream for one host.
 * @param ctx - Client Cordis context with the generated Workspace Remote namespace.
 */
declare const applyWorkspaces: (ctx: Parameters<typeof apply$3>[0]) => void;
/**
 * Install shared Session state and reconnecting streams for one host.
 * @param ctx - Client Cordis context with the generated Session Remotes.
 * @param options - platform callbacks and hydrated host-specific navigation.
 */
declare const applySessions: typeof applySessions$1;
//#endregion
export { type AccountAttemptId, type AccountPromptId, type AgentModelCatalogView, type AgentModelOption, type AgentModelTargetId, type AgentModelTargetView, type AgentModelsSnapshot, type ApiRemoteForwardedEvent, type ApprovalRequestId, type BeginSubmissionInput, type ClientRemote, ClientWorkspaceModel, type ConnectionActivationId, type ConnectionDeviceCredential, type ConnectionDeviceEnrollment, type ConnectionDeviceGrant, type ConnectionDeviceId, type ConnectionDeviceInfo, type ConnectionHandle, type ConnectionHostId, type ConnectionIdentity, type ConnectionNetworkSource, type ConnectionOptions, type ConnectionRpcOptions, type ConnectionSinks, type ContentBlock, type CordisDynamicPackageId, type CordisDynamicPluginId, type CordisDynamicPluginRunId, type CordisDynamicRunMode, type CordisHalfState, type CordisInspectMethodManifest, type CordisInspectPlatform, type CordisInspectProviderManifest, type CordisInspectProviderView, type CordisInspectQueryRequest, type CordisInspectQueryResolution, type CordisInspectQueryResolved, type CordisInspectRequestId, type CordisInspectResolveAck, type CordisRunDiagnostic, type CordisRunStatus, type CredentialInfo, DEVICE_ACCESS_PATHS, type DeviceEnrollmentClaimOptions, type DirectoryEntry, type DirectoryListing, type DynamicCordisClientSource, type DynamicCordisHostHalfResult, type DynamicCordisInventoryRow, type DynamicCordisInvokeResult, type DynamicCordisPackage, type DynamicCordisRequestResolved, type DynamicCordisResolveAck, type DynamicCordisRetracted, type DynamicCordisRunAttempt, type DynamicCordisRunRequest, type DynamicCordisRunResolution, type DynamicCordisRunResponse, type DynamicCordisStopResponse, type DynamicCordisUndefineReceipt, type FileReferenceCandidate, type HostCapabilities, type HostCapability, type ISessions, type IWorkspaces, type SessionJob as JobView, type SessionJob, type LlmConfigurableProvider, type LlmDiscoveredModel, type LlmModelDiscoveryRequest, type LlmProviderInfo, type MessageId, type ModelCatalog, type ModelCatalogFailure, type ModelCatalogModel, type ModelProviderGroup, type ModelReasoning, type ModelReasoningEffort, type ModelSelection, type ModelSelectionProjection, type ModelSelectionProjectionState, MutableSessionEventSource, type PendingSubmission, type PluginInventorySnapshot, type PromptContentPart, type ProviderAccount, type ProviderAccountPrompt, type ProviderAccountUpdate, type QueueAction, type RemoteCapabilityRequirement, type RemoteClientAdmission, type RemoteClientOptions, type RemoteErrorCode, type RemoteErrorDetailsMap, type RemoteFailure, type RemoteHostFacts, type RemoteJournalChange, type RemoteJournalFrame, RemoteJournalStream, type RemoteJournalStreamOptions, type RemoteResult, RemoteSnapshotStream, type RemoteSnapshotStreamOptions, RemoteStream, RemoteStreamCarrierError, type RemoteStreamFactory, type RemoteStreamItem, type RemoteStreamMuxOptions, type RemoteStreamOptions, type RemoteStreamSignal, type RemoteStreamSocket, type RequestRunOutcome, type RpcFetch, type RpcFetchResponse, type RpcId, type RpcRequest, type RpcResponse, type RpcResult, type RpcStreamOpen, type SESSION_SEARCH_RESULT_LIMIT, type SESSION_SEARCH_SNIPPET_MAX_CODE_POINTS, type SessionAddress, type SessionAssistantStreamAttempt, type SessionAssistantStreamBaseline, type SessionAssistantStreamFrame, type SessionAttachmentRequest, type SessionAttachmentValue, type SessionBinding, type SessionCancelRequest, type SessionCancelValue, type SessionClientOptions, type SessionControlBaseline, type SessionControlFrame, SessionCreateError, type SessionCreateRequest, type SessionCreateValue, type SessionEventChange, type SessionEventEntry, type SessionEventLikeEntry, type SessionEventSource, SessionEventStream, type SessionEventWindow, type SessionFace, type SessionFollowFrame, type SessionFollowRequest, SessionForkError, type SessionForkRequest, type SessionForkValue, type SessionHistoryDetailRequest, type SessionHistoryRecord, type SessionId, type SessionListCursor, type SessionListMetadata, type SessionListRequest, type SessionListState, type SessionListValue, type SessionOpenWorkspacePathRequest, type SessionOpenWorkspacePathValue, type SessionPage, type SessionPageRequest, type SessionPlatform, type SessionProjectionBaseline, type SessionProjectionHints, type SessionProjectionUpdate, type SessionProjectionValue, type SessionProjectionValues, type SessionPromptRequest, type SessionPromptValue, type SessionQueuedItem, type SessionReferenceMentionCandidate, type SessionRenameRequest, type SessionRenameValue, type SessionRequestId, type SessionSearchItem, type SessionSearchRequest, type SessionSearchValue, type SessionSelectModelRequest, type SessionSelectModelValue, type SessionSelection, type SessionSelectionStore, type SessionSnapshot, type SessionSummary, type SessionUpdateQueueRequest, type SessionUpdateQueueValue, type SessionWireEvent, type SessionWireHeader, type SessionWireSurfaceOp, type SettingsDescribeValue, type SettingsNamespaceView, type SettingsPathOpView, type SettingsSecretView, type SkillEntry, type SkillListRequest, type SkillListValue, type StoredAgentModelSelection, type StreamChunk, type SubagentAddress, type SubagentCatalog, type SubagentCatalogEntry, type SubagentIdentityProjection, type SubagentInterruptReceipt, type SubagentListEntry, type SubagentPromptReceipt, type SubagentPromptRequest, type SubagentPromptRequestId, type SubagentTimingProjection, type SubmissionHandle, type WorkspaceArchiveSessionRequest, type WorkspaceArchiveValue, type WorkspaceBaseline, type WorkspaceByteRange, WorkspaceController, WorkspaceCreateError, type WorkspaceCreateRequest, type WorkspaceCreateValue, type WorkspaceDeleteRequest, type WorkspaceDeleteValue, type WorkspaceDirectoryEntry, type WorkspaceDirectoryListing, type WorkspaceFileBytes, type WorkspaceFileChange, type WorkspaceFileRange, type WorkspaceFileStat, type WorkspaceFileText, type WorkspaceFileWatchFrame, type WorkspaceFollowFrame, type WorkspaceFollowIncrement, type WorkspaceFollowSink, type WorkspaceId, type WorkspaceInsertBeforeRequest, type WorkspaceInsertSessionBeforeRequest, type WorkspaceListPhase, type WorkspaceOrderValue, type WorkspaceRemote, type WorkspaceRenameRequest, type WorkspaceSnapshot, type WorkspaceSource, type WorkspaceStateStream, type WorkspaceStateStreamOptions, type WorkspaceValue, type WorkspaceView, apply, apply$1 as applyRegistry, applyRemoteClient, applySessions, applyWorkspaces, claimDeviceEnrollment, connectionDeviceEnrollmentSchema, connectionDeviceGrantSchema, connectionHostIdSchema, createConnection, createConnectionRpc, createRemoteStreamMux, createSessionControlStream, createWorkspaceStateStream, inject, isRemoteFailure, readHostCapabilities, readHostIdentity, inject$1 as registryInject, scopeOf, selectRemoteCapabilities, inject$2 as sessionInject, inject$3 as workspaceInject };