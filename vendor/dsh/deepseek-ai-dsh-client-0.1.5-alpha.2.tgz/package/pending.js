//#region ../store/src/index.ts
/**
* Notify an observer set without allowing one callback to starve the rest.
* @param listeners - current observer callbacks; copied before dispatch.
* @param label - diagnostic owner prefix.
* @param args - callback arguments.
*/
function notifySubscribers(listeners, label, ...args) {
	for (const listener of [...listeners]) try {
		listener(...args);
	} catch (error) {
		console.error(`${label} subscriber failed:`, error);
	}
}
//#endregion
//#region lib/types/client/pending-interactions.js
var PendingInteractionDomain = class {
	precedence;
	changed;
	released = false;
	values = /* @__PURE__ */ new Map();
	constructor(precedence, changed) {
		this.precedence = precedence;
		this.changed = changed;
	}
	valuesSnapshot() {
		return [...this.values.values()].map((entry) => entry.interaction);
	}
	publish(interaction, delegate) {
		if (this.released) throw new Error("ui-session: pending interaction domain is disposed");
		if (this.values.has(interaction.key)) throw new Error(`ui-session: duplicate pending interaction key '${interaction.key}'`);
		this.values.set(interaction.key, {
			interaction,
			delegate
		});
		this.changed();
		let active = true;
		return () => {
			if (!active) return;
			active = false;
			if (!this.values.delete(interaction.key)) return;
			this.changed();
		};
	}
	/** Remove every pending value and return the operations that settle their owners. */
	release() {
		this.released = true;
		const delegates = [...this.values.values()].map((entry) => entry.delegate);
		this.values.clear();
		return delegates;
	}
};
/** Per-Host registry of effect-owned pending requests, shared across presentation targets. */
var PendingInteractions = class {
	pendingDomains = [];
	pendingSnapshot = /* @__PURE__ */ new Map();
	pendingListeners = /* @__PURE__ */ new Set();
	/** Root source of pending UI interactions, independent from Controller snapshots. */
	source = {
		getSnapshot: () => this.pendingSnapshot,
		subscribe: (listener) => {
			this.pendingListeners.add(listener);
			return () => {
				this.pendingListeners.delete(listener);
			};
		}
	};
	/**
	* Register one pending-interaction domain and return its publication function.
	* Domain teardown first removes its visible values, then delegates and awaits
	* every still-active owner request.
	* Released domains reject subsequent publication.
	* @param ctx - Contributing plugin context that owns domain teardown.
	* @param precedence - deterministic cross-domain precedence; larger values win.
	* @returns a function that publishes one interaction and its teardown delegation.
	*/
	register(ctx, precedence) {
		const domain = new PendingInteractionDomain(precedence, () => {
			this.publishPendingInteractions();
		});
		const runtimeDomain = domain;
		ctx.effect(() => {
			this.pendingDomains.push(runtimeDomain);
			this.publishPendingInteractions();
			return async () => {
				const delegates = domain.release();
				const index = this.pendingDomains.indexOf(runtimeDomain);
				this.pendingDomains.splice(index, 1);
				this.publishPendingInteractions();
				await Promise.allSettled(delegates.map((delegate) => Promise.resolve().then(delegate)));
			};
		}, "uiSession.registerPendingInteraction()");
		return (interaction, delegate) => domain.publish(interaction, delegate);
	}
	publishPendingInteractions() {
		const next = /* @__PURE__ */ new Map();
		for (const domain of this.pendingDomains) for (const interaction of domain.valuesSnapshot()) {
			const precedence = domain.precedence(interaction);
			const previous = next.get(interaction.sessionId);
			if (previous === void 0 || precedence >= previous.precedence) next.set(interaction.sessionId, {
				interaction,
				precedence
			});
		}
		const projected = new Map([...next].map(([sessionId, value]) => [sessionId, value.interaction]));
		if (samePendingInteractions(this.pendingSnapshot, projected)) return;
		this.pendingSnapshot = projected;
		notifySubscribers(this.pendingListeners, "[ui-session] pending interactions");
	}
};
function samePendingInteractions(left, right) {
	if (left.size !== right.size) return false;
	for (const [sessionId, interaction] of left) if (right.get(sessionId) !== interaction) return false;
	return true;
}
//#endregion
export { PendingInteractions };
