import { Service } from "@deepseek-ai/cordis";
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/zustand@4.4.7_@types+react@18.3.31_immer@10.2.0_react@18.3.1/node_modules/zustand/esm/vanilla.mjs
const createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const destroy = () => {
		if ((import.meta.env ? import.meta.env.MODE : void 0) !== "production") console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected.");
		listeners.clear();
	};
	const api = {
		setState,
		getState,
		subscribe,
		destroy
	};
	state = createState(setState, getState, api);
	return api;
};
const createStore = (createState) => createState ? createStoreImpl(createState) : createStoreImpl;
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/zustand@4.4.7_@types+react@18.3.31_immer@10.2.0_react@18.3.1/node_modules/zustand/esm/middleware.mjs
const subscribeWithSelectorImpl = (fn) => (set, get, api) => {
	const origSubscribe = api.subscribe;
	api.subscribe = (selector, optListener, options) => {
		let listener = selector;
		if (optListener) {
			const equalityFn = (options == null ? void 0 : options.equalityFn) || Object.is;
			let currentSlice = selector(api.getState());
			listener = (state) => {
				const nextSlice = selector(state);
				if (!equalityFn(currentSlice, nextSlice)) {
					const previousSlice = currentSlice;
					optListener(currentSlice = nextSlice, previousSlice);
				}
			};
			if (options == null ? void 0 : options.fireImmediately) optListener(currentSlice, currentSlice);
		}
		return origSubscribe(listener);
	};
	return fn(set, get, api);
};
const subscribeWithSelector = subscribeWithSelectorImpl;
//#endregion
//#region ../../../../../../../../../Volumes/SD-2T/Caches/node_modules/Devel_daedal-one_infrastracture_deepseek-harness-daedal-dsh/.pnpm/immer@10.2.0/node_modules/immer/dist/immer.mjs
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");
function die(error, ...args) {
	throw new Error(`[Immer] minified error nr: ${error}. Full error at: https://bit.ly/3cXEKWf`);
}
var getPrototypeOf = Object.getPrototypeOf;
function isDraft(value) {
	return !!value && !!value[DRAFT_STATE];
}
function isDraftable(value) {
	if (!value) return false;
	return isPlainObject(value) || Array.isArray(value) || !!value[DRAFTABLE] || !!value.constructor?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = Object.prototype.constructor.toString();
var cachedCtorStrings = /* @__PURE__ */ new WeakMap();
function isPlainObject(value) {
	if (!value || typeof value !== "object") return false;
	const proto = Object.getPrototypeOf(value);
	if (proto === null || proto === Object.prototype) return true;
	const Ctor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
	if (Ctor === Object) return true;
	if (typeof Ctor !== "function") return false;
	let ctorString = cachedCtorStrings.get(Ctor);
	if (ctorString === void 0) {
		ctorString = Function.toString.call(Ctor);
		cachedCtorStrings.set(Ctor, ctorString);
	}
	return ctorString === objectCtorString;
}
function each(obj, iter, strict = true) {
	if (getArchtype(obj) === 0) (strict ? Reflect.ownKeys(obj) : Object.keys(obj)).forEach((key) => {
		iter(key, obj[key], obj);
	});
	else obj.forEach((entry, index) => iter(index, entry, obj));
}
function getArchtype(thing) {
	const state = thing[DRAFT_STATE];
	return state ? state.type_ : Array.isArray(thing) ? 1 : isMap(thing) ? 2 : isSet(thing) ? 3 : 0;
}
function has(thing, prop) {
	return getArchtype(thing) === 2 ? thing.has(prop) : Object.prototype.hasOwnProperty.call(thing, prop);
}
function set(thing, propOrOldValue, value) {
	const t = getArchtype(thing);
	if (t === 2) thing.set(propOrOldValue, value);
	else if (t === 3) thing.add(value);
	else thing[propOrOldValue] = value;
}
function is(x, y) {
	if (x === y) return x !== 0 || 1 / x === 1 / y;
	else return x !== x && y !== y;
}
function isMap(target) {
	return target instanceof Map;
}
function isSet(target) {
	return target instanceof Set;
}
function latest(state) {
	return state.copy_ || state.base_;
}
function shallowCopy(base, strict) {
	if (isMap(base)) return new Map(base);
	if (isSet(base)) return new Set(base);
	if (Array.isArray(base)) return Array.prototype.slice.call(base);
	const isPlain = isPlainObject(base);
	if (strict === true || strict === "class_only" && !isPlain) {
		const descriptors = Object.getOwnPropertyDescriptors(base);
		delete descriptors[DRAFT_STATE];
		let keys = Reflect.ownKeys(descriptors);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			const desc = descriptors[key];
			if (desc.writable === false) {
				desc.writable = true;
				desc.configurable = true;
			}
			if (desc.get || desc.set) descriptors[key] = {
				configurable: true,
				writable: true,
				enumerable: desc.enumerable,
				value: base[key]
			};
		}
		return Object.create(getPrototypeOf(base), descriptors);
	} else {
		const proto = getPrototypeOf(base);
		if (proto !== null && isPlain) return { ...base };
		return Object.assign(Object.create(proto), base);
	}
}
function freeze(obj, deep = false) {
	if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
	if (getArchtype(obj) > 1) Object.defineProperties(obj, {
		set: dontMutateMethodOverride,
		add: dontMutateMethodOverride,
		clear: dontMutateMethodOverride,
		delete: dontMutateMethodOverride
	});
	Object.freeze(obj);
	if (deep) Object.values(obj).forEach((value) => freeze(value, true));
	return obj;
}
function dontMutateFrozenCollections() {
	die(2);
}
var dontMutateMethodOverride = { value: dontMutateFrozenCollections };
function isFrozen(obj) {
	if (obj === null || typeof obj !== "object") return true;
	return Object.isFrozen(obj);
}
var plugins = {};
function getPlugin(pluginKey) {
	const plugin = plugins[pluginKey];
	if (!plugin) die(0, pluginKey);
	return plugin;
}
var currentScope;
function getCurrentScope() {
	return currentScope;
}
function createScope(parent_, immer_) {
	return {
		drafts_: [],
		parent_,
		immer_,
		canAutoFreeze_: true,
		unfinalizedDrafts_: 0
	};
}
function usePatchesInScope(scope, patchListener) {
	if (patchListener) {
		getPlugin("Patches");
		scope.patches_ = [];
		scope.inversePatches_ = [];
		scope.patchListener_ = patchListener;
	}
}
function revokeScope(scope) {
	leaveScope(scope);
	scope.drafts_.forEach(revokeDraft);
	scope.drafts_ = null;
}
function leaveScope(scope) {
	if (scope === currentScope) currentScope = scope.parent_;
}
function enterScope(immer2) {
	return currentScope = createScope(currentScope, immer2);
}
function revokeDraft(draft) {
	const state = draft[DRAFT_STATE];
	if (state.type_ === 0 || state.type_ === 1) state.revoke_();
	else state.revoked_ = true;
}
function processResult(result, scope) {
	scope.unfinalizedDrafts_ = scope.drafts_.length;
	const baseDraft = scope.drafts_[0];
	if (result !== void 0 && result !== baseDraft) {
		if (baseDraft[DRAFT_STATE].modified_) {
			revokeScope(scope);
			die(4);
		}
		if (isDraftable(result)) {
			result = finalize(scope, result);
			if (!scope.parent_) maybeFreeze(scope, result);
		}
		if (scope.patches_) getPlugin("Patches").generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope.patches_, scope.inversePatches_);
	} else result = finalize(scope, baseDraft, []);
	revokeScope(scope);
	if (scope.patches_) scope.patchListener_(scope.patches_, scope.inversePatches_);
	return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value, path) {
	if (isFrozen(value)) return value;
	const useStrictIteration = rootScope.immer_.shouldUseStrictIteration();
	const state = value[DRAFT_STATE];
	if (!state) {
		each(value, (key, childValue) => finalizeProperty(rootScope, state, value, key, childValue, path), useStrictIteration);
		return value;
	}
	if (state.scope_ !== rootScope) return value;
	if (!state.modified_) {
		maybeFreeze(rootScope, state.base_, true);
		return state.base_;
	}
	if (!state.finalized_) {
		state.finalized_ = true;
		state.scope_.unfinalizedDrafts_--;
		const result = state.copy_;
		let resultEach = result;
		let isSet2 = false;
		if (state.type_ === 3) {
			resultEach = new Set(result);
			result.clear();
			isSet2 = true;
		}
		each(resultEach, (key, childValue) => finalizeProperty(rootScope, state, result, key, childValue, path, isSet2), useStrictIteration);
		maybeFreeze(rootScope, result, false);
		if (path && rootScope.patches_) getPlugin("Patches").generatePatches_(state, path, rootScope.patches_, rootScope.inversePatches_);
	}
	return state.copy_;
}
function finalizeProperty(rootScope, parentState, targetObject, prop, childValue, rootPath, targetIsSet) {
	if (childValue == null) return;
	if (typeof childValue !== "object" && !targetIsSet) return;
	const childIsFrozen = isFrozen(childValue);
	if (childIsFrozen && !targetIsSet) return;
	if (isDraft(childValue)) {
		const res = finalize(rootScope, childValue, rootPath && parentState && parentState.type_ !== 3 && !has(parentState.assigned_, prop) ? rootPath.concat(prop) : void 0);
		set(targetObject, prop, res);
		if (isDraft(res)) rootScope.canAutoFreeze_ = false;
		else return;
	} else if (targetIsSet) targetObject.add(childValue);
	if (isDraftable(childValue) && !childIsFrozen) {
		if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) return;
		if (parentState && parentState.base_ && parentState.base_[prop] === childValue && childIsFrozen) return;
		finalize(rootScope, childValue);
		if ((!parentState || !parentState.scope_.parent_) && typeof prop !== "symbol" && (isMap(targetObject) ? targetObject.has(prop) : Object.prototype.propertyIsEnumerable.call(targetObject, prop))) maybeFreeze(rootScope, childValue);
	}
}
function maybeFreeze(scope, value, deep = false) {
	if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) freeze(value, deep);
}
function createProxyProxy(base, parent) {
	const isArray = Array.isArray(base);
	const state = {
		type_: isArray ? 1 : 0,
		scope_: parent ? parent.scope_ : getCurrentScope(),
		modified_: false,
		finalized_: false,
		assigned_: {},
		parent_: parent,
		base_: base,
		draft_: null,
		copy_: null,
		revoke_: null,
		isManual_: false
	};
	let target = state;
	let traps = objectTraps;
	if (isArray) {
		target = [state];
		traps = arrayTraps;
	}
	const { revoke, proxy } = Proxy.revocable(target, traps);
	state.draft_ = proxy;
	state.revoke_ = revoke;
	return proxy;
}
var objectTraps = {
	get(state, prop) {
		if (prop === DRAFT_STATE) return state;
		const source = latest(state);
		if (!has(source, prop)) return readPropFromProto(state, source, prop);
		const value = source[prop];
		if (state.finalized_ || !isDraftable(value)) return value;
		if (value === peek(state.base_, prop)) {
			prepareCopy(state);
			return state.copy_[prop] = createProxy(value, state);
		}
		return value;
	},
	has(state, prop) {
		return prop in latest(state);
	},
	ownKeys(state) {
		return Reflect.ownKeys(latest(state));
	},
	set(state, prop, value) {
		const desc = getDescriptorFromProto(latest(state), prop);
		if (desc?.set) {
			desc.set.call(state.draft_, value);
			return true;
		}
		if (!state.modified_) {
			const current2 = peek(latest(state), prop);
			const currentState = current2?.[DRAFT_STATE];
			if (currentState && currentState.base_ === value) {
				state.copy_[prop] = value;
				state.assigned_[prop] = false;
				return true;
			}
			if (is(value, current2) && (value !== void 0 || has(state.base_, prop))) return true;
			prepareCopy(state);
			markChanged(state);
		}
		if (state.copy_[prop] === value && (value !== void 0 || prop in state.copy_) || Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
		state.copy_[prop] = value;
		state.assigned_[prop] = true;
		return true;
	},
	deleteProperty(state, prop) {
		if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
			state.assigned_[prop] = false;
			prepareCopy(state);
			markChanged(state);
		} else delete state.assigned_[prop];
		if (state.copy_) delete state.copy_[prop];
		return true;
	},
	getOwnPropertyDescriptor(state, prop) {
		const owner = latest(state);
		const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
		if (!desc) return desc;
		return {
			writable: true,
			configurable: state.type_ !== 1 || prop !== "length",
			enumerable: desc.enumerable,
			value: owner[prop]
		};
	},
	defineProperty() {
		die(11);
	},
	getPrototypeOf(state) {
		return getPrototypeOf(state.base_);
	},
	setPrototypeOf() {
		die(12);
	}
};
var arrayTraps = {};
each(objectTraps, (key, fn) => {
	arrayTraps[key] = function() {
		arguments[0] = arguments[0][0];
		return fn.apply(this, arguments);
	};
});
arrayTraps.deleteProperty = function(state, prop) {
	return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function(state, prop, value) {
	return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
	const state = draft[DRAFT_STATE];
	return (state ? latest(state) : draft)[prop];
}
function readPropFromProto(state, source, prop) {
	const desc = getDescriptorFromProto(source, prop);
	return desc ? `value` in desc ? desc.value : desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
	if (!(prop in source)) return void 0;
	let proto = getPrototypeOf(source);
	while (proto) {
		const desc = Object.getOwnPropertyDescriptor(proto, prop);
		if (desc) return desc;
		proto = getPrototypeOf(proto);
	}
}
function markChanged(state) {
	if (!state.modified_) {
		state.modified_ = true;
		if (state.parent_) markChanged(state.parent_);
	}
}
function prepareCopy(state) {
	if (!state.copy_) state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
}
var Immer2 = class {
	constructor(config) {
		this.autoFreeze_ = true;
		this.useStrictShallowCopy_ = false;
		this.useStrictIteration_ = true;
		/**
		* The `produce` function takes a value and a "recipe function" (whose
		* return value often depends on the base state). The recipe function is
		* free to mutate its first argument however it wants. All mutations are
		* only ever applied to a __copy__ of the base state.
		*
		* Pass only a function to create a "curried producer" which relieves you
		* from passing the recipe function every time.
		*
		* Only plain objects and arrays are made mutable. All other objects are
		* considered uncopyable.
		*
		* Note: This function is __bound__ to its `Immer` instance.
		*
		* @param {any} base - the initial state
		* @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
		* @param {Function} patchListener - optional function that will be called with all the patches produced here
		* @returns {any} a new state, or the initial state if nothing was modified
		*/
		this.produce = (base, recipe, patchListener) => {
			if (typeof base === "function" && typeof recipe !== "function") {
				const defaultBase = recipe;
				recipe = base;
				const self = this;
				return function curriedProduce(base2 = defaultBase, ...args) {
					return self.produce(base2, (draft) => recipe.call(this, draft, ...args));
				};
			}
			if (typeof recipe !== "function") die(6);
			if (patchListener !== void 0 && typeof patchListener !== "function") die(7);
			let result;
			if (isDraftable(base)) {
				const scope = enterScope(this);
				const proxy = createProxy(base, void 0);
				let hasError = true;
				try {
					result = recipe(proxy);
					hasError = false;
				} finally {
					if (hasError) revokeScope(scope);
					else leaveScope(scope);
				}
				usePatchesInScope(scope, patchListener);
				return processResult(result, scope);
			} else if (!base || typeof base !== "object") {
				result = recipe(base);
				if (result === void 0) result = base;
				if (result === NOTHING) result = void 0;
				if (this.autoFreeze_) freeze(result, true);
				if (patchListener) {
					const p = [];
					const ip = [];
					getPlugin("Patches").generateReplacementPatches_(base, result, p, ip);
					patchListener(p, ip);
				}
				return result;
			} else die(1, base);
		};
		this.produceWithPatches = (base, recipe) => {
			if (typeof base === "function") return (state, ...args) => this.produceWithPatches(state, (draft) => base(draft, ...args));
			let patches, inversePatches;
			return [
				this.produce(base, recipe, (p, ip) => {
					patches = p;
					inversePatches = ip;
				}),
				patches,
				inversePatches
			];
		};
		if (typeof config?.autoFreeze === "boolean") this.setAutoFreeze(config.autoFreeze);
		if (typeof config?.useStrictShallowCopy === "boolean") this.setUseStrictShallowCopy(config.useStrictShallowCopy);
		if (typeof config?.useStrictIteration === "boolean") this.setUseStrictIteration(config.useStrictIteration);
	}
	createDraft(base) {
		if (!isDraftable(base)) die(8);
		if (isDraft(base)) base = current(base);
		const scope = enterScope(this);
		const proxy = createProxy(base, void 0);
		proxy[DRAFT_STATE].isManual_ = true;
		leaveScope(scope);
		return proxy;
	}
	finishDraft(draft, patchListener) {
		const state = draft && draft[DRAFT_STATE];
		if (!state || !state.isManual_) die(9);
		const { scope_: scope } = state;
		usePatchesInScope(scope, patchListener);
		return processResult(void 0, scope);
	}
	/**
	* Pass true to automatically freeze all copies created by Immer.
	*
	* By default, auto-freezing is enabled.
	*/
	setAutoFreeze(value) {
		this.autoFreeze_ = value;
	}
	/**
	* Pass true to enable strict shallow copy.
	*
	* By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
	*/
	setUseStrictShallowCopy(value) {
		this.useStrictShallowCopy_ = value;
	}
	/**
	* Pass false to use faster iteration that skips non-enumerable properties
	* but still handles symbols for compatibility.
	*
	* By default, strict iteration is enabled (includes all own properties).
	*/
	setUseStrictIteration(value) {
		this.useStrictIteration_ = value;
	}
	shouldUseStrictIteration() {
		return this.useStrictIteration_;
	}
	applyPatches(base, patches) {
		let i;
		for (i = patches.length - 1; i >= 0; i--) {
			const patch = patches[i];
			if (patch.path.length === 0 && patch.op === "replace") {
				base = patch.value;
				break;
			}
		}
		if (i > -1) patches = patches.slice(i + 1);
		const applyPatchesImpl = getPlugin("Patches").applyPatches_;
		if (isDraft(base)) return applyPatchesImpl(base, patches);
		return this.produce(base, (draft) => applyPatchesImpl(draft, patches));
	}
};
function createProxy(value, parent) {
	const draft = isMap(value) ? getPlugin("MapSet").proxyMap_(value, parent) : isSet(value) ? getPlugin("MapSet").proxySet_(value, parent) : createProxyProxy(value, parent);
	(parent ? parent.scope_ : getCurrentScope()).drafts_.push(draft);
	return draft;
}
function current(value) {
	if (!isDraft(value)) die(10, value);
	return currentImpl(value);
}
function currentImpl(value) {
	if (!isDraftable(value) || isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	let copy;
	let strict = true;
	if (state) {
		if (!state.modified_) return state.base_;
		state.finalized_ = true;
		copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
		strict = state.scope_.immer_.shouldUseStrictIteration();
	} else copy = shallowCopy(value, true);
	each(copy, (key, childValue) => {
		set(copy, key, currentImpl(childValue));
	}, strict);
	if (state) state.finalized_ = false;
	return copy;
}
var produce = new Immer2().produce;
//#endregion
//#region ../store/src/index.ts
/**
* React-free snapshot store engine (zustand vanilla + immer + subscribeWithSelector +
* rafFlush middleware + opt-in persist + dev freeze) plus the declarative
* shell over it: {@link defineStore} bakes an init/persist/actions literal
* into a {@link StoreHandle}, the registration-side store seat of slot
* terminals. Engine products are bare observables — subscribe/getSnapshot/
* update/set, NO selector hook. Hook synthesis is ui-renderer's (the one
* uSES bridge, cached per source at the binding site).
*/
/**
* Notify an observer set without allowing one callback to starve the rest.
* @param listeners - current observer callbacks; copied before dispatch.
* @param label - diagnostic owner prefix.
* @param args - callback arguments.
*/
function notifySubscribers(listeners, label, ...args) {
	for (const listener of [...listeners]) try {
		listener(...args);
	} catch (error) {
		console.error(`${label} subscriber failed:`, error);
	}
}
/** Batches subscriber notification into one flush per animation frame. */
function rafBatch(notify) {
	const schedule = typeof requestAnimationFrame === "function" ? (fn) => {
		requestAnimationFrame(() => {
			fn();
		});
	} : (fn) => {
		queueMicrotask(fn);
	};
	let scheduled = false;
	return () => {
		if (scheduled) return;
		scheduled = true;
		schedule(() => {
			scheduled = false;
			notify();
		});
	};
}
/**
* Create a snapshot store.
*
* Flush default is 'sync' (controlled inputs need same-tick echo); frame-driven
* stores opt into 'raf', where a frame's worth of updates coalesces into one
* notification. Known raf-mode tradeoff: a component mounting mid-frame reads
* fresh state while existing subscribers hear it next flush — transient
* frame-level skew, same nature as the object layer's microtask batching.
*
* @param init - initial state.
* @param opts - flush mode and opt-in persistence (localStorage, keyed by name).
* @returns the store.
*/
function createSnapshotStore(init, opts) {
	const withSelector = subscribeWithSelector(() => init);
	const api = createStore()(withSelector);
	if (opts?.persist) attachPersistence(api, opts.persist.name);
	let subscribe = (fn) => api.subscribe(() => {
		notifySubscribers([fn], "[client-store]");
	});
	if (opts?.flush === "raf") {
		const listeners = /* @__PURE__ */ new Set();
		const flush = rafBatch(() => {
			notifySubscribers(listeners, "[client-store]");
		});
		api.subscribe(flush);
		subscribe = (fn) => {
			listeners.add(fn);
			return () => {
				listeners.delete(fn);
			};
		};
	}
	return {
		getSnapshot: () => api.getState(),
		subscribe: (fn) => subscribe(fn),
		update: (mutator) => {
			api.setState(produce(api.getState(), (draft) => {
				mutator(draft);
			}), true);
		},
		set: (next) => {
			api.setState(devFreeze(next), true);
		}
	};
}
/**
* Whole-value JSON persistence to localStorage. Hand-rolled instead of the
* zustand persist middleware: its write path spreads state into an object
* (`partialize({ ...get() })`), exploding primitive state (a persisted string
* draft becomes {0:'h',1:'e',...}) — not fixable via merge/deserialize options
* because the corruption happens before serialization. Storage failures
* (quota, private mode) only disable persistence, never break the store.
*/
function attachPersistence(api, name) {
	if (typeof localStorage === "undefined") return;
	try {
		const raw = localStorage.getItem(name);
		if (raw !== null) api.setState(devFreeze(JSON.parse(raw)), true);
	} catch (error) {
		console.error(`snapshot store '${name}' rehydration failed:`, error);
	}
	api.subscribe((state) => {
		try {
			localStorage.setItem(name, JSON.stringify(state));
		} catch (error) {
			console.error(`snapshot store '${name}' persistence failed:`, error);
		}
	});
}
/** Deep-freeze draftable wholesale-set state outside production: set() bypasses immer's freeze. */
function devFreeze(value) {
	return value;
}
//#endregion
//#region lib/types/client/conversation/binding.js
/** One portable Session event-window owner with platform-supplied publication timing. */
var ConversationBindingModel = class {
	assembler;
	scheduler;
	snapshot;
	store;
	viewStore;
	targetSources = /* @__PURE__ */ new Map();
	revision = -1;
	cancelPublication;
	publicationEpoch = 0;
	disposed = false;
	disposeFeed;
	/**
	* @param feed - shared contiguous Session window; this binding never opens a transport.
	* @param assembler - exclusively owned assembler with the selected Definitions.
	* @param scheduler - deferred streaming publication, or null for immediate publication.
	*/
	constructor(feed, assembler, scheduler) {
		this.assembler = assembler;
		this.scheduler = scheduler;
		this.viewStore = assembler;
		this.store = createSnapshotStore(this.currentSnapshot());
		this.snapshot = this.store;
		this.replace(feed.getSnapshot());
		this.disposeFeed = feed.subscribe(() => {
			this.accept(feed.getSnapshot());
		});
	}
	/** @param target - registered target key. @returns identity-stable target source. */
	target(target) {
		let source = this.targetSources.get(target);
		if (source === void 0) {
			const views = this.viewStore;
			source = {
				getSnapshot: () => views.get(target),
				subscribe: (listener) => {
					const unsubscribe = this.snapshot.subscribe(listener);
					this.activate(target);
					return unsubscribe;
				}
			};
			this.targetSources.set(target, source);
		}
		return source;
	}
	/** @param target - target to activate for this binding; ignored after disposal. */
	activate(target) {
		if (this.disposed) return;
		if (this.assembler.activateTarget(target)) this.store.set(this.currentSnapshot());
	}
	/** Rebuild contributed Definitions while retaining this binding and target sources. */
	rebuild() {
		if (!this.disposed) this.publish(this.assembler.rebuildRegistry());
	}
	/** Detach the source and cancel publication; retained snapshots remain readable. Idempotent. */
	dispose() {
		if (this.disposed) return;
		this.disposed = true;
		this.disposeFeed();
		this.cancelScheduled();
	}
	replace(window) {
		this.revision = window.revision;
		this.publish(this.assembler.replaceWindow(window.entries, window.hasMore));
	}
	accept(window) {
		if (this.disposed || window.revision === this.revision) return;
		if (window.revision !== this.revision + 1 || window.change.kind === "replace") {
			this.replace(window);
			return;
		}
		this.revision = window.revision;
		switch (window.change.kind) {
			case "prepend":
				this.publish(this.assembler.prepend(window.change.entries, window.hasMore));
				return;
			case "append": {
				let publication = "none";
				for (const event of window.change.entries) {
					const next = this.assembler.append(event);
					if (next === "immediate" || publication === "none") publication = next;
				}
				this.publish(publication);
				return;
			}
			case "settle-assistant":
				this.publish(this.assembler.settleAssistant(window.change.attemptId, window.change.entry));
				return;
		}
	}
	publish(publication) {
		if (publication === "none") return;
		if (publication === "animation-frame" && this.scheduler !== null) {
			if (this.cancelPublication !== void 0) return;
			const epoch = this.publicationEpoch;
			this.cancelPublication = this.scheduler.schedule(() => {
				if (this.disposed || epoch !== this.publicationEpoch) return;
				this.cancelPublication = void 0;
				this.flush();
			});
			return;
		}
		this.cancelScheduled();
		this.flush();
	}
	cancelScheduled() {
		this.publicationEpoch++;
		const cancel = this.cancelPublication;
		this.cancelPublication = void 0;
		cancel?.();
	}
	flush() {
		if (this.assembler.flush()) this.store.set(this.currentSnapshot());
	}
	currentSnapshot() {
		return {
			views: this.viewStore,
			activeTargets: this.assembler.activityTargets()
		};
	}
};
//#endregion
//#region lib/types/client/contract/conversation.js
/**
* Build a stable collision-free key for one Definition-local business identity.
* @param kind - Definition kind.
* @param id - Definition-local business identity.
* @returns engine-owned Context key.
*/
function conversationContextKey(kind, id) {
	return `${kind.length}:${kind}${id}`;
}
//#endregion
//#region lib/types/client/conversation/location-index.js
var MutableLocationDataSource = class {
	store;
	key;
	listeners = /* @__PURE__ */ new Set();
	published;
	constructor(store, key) {
		this.store = store;
		this.key = key;
		this.published = store.get(key);
	}
	getSnapshot = () => this.store.get(this.key);
	subscribe = (listener) => {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	};
	publish() {
		const next = this.getSnapshot();
		if (this.published === next) return;
		this.published = next;
		notifySubscribers(this.listeners, `[ui-conversation] Location data ${this.key}`);
	}
};
var MutableLocationDataStore = class {
	markDirty;
	entries = /* @__PURE__ */ new Map();
	sources = /* @__PURE__ */ new Map();
	dirtyKeys = /* @__PURE__ */ new Set();
	constructor(markDirty) {
		this.markDirty = markDirty;
	}
	get(key) {
		return this.entries.get(key)?.value;
	}
	source(key) {
		let source = this.sources.get(key);
		if (source === void 0) {
			source = new MutableLocationDataSource(this, key);
			this.sources.set(key, source);
		}
		return source;
	}
	remove(owner, key) {
		if (this.entries.get(key)?.owner !== owner) return false;
		this.entries.delete(key);
		this.changed(key);
		return true;
	}
	set(owner, key, value) {
		const current = this.entries.get(key);
		if (current !== void 0 && current.owner !== owner) throw new Error(`conversation Location data "${key}" is already owned by ${current.owner}`);
		if (current?.value === value) return false;
		this.entries.set(key, {
			owner,
			value
		});
		this.changed(key);
		return true;
	}
	replace(entries) {
		const changedKeys = [];
		for (const key of new Set([...this.entries.keys(), ...entries.keys()])) {
			const current = this.entries.get(key);
			const next = entries.get(key);
			if (current?.owner !== next?.owner || current?.value !== next?.value) changedKeys.push(key);
		}
		if (changedKeys.length === 0) return false;
		this.entries = new Map(entries);
		for (const key of changedKeys) this.changed(key);
		return true;
	}
	publish() {
		const dirty = [...this.dirtyKeys];
		this.dirtyKeys.clear();
		for (const key of dirty) this.sources.get(key)?.publish();
	}
	changed(key) {
		this.dirtyKeys.add(key);
		this.markDirty(this);
	}
};
const SESSION_LOCATION = { kind: "session" };
const UNRESOLVED_LOCATION = { kind: "unresolved" };
function payloadCoordinates(event) {
	const data = event.data;
	if (data.turn === null) return { session: true };
	const turn = Number.isSafeInteger(data.turn) && data.turn >= 0 ? data.turn : void 0;
	const step = Number.isSafeInteger(data.step) && data.step >= 0 ? data.step : void 0;
	return {
		...turn === void 0 ? {} : { turn },
		...step === void 0 ? {} : { step }
	};
}
function sameReferences(left, right) {
	return left.length === right.length && left.every((value, index) => value === right[index]);
}
function sameStep(left, right) {
	return left !== void 0 && left.start === right.start && left.end === right.end && left.status === right.status && left.data === right.data;
}
function sameTurn(left, right) {
	return left !== void 0 && left.start === right.start && left.end === right.end && left.status === right.status && left.data === right.data && sameReferences(left.steps, right.steps);
}
function sameLocation(left, right) {
	if (left === void 0 || right === void 0 || left.kind !== right.kind) return left === right;
	if (left.kind === "session" || left.kind === "unresolved") return true;
	if (right.kind === "session" || right.kind === "unresolved") return false;
	if (left.kind === "turn" || right.kind === "turn") return left.kind === "turn" && right.kind === "turn" && left.turn === right.turn;
	return left.turn === right.turn && left.step === right.step;
}
/** Session-owned Turn/Step timeline and event-to-Location index. */
var ConversationLocationIndex = class {
	coordinates = /* @__PURE__ */ new Map();
	locations = /* @__PURE__ */ new Map();
	seqsByTurn = /* @__PURE__ */ new Map();
	timeline = {
		turnOrder: [],
		turns: /* @__PURE__ */ new Map()
	};
	turnDataStores = /* @__PURE__ */ new Map();
	stepDataStores = /* @__PURE__ */ new Map();
	dirtyDataStores = /* @__PURE__ */ new Set();
	currentTurn;
	currentStep;
	/**
	* Return the current reference-stable timeline.
	* @returns current timeline snapshot.
	*/
	snapshot() {
		return this.timeline;
	}
	/**
	* Replace all Definition-owned Location values while preserving reader identities.
	* @param entries - complete current set of Definition-owned Location values.
	* @returns whether any published Location data changed.
	*/
	replaceData(entries) {
		const turns = /* @__PURE__ */ new Map();
		const steps = /* @__PURE__ */ new Map();
		for (const { owner, data } of entries) {
			const values = data.kind === "turn" ? turns.get(data.turn) ?? /* @__PURE__ */ new Map() : steps.get(stepDataKey(data.turn, requireStep(data))) ?? /* @__PURE__ */ new Map();
			const current = values.get(data.key);
			if (current !== void 0 && current.owner !== owner) throw new Error(`conversation Location data "${data.key}" is already owned by ${current.owner}`);
			values.set(data.key, {
				owner,
				value: data.value
			});
			if (data.kind === "turn") turns.set(data.turn, values);
			else steps.set(stepDataKey(data.turn, requireStep(data)), values);
		}
		let changed = false;
		for (const turn of new Set([...this.turnDataStores.keys(), ...turns.keys()])) changed = this.mutableTurnData(turn).replace(turns.get(turn) ?? /* @__PURE__ */ new Map()) || changed;
		for (const step of new Set([...this.stepDataStores.keys(), ...steps.keys()])) changed = this.mutableStepData(step).replace(steps.get(step) ?? /* @__PURE__ */ new Map()) || changed;
		return changed;
	}
	/**
	* Apply changed Context publications without rebuilding Turn/Step membership.
	* @param changes - incremental removals and replacements from published Contexts.
	* @returns whether any published Location data changed.
	*/
	applyData(changes) {
		let changed = false;
		for (const change of changes) {
			const previous = change.previous;
			if (previous === null) continue;
			changed = this.storeFor(previous).remove(change.owner, previous.key) || changed;
		}
		for (const change of changes) {
			const next = change.next;
			if (next === null) continue;
			changed = this.storeFor(next).set(change.owner, next.key, next.value) || changed;
		}
		return changed;
	}
	/** Publish committed Location-data changes to their keyed sources. */
	publishData() {
		const dirty = [...this.dirtyDataStores];
		this.dirtyDataStores.clear();
		for (const store of dirty) store.publish();
	}
	/**
	* Resolve the latest Location for one event.
	* @param event - event already ingested into this index.
	* @returns current Location, falling back to session when it has no Turn/Step affinity.
	*/
	locationOf(event) {
		return this.locations.get(event.seq) ?? SESSION_LOCATION;
	}
	/**
	* Rebuild timeline facts after replace/prepend or a boundary append.
	* @param entries - complete current window in ascending seq order.
	* @returns seqs whose resolved Location changed.
	*/
	rebuild(entries) {
		const previousLocations = this.locations;
		const turns = /* @__PURE__ */ new Map();
		const coordinates = /* @__PURE__ */ new Map();
		let currentTurn;
		let currentStep;
		const turnDraft = (turn, seq) => {
			let draft = turns.get(turn);
			if (draft === void 0) {
				draft = {
					turn,
					firstSeq: seq,
					steps: /* @__PURE__ */ new Map()
				};
				turns.set(turn, draft);
			} else draft.firstSeq = Math.min(draft.firstSeq, seq);
			return draft;
		};
		const stepDraft = (turn, step, seq) => {
			const owner = turnDraft(turn, seq);
			let draft = owner.steps.get(step);
			if (draft === void 0) {
				draft = {
					turn,
					step,
					firstSeq: seq
				};
				owner.steps.set(step, draft);
			} else draft.firstSeq = Math.min(draft.firstSeq, seq);
			return draft;
		};
		for (const { event } of entries) {
			const explicit = payloadCoordinates(event);
			if (event.type === "turn/start") {
				currentTurn = event.data.turn;
				currentStep = void 0;
			}
			if (event.type === "step/start") {
				currentTurn = event.data.turn;
				currentStep = event.data.step;
			}
			if (explicit.session !== true && explicit.turn !== void 0) {
				if (currentTurn !== explicit.turn) currentStep = void 0;
				currentTurn = explicit.turn;
				if (explicit.step !== void 0) currentStep = explicit.step;
			}
			const turn = explicit.session === true ? void 0 : explicit.turn ?? currentTurn;
			const step = explicit.session === true || event.type === "turn/start" || event.type === "turn/end" ? void 0 : explicit.step ?? (turn === currentTurn ? currentStep : void 0);
			coordinates.set(event.seq, {
				...turn === void 0 ? {} : { turn },
				...turn === void 0 || step === void 0 ? {} : { step }
			});
			if (turn !== void 0) turnDraft(turn, event.seq);
			if (turn !== void 0 && step !== void 0) stepDraft(turn, step, event.seq);
			if (event.type === "turn/start") turnDraft(event.data.turn, event.seq).start = event;
			else if (event.type === "turn/end") turnDraft(event.data.turn, event.seq).end = event;
			else if (event.type === "step/start") stepDraft(event.data.turn, event.data.step, event.seq).start = event;
			else if (event.type === "step/end") stepDraft(event.data.turn, event.data.step, event.seq).end = event;
			if (event.type === "step/end" && currentTurn === event.data.turn && currentStep === event.data.step) currentStep = void 0;
			if (event.type === "turn/end" && currentTurn === event.data.turn) {
				currentTurn = void 0;
				currentStep = void 0;
			}
		}
		const previousTurns = this.timeline.turns;
		const nextTurns = /* @__PURE__ */ new Map();
		const orderedDrafts = [...turns.values()].sort((left, right) => left.firstSeq - right.firstSeq);
		for (const draft of orderedDrafts) {
			const previousTurn = previousTurns.get(draft.turn);
			const previousSteps = new Map(previousTurn?.steps.map((step) => [step.step, step]) ?? []);
			const steps = [...draft.steps.values()].sort((left, right) => left.firstSeq - right.firstSeq).map((candidate) => {
				const value = {
					turn: candidate.turn,
					step: candidate.step,
					start: candidate.start,
					end: candidate.end,
					status: candidate.end !== void 0 ? "closed" : candidate.start === void 0 ? "unknown" : "open",
					data: this.stepData(candidate.turn, candidate.step)
				};
				const previous = previousSteps.get(candidate.step);
				return sameStep(previous, value) ? previous : value;
			});
			const value = {
				turn: draft.turn,
				start: draft.start,
				end: draft.end,
				status: draft.end !== void 0 ? "closed" : draft.start === void 0 ? "unknown" : "open",
				steps,
				data: this.turnData(draft.turn)
			};
			nextTurns.set(draft.turn, sameTurn(previousTurn, value) ? previousTurn : value);
		}
		const nextOrder = orderedDrafts.map((draft) => draft.turn);
		const turnOrder = this.timeline.turnOrder.length === nextOrder.length && this.timeline.turnOrder.every((turn, index) => turn === nextOrder[index]) ? this.timeline.turnOrder : nextOrder;
		let sameMap = previousTurns.size === nextTurns.size;
		if (sameMap) {
			for (const [turn, value] of nextTurns) if (previousTurns.get(turn) !== value) {
				sameMap = false;
				break;
			}
		}
		this.timeline = sameMap && turnOrder === this.timeline.turnOrder ? this.timeline : {
			turnOrder,
			turns: nextTurns
		};
		this.coordinates = coordinates;
		this.locations = /* @__PURE__ */ new Map();
		this.seqsByTurn = /* @__PURE__ */ new Map();
		for (const { event } of entries) {
			const coordinates = this.coordinates.get(event.seq);
			if (coordinates?.turn !== void 0) this.indexTurnSeq(coordinates.turn, event.seq);
			this.locations.set(event.seq, this.resolve(event.seq));
		}
		this.currentTurn = currentTurn;
		this.currentStep = currentStep;
		const changed = /* @__PURE__ */ new Set();
		for (const { event } of entries) if (!sameLocation(previousLocations.get(event.seq), this.locations.get(event.seq))) changed.add(event.seq);
		return changed;
	}
	/**
	* Append one Turn/Step boundary while revisiting only the owning Turn.
	* @param event - contiguous tail boundary event.
	* @returns seqs whose immutable Location reference changed.
	*/
	appendBoundary(event) {
		if (event.type !== "turn/start" && event.type !== "turn/end" && event.type !== "step/start" && event.type !== "step/end") throw new Error(`conversation Location boundary expected, received ${event.type}`);
		const explicit = payloadCoordinates(event);
		if (event.type === "turn/start") {
			this.currentTurn = event.data.turn;
			this.currentStep = void 0;
		} else if (event.type === "step/start") {
			this.currentTurn = event.data.turn;
			this.currentStep = event.data.step;
		}
		if (explicit.turn !== void 0) {
			if (this.currentTurn !== explicit.turn) this.currentStep = void 0;
			this.currentTurn = explicit.turn;
			if (explicit.step !== void 0) this.currentStep = explicit.step;
		}
		const turnNumber = explicit.turn ?? this.currentTurn;
		if (turnNumber === void 0) throw new Error(`conversation boundary ${event.type} has no turn`);
		const stepNumber = event.type === "turn/start" || event.type === "turn/end" ? void 0 : explicit.step ?? (turnNumber === this.currentTurn ? this.currentStep : void 0);
		this.coordinates.set(event.seq, {
			turn: turnNumber,
			...stepNumber === void 0 ? {} : { step: stepNumber }
		});
		this.indexTurnSeq(turnNumber, event.seq);
		const previousTurn = this.timeline.turns.get(turnNumber);
		let steps = previousTurn?.steps ?? [];
		if (event.type === "step/start" || event.type === "step/end") {
			const number = event.data.step;
			const previousStep = steps.find((candidate) => candidate.step === number);
			const candidate = {
				turn: turnNumber,
				step: number,
				start: event.type === "step/start" ? event : previousStep?.start,
				end: event.type === "step/end" ? event : previousStep?.end,
				status: event.type === "step/end" || previousStep?.end !== void 0 ? "closed" : "open",
				data: this.stepData(turnNumber, number)
			};
			const nextStep = sameStep(previousStep, candidate) ? previousStep : candidate;
			const index = steps.findIndex((step) => step.step === number);
			steps = index < 0 ? [...steps, nextStep] : steps.map((step, at) => at === index ? nextStep : step);
		}
		const candidate = {
			turn: turnNumber,
			start: event.type === "turn/start" ? event : previousTurn?.start,
			end: event.type === "turn/end" ? event : previousTurn?.end,
			status: event.type === "turn/end" || previousTurn?.end !== void 0 ? "closed" : event.type === "turn/start" || previousTurn?.start !== void 0 ? "open" : "unknown",
			steps,
			data: this.turnData(turnNumber)
		};
		const turn = sameTurn(previousTurn, candidate) ? previousTurn : candidate;
		const turns = new Map(this.timeline.turns);
		turns.set(turnNumber, turn);
		const turnOrder = previousTurn === void 0 ? [...this.timeline.turnOrder, turnNumber] : this.timeline.turnOrder;
		this.timeline = {
			turnOrder,
			turns
		};
		const changed = /* @__PURE__ */ new Set();
		for (const seq of this.seqsByTurn.get(turnNumber) ?? []) {
			const previous = this.locations.get(seq);
			const next = this.resolve(seq);
			this.locations.set(seq, next);
			if (!sameLocation(previous, next)) changed.add(seq);
		}
		if (event.type === "step/end" && this.currentTurn === event.data.turn && this.currentStep === event.data.step) this.currentStep = void 0;
		if (event.type === "turn/end" && this.currentTurn === event.data.turn) {
			this.currentTurn = void 0;
			this.currentStep = void 0;
		}
		return changed;
	}
	/**
	* Index one non-boundary tail event without rescanning the window.
	* @param event - contiguous appended event.
	*/
	appendNonBoundary(event) {
		const explicit = payloadCoordinates(event);
		if (explicit.session === true) {
			this.coordinates.set(event.seq, {});
			this.locations.set(event.seq, SESSION_LOCATION);
			return;
		}
		if (explicit.turn !== void 0) {
			if (this.currentTurn !== explicit.turn) this.currentStep = void 0;
			this.currentTurn = explicit.turn;
			if (explicit.step !== void 0) this.currentStep = explicit.step;
		}
		const turn = explicit.turn ?? this.currentTurn;
		const step = explicit.step ?? (turn === this.currentTurn ? this.currentStep : void 0);
		this.coordinates.set(event.seq, {
			...turn === void 0 ? {} : { turn },
			...turn === void 0 || step === void 0 ? {} : { step }
		});
		if (turn !== void 0) this.indexTurnSeq(turn, event.seq);
		this.locations.set(event.seq, this.resolve(event.seq));
	}
	/**
	* Remove indexed Assistant transients without rebuilding the Turn/Step timeline.
	* @param events - transient events retired by one Assistant settlement.
	*/
	removeAssistantTransients(events) {
		for (const event of events) {
			const turn = this.coordinates.get(event.seq)?.turn;
			if (turn !== void 0) {
				const seqs = this.seqsByTurn.get(turn);
				seqs?.delete(event.seq);
				if (seqs?.size === 0) this.seqsByTurn.delete(turn);
			}
			this.coordinates.delete(event.seq);
			this.locations.delete(event.seq);
		}
	}
	/**
	* Index one durable Assistant settlement inserted before an already visible tail.
	* @param event - message or attempt settlement with explicit Turn and Step coordinates.
	*/
	insertAssistantSettlement(event) {
		this.coordinates.set(event.seq, {
			turn: event.data.turn,
			step: event.data.step
		});
		this.indexTurnSeq(event.data.turn, event.seq);
		this.locations.set(event.seq, this.resolve(event.seq));
	}
	indexTurnSeq(turn, seq) {
		const current = this.seqsByTurn.get(turn) ?? /* @__PURE__ */ new Set();
		current.add(seq);
		this.seqsByTurn.set(turn, current);
	}
	turnData(turn) {
		return this.mutableTurnData(turn);
	}
	stepData(turn, step) {
		return this.mutableStepData(stepDataKey(turn, step));
	}
	mutableTurnData(turn) {
		const current = this.turnDataStores.get(turn) ?? this.createDataStore();
		this.turnDataStores.set(turn, current);
		return current;
	}
	mutableStepData(key) {
		const current = this.stepDataStores.get(key) ?? this.createDataStore();
		this.stepDataStores.set(key, current);
		return current;
	}
	createDataStore() {
		return new MutableLocationDataStore((store) => this.dirtyDataStores.add(store));
	}
	storeFor(data) {
		return data.kind === "turn" ? this.mutableTurnData(data.turn) : this.mutableStepData(stepDataKey(data.turn, requireStep(data)));
	}
	resolve(seq) {
		const coordinates = this.coordinates.get(seq);
		if (coordinates?.turn === void 0) return SESSION_LOCATION;
		const turn = this.timeline.turns.get(coordinates.turn);
		if (turn === void 0) return UNRESOLVED_LOCATION;
		if (coordinates.step === void 0) return {
			kind: "turn",
			turn
		};
		const step = turn.steps.find((candidate) => candidate.step === coordinates.step);
		return step === void 0 ? {
			kind: "turn",
			turn
		} : {
			kind: "step",
			turn,
			step
		};
	}
};
function stepDataKey(turn, step) {
	return `${turn}:${step}`;
}
function requireStep(data) {
	if (data.kind === "step" && data.step !== void 0) return data.step;
	throw new Error(`conversation Step data "${data.key}" requires a step`);
}
//#endregion
//#region lib/types/client/conversation/assembler.js
const PUBLICATION_RANK = {
	none: 0,
	"animation-frame": 1,
	immediate: 2
};
const LOCATION_DATA_SCOPES = ["step", "turn"];
function emptyLocationData() {
	return {
		step: null,
		turn: null
	};
}
function maximumPublication(left, right) {
	return PUBLICATION_RANK[left] >= PUBLICATION_RANK[right] ? left : right;
}
function startSeq(context) {
	return context.startSeq;
}
function insertionIndex(contexts, seq) {
	let low = 0;
	let high = contexts.length;
	while (low < high) {
		const middle = low + Math.floor((high - low) / 2);
		const candidate = contexts[middle];
		if (candidate !== void 0 && candidate.startSeq < seq) low = middle + 1;
		else high = middle;
	}
	return low;
}
function contextSnapshot(context) {
	return {
		key: context.key,
		kind: context.kind,
		id: context.id,
		matches: context.matches,
		start: context.start,
		state: context.state,
		current: context.current
	};
}
function mergeMatches(key, additions, existing) {
	const merged = [];
	let added = 0;
	let current = 0;
	while (added < additions.length || current < existing.length) {
		const left = additions[added];
		const right = existing[current];
		if (left !== void 0 && right !== void 0 && left.event.seq === right.event.seq) throw new Error(`conversation Context ${key} received duplicate Match ${left.event.seq}`);
		if (right === void 0 || left !== void 0 && left.event.seq < right.event.seq) {
			merged.push(left);
			added++;
		} else {
			merged.push(right);
			current++;
		}
	}
	return merged;
}
function conversationMatch(key, input, role, location) {
	if (role === "start") {
		if (input.type !== "event") throw new Error(`conversation Context ${key} received a transient start Match`);
		return {
			event: input.event,
			role,
			location,
			...input.detail !== void 0 ? { detail: input.detail } : {}
		};
	}
	return {
		event: input.event,
		role,
		location,
		...input.type === "event" && input.detail !== void 0 ? { detail: input.detail } : {}
	};
}
/**
* Session-owned incremental engine that assembles business Contexts from a
* contiguous Event window and materializes registered view snapshots.
*/
var ConversationNodeAssembler = class {
	eventDefinitions;
	viewDefinitions;
	contexts = /* @__PURE__ */ new Map();
	contextsByKind = /* @__PURE__ */ new Map();
	contextsBySeq = /* @__PURE__ */ new Map();
	contextsByTarget = /* @__PURE__ */ new Map();
	inputs = /* @__PURE__ */ new Map();
	locationIndex = new ConversationLocationIndex();
	dirty = /* @__PURE__ */ new Set();
	dirtyByTarget = /* @__PURE__ */ new Map();
	revised = /* @__PURE__ */ new Set();
	dependents = /* @__PURE__ */ new Map();
	views = /* @__PURE__ */ new Map();
	activeTargets = /* @__PURE__ */ new Set();
	hasMore = false;
	replacePending = true;
	timelineDirty = true;
	/**
	* @param eventDefinitions - live Event Definition registry.
	* @param viewDefinitions - live view builder registry.
	*/
	constructor(eventDefinitions, viewDefinitions) {
		this.eventDefinitions = eventDefinitions;
		this.viewDefinitions = viewDefinitions;
		this.resetViewBuilders();
	}
	/**
	* Replace the complete loaded window after open, resync, or gap repair.
	* @param entries - complete contiguous window.
	* @param hasMore - whether older history remains outside the window.
	* @returns immediate publication request.
	*/
	replaceWindow(entries, hasMore) {
		this.contexts.clear();
		this.contextsByKind.clear();
		this.contextsBySeq.clear();
		this.contextsByTarget.clear();
		this.inputs.clear();
		this.dirty.clear();
		this.dirtyByTarget.clear();
		this.revised.clear();
		this.dependents.clear();
		this.hasMore = hasMore;
		const sorted = [...entries].sort((left, right) => left.event.seq - right.event.seq);
		for (const entry of sorted) this.inputs.set(entry.event.seq, entry);
		this.locationIndex.rebuild(sorted);
		this.timelineDirty = true;
		for (const entry of sorted) this.matchInput(entry);
		this.replayDependencies();
		this.revised.clear();
		for (const context of this.contexts.values()) this.markDirty(context);
		this.replacePending = true;
		return "immediate";
	}
	/**
	* Add one contiguous live tail event without scanning existing Contexts.
	* @param record - appended Session event entry.
	* @returns highest requested publication cadence.
	*/
	append(record) {
		const event = record.event;
		if (this.inputs.has(event.seq)) return "none";
		this.revised.clear();
		this.inputs.set(event.seq, record);
		let publication = "none";
		if (event.type !== "assistant/live-chunk" && isLocationBoundary(event.type)) {
			const previousTimeline = this.locationIndex.snapshot();
			const changed = this.locationIndex.appendBoundary(event);
			if (this.locationIndex.snapshot() !== previousTimeline) {
				this.timelineDirty = true;
				publication = "immediate";
			}
			this.replayContexts(this.refreshMatchLocations(changed));
			if (changed.size > 0) publication = "immediate";
		} else this.locationIndex.appendNonBoundary(event);
		publication = maximumPublication(publication, this.matchInput(record));
		if (this.replayRevisedDependents()) publication = "immediate";
		this.revised.clear();
		return publication;
	}
	/**
	* Retire one Assistant attempt's transient matches and apply its optional durable settlement.
	* @param attemptId - process-local attempt whose transient presentation ended.
	* @param entry - durable message or attempt event committed for the stream.
	* @returns highest requested publication cadence.
	*/
	settleAssistant(attemptId, entry) {
		this.revised.clear();
		const retired = [...this.inputs.values()].filter((candidate) => candidate.type === "transient" && candidate.event.data.attemptId === attemptId);
		const retiredSeqs = new Set(retired.map((candidate) => candidate.event.seq));
		const affected = /* @__PURE__ */ new Set();
		for (const seq of retiredSeqs) {
			this.inputs.delete(seq);
			for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context);
			this.contextsBySeq.delete(seq);
		}
		for (const context of affected) context.matches = context.matches.filter((match) => !retiredSeqs.has(match.event.seq));
		this.locationIndex.removeAssistantTransients(retired.map((candidate) => candidate.event));
		let publication = retired.length === 0 ? "none" : "immediate";
		if (entry !== void 0 && !this.inputs.has(entry.event.seq)) {
			this.inputs.set(entry.event.seq, entry);
			this.locationIndex.insertAssistantSettlement(entry.event);
			const pending = /* @__PURE__ */ new Map();
			publication = maximumPublication(publication, this.collectInput(entry, pending));
			this.applyPendingMatches(pending, affected);
		}
		this.replayContexts(affected);
		if (this.replayRevisedDependents()) publication = "immediate";
		this.revised.clear();
		return publication;
	}
	/**
	* Add an older page while preserving existing Context and view identities.
	* @param entries - newly loaded older Events.
	* @param hasMore - whether history still precedes the expanded window.
	* @returns highest requested publication cadence.
	*/
	prepend(entries, hasMore) {
		this.revised.clear();
		let publication = "none";
		const previousHasMore = this.hasMore;
		const fresh = entries.filter((entry) => !this.inputs.has(entry.event.seq)).sort((left, right) => left.event.seq - right.event.seq);
		for (const entry of fresh) this.inputs.set(entry.event.seq, entry);
		this.hasMore = hasMore;
		const previousTimeline = this.locationIndex.snapshot();
		const changedLocations = this.locationIndex.rebuild(this.sortedInputs());
		if (this.locationIndex.snapshot() !== previousTimeline) this.timelineDirty = true;
		const affected = this.refreshMatchLocations(changedLocations);
		const pending = /* @__PURE__ */ new Map();
		for (const entry of fresh) publication = maximumPublication(publication, this.collectInput(entry, pending));
		this.applyPendingMatches(pending, affected);
		this.replayContexts(affected);
		if ((this.revised.size > 0 || previousHasMore !== hasMore) && this.replayDependencies()) publication = "immediate";
		if (changedLocations.size > 0) publication = "immediate";
		this.revised.clear();
		return publication;
	}
	/**
	* Rebuild against the current Registry set after a low-frequency plugin change.
	* @returns immediate publication request.
	*/
	rebuildRegistry() {
		this.resetViewBuilders();
		return this.replaceWindow(this.sortedInputs(), this.hasMore);
	}
	/**
	* Materialize dirty Contexts and advance every active view builder.
	* @returns whether any view snapshot was rebuilt or incrementally applied.
	*/
	flush() {
		if (!this.replacePending && this.dirty.size === 0 && !this.timelineDirty) return false;
		if (this.replacePending) {
			this.replaceLocationData();
			let published = false;
			for (const target of this.activeTargets) {
				const view = this.views.get(target);
				if (view === void 0) continue;
				const builder = view.builder ?? view.definition.create();
				view.builder = builder;
				view.snapshot = builder.replace({
					nodes: this.buildTargetNodes(target, this.contextsByTarget.get(target)),
					timeline: this.locationIndex.snapshot()
				});
				published = true;
			}
			this.locationIndex.publishData();
			this.replacePending = false;
			this.dirty.clear();
			this.dirtyByTarget.clear();
			this.timelineDirty = false;
			return published;
		}
		let published = false;
		if (this.applyDirtyLocationData()) this.timelineDirty = true;
		const timelineDirty = this.timelineDirty;
		for (const target of this.activeTargets) {
			const view = this.views.get(target);
			if (view === void 0) continue;
			const builder = view.builder;
			if (builder === void 0) continue;
			const upserts = this.buildTargetUpserts(target, this.dirtyByTarget.get(target));
			if (upserts.length === 0 && !timelineDirty) continue;
			view.snapshot = builder.apply({
				upserts,
				timeline: this.locationIndex.snapshot()
			});
			published = true;
		}
		this.locationIndex.publishData();
		this.dirty.clear();
		this.dirtyByTarget.clear();
		this.timelineDirty = false;
		return published;
	}
	/**
	* Add one target to the monotonic active set and materialize its current snapshot.
	* Pending Context work is flushed before the first complete replacement.
	* @param target - registered or subsequently registered view target.
	* @returns whether any active target snapshot changed.
	*/
	activateTarget(target) {
		const view = this.views.get(target);
		if (this.activeTargets.has(target)) return false;
		const published = this.flush();
		this.activeTargets.add(target);
		if (view === void 0) return published;
		this.replaceView(view);
		return true;
	}
	/**
	* Read the latest snapshot of a registered target.
	* @param target - registered view target.
	* @returns target snapshot, or undefined before registration or activation.
	*/
	snapshot(target) {
		return this.views.get(target)?.snapshot;
	}
	get(target) {
		return this.snapshot(target);
	}
	/**
	* Read targets whose owners classify their latest snapshot as visible activity.
	* @returns target ids contributing visible activity.
	*/
	activityTargets() {
		const active = /* @__PURE__ */ new Set();
		for (const target of this.activeTargets) {
			const view = this.views.get(target);
			if (view === void 0) continue;
			if (view.isActive?.(view.snapshot) === true) active.add(view.target);
		}
		return active;
	}
	sortedInputs() {
		return [...this.inputs.values()].sort((left, right) => left.event.seq - right.event.seq);
	}
	matchInput(input) {
		return this.dispatchInput(input, (definition, id, role) => this.acceptMatch(definition, id, role, input));
	}
	collectInput(input, pending) {
		return this.dispatchInput(input, (definition, id, role) => {
			const key = conversationContextKey(definition.kind, id);
			const match = conversationMatch(key, input, role, this.locationIndex.locationOf(input.event));
			const matches = pending.get(key) ?? [];
			matches.push({
				definition,
				id,
				match
			});
			pending.set(key, matches);
			return definition.publication?.(match) ?? "immediate";
		});
	}
	dispatchInput(input, accept) {
		const event = input.event;
		const matchedTargets = /* @__PURE__ */ new Set();
		let publication = "none";
		for (const definition of this.eventDefinitions.entries()) {
			const result = definition.match(event);
			if (result === null) continue;
			if (definition.target !== void 0) matchedTargets.add(definition.target);
			publication = maximumPublication(publication, accept(definition, result.id, result.role));
		}
		const fallback = this.eventDefinitions.fallbackEntry();
		const target = fallback?.target;
		if (fallback !== void 0 && target !== void 0 && !matchedTargets.has(target)) {
			const result = fallback.match(event);
			if (result !== null) publication = maximumPublication(publication, accept(fallback, result.id, result.role));
		}
		return publication;
	}
	createContext(definition, id, key) {
		const context = {
			key,
			kind: definition.kind,
			id,
			definition,
			startSeq: void 0,
			start: void 0,
			matches: [],
			state: void 0,
			revision: 0,
			current: /* @__PURE__ */ new Map(),
			locationData: emptyLocationData(),
			dependencies: /* @__PURE__ */ new Map()
		};
		this.contexts.set(key, context);
		this.indexTargetContext(context);
		return context;
	}
	acceptMatch(definition, id, role, input) {
		const key = conversationContextKey(definition.kind, id);
		let context = this.contexts.get(key);
		if (role === "start" && context?.start !== void 0) throw new Error(`conversation Context ${key} received more than one start Match`);
		context ??= this.createContext(definition, id, key);
		const match = conversationMatch(key, input, role, this.locationIndex.locationOf(input.event));
		const previous = context.matches.at(-1);
		if (previous !== void 0 && previous.event.seq >= input.event.seq) throw new Error(`conversation Context ${key} received non-appended Match ${input.event.seq}`);
		if (role === "start" && context.matches.length > 0) throw new Error(`conversation Context ${key} received an update before its start Match`);
		context.matches.push(match);
		if (match.role === "start") {
			context.startSeq = input.event.seq;
			context.start = match;
			this.indexStartedContext(context);
		}
		const owners = this.contextsBySeq.get(input.event.seq) ?? /* @__PURE__ */ new Set();
		owners.add(context);
		this.contextsBySeq.set(input.event.seq, owners);
		if (match.role === "start") this.replayContext(context);
		else if (context.state !== void 0) {
			const typed = contextSnapshot(context);
			context.state = requireState(definition, "update", definition.update(typed, match));
			context.revision++;
			this.revised.add(context);
		}
		this.markDirty(context);
		return definition.publication?.(match) ?? "immediate";
	}
	applyPendingMatches(pending, affected) {
		const startsByKind = /* @__PURE__ */ new Map();
		for (const [key, entries] of pending) {
			const first = entries[0];
			if (first === void 0) continue;
			let context = this.contexts.get(key);
			context ??= this.createContext(first.definition, first.id, key);
			let discoveredStart;
			const additions = entries.map((entry) => {
				if (entry.definition !== context.definition || entry.id !== context.id) throw new Error(`conversation Context ${key} received inconsistent Definition identity`);
				if (entry.match.role === "start") {
					if (discoveredStart !== void 0 || context.start !== void 0) throw new Error(`conversation Context ${key} received more than one start Match`);
					discoveredStart = entry.match;
				}
				const owners = this.contextsBySeq.get(entry.match.event.seq) ?? /* @__PURE__ */ new Set();
				owners.add(context);
				this.contextsBySeq.set(entry.match.event.seq, owners);
				return entry.match;
			}).sort((left, right) => left.event.seq - right.event.seq);
			context.matches = mergeMatches(context.key, additions, context.matches);
			if (discoveredStart !== void 0) {
				context.start = discoveredStart;
				context.startSeq = discoveredStart.event.seq;
				const starts = startsByKind.get(context.kind) ?? [];
				starts.push(context);
				startsByKind.set(context.kind, starts);
			}
			if (context.start !== void 0 && context.matches[0] !== context.start) throw new Error(`conversation Context ${context.key} received an update before its start Match`);
			affected.add(context);
			this.markDirty(context);
		}
		for (const [kind, contexts] of startsByKind) this.indexStartedContexts(kind, contexts);
	}
	replayContexts(contexts) {
		const ordered = [...contexts].sort((left, right) => (left.startSeq ?? Number.POSITIVE_INFINITY) - (right.startSeq ?? Number.POSITIVE_INFINITY));
		for (const context of ordered) {
			if (context.start === void 0) {
				context.state = void 0;
				this.markDirty(context);
				continue;
			}
			this.replayContext(context);
		}
	}
	replayContext(context) {
		const start = context.start;
		if (start === void 0) {
			context.state = void 0;
			return;
		}
		if (context.matches[0] !== start) throw new Error(`conversation Context ${context.key} received an update before its start Match`);
		const dependencies = /* @__PURE__ */ new Map();
		const reader = this.readerFor(start.event.seq, dependencies);
		context.state = void 0;
		context.state = requireState(context.definition, "start", context.definition.start(contextSnapshot(context), start, reader));
		this.replaceDependencies(context, dependencies);
		for (let index = 1; index < context.matches.length; index++) {
			const match = context.matches[index];
			if (match === void 0 || match.role !== "update") continue;
			const typed = contextSnapshot(context);
			context.state = requireState(context.definition, "update", context.definition.update(typed, match));
		}
		context.revision++;
		this.revised.add(context);
		this.markDirty(context);
	}
	indexTargetContext(context) {
		const target = context.definition.target;
		if (target === void 0) return;
		const contexts = this.contextsByTarget.get(target) ?? /* @__PURE__ */ new Set();
		contexts.add(context);
		this.contextsByTarget.set(target, contexts);
	}
	markDirty(context) {
		this.dirty.add(context);
		const target = context.definition.target;
		if (target === void 0 || !this.activeTargets.has(target)) return;
		const contexts = this.dirtyByTarget.get(target) ?? /* @__PURE__ */ new Set();
		contexts.add(context);
		this.dirtyByTarget.set(target, contexts);
	}
	replaceDependencies(context, dependencies) {
		for (const dependency of context.dependencies.values()) {
			if (dependency.key === void 0) continue;
			const current = this.dependents.get(dependency.key);
			current?.delete(context);
			if (current?.size === 0) this.dependents.delete(dependency.key);
		}
		context.dependencies = dependencies;
		for (const dependency of dependencies.values()) {
			if (dependency.key === void 0) continue;
			const current = this.dependents.get(dependency.key) ?? /* @__PURE__ */ new Set();
			current.add(context);
			this.dependents.set(dependency.key, current);
		}
	}
	replayRevisedDependents() {
		const pending = [...this.revised];
		const affected = /* @__PURE__ */ new Set();
		for (let index = 0; index < pending.length; index++) {
			const dependency = pending[index];
			if (dependency === void 0) continue;
			for (const dependent of this.dependents.get(dependency.key) ?? []) {
				if (affected.has(dependent)) continue;
				affected.add(dependent);
				pending.push(dependent);
			}
		}
		this.replayContexts(affected);
		return affected.size > 0;
	}
	readerFor(beforeSeq, dependencies) {
		return { previous: (kind) => {
			const predecessor = this.previousContext(kind, beforeSeq);
			dependencies.set(kind, {
				kind,
				key: predecessor?.key,
				revision: predecessor?.revision,
				windowGap: predecessor === void 0 && this.hasMore
			});
			if (predecessor?.state === void 0) return void 0;
			const seq = startSeq(predecessor);
			if (seq === void 0) return void 0;
			return {
				key: predecessor.key,
				kind: predecessor.kind,
				id: predecessor.id,
				startSeq: seq,
				state: predecessor.state,
				matches: predecessor.matches
			};
		} };
	}
	previousContext(kind, beforeSeq) {
		const candidates = this.contextsByKind.get(kind) ?? [];
		const indexBefore = insertionIndex(candidates, beforeSeq);
		for (let index = indexBefore - 1; index >= 0; index--) {
			const candidate = candidates[index];
			if (candidate?.state !== void 0) return candidate;
		}
	}
	/** Insert one newly discovered start into its Definition's ordered predecessor index. */
	indexStartedContext(context) {
		const seq = context.startSeq;
		if (seq === void 0) return;
		const candidates = this.contextsByKind.get(context.kind) ?? [];
		const previous = candidates.at(-1);
		if (previous === void 0 || previous.startSeq < seq) candidates.push(context);
		else candidates.splice(insertionIndex(candidates, seq), 0, context);
		this.contextsByKind.set(context.kind, candidates);
	}
	indexStartedContexts(kind, additions) {
		if (additions.length === 0) return;
		const sorted = [...additions].sort((left, right) => left.startSeq - right.startSeq);
		const existing = this.contextsByKind.get(kind) ?? [];
		const merged = [];
		let before = 0;
		let added = 0;
		while (before < existing.length || added < sorted.length) {
			const left = existing[before];
			const right = sorted[added];
			if (right === void 0 || left !== void 0 && left.startSeq < right.startSeq) {
				merged.push(left);
				before++;
			} else {
				merged.push(right);
				added++;
			}
		}
		this.contextsByKind.set(kind, merged);
	}
	replayDependencies() {
		let replayed = false;
		const ordered = [...this.contexts.values()].filter((context) => startSeq(context) !== void 0).sort((left, right) => startSeq(left) - startSeq(right));
		for (const context of ordered) {
			if (context.state === void 0 || context.dependencies.size === 0) continue;
			const before = startSeq(context);
			if (before === void 0) continue;
			let changed = false;
			for (const dependency of context.dependencies.values()) {
				const current = this.previousContext(dependency.kind, before);
				const windowGap = current === void 0 && this.hasMore;
				if (current?.key !== dependency.key || current?.revision !== dependency.revision || windowGap !== dependency.windowGap) {
					changed = true;
					break;
				}
			}
			if (changed) {
				this.replayContext(context);
				replayed = true;
			}
		}
		return replayed;
	}
	refreshMatchLocations(changedSeqs) {
		const affected = /* @__PURE__ */ new Set();
		if (changedSeqs.size === 0) return affected;
		for (const seq of changedSeqs) for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context);
		for (const context of affected) {
			let start = context.start;
			context.matches = context.matches.map((match) => {
				if (!changedSeqs.has(match.event.seq)) return match;
				if (match.role === "start") {
					const refreshed = {
						...match,
						location: this.locationIndex.locationOf(match.event)
					};
					if (match === start) start = refreshed;
					return refreshed;
				}
				return {
					...match,
					location: this.locationIndex.locationOf(match.event)
				};
			});
			context.start = start;
		}
		return affected;
	}
	buildNode(context, target) {
		if (context.definition.target !== target || context.definition.buildViewNode === void 0) return null;
		const node = context.definition.buildViewNode(contextSnapshot(context));
		if (node === null) return null;
		if (node.key !== context.key) throw new Error(`conversation Definition "${context.kind}" returned unstable key "${node.key}"; expected "${context.key}"`);
		if (node.target !== target) throw new Error(`conversation Definition "${context.kind}" returned target "${node.target}" while building "${target}"`);
		return node;
	}
	replaceView(view) {
		const builder = view.builder ?? view.definition.create();
		view.builder = builder;
		view.snapshot = builder.replace({
			nodes: this.buildTargetNodes(view.target, this.contextsByTarget.get(view.target)),
			timeline: this.locationIndex.snapshot()
		});
	}
	buildTargetNodes(target, contexts) {
		const nodes = [];
		for (const context of contexts ?? []) {
			const node = this.buildNode(context, target);
			context.current.set(target, node);
			if (node !== null) nodes.push(node);
		}
		return nodes;
	}
	buildTargetUpserts(target, contexts) {
		const upserts = [];
		for (const context of contexts ?? []) {
			const previous = context.current.get(target) ?? null;
			const node = this.buildNode(context, target);
			if (node === null && previous !== null) throw new Error(`conversation Definition "${context.kind}" withdrew materialized target "${target}"; return the same key with hidden visibility instead`);
			context.current.set(target, node);
			if (node !== null) upserts.push(node);
		}
		return upserts;
	}
	buildLocationData(context, scope, previous) {
		if (context.definition.buildLocationData === void 0) return null;
		const data = context.definition.buildLocationData(contextSnapshot(context), scope, previous);
		if (data === null) return null;
		if (data.kind !== scope) throw new Error(`conversation Definition "${context.kind}" published ${data.kind} data through its ${scope} scope`);
		if (data.key !== context.kind) throw new Error(`conversation Definition "${context.kind}" published Location data key "${data.key}"; expected its owned kind`);
		if (!Number.isSafeInteger(data.turn) || data.turn < 0) throw new Error(`conversation Definition "${context.kind}" published invalid turn ${data.turn}`);
		if (data.kind === "step" && (!Number.isSafeInteger(data.step) || data.step < 0)) throw new Error(`conversation Definition "${context.kind}" published invalid step ${String(data.step)}`);
		return data;
	}
	replaceLocationData() {
		const entries = [];
		for (const scope of LOCATION_DATA_SCOPES) {
			for (const context of this.contexts.values()) {
				const data = this.buildLocationData(context, scope, context.locationData[scope]);
				context.locationData[scope] = data;
				if (data !== null) entries.push({
					owner: context.key,
					data
				});
			}
			this.locationIndex.replaceData(entries);
		}
	}
	applyDirtyLocationData() {
		let changed = false;
		for (const scope of LOCATION_DATA_SCOPES) {
			const changes = [];
			for (const context of this.dirty) {
				const previous = context.locationData[scope];
				const next = this.buildLocationData(context, scope, previous);
				if (previous === next) continue;
				context.locationData[scope] = next;
				changes.push({
					owner: context.key,
					previous,
					next
				});
			}
			changed = this.locationIndex.applyData(changes) || changed;
		}
		return changed;
	}
	resetViewBuilders() {
		this.views.clear();
		for (const definition of this.viewDefinitions.entries()) {
			const view = {
				target: definition.target,
				definition,
				isActive: definition.isActive === void 0 ? void 0 : (snapshot) => definition.isActive?.(snapshot) === true,
				builder: void 0,
				snapshot: void 0
			};
			this.views.set(definition.target, view);
		}
		this.replacePending = true;
	}
};
function isLocationBoundary(type) {
	return type === "turn/start" || type === "turn/end" || type === "step/start" || type === "step/end";
}
function requireState(definition, phase, state) {
	if (state === void 0) throw new Error(`conversation Definition "${definition.kind}" returned undefined from ${phase}()`);
	return state;
}
//#endregion
//#region lib/types/client/conversation/definition-registry.js
/** Shared lifecycle and stable-entry storage for one Conversation Definition registry. */
var ConversationDefinitionRegistry = class {
	ctx;
	definitions = /* @__PURE__ */ new Map();
	listeners = /* @__PURE__ */ new Set();
	cached = [];
	/** @param ctx - Context whose effects own contributed Definitions. */
	constructor(ctx) {
		this.ctx = ctx;
		Object.defineProperty(this, Service.tracker, { value: { property: "ctx" } });
	}
	/**
	* Return reference-stable Definitions in registration order.
	* @returns current Definitions.
	*/
	entries() {
		return this.cached;
	}
	/**
	* Observe low-frequency registry changes.
	* @param listener - synchronous invalidation callback.
	* @returns unsubscribe callback.
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	}
	/**
	* Register one uniquely keyed Definition for the caller's lifetime.
	* @param key - registry-local unique key.
	* @param definition - contributed Definition.
	* @param duplicateMessage - error raised when the key is already owned.
	* @param effectName - Cordis effect diagnostic label.
	* @returns idempotent disposer.
	*/
	registerDefinition(key, definition, duplicateMessage, effectName) {
		if (this.definitions.has(key)) throw new Error(duplicateMessage);
		const dispose = this.ctx.effect(() => {
			this.definitions.set(key, definition);
			this.refresh();
			return () => {
				if (this.definitions.get(key) !== definition) return;
				this.definitions.delete(key);
				this.refresh();
			};
		}, effectName);
		return () => {
			dispose();
		};
	}
	/** Refresh cached entries and synchronously invalidate subscribers. */
	refresh() {
		this.cached = [...this.definitions.values()];
		notifySubscribers(this.listeners, "[ui-conversation] definition registry");
	}
};
//#endregion
//#region lib/types/client/conversation/event-registry.js
/** Runtime registry of independently owned Conversation business Definitions. */
var ConversationEventRegistry = class extends ConversationDefinitionRegistry {
	fallback;
	/**
	* Register a uniquely named business Definition for the caller's lifetime.
	* @param definition - Definition contribution.
	* @returns idempotent disposer.
	*/
	register(definition) {
		assertDefinitionTarget(definition);
		return this.registerDefinition(definition.kind, definition, `conversation Definition "${definition.kind}" is already registered`, `uiConversation.events.register(${JSON.stringify(definition.kind)})`);
	}
	/**
	* Register the sole fallback used only when no ordinary Definition matches.
	* @param definition - fallback Definition.
	* @returns idempotent disposer.
	*/
	registerFallback(definition) {
		assertDefinitionTarget(definition);
		if (definition.target === void 0) throw new Error("conversation fallback Definition must declare a target");
		if (this.fallback !== void 0) throw new Error("conversation fallback Definition is already registered");
		const dispose = this.ctx.effect(() => {
			this.fallback = definition;
			this.refresh();
			return () => {
				if (this.fallback !== definition) return;
				this.fallback = void 0;
				this.refresh();
			};
		}, `uiConversation.events.registerFallback(${JSON.stringify(definition.kind)})`);
		return () => {
			dispose();
		};
	}
	/**
	* Return the current unmatched-event fallback.
	* @returns installed fallback, when present.
	*/
	fallbackEntry() {
		return this.fallback;
	}
};
function assertDefinitionTarget(definition) {
	if (definition.target === void 0 !== (definition.buildViewNode === void 0)) throw new Error(`conversation Definition "${definition.kind}" must declare target and buildViewNode together`);
}
//#endregion
//#region lib/types/client/conversation/view-registry.js
/** Runtime registry of per-target Conversation snapshot builders. */
var ConversationViewRegistry = class extends ConversationDefinitionRegistry {
	/**
	* Register a uniquely named view builder factory for the caller's lifetime.
	* @param definition - target builder contribution.
	* @returns idempotent disposer.
	*/
	register(definition) {
		return this.registerDefinition(definition.target, definition, `conversation view target "${definition.target}" is already registered`, `uiConversation.views.register(${JSON.stringify(definition.target)})`);
	}
};
//#endregion
//#region lib/types/client/contract/request-inspection.js
/**
* Canonicalize one request header against the system node in force and
* classify the model-visible prompt change.
* @param previous - Prompt from the preceding loaded request header, when available.
* @param event - Durable full request header to inspect.
* @param system - Effective nonempty system prompt after loaded surface replacements; empty when removed.
* An in-history update already presented its text at its own position, so the header reports no system change for it.
* @returns The canonical prompt and an initial/system/tool change when it can be established.
*/
function inspectRequestPrompt(previous, event, system) {
	const header = event.data.header;
	const rawTools = header.tools;
	const prompt = {
		config: header.config,
		system: system?.text ?? "",
		tools: Array.isArray(rawTools) ? rawTools : []
	};
	if (previous === void 0 && event.data.reason !== "initial") return { prompt };
	const systemChanged = previous !== void 0 && previous.system !== prompt.system && system?.update !== true;
	const toolsChanged = previous !== void 0 && JSON.stringify(previous.tools) !== JSON.stringify(prompt.tools);
	if (previous !== void 0 && !systemChanged && !toolsChanged) return { prompt };
	const origin = system !== void 0 && (previous === void 0 || systemChanged) ? system : event;
	return {
		prompt,
		change: {
			seq: origin.seq,
			time: origin.time,
			kind: previous === void 0 ? "initial" : systemChanged && toolsChanged ? "system-and-tools" : systemChanged ? "system" : "tools",
			...previous === void 0 ? {} : { previous }
		}
	};
}
//#endregion
//#region ../../core/session/src/surface.ts
/** Runtime counterpart of the message-producing event union. */
const SURFACE_EVENT_TYPES = new Set([
	"system/message",
	"user/message",
	"assistant/message",
	"tool/result"
]);
/**
* Narrow an event to a surface-eligible event carrying its required marker.
* @param event - event to test.
* @returns true when both the type and marker identify a surface event.
*/
function isSurfaceEvent(event) {
	if (!SURFACE_EVENT_TYPES.has(event.type)) return false;
	return event.surfaceOp !== void 0;
}
//#endregion
//#region lib/types/client/contract/system-prompt.js
/**
* Apply a system event or positional replacement without retaining ordinary messages.
* Replacement positions inherit their start endpoint, not their chronological seq.
* Unknown older endpoint order withholds the prompt until prepend replay resolves it.
* @param previous - Interpretation at the preceding relevant event in the loaded window.
* @param event - System message or surface replacement already admitted by Session.
* @returns Immutable surviving system facts and the effective nonempty prompt.
*/
function inspectSystemPrompt(previous, event) {
	const op = isSurfaceEvent(event) ? event.surfaceOp : void 0;
	const firstSeq = previous?.firstSeq ?? event.seq;
	let nodes = previous?.nodes ?? [];
	let replacements = previous?.replacements ?? /* @__PURE__ */ new Map();
	const unknownEndpoint = (seq) => seq < firstSeq && !replacements.has(seq);
	const uncertain = previous?.uncertain === true || op !== void 0 && op !== "append" && (unknownEndpoint(op.startSeq) || unknownEndpoint(op.endSeq));
	if (uncertain) return {
		firstSeq,
		uncertain,
		nodes: [],
		replacements: /* @__PURE__ */ new Map(),
		effective: void 0,
		introduced: void 0
	};
	let position = event.seq;
	if (op !== void 0 && op !== "append") {
		position = replacements.get(op.startSeq) ?? op.startSeq;
		const end = replacements.get(op.endSeq) ?? op.endSeq;
		nodes = nodes.filter((item) => item.position < position || item.position > end);
		const retained = new Map([...replacements].filter(([, value]) => value < position || value > end));
		retained.set(event.seq, position);
		replacements = retained;
	}
	const introduced = event.type === "system/message" ? {
		seq: event.seq,
		time: event.time,
		turn: event.data.turn,
		step: event.data.step,
		text: event.data.message.content.flatMap((block) => block.type === "text" ? [block.text] : []).join(""),
		update: op === "append" && previous?.nodes.some((item) => item.node.text !== "") === true
	} : void 0;
	if (introduced !== void 0) nodes = [...nodes, {
		position,
		node: introduced
	}].sort((a, b) => a.position - b.position);
	const surviving = nodes.findLast((item) => item.node.text !== "")?.node;
	const effective = surviving === previous?.nodes.findLast((item) => item.node.text !== "")?.node ? previous?.effective : introduced !== void 0 && introduced === surviving ? introduced : {
		seq: event.seq,
		time: event.time,
		turn: surviving?.turn ?? 0,
		step: surviving?.step ?? 0,
		text: surviving?.text ?? "",
		update: false
	};
	return {
		firstSeq,
		uncertain,
		nodes,
		replacements,
		effective,
		introduced
	};
}
//#endregion
export { ConversationBindingModel, ConversationEventRegistry, ConversationNodeAssembler, ConversationViewRegistry, inspectRequestPrompt, inspectSystemPrompt };
