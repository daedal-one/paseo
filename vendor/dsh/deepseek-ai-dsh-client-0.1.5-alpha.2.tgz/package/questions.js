//#region lib/types/client/pending-question.js
function settlePendingComposer(settle, failureMessage) {
	try {
		settle();
		return Promise.resolve();
	} catch (error) {
		return Promise.reject(error instanceof Error ? error : new Error(failureMessage, { cause: error }));
	}
}
/**
* Narrow a request to a renderable plan review, or return undefined to leave it
* to the generic question flow.
*
* The card is one decision over one plan, and it claims a request only when it
* can send every answer that request allows — an intent changes the layout,
* never which answers are reachable. So the batch must be a single question
* that declares the intent, carries the plan as its detail, offers the approve
* label the intent names, and is a binary single choice: at most one option
* besides approve, and not multi-select. A third option or a multi-select batch
* has answers two buttons cannot express, so the generic flow keeps it — as it
* keeps any request whose intent the asker's own service would have rejected,
* because the client sits downstream of a wire boundary and every request must
* stay answerable.
*
* @param questions - the request's whole question batch.
* @returns The narrowed review, or undefined when the generic flow owns it.
*/
function planReviewOf(questions) {
	if (questions.length !== 1) return void 0;
	const question = questions[0];
	const intent = question.intent;
	if (intent?.kind !== "plan-review" || question.detail === void 0) return void 0;
	if (question.multiSelect === true) return void 0;
	const options = question.options ?? [];
	if (options.length > 2) return void 0;
	const approve = options.find((option) => option.label === intent.approve);
	if (approve === void 0) return void 0;
	const decline = options.find((option) => option.label !== intent.approve);
	return {
		id: question.id,
		question: question.question,
		plan: question.detail,
		approve,
		...decline === void 0 ? {} : { decline }
	};
}
let nextQuestionKey = 0;
/** Create a wire-preserved user-question rejection. */
function questionError(message, code) {
	const error = new Error(message);
	error.name = "UserQuestionError";
	error.code = code;
	return error;
}
/** One answerable Client presentation of a pending Host waterfall. */
var PendingQuestion = class {
	sessionId;
	/** Presentation discriminator used by Session pending-interaction consumers. */
	kind;
	/** Opaque render identity and request key for the Session-scoped draft store. */
	key;
	/** The request's question list. */
	questions;
	/** Result returned by the Remote Event listener to the Host waterfall. */
	result;
	#resolve;
	#reject;
	#signal;
	#onAbort;
	#delegated = Symbol("pending question delegated");
	#settled = false;
	/**
	* @param sessionId - Agent/Session identity owning the scoped request.
	* @param questions - complete question batch.
	* @param signal - Host request and delivery lifetime.
	*/
	constructor(sessionId, questions, signal) {
		this.sessionId = sessionId;
		nextQuestionKey += 1;
		this.key = `question:${String(nextQuestionKey)}`;
		this.questions = questions;
		this.kind = planReviewOf(questions) === void 0 ? "question" : "plan-review";
		const completion = Promise.withResolvers();
		this.result = completion.promise;
		this.#resolve = completion.resolve;
		this.#reject = completion.reject;
		this.#signal = signal;
		if (signal === void 0) {
			this.#onAbort = void 0;
			return;
		}
		const onAbort = () => {
			this.abort(questionError("ask_user_question was aborted before the user answered", "ASK_ABORTED"));
		};
		this.#onAbort = onAbort;
		signal.addEventListener("abort", onAbort, { once: true });
		if (signal.aborted) onAbort();
	}
	/**
	* Resolve the Host waterfall with the whole answer batch.
	* @param answer - complete structured answer batch.
	* @returns completion, or a rejection if the request is already settled.
	*/
	answer(answer) {
		return settlePendingComposer(() => {
			this.finish(() => {
				this.#resolve(answer);
			});
		}, "pending question settlement failed");
	}
	/** Delegate an unanswered request to the next waterfall listener. */
	delegate() {
		if (this.#settled) return;
		this.finish(() => {
			this.#reject(this.#delegated);
		});
	}
	/**
	* Test whether a rejection requests waterfall delegation.
	* @param reason - rejection received from {@link PendingQuestion.result}.
	* @returns whether {@link PendingQuestion.delegate} produced it.
	*/
	isDelegation(reason) {
		return reason === this.#delegated;
	}
	/**
	* Reject the Host waterfall because the user closed the question.
	* @returns completion, or a rejection if the request is already settled.
	*/
	cancel() {
		return settlePendingComposer(() => {
			this.finish(() => {
				this.#reject(questionError("the user cancelled ask_user_question", "ASK_CANCELLED"));
			});
		}, "pending question cancellation failed");
	}
	/**
	* End an unanswered presentation when its transport, scope, or plugin lifetime ends.
	* @param reason - rejection exposed to the waiting Remote Event listener.
	*/
	abort(reason) {
		if (this.#settled) return;
		this.finish(() => {
			this.#reject(reason);
		});
	}
	finish(settle) {
		if (this.#settled) throw new Error(`pending question ${this.key} is already settled`);
		this.#settled = true;
		if (this.#signal !== void 0 && this.#onAbort !== void 0) this.#signal.removeEventListener("abort", this.#onAbort);
		settle();
	}
};
//#endregion
//#region lib/types/client/requests.js
/** Present one request until the user answers, cancels, or its lifetime ends. */
async function answerQuestion(sessions, owner, request, next, registerPendingInteraction) {
	const sessionId = sessions.scopeOf(owner);
	if (sessionId === void 0) return next();
	const pending = new PendingQuestion(sessionId, request.questions, request.signal);
	const completed = Promise.withResolvers();
	let remove;
	try {
		remove = registerPendingInteraction(pending, async () => {
			pending.delegate();
			await completed.promise;
		});
	} catch (error) {
		pending.abort(error);
		await Promise.allSettled([pending.result]);
		completed.resolve(void 0);
		throw error;
	}
	try {
		try {
			return await pending.result;
		} catch (error) {
			if (pending.isDelegation(error)) return await next();
			throw error;
		}
	} finally {
		remove();
		completed.resolve(void 0);
	}
}
/**
* Register question delivery and its pending domain in the same caller-owned fiber.
* The Remote service and domain registrar must belong to that fiber; its teardown
* withdraws requests and waits for delegation before completing.
* @param remote - Caller-scoped generated Remote service.
* @param sessions - Session owner that resolves each delivered request's Context.
* @param registerPendingInteraction - Caller-owned domain registration.
*/
function registerQuestionRequests(remote, sessions, registerPendingInteraction) {
	const publish = registerPendingInteraction((pending) => pending.kind === "plan-review" ? 2 : 1);
	remote.$on("user-questions/request", function(request, next) {
		return answerQuestion(sessions, this, request, next, publish);
	});
}
//#endregion
export { PendingQuestion, planReviewOf, registerQuestionRequests };
