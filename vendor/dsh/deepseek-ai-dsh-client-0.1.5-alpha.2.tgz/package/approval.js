//#region lib/types/client/pending-approval.js
function settlePendingComposer(settle, failureMessage) {
	try {
		settle();
		return Promise.resolve();
	} catch (error) {
		return Promise.reject(error instanceof Error ? error : new Error(failureMessage, { cause: error }));
	}
}
let nextApprovalKey = 0;
/** One answerable Client presentation of a pending Host waterfall. */
var PendingApproval = class {
	sessionId;
	/** Domain discriminator used by Session pending-interaction consumers. */
	kind;
	/** Opaque render identity and one-shot remount axis. */
	key;
	/** Tool requesting the decision. */
	toolName;
	/** Correlated Tool call, when supplied by the asker. */
	callId;
	/** Human-readable reason supplied by the asker. */
	reason;
	/** Result returned by the Remote Event listener to the Host waterfall. */
	result;
	#resolve;
	#reject;
	#signal;
	#onAbort;
	#delegated = Symbol("pending approval delegated");
	#settled = false;
	/**
	* @param sessionId - Agent/Session identity owning the scoped request.
	* @param request - Host approval request projected through the Remote Event.
	*/
	constructor(sessionId, request) {
		this.sessionId = sessionId;
		this.kind = "approval";
		nextApprovalKey += 1;
		this.key = `approval:${String(nextApprovalKey)}`;
		this.toolName = request.toolName;
		this.callId = request.callId;
		this.reason = request.reason;
		const completion = Promise.withResolvers();
		this.result = completion.promise;
		this.#resolve = completion.resolve;
		this.#reject = completion.reject;
		this.#signal = request.signal;
		if (request.signal === void 0) {
			this.#onAbort = void 0;
			return;
		}
		const onAbort = () => {
			this.abort(request.signal?.reason ?? /* @__PURE__ */ new Error("approval request was aborted"));
		};
		this.#onAbort = onAbort;
		request.signal.addEventListener("abort", onAbort, { once: true });
		if (request.signal.aborted) onAbort();
	}
	/**
	* Resolve the Host waterfall with the user's decision.
	* @param outcome - supported interactive decision.
	* @returns completion, or a rejection if the request is already settled.
	*/
	answer(outcome) {
		return settlePendingComposer(() => {
			this.finish(() => {
				this.#resolve(outcome);
			});
		}, "pending approval settlement failed");
	}
	/** Delegate an unanswered request to the next waterfall listener. */
	delegate() {
		if (this.#settled) return;
		this.finish(() => {
			this.#reject(this.#delegated);
		});
	}
	/**
	* Test whether a rejection requests waterfall delegation.
	* @param reason - rejection received from {@link PendingApproval.result}.
	* @returns whether {@link PendingApproval.delegate} produced it.
	*/
	isDelegation(reason) {
		return reason === this.#delegated;
	}
	/**
	* End an unanswered presentation when its transport, scope, or plugin lifetime ends.
	* @param reason - rejection exposed to the waiting Remote Event listener.
	*/
	abort(reason) {
		if (this.#settled) return;
		this.finish(() => {
			this.#reject(reason);
		});
	}
	finish(settle) {
		if (this.#settled) throw new Error(`pending approval ${this.key} is already settled`);
		this.#settled = true;
		if (this.#signal !== void 0 && this.#onAbort !== void 0) this.#signal.removeEventListener("abort", this.#onAbort);
		settle();
	}
};
//#endregion
//#region lib/types/client/requests.js
/** Present one request until the user answers or its lifetime ends. */
async function answerApproval(sessions, owner, request, next, registerPendingInteraction) {
	const sessionId = sessions.scopeOf(owner);
	if (sessionId === void 0) return next();
	const pending = new PendingApproval(sessionId, {
		toolName: request.toolName,
		...request.callId === void 0 ? {} : { callId: request.callId },
		...request.reason === void 0 ? {} : { reason: request.reason },
		...request.signal === void 0 ? {} : { signal: request.signal }
	});
	const completed = Promise.withResolvers();
	let remove;
	try {
		remove = registerPendingInteraction(pending, async () => {
			pending.delegate();
			await completed.promise;
		});
	} catch (error) {
		pending.abort(error);
		await Promise.allSettled([pending.result]);
		completed.resolve(void 0);
		throw error;
	}
	try {
		try {
			return await pending.result;
		} catch (error) {
			if (pending.isDelegation(error)) return await next();
			throw error;
		}
	} finally {
		remove();
		completed.resolve(void 0);
	}
}
/**
* Register approval delivery and its pending domain in the same caller-owned fiber.
* The Remote service and domain registrar must belong to that fiber; its teardown
* withdraws requests and waits for delegation before completing.
* @param remote - Caller-scoped generated Remote service.
* @param sessions - Session owner that resolves each delivered request's Context.
* @param registerPendingInteraction - Caller-owned domain registration.
*/
function registerApprovalRequests(remote, sessions, registerPendingInteraction) {
	const publish = registerPendingInteraction(() => 0);
	remote.$on("approval/request", function(request, next) {
		return answerApproval(sessions, this, request, next, publish);
	});
}
//#endregion
export { PendingApproval, registerApprovalRequests };
