/** Durable workspace outcomes shared by host and client projections. @module */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { Message } from "../../../../llm/llm/lib/types/types.js";
import type { EnvironmentId } from "./environment-types.js";
import type { SessionId, SessionSeq } from "../../../../core/session/lib/types/types.js";
/** Stable identity of one repository return receipt. */
export type WorkspaceProvenanceId = Branded<'WorkspaceProvenanceId'>;
/** Immutable host receipt; observed history does not assert conversation authorship. */
export interface WorkspaceProvenance {
    version: 1;
    id: WorkspaceProvenanceId;
    workspaceId: ConversationWorkspaceId;
    sessionId: SessionId;
    turn: number;
    /** Inclusive owner-conversation event interval through the completed turn. */
    eventRange: [SessionSeq, SessionSeq];
    repository: string;
    baseline: string;
    createdAt: string;
    refs: Array<{
        source: string;
        branch: string;
        commit: string;
        topic: string;
    }>;
    /** Commits reachable from returned tips but not the imported baseline, plus the tips themselves. */
    observedCommits: string[];
    /** Only commits created by this Harness finalization transaction. */
    createdCommits: string[];
}
/** Host-generated identity for one conversation repository. */
export type ConversationWorkspaceId = Branded<'ConversationWorkspaceId'>;
/** Identity of one turn's workspace admission request. */
export type WorkspaceAdmissionId = Branded<'WorkspaceAdmissionId'>;
/** Durable identity of one explicitly triggered save attempt. */
export type WorkspaceSaveAttemptId = Branded<'WorkspaceSaveAttemptId'>;
/** Save operations whose failure can require independent recovery. */
export type WorkspaceSaveStage = 'persistence' | 'writers' | 'capture' | 'commit' | 'return' | 'metadata' | 'cleanup';
/** Safe diagnostics never include raw subprocess output or credentials. */
export interface WorkspaceSaveDiagnostic {
    stage: WorkspaceSaveStage;
    quiescent: boolean;
    repository?: string;
    causes: Array<{
        code: string;
        message: string;
        fingerprint?: string;
    }>;
}
/** Durable execution waiting state, independent of conversation creation. */
export interface WorkspaceAdmissionState {
    id: WorkspaceAdmissionId;
    status: 'waiting' | 'admitted' | 'cancelled' | 'failed';
    error?: string;
}
/** Independently recorded synchronization outcome; model completion remains in turn/end. */
export interface WorkspaceState {
    workspaceId: ConversationWorkspaceId;
    turn: number;
    /** Pending is a legacy recovery-required outcome; neither pending nor failed authorizes automatic retry. */
    phase: 'ready' | 'saving' | 'cancelling' | 'cancelled' | 'returned' | 'checkpointed' | 'pending' | 'failed';
    attemptId?: WorkspaceSaveAttemptId;
    diagnostic?: WorkspaceSaveDiagnostic;
    baseline: string;
    checkpoint: number;
    checkpointHash: string;
    branches: Record<string, string>;
    error?: string;
    /** Environment scope for workspaces using independently owned grants. */
    environmentId?: EnvironmentId;
    /** Individual repository outcomes; Git return across these repositories is not atomic. */
    repositories?: Array<{
        remote: string;
        path: string;
        baseline: string;
        lastTurn: number;
        branches: Record<string, string>;
    }>;
}
declare module "../../../../core/session/lib/types/types.js" {
    interface SessionEventMap {
        /** Execution capacity admission; never inserts model messages. */
        'workspace/admission': WorkspaceAdmissionState;
        /** Workspace identity and synchronization facts; never inserts agent messages. */
        'workspace/state': WorkspaceState;
        /** Exact bounded auxiliary request recorded before dispatch. */
        'workspace/commit-message-request': {
            turn: number;
            system: string;
            messages: Message[];
            provider: string;
            model: string;
            maxTokens: number;
        };
        /** Exact bounded naming input recorded before the auxiliary request. */
        'workspace/branch-name-request': {
            turn: number;
            system: string;
            messages: Message[];
            provider: string;
            model: string;
            maxTokens: number;
        };
        /** Host-persisted repository return metadata, independent of mutable branch names. */
        'workspace/provenance': WorkspaceProvenance;
    }
}
