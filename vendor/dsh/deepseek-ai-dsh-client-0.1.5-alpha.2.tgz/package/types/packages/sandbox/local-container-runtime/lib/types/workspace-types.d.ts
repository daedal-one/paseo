/** Durable workspace outcomes shared by host and client projections. @module */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { Message } from "../../../../llm/llm/lib/types/types.js";
/** Host-generated identity for one conversation repository. */
export type ConversationWorkspaceId = Branded<'ConversationWorkspaceId'>;
/** Independently recorded synchronization outcome; model completion remains in turn/end. */
export interface WorkspaceState {
    workspaceId: ConversationWorkspaceId;
    turn: number;
    phase: 'ready' | 'saving' | 'returned' | 'checkpointed' | 'pending';
    baseline: string;
    checkpoint: number;
    checkpointHash: string;
    branches: Record<string, string>;
    error?: string;
}
declare module "../../../../core/session/lib/types/types.js" {
    interface SessionEventMap {
        /** Workspace identity and synchronization facts; never inserts agent messages. */
        'workspace/state': WorkspaceState;
        /** Exact bounded auxiliary request recorded before dispatch. */
        'workspace/commit-message-request': {
            turn: number;
            system: string;
            messages: Message[];
            provider: string;
            model: string;
            maxTokens: number;
        };
    }
}
