import type { Branded } from '@deepseek-ai/dsh-brand';
/** Stable memory identifier shared by providers and Consumers. */
export type MemoryId = Branded<'MemoryId'>;
/**
 * Construct a memory identifier at a validated persistence or creation boundary.
 * @param value - validated opaque identifier text.
 * @returns the branded memory identifier.
 */
export declare const MemoryId: (value: string) => MemoryId;
/** An explicit isolation domain for one memory operation. */
export type MemoryScope = {
    readonly kind: 'project';
    readonly project: string;
} | {
    readonly kind: 'global';
};
/** Evidence supporting or challenging a durable memory. */
export interface MemoryEvidence {
    readonly kind: 'session' | 'file' | 'url' | 'user' | 'agent' | 'tool' | 'outcome';
    readonly ref: string;
    readonly excerpt?: string;
    readonly source?: MemorySourceRef;
}
/** Exact source identity and monotonically increasing owner revision. */
export interface MemorySourceRef {
    readonly owner: string;
    readonly ref: string;
    readonly revision: number;
}
/** Explicit prerequisites and limits retained beside reusable evidence. */
export interface MemoryApplicability {
    readonly conditions: readonly string[];
    readonly failureLimits: readonly string[];
}
/** Source-owner lease; revocation, retraction and revision changes refuse the callback. */
export interface MemorySourceAuthority {
    readonly owner: string;
    /**
     * Hold current source access and revision stable while the operation settles.
     * @param scope - exact memory isolation domain.
     * @param source - owner reference and expected revision.
     * @param consume - operation admitted only while current access holds.
     * @returns the operation result; throws MemoryError MEMORY_SOURCE_UNAVAILABLE on refusal.
     */
    withCurrent<T>(scope: MemoryScope, source: MemorySourceRef, consume: () => Promise<T>): Promise<T>;
    /**
     * Authorize a correction or inspection of a historical source revision.
     * Current access must hold through return; source freshness is not required.
     * @param scope - Exact memory isolation domain.
     * @param source - Source whose history the caller may inspect or correct.
     * @param consume - Operation admitted under current source access.
     * @returns The authorized operation result, or an access refusal.
     */
    withAccess<T>(scope: MemoryScope, source: MemorySourceRef, consume: () => Promise<T>): Promise<T>;
}
/** Atomic idempotent proposal from one exact source revision. */
export interface MemorySourceProposal {
    readonly source: MemorySourceRef;
    readonly proposal: MemoryProposal;
}
/** Durable retry result; an absent record records erasure or retention. */
export type MemorySourceProposalResult = {
    readonly kind: 'proposed';
    readonly record: MemoryRecord;
} | {
    readonly kind: 'already-processed';
    readonly record?: MemoryRecord;
};
/** Durable consolidation retry checkpoint; gaps are not accepted memory. */
export interface MemorySourceState {
    readonly source: MemorySourceRef;
    readonly memoryId?: MemoryId;
    readonly gap?: string;
}
/** Source-bound failure retained until a successful proposal replaces it. */
export interface MemorySourceGap {
    readonly scope: MemoryScope;
    readonly source: MemorySourceRef;
    readonly reason: string;
}
/** Confidence and provenance assigned to one memory revision. */
export interface MemoryTrust {
    readonly score: number;
    readonly source: 'extracted' | 'agent' | 'user' | 'reviewer';
}
/** Optional interval during which the statement is expected to hold. */
export interface MemoryValidity {
    readonly validFrom?: number;
    readonly validUntil?: number;
}
/** Review lifecycle of a durable memory. */
export type MemoryStatus = 'proposed' | 'active' | 'challenged' | 'rejected' | 'superseded';
/** Complete durable memory record. */
export interface MemoryRecord {
    readonly id: MemoryId;
    readonly revision: number;
    readonly scope: MemoryScope;
    readonly statement: string;
    readonly applicability?: MemoryApplicability;
    readonly status: MemoryStatus;
    readonly evidence: readonly MemoryEvidence[];
    readonly trust: MemoryTrust;
    readonly validity: MemoryValidity;
    readonly contradicts: readonly MemoryId[];
    readonly challenge?: {
        readonly reason: string;
        readonly evidence: readonly MemoryEvidence[];
    };
    readonly supersededBy?: MemoryId;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly lastAccessedAt: number;
    readonly accessCount: number;
}
/** Compare-and-set reference used for review mutations. */
export interface MemoryRef {
    readonly scope: MemoryScope;
    readonly id: MemoryId;
    readonly revision: number;
}
/** New unreviewed statement. */
export interface MemoryProposal {
    readonly scope: MemoryScope;
    readonly statement: string;
    readonly applicability?: MemoryApplicability;
    readonly evidence: readonly MemoryEvidence[];
    readonly trust: MemoryTrust;
    readonly validity?: MemoryValidity;
    readonly contradicts?: readonly MemoryId[];
}
/** Scope-bounded full-text lookup. */
export interface MemoryQuery {
    readonly scope: MemoryScope;
    readonly text: string;
    readonly statuses?: readonly MemoryStatus[];
    readonly limit?: number;
    readonly at?: number;
}
/** One query response, including provider-side truncation. */
export interface MemoryQueryResult {
    readonly memories: readonly MemoryRecord[];
    readonly truncated: boolean;
}
/** Challenge one exact memory revision. */
export interface MemoryChallenge {
    readonly ref: MemoryRef;
    readonly reason: string;
    readonly evidence?: readonly MemoryEvidence[];
}
/** Reviewer decision over one exact revision. */
export interface MemoryReview {
    readonly ref: MemoryRef;
    readonly decision: 'accept' | 'reject';
    readonly trust?: MemoryTrust;
}
/** Atomically replace one memory with a reviewed successor. */
export interface MemorySupersession {
    readonly ref: MemoryRef;
    readonly replacement: MemoryProposal;
}
/** Record access to exact scope-bound memory revisions. */
export interface MemoryCheckpoint {
    readonly refs: readonly MemoryRef[];
}
/** Bounded admission lease; expiry cannot undo an already dispatched external effect. */
export interface MemoryCurrentLease {
    readonly expiresAt: number;
    /** Refuse expired, corrected or released revisions immediately before bounded admission. */
    assertCurrent(): void;
}
/** Storage implementation behind the memory Service Definition. */
export interface MemoryProvider {
    readonly id: string;
    /**
     * Hold one active valid revision stable during bounded admission; unsupported providers refuse at the runtime.
     * @param ref - Exact active reviewed revision and scope.
     * @param consume - Bounded admission callback that asserts freshness before dispatch.
     * @returns Callback result after final validation; expiry cannot undo dispatched effects.
     */
    withCurrent?<T>(ref: MemoryRef, consume: (record: MemoryRecord, lease: MemoryCurrentLease) => Promise<T>): Promise<T>;
    query(request: MemoryQuery): Promise<MemoryQueryResult>;
    get(scope: MemoryScope, id: MemoryId): Promise<MemoryRecord | undefined>;
    propose(request: MemoryProposal): Promise<MemoryRecord>;
    proposeFromSource(request: MemorySourceProposal): Promise<MemorySourceProposalResult>;
    recordSourceGap(request: MemorySourceGap): Promise<void>;
    sourceState(scope: MemoryScope, source: MemorySourceRef): Promise<MemorySourceState | undefined>;
    challenge(request: MemoryChallenge): Promise<MemoryRecord>;
    review(request: MemoryReview): Promise<MemoryRecord>;
    supersede(request: MemorySupersession): Promise<{
        readonly previous: MemoryRecord;
        readonly replacement: MemoryRecord;
    }>;
    checkpoint(request: MemoryCheckpoint): Promise<readonly MemoryRecord[]>;
    delete(ref: MemoryRef): Promise<boolean>;
}
/** Stable provider-neutral memory failure. */
export declare class MemoryError extends Error {
    readonly code: string;
    constructor(message: string, code: string);
}
