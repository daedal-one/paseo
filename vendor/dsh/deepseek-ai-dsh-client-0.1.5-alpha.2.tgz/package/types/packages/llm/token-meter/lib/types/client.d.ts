/**
 * Client-namespace projection of token-meter's browser-safe contracts and folds.
 *
 * @module @deepseek-ai/dsh-token-meter/client
 */
export type * from "./projection.js";
export { deriveTurnTokenUsage } from "./turn-usage.js";
export type { TurnTokenUsage, TurnTokenUsageRoute } from "./turn-usage.js";
