/**
 * The OpenRouter network boundary: one JSON endpoint read with failure
 * mapping, plus the public catalog read both the spend report and model
 * routing consume. Every exported failure keeps the credential out of
 * `detail`.
 *
 * @module @deepseek-ai/dsh-openrouter-catalog/read
 */
import type { OpenRouterModelCatalogEntry, OpenRouterParseResult, OpenRouterReadOptions, OpenRouterReadResult } from "./types.js";
/** Result of one OpenRouter `GET /models` read. */
export type OpenRouterModelsReadResult = OpenRouterReadResult<readonly OpenRouterModelCatalogEntry[]>;
/**
 * Append one path segment to the endpoint base.
 * @param baseURL - the configured base, with any trailing slash removed.
 * @param segment - the path segment to append.
 * @returns the full endpoint URL.
 */
export declare function endpointOf(baseURL: string, segment: string): string;
/**
 * Read one JSON endpoint of OpenRouter and run its parser.
 * @param endpoint - full URL to fetch.
 * @param options - the endpoint base, key, and request bound.
 * @param signal - caller cancellation for the request.
 * @param parser - the pure body parser for this endpoint.
 * @param apiKey - optional inference credential, sent only to an authenticated endpoint.
 * @returns the parsed value, or the mapped failure.
 */
export declare function readEndpoint<T>(endpoint: string, options: Pick<OpenRouterReadOptions, 'requestTimeoutMs'>, signal: AbortSignal, parser: (payload: unknown) => OpenRouterParseResult<T>, apiKey?: string): Promise<OpenRouterReadResult<T>>;
/**
 * Read the public model catalog from `GET {baseURL}/models`.
 * @param options - the endpoint base and request bound for the public catalog read.
 * @param signal - caller cancellation for the request.
 * @returns the parsed catalog, or the mapped failure.
 */
export declare function readModels(options: Pick<OpenRouterReadOptions, 'baseURL' | 'requestTimeoutMs'>, signal: AbortSignal): Promise<OpenRouterModelsReadResult>;
