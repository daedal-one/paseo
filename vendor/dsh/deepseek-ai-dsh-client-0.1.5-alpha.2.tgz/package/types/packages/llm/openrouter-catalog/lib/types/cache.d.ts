/**
 * Bounded TTL cache with in-flight de-duplication for one asynchronous load.
 * @module @deepseek-ai/dsh-openrouter-catalog/cache
 */
/** One value and the time its successful fetch completed. */
export interface CachedValue<T> {
    /** Loaded value. */
    readonly value: T;
    /** Epoch milliseconds at which the load completed. */
    readonly fetchedAt: number;
}
/**
 * One cached value and the in-flight load that fetched it.
 * `read` returns the cached value while it is fresh; a fresh cache and a
 * running load are distinct states, so both are kept.
 */
export declare class TtlCache<T> {
    private readonly ttlMs;
    private slot;
    private inflight;
    private generation;
    /**
     * @param ttlMs - lifetime of one cached reading in milliseconds; must be a non-negative finite number.
     * @throws {RangeError} when the TTL is not a non-negative finite number (misconfiguration fails loud).
     */
    constructor(ttlMs: number);
    /**
     * Invalidate a value and prevent an older in-flight load from repopulating it.
     */
    clear(): void;
    /**
     * Return the fresh cached value, or load one. Concurrent callers sharing a
     * stale or absent cache share the single in-flight load; non-cacheable values
     * and rejected loads leave no slot so the next read retries immediately.
     * @param load - the operation that fetches a fresh value when the cache is stale or empty.
     * @param cacheable - decides whether a successfully loaded value may occupy the cache.
     * @returns the fresh or just-fetched value with its actual fetch time.
     */
    read(load: () => Promise<T>, cacheable?: (value: T) => boolean): Promise<CachedValue<T>>;
}
