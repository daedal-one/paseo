/**
 * Pure parsing of OpenRouter's public `GET /models` reply body, and the one
 * conversion from its raw price strings to usable numbers. No network, no
 * timers: every export is a synchronous function over `unknown` or over
 * already-parsed entries.
 *
 * @module @deepseek-ai/dsh-openrouter-catalog/parse
 */
import type { OpenRouterModelCatalogEntry, OpenRouterModelPricing, OpenRouterParseResult } from "./types.js";
/**
 * Parse one OpenRouter `GET /models` reply body.
 * Elements without a usable string id are skipped — they cannot be addressed
 * by model id — and are not a failure.
 * @param payload - the parsed JSON reply body.
 * @returns the addressable catalog entries, or a detail naming the envelope problem.
 */
export declare function parseModelsReply(payload: unknown): OpenRouterParseResult<readonly OpenRouterModelCatalogEntry[]>;
/**
 * Look up one model's pricing by exact id.
 * @param models - parsed catalog entries.
 * @param modelId - exact OpenRouter model id to match.
 * @returns the entry's pricing, or undefined when no entry has that id.
 */
export declare function findModelPricing(models: readonly OpenRouterModelCatalogEntry[], modelId: string): OpenRouterModelPricing | undefined;
/**
 * Parse one OpenRouter catalog price string into a usable per-token USD value.
 * A value of `-1` is OpenRouter's pass-through marker: any blank, negative,
 * non-finite, or non-numeric price is unpriceable, never a real number.
 * @param raw - the raw catalog price string, or null when the slot is absent.
 * @returns the finite non-negative per-token USD value, or null when unpriceable.
 */
export declare function usdPerToken(raw: string | null): number | null;
