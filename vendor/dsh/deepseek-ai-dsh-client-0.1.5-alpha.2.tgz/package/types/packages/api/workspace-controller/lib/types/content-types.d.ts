/** Portable Workspace source-file and reviewed-memory requests. */
import type { MemoryId, MemoryRecord, MemoryStatus } from "../../../../memory/memory/lib/types/types.js";
/** A child of the registered Host source directory. Symlinks are not followed. */
export interface WorkspaceContentEntry {
    readonly name: string;
    readonly type: 'file' | 'directory' | 'symlink' | 'other';
}
/** Bounded directory children; paths are relative to the registered Workspace. */
export interface WorkspaceContentListing {
    readonly path: string;
    readonly entries: readonly WorkspaceContentEntry[];
    readonly truncated: boolean;
}
/** Bounded UTF-8 preview of a registered Workspace source file. */
export interface WorkspaceContentFile {
    readonly path: string;
    readonly version: string;
    readonly bytes: number;
    readonly text: string;
    readonly truncated: boolean;
}
/** A bounded query within one Workspace's project memory. */
export interface WorkspaceMemoryQuery {
    readonly text: string;
    readonly statuses?: readonly MemoryStatus[];
}
/** Human decision over an exact pending or challenged memory revision. */
export interface WorkspaceMemoryReview {
    readonly id: MemoryId;
    readonly revision: number;
    readonly decision: 'accept' | 'reject';
}
/** Human correction over an exact active or challenged memory revision. */
export interface WorkspaceMemoryCorrection {
    readonly id: MemoryId;
    readonly revision: number;
    readonly statement: string;
}
/** Historical record and its reviewed successor committed atomically. */
export interface WorkspaceMemoryCorrected {
    readonly previous: MemoryRecord;
    readonly replacement: MemoryRecord;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        /** A path escapes the registered directory or crosses a symbolic link. */
        'workspace-content/invalid-path': {
            readonly path: string;
        };
        /** The path is absent, unreadable, or not the requested regular kind. */
        'workspace-content/unavailable': {
            readonly path: string;
        };
        /** The file is binary or is not valid UTF-8. */
        'workspace-content/not-text': {
            readonly path: string;
        };
        /** A file changed while the preview was being read. */
        'workspace-content/changed': {
            readonly path: string;
        };
        /** The Memory owner refused a scoped operation; its stable code is retained. */
        'workspace-memory/refused': {
            readonly code: string;
        };
    }
}
