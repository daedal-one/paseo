/** Public Workspace Work views; execution and acceptance remain with their domain owners. */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { SessionId } from "../../../../core/session/lib/types/types.js";
import type { WorkspaceId } from "../../../../workspace/workspace/lib/types/types.js";
/** Durable Work identity, shared with the authoritative Work owner. */
export type WorkspaceWorkId = Branded<'WorkTaskId'>;
/** Explicit local project identity. */
export type WorkspaceWorkProjectId = Branded<'WorkProjectId'>;
/** Common navigation data; no execution or acceptance authority is conveyed. */
export interface WorkspaceWorkSummary {
    readonly id: WorkspaceWorkId;
    readonly project: WorkspaceWorkProjectId;
    readonly revision: number;
    readonly title: string;
    readonly sessions: readonly SessionId[];
    readonly contributors: readonly Branded<'WorkPrincipalId'>[];
}
/** Ordinary durable brief and its attributed Sessions. */
export interface WorkspaceTrackingWorkItem extends WorkspaceWorkSummary {
    readonly basis: 'tracking';
    readonly status: 'open' | 'completed' | 'cancelled';
    readonly brief: string;
    readonly briefRevision: number;
    readonly createdAt: string;
    readonly updatedAt: string;
    readonly executionLinks: readonly {
        sessionId: SessionId;
        briefRevision: number;
        brief: string;
        linkedAt: string;
    }[];
}
/** Read-only navigation projection of protected qualified work. */
export interface WorkspaceQualifiedWorkItem extends WorkspaceWorkSummary {
    readonly basis: 'qualified';
    readonly status: 'open' | 'accepted' | 'cancelled';
}
/** Tracking completion and qualified acceptance are different decisions. */
export type WorkspaceWorkItem = WorkspaceTrackingWorkItem | WorkspaceQualifiedWorkItem;
/** Public work view consumed by the shared Workspace UI. */
export type WorkItem = WorkspaceWorkItem;
/** Explicit Workspace association; directory equality alone never creates one. */
export interface WorkspaceWorkBinding {
    readonly workspaceId: WorkspaceId;
    readonly projectId: WorkspaceWorkProjectId;
    readonly path: string;
    readonly revision: number;
}
/** Public association projection. */
export type WorkWorkspaceBinding = WorkspaceWorkBinding;
/** Explicit registration of a local Work project, or adoption by its exact identity. */
export type WorkspaceWorkInitializeRequest = {
    workspaceId: WorkspaceId;
    requestId: string;
    projectId: WorkspaceWorkProjectId;
    title: string;
};
/** Bounded page; the cursor is the last Task identity from the prior page. */
export type WorkspaceWorkListRequest = {
    workspaceId: WorkspaceId;
    after: string | null;
    limit: number;
};
/** Consistent bounded Work read and activity watermark; the overall Workspace is not globally atomic. */
export type WorkspaceWorkPage = {
    binding: WorkspaceWorkBinding | null;
    /** Read-only suggestion for explicit adoption; never an inferred binding. */
    adoptionCandidate: {
        id: WorkspaceWorkProjectId;
        title: string;
    } | null;
    items: readonly WorkspaceWorkItem[];
    nextCursor: string | null;
    watermark: number;
};
/** One work record in its registered Workspace. */
export type WorkspaceWorkGetRequest = {
    workspaceId: WorkspaceId;
    id: WorkspaceWorkId;
};
/** Stable client-selected identities reconcile responses lost after creation. */
export type WorkspaceWorkCreateRequest = WorkspaceWorkGetRequest & {
    requestId: string;
    title: string;
    brief: string;
};
/** Exact revision required to change the current brief. */
export type WorkspaceWorkUpdateRequest = WorkspaceWorkCreateRequest & {
    expectedRevision: number;
};
/** Completion is a human tracking decision and never protected acceptance. */
export type WorkspaceWorkStatusRequest = WorkspaceWorkGetRequest & {
    requestId: string;
    expectedRevision: number;
    status: 'open' | 'completed' | 'cancelled';
};
/** Attribute an existing member Session to the exact current work brief. */
export type WorkspaceWorkAttachRequest = WorkspaceWorkGetRequest & {
    requestId: string;
    expectedRevision: number;
    sessionId: SessionId;
};
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface RemoteErrorDetailsMap {
        /** The Work transaction did not commit; the caller can revise its request. */
        'workspace-work/rejected': {
            readonly reason: string;
        };
        /** The transaction outcome requires reconciliation using the identical request identity. */
        'workspace-work/unknown': {
            readonly requestId: string | null;
        };
    }
}
