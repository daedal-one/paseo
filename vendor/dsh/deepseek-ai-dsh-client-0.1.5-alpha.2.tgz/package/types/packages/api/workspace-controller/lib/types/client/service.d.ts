/** React-free Client Workspace service and command facade. */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { SessionId } from "../../../../../core/session/lib/types/types.js";
import type { RemoteFailure } from '@deepseek-ai/dsh-typert-protocol';
import type { WorkspaceId } from "../../../../../workspace/workspace/lib/types/types.js";
import type { WorkspaceResolveRequest, WorkspaceView } from "../types.js";
import type { ClientWorkspaceModel, WorkspaceSnapshot } from "./model.js";
/**
 * Structured create failure. `workspace/create-rejected` confirms that this
 * request began no registration write; other codes do not prove that outcome.
 */
export declare class WorkspaceCreateError extends Error {
    readonly rpcError: RemoteFailure;
    readonly name = "WorkspaceCreateError";
    /** @param rpcError - Host business or folded carrier failure. */
    constructor(rpcError: RemoteFailure);
}
/** Structured read failure; callers must not interpret it as an absent registration. */
export declare class WorkspaceResolveError extends Error {
    readonly rpcError: RemoteFailure;
    readonly name = "WorkspaceResolveError";
    /** @param rpcError - Host lookup or folded carrier failure. */
    constructor(rpcError: RemoteFailure);
}
/** Bare observable source for the Workspace Controller snapshot. */
export interface WorkspaceSource {
    /** Read the identity-stable current snapshot. */
    getSnapshot(): WorkspaceSnapshot;
    /**
     * Subscribe to snapshot changes.
     * @param listener - invalidation callback.
     * @returns unsubscribe function.
     */
    subscribe(listener: () => void): () => void;
}
/** Workspace Controller's Client service face. */
export interface IWorkspaces {
    /** Host-authoritative Workspace rows, order, archive set, and follow lifecycle. */
    readonly list: WorkspaceSource;
    /**
     * Register an existing path as a Workspace.
     * @param input - Host create payload.
     * @returns the created or idempotently resolved Workspace.
     */
    create(input: {
        path: string;
    }): Promise<WorkspaceView>;
    /**
     * Read the current registration at a Host path without registering it.
     * @param input - fully qualified Host path; only the Host canonicalizes it.
     * @param signal - caller-owned cancellation.
     * @returns the current Workspace or null; neither result is a prior request receipt.
     */
    resolveByPath(input: WorkspaceResolveRequest, signal?: AbortSignal): Promise<WorkspaceView | null>;
    /**
     * Rename a Workspace.
     * @param workspaceId - target Workspace.
     * @param title - new display title.
     * @returns the renamed Workspace.
     */
    rename(workspaceId: WorkspaceId, title: string): Promise<WorkspaceView>;
    /**
     * Delete a Workspace registration without deleting Sessions or files.
     * @param workspaceId - target Workspace.
     */
    delete(workspaceId: WorkspaceId): Promise<void>;
    /**
     * Move a Workspace within the Host registry order.
     * @param workspaceId - Workspace to move.
     * @param beforeWorkspaceId - anchor Workspace; omitted appends.
     */
    insertBefore(workspaceId: WorkspaceId, beforeWorkspaceId?: WorkspaceId): Promise<void>;
    /**
     * Archive a Session from Workspace grouping surfaces.
     * @param sessionId - Session to archive.
     */
    archiveSession(sessionId: SessionId): Promise<void>;
    /**
     * Move a Session within one Workspace account.
     * @param workspaceId - owning Workspace.
     * @param sessionId - Session to move.
     * @param beforeSessionId - anchor Session; omitted appends.
     * @returns the changed Workspace.
     */
    insertSessionBefore(workspaceId: WorkspaceId, sessionId: SessionId, beforeSessionId?: SessionId): Promise<WorkspaceView>;
}
/** Owns the bare Workspace snapshot and Workspace-only commands. */
export declare class WorkspaceController extends Service implements IWorkspaces {
    private readonly model;
    readonly list: WorkspaceSource;
    /**
     * @param ctx - Client root Context.
     * @param model - Remote-backed Workspace state model.
     */
    constructor(ctx: Context, model: ClientWorkspaceModel);
    create(input: {
        path: string;
    }): Promise<WorkspaceView>;
    resolveByPath(input: WorkspaceResolveRequest, signal?: AbortSignal): Promise<WorkspaceView | null>;
    rename(workspaceId: WorkspaceId, title: string): Promise<WorkspaceView>;
    delete(workspaceId: WorkspaceId): Promise<void>;
    insertBefore(workspaceId: WorkspaceId, beforeWorkspaceId?: WorkspaceId): Promise<void>;
    archiveSession(sessionId: SessionId): Promise<void>;
    insertSessionBefore(workspaceId: WorkspaceId, sessionId: SessionId, beforeSessionId?: SessionId): Promise<WorkspaceView>;
}
