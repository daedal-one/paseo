/** Platform-neutral assembly of generated Host Remote contributions. */
import type { Context } from '@deepseek-ai/cordis';
import type { TypertRemoteMap } from '@deepseek-ai/dsh-typert-protocol';
import type { RemoteCapabilityRequirement } from "../../../../gateway/lib/types/client/index.js";
import type { ClientRemote } from "../../../../gateway/lib/types/client/index.js";
export type { ClientRemote } from "../../../../gateway/lib/types/client/index.js";
export type { PluginInventorySnapshot } from "../../../../../host/plugin-inventory/lib/types/types.js";
export type {} from "../../../../../core/agent-default-model/lib/typert.remote-client.js";
export type {} from "../../../../../preset/agent-presets/lib/typert.remote-client.js";
export type {} from "../../../../../interaction/commands/lib/typert.remote-client.js";
export type {} from "../../../../settings-controller/lib/typert.remote-client.js";
export type {} from "../../../../../goal/goal/lib/typert.remote-client.js";
export type {} from "../../../../../llm/llm/lib/typert.remote-client.js";
export type {} from "../../../../../host/plugin-inventory/lib/typert.remote-client.js";
export type {} from "../../../../../feedback/message-feedback/lib/typert.remote-client.js";
export type {} from "../../../../../feedback/command-feedback/lib/typert.remote-client.js";
export type {} from "../../../../../client/file-upload/lib/typert.remote-client.js";
export type {} from "../../../../../context/session-reference/lib/typert.remote-client.js";
export type {} from "../../../../../subagent/subagent/lib/typert.remote-client.js";
export type * from "../../../../../subagent/subagent/lib/types/client.js";
export type {} from "../../../../session-controller/lib/typert.remote-client.js";
export type * from "../../../../session-controller/lib/types/types.js";
export type {} from "../../../../workspace-controller/lib/typert.remote-client.js";
export type * from "../../../../workspace-controller/lib/types/types.js";
export type {} from "../../../../workspace-files/lib/typert.remote-client.js";
export type * from "../../../../workspace-files/lib/types/types.js";
export type { SessionJob as JobView } from "../../../../session-controller/lib/types/types.js";
export type { ApiRemoteForwardedEvent } from "../types.js";
export type * from "../../../../../core/agent-default-model/lib/types/types.js";
export type {} from "../../../../../interaction/commands/lib/types/types.js";
export type {} from "../../../../../extensions/cordis-host-runner/lib/types/types.js";
export type {} from "../../../../../credentials/credentials/lib/types/types.js";
export type {} from "../../../../../llm/llm/lib/types/types.js";
export type {} from "../../../../../preset/agent-presets/lib/types/types.js";
export type {} from "../../../../../settings/settings/lib/types/types.js";
export type {} from "../../../../../interaction/user-approval/lib/types/types.js";
export type {} from "../../../../../interaction/user-questions/lib/types/types.js";
export type {} from "../../../../session-controller/lib/types/types.js";
/**
 * The carrier's Client-facing types, re-exported so a business package names one
 * assembly package instead of both this facade and the Connection plugin. Type-only:
 * the carrier's runtime values stay behind their own module edge.
 */
export type { ConnectionHandle, ConnectionSinks, ContentBlock, MessageId, RpcId, RpcRequest, RpcResponse, RpcResult, SessionId, StreamChunk, } from "../../../../../client/connection/lib/types/client/index.js";
export type {} from "../../../../gateway/lib/types/client/index.js";
export type {} from "../../../../../extensions/cordis-host-runner/lib/typert.remote-client.js";
export type { ApprovalRequestId, CordisHalfState, CordisDynamicPackageId, CordisDynamicPluginId, CordisDynamicPluginRunId, CordisDynamicRunMode, CordisInspectMethodManifest, CordisInspectPlatform, CordisInspectProviderManifest, CordisInspectProviderView, CordisInspectQueryRequest, CordisInspectQueryResolution, CordisInspectQueryResolved, CordisInspectRequestId, CordisInspectResolveAck, CordisRunDiagnostic, CordisRunStatus, DynamicCordisClientSource, DynamicCordisHostHalfResult, DynamicCordisInventoryRow, DynamicCordisInvokeResult, DynamicCordisPackage, DynamicCordisRequestResolved, DynamicCordisResolveAck, DynamicCordisRetracted, DynamicCordisRunRequest, DynamicCordisRunResolution, DynamicCordisRunAttempt, DynamicCordisRunResponse, DynamicCordisStopResponse, DynamicCordisUndefineReceipt, RequestRunOutcome, } from "../../../../../extensions/cordis-host-runner/lib/types/types.js";
export type { CredentialInfo } from "../../../../../credentials/credentials/lib/types/types.js";
export type { SettingsDescribeValue, SettingsNamespaceView, SettingsPathOpView, SettingsSecretView, } from "../../../../../settings/settings/lib/types/types.js";
export type { LlmConfigurableProvider, LlmDiscoveredModel, LlmModelDiscoveryRequest, LlmProviderInfo, } from "../../../../../llm/llm/lib/types/types.js";
export type { FileReferenceCandidate } from "../../../../../context/file-reference/lib/types/types.js";
export type { SessionReferenceMentionCandidate } from "../../../../../context/session-reference/lib/types/types.js";
export type { RemoteErrorCode, RemoteErrorDetailsMap, RemoteFailure, RemoteResult, } from '@deepseek-ai/dsh-typert-protocol';
export type { RemoteHostFacts } from "../../../../gateway/lib/types/client/index.js";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by this Client assembly. */
        remote: ClientRemote;
    }
}
/**
 * Select admission requirements from the exact generated descriptors this assembly mounts.
 * @param endpoints - required endpoints; duplicates collapse and an empty selection admits metadata only.
 * @returns requirements sorted by endpoint, ready before any Client plugin mounts.
 * @throws when an endpoint is absent from this assembly or lacks generated compatibility evidence.
 */
export declare function selectRemoteCapabilities(endpoints: readonly (keyof TypertRemoteMap)[]): readonly RemoteCapabilityRequirement[];
/** Required service: the typed Client Remote contribution mount. */
export declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
export type { AccountAttemptId, AccountPromptId, ProviderAccount, ProviderAccountPrompt, ProviderAccountUpdate } from "../../../../settings-controller/lib/types/types.js";
