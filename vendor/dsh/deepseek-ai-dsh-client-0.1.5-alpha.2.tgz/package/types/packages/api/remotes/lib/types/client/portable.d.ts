/** Normal ESM Client entry for portable Cordis compositions. */
import { apply as applyClient } from "./index.js";
import { applySessions as applySessionClient } from "../../../../session-controller/lib/types/client/index.js";
import { apply as applyWorkspaceClient } from "../../../../workspace-controller/lib/types/client/index.js";
export * from "./index.js";
export { createConnection, createConnectionRpc, readHostIdentity, claimDeviceEnrollment, connectionHostIdSchema, connectionDeviceGrantSchema, connectionDeviceEnrollmentSchema, DEVICE_ACCESS_PATHS, } from "../../../../../client/connection/lib/types/client/portable.js";
export type { DeviceEnrollmentClaimOptions, ConnectionDeviceId, ConnectionDeviceCredential, ConnectionDeviceInfo, ConnectionDeviceEnrollment, ConnectionDeviceGrant, ConnectionOptions, ConnectionRpcOptions, ConnectionNetworkSource, RpcFetch, RpcFetchResponse, RpcStreamOpen, ConnectionIdentity, ConnectionHostId, ConnectionActivationId, } from "../../../../../client/connection/lib/types/client/portable.js";
export { readHostCapabilities, applyRemoteClient, createRemoteStreamMux, isRemoteFailure, RemoteStream, RemoteJournalStream, RemoteSnapshotStream, RemoteStreamCarrierError, } from "../../../../gateway/lib/types/client/portable.js";
export type { HostCapabilities, HostCapability, RemoteCapabilityRequirement, RemoteClientAdmission, RemoteClientOptions, RemoteStreamMuxOptions, RemoteStreamSocket, RemoteStreamSignal, RemoteStreamOptions, RemoteStreamItem, RemoteSnapshotStreamOptions, RemoteJournalChange, RemoteJournalFrame, RemoteJournalStreamOptions, RemoteStreamFactory, } from "../../../../gateway/lib/types/client/portable.js";
export { apply as applyRegistry, inject as registryInject } from "../../../../../typert/registry/lib/types/client/portable.js";
/**
 * Install the Client plugin through a callback Cordis invokes as a function.
 * Binding prevents Cordis from treating a transpiled function as a constructor.
 * @param ctx - Client Cordis root with this plugin's injected services.
 * @returns disposer once every generated namespace is ready.
 */
export declare const apply: (ctx: Parameters<typeof applyClient>[0]) => Promise<() => Promise<void>>;
export { inject as workspaceInject, ClientWorkspaceModel, WorkspaceController, WorkspaceCreateError, createWorkspaceStateStream } from "../../../../workspace-controller/lib/types/client/index.js";
export type { IWorkspaces, WorkspaceSource, WorkspaceSnapshot, WorkspaceListPhase, WorkspaceFollowSink, WorkspaceRemote, WorkspaceStateStream, WorkspaceStateStreamOptions, } from "../../../../workspace-controller/lib/types/client/index.js";
/**
 * Install the shared Workspace projection and reconnecting follow stream for one host.
 * @param ctx - Client Cordis context with the generated Workspace Remote namespace.
 */
export declare const applyWorkspaces: (ctx: Parameters<typeof applyWorkspaceClient>[0]) => void;
export { sessionInject, SessionCreateError, SessionForkError, SessionEventStream, createSessionControlStream, MutableSessionEventSource, scopeOf, } from "../../../../session-controller/lib/types/client/index.js";
export type { ISessions, SessionFace, SessionSnapshot, SessionListState, SessionBinding, SessionPlatform, SessionSelection, SessionSelectionStore, SessionClientOptions, SessionEventSource, SessionEventWindow, SessionEventChange, SessionEventLikeEntry, BeginSubmissionInput, SubmissionHandle, PendingSubmission, } from "../../../../session-controller/lib/types/client/index.js";
/**
 * Install shared Session state and reconnecting streams for one host.
 * @param ctx - Client Cordis context with the generated Session Remotes.
 * @param options - platform callbacks and hydrated host-specific navigation.
 */
export declare const applySessions: typeof applySessionClient;
