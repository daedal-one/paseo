/** Remote values and declarations shared by browser and portable Client entries. */
export { readHostCapabilities } from "./host-capabilities.js";
export type { RemoteCapabilityRequirement, RemoteClientAdmission } from "./host-capabilities.js";
export type { HostCapabilities, HostCapability } from "../capabilities-protocol.js";
export { inject, isRemoteFailure, RemoteStreamCarrierError, RemoteJournalStream, RemoteStream, RemoteSnapshotStream, } from "./service.js";
export type { ClientRemote, RemoteHostFacts, TypertGatewayFaultDetails, RemoteJournalChange, RemoteJournalFrame, RemoteJournalStreamOptions, RemoteStreamFactory, RemoteStreamItem, RemoteStreamOptions, RemoteSnapshotStreamOptions, } from "./service.js";
