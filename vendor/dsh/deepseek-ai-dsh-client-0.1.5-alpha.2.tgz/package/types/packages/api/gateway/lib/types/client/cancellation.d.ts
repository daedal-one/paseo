/** Cancellation links whose event listeners have an explicit operation lifetime. */
/** A combined signal and the cleanup owned by its caller. */
export interface RemoteCancellationScope {
    /** Aborts with the first source's reason. */
    readonly signal: AbortSignal;
    /** Remove source listeners when the operation finishes without cancellation. */
    dispose(): void;
}
/**
 * Link operation lifetimes without requiring AbortSignal.any or garbage collection.
 * @param signals - cancellation sources, in priority order when already aborted.
 * @param createController - platform controller preserving abort reasons and signal helpers.
 * @returns combined signal; the owner must dispose it when its operation settles.
 */
export declare function combineRemoteCancellation(signals: readonly AbortSignal[], createController: () => AbortController): RemoteCancellationScope;
