/** Browser plugin adapter for the shared typed Remote service. */
import type { Context } from '@deepseek-ai/cordis';
export * from "./shared-api.js";
/**
 * Install the shared Remote service using browser socket and crypto inputs.
 * @param ctx - Client Cordis root.
 */
export declare function apply(ctx: Context): void;
