/** Browser plugin adapter for the shared typed Remote service. */
import type { Context } from '@deepseek-ai/cordis';
export { readHostCapabilities } from "./host-capabilities.js";
export type { RemoteCapabilityRequirement, RemoteClientAdmission } from "./host-capabilities.js";
export type { HostCapabilities, HostCapability } from "../capabilities-protocol.js";
export { inject, isRemoteFailure, RemoteStreamCarrierError, RemoteJournalStream, RemoteStream, RemoteSnapshotStream, } from "./service.js";
export type { ClientRemote, RemoteHostFacts, TypertGatewayFaultDetails, RemoteJournalChange, RemoteJournalFrame, RemoteJournalStreamOptions, RemoteStreamFactory, RemoteStreamItem, RemoteStreamOptions, RemoteSnapshotStreamOptions, } from "./service.js";
/**
 * Install the shared Remote service using browser socket and crypto inputs.
 * @param ctx - Client Cordis root.
 */
export declare function apply(ctx: Context): void;
