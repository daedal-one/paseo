/** Socket operations required by the multiplexed stream carrier. */
export interface RemoteStreamSocket {
    readonly readyState: number;
    /** @param data - one encoded client frame. */
    send(data: string): void;
    /**
     * @param code - protocol close code.
     * @param reason - close description.
     */
    close(code?: number, reason?: string): void;
    /**
     * @param type - lifecycle event.
     * @param listener - callback.
     * @param options - once-only delivery.
     */
    addEventListener(type: 'open' | 'error' | 'close', listener: () => void, options?: {
        once?: boolean;
    }): void;
    /**
     * @param type - message event.
     * @param listener - incoming frame callback.
     */
    addEventListener(type: 'message', listener: (event: {
        readonly data: unknown;
    }) => void): void;
    /**
     * @param type - lifecycle event.
     * @param listener - registered callback.
     */
    removeEventListener(type: 'open' | 'error' | 'close', listener: () => void): void;
    /**
     * @param type - message event.
     * @param listener - registered callback.
     */
    removeEventListener(type: 'message', listener: (event: {
        readonly data: unknown;
    }) => void): void;
}
/** Cancellation subset supported by browser and native platform signals. */
export interface RemoteStreamSignal {
    readonly aborted: boolean;
    readonly reason?: unknown;
    /**
     * @param type - abort event.
     * @param listener - cancellation callback.
     * @param options - once-only delivery.
     */
    addEventListener(type: 'abort', listener: () => void, options?: {
        once?: boolean;
    }): void;
    /**
     * @param type - abort event.
     * @param listener - registered callback.
     */
    removeEventListener(type: 'abort', listener: () => void): void;
}
/** Physical socket and correlation identity supplied by the transport owner. */
export interface RemoteStreamTransport {
    /** @returns a fresh socket for one physical connection attempt. */
    createSocket(): RemoteStreamSocket;
    /** @returns a new wire identity for each logical stream, including after reconnect. */
    randomId(): string;
}
/** Physical Remote stream socket failure that may be retried by a domain transport. */
export declare class RemoteStreamCarrierError extends Error {
    /**
     * @param message - physical carrier failure description.
     * @param options - optional causal error.
     */
    constructor(message: string, options?: ErrorOptions);
}
/** Keep one physical WebSocket and share it among independently cancellable Remote streams. */
export declare class RemoteStreamMuxClient {
    private readonly transport;
    private socket;
    private cancelCandidate;
    private keepAlive;
    private revision;
    private readonly streams;
    private readonly waiters;
    private running;
    private disposed;
    /** @param transport - per-owner socket creation and logical stream identity. */
    constructor(transport: RemoteStreamTransport);
    /** Ensure a physical attempt exists, following the current attempt once if needed. */
    start(): void;
    /** Cancel the current socket or retry wait and start a fresh attempt immediately. */
    reconnect(): void;
    /**
     * Open one logical stream on the persistent physical connection.
     * If no physical attempt is active, opening waits for Connection to request
     * one or for the signal to abort.
     * @param endpoint - Typert Remote stream endpoint.
     * @param payload - endpoint request encoded on the wire.
     * @param signal - cancellation for this logical stream.
     * @returns Host items until completion, cancellation, or failure.
     */
    open(endpoint: string, payload: unknown, signal: RemoteStreamSignal): AsyncGenerator;
    /**
     * Permanently stop the carrier, close the physical socket, and fail every
     * active logical stream.
     * @returns once the active connection attempt has stopped.
     */
    close(): Promise<void>;
    private connect;
    private waitForSocket;
    private receive;
    private lost;
    private maintain;
    private failAll;
    private send;
}
