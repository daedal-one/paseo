/** Advisory dispatch metadata carried by the authenticated Gateway. */
import { z } from 'zod';
import type { ConnectionIdentity } from "../../../../client/connection/lib/types/types.js";
/** Gateway-owned unary endpoint; the request is an empty object. */
export declare const HOST_CAPABILITIES_ENDPOINT = "$capabilities";
/** Exact empty discovery request, independent of domain Remote arguments. */
export declare const hostCapabilitiesRequestSchema: z.ZodObject<{}, z.core.$strict>;
/** One strict endpoint's current prerequisites; availability grants no authority. */
export type HostCapability = {
    readonly endpoint: string;
    readonly mode: 'unary' | 'stream';
    /** Generated schema evidence; absence does not establish compatibility. */
    readonly wireFingerprint?: string | undefined;
    /** Authored business revision, independent of codec equivalence. */
    readonly semanticRevision?: number | undefined;
} & ({
    readonly availability: 'available';
} | {
    readonly availability: 'context-required';
} | {
    readonly availability: 'unavailable';
    readonly reason: 'service' | 'binding' | 'method' | 'lookup' | 'context';
});
/** Exact versioned response with unique endpoints in code-point order. */
export declare const hostCapabilitiesSchema: z.ZodType<HostCapabilities>;
/** Snapshot for one Host activation; version describes metadata, not domain schemas. */
export interface HostCapabilities {
    readonly version: 3;
    readonly identity: ConnectionIdentity;
    readonly capabilities: readonly HostCapability[];
}
