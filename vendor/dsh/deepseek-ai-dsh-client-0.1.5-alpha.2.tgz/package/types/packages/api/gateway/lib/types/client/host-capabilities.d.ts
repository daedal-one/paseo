/** Validated capability snapshots for an already authenticated Host activation. */
import type { ClientConnectionRpc, ConnectionRpcResult, ConnectionIdentity, ConnectionHostId } from "../../../../../client/connection/lib/types/client/index.js";
import { type HostCapabilities } from "../capabilities-protocol.js";
/**
 * Read advisory Host dispatch facts without retries or implicit generation recovery.
 * @param rpc - authenticated carrier for the selected Host.
 * @param expectedIdentity - validated event-stream identity; both Host and activation must match.
 * @param signal - caller-owned lifetime, cancelled when its generation ends.
 * @returns validated facts or a failure; carrier rejection and cancellation propagate.
 */
export declare function readHostCapabilities(rpc: ClientConnectionRpc, expectedIdentity: ConnectionIdentity, signal?: AbortSignal): Promise<ConnectionRpcResult<HostCapabilities>>;
/** One Client-owned requirement selected from its generated Remote descriptors. */
export interface RemoteCapabilityRequirement {
    readonly endpoint: string;
    readonly mode: 'unary' | 'stream';
    readonly wireFingerprint: string;
    readonly semanticRevision: number;
}
/** Paired identity and explicit requirements fixed for a native Client composition. */
export interface RemoteClientAdmission {
    readonly expectedHostId: ConnectionHostId;
    /** An empty list admits a metadata-only composition. */
    readonly requiredCapabilities: readonly RemoteCapabilityRequirement[];
}
/**
 * Require matching endpoint evidence before accepting a native generation.
 * @param rpc - authenticated carrier for this generation.
 * @param identity - identity validated on this generation's event-stream opening.
 * @param requirements - Client-generated requirements independent of Host metadata.
 * @param signal - generation lifetime; cancelled reads cannot return accepted facts.
 * @returns the full validated snapshot, including optional endpoint availability.
 */
export declare function admitHostCapabilities(rpc: ClientConnectionRpc, identity: ConnectionIdentity, requirements: readonly RemoteCapabilityRequirement[], signal: AbortSignal): Promise<HostCapabilities>;
