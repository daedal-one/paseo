/**
 * Client projection of generated Typert Remote descriptors. Contributions
 * install traced `remote.<namespace>` services; no JavaScript Proxy
 * participates in method lookup, invocation, or type exposure.
 */
export type { TypertGatewayFaultDetails } from "../remote-error-codes.js";
import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionIdentity } from "../../../../../client/connection/lib/types/client/index.js";
import type { TypertClientRemote, RemoteFailure } from '@deepseek-ai/dsh-typert-protocol';
import type { RemoteStreamMuxClient } from "./stream-client.js";
import type { RemoteClientAdmission } from "./host-capabilities.js";
import type { HostCapabilities } from "../capabilities-protocol.js";
import { RemoteStream, type RemoteStreamOptions } from "./remote-stream.js";
export { RemoteStreamCarrierError } from "./stream-client.js";
export { RemoteJournalStream } from "./journal-stream.js";
export type { RemoteJournalChange, RemoteJournalFrame, RemoteJournalStreamOptions, RemoteStreamFactory, } from "./journal-stream.js";
export { RemoteStream } from "./remote-stream.js";
export type { RemoteStreamItem, RemoteStreamOptions } from "./remote-stream.js";
export { RemoteSnapshotStream } from "./snapshot-stream.js";
export type { RemoteSnapshotStreamOptions } from "./snapshot-stream.js";
/** Typed Remote service augmented by generated direct namespaces and Gateway stream supervision. */
export interface ClientRemote extends TypertClientRemote {
    /**
     * Create one independently cancellable, reconnecting logical stream.
     * @param options - domain-owned opener and generation-end classification.
     * @returns a single-consumer stream annotated with physical generation ids.
     */
    $stream<Item>(options: RemoteStreamOptions<Item>): RemoteStream<Item>;
    /**
     * Active Host facts as plain reads. Subscribe to Connection generation changes
     * to observe readiness and loss; disconnected facts remain undefined.
     */
    readonly $host: RemoteHostFacts;
}
/** The active Host facts exposed on `ctx.remote.$host`. */
export interface RemoteHostFacts {
    /** Identity validated on the active Gateway stream, undefined while disconnected. */
    readonly identity: ConnectionIdentity | undefined;
    /** Capability metadata admitted for the active native generation, otherwise undefined. */
    readonly capabilities: HostCapabilities | undefined;
    /** Host home directory from the ready frame, undefined before it. */
    readonly home: string | undefined;
    /** Whether the carrier connects to the local Host. */
    readonly isLoopback: boolean;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by the Client assembly. */
        remote: ClientRemote;
    }
}
/** Required Client services: the Typert registry and the existing Connection carrier. */
export declare const inject: string[];
/**
 * Install the shared typed Remote service with explicit platform inputs.
 * @param ctx - Client Cordis root with Typert and Connection services.
 * @param streams - physical stream carrier owned and disposed by this service.
 * @param eventId - unique identity for this service's private event registrations.
 * @param createController - fresh platform controllers preserving abort reasons and signal helpers.
 * @param admission - paired Host and Client-required endpoints checked before native readiness.
 */
export declare function installRemoteClient(ctx: Context, streams: RemoteStreamMuxClient, eventId: string, createController: () => AbortController, admission?: RemoteClientAdmission): void;
/**
 * Whether a caught value is a Remote failure this face delivered or threw.
 * The one consumer-facing discrimination point: marked instances carry their
 * Host code; anything else is a local fault the caller should let crash.
 * @param error - a caught value.
 * @returns true when the value narrows to RemoteFailure.
 */
export declare function isRemoteFailure(error: unknown): error is RemoteFailure;
