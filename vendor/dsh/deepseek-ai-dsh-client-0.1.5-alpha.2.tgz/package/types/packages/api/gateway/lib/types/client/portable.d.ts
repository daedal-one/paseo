/** Normal ESM entry for per-host Gateway stream transports. */
import type { Context } from '@deepseek-ai/cordis';
import type { RemoteClientAdmission } from "./host-capabilities.js";
import { RemoteStreamMuxClient, type RemoteStreamSocket } from "./stream-client.js";
export { readHostCapabilities } from "./host-capabilities.js";
export type { RemoteCapabilityRequirement, RemoteClientAdmission } from "./host-capabilities.js";
export type { HostCapabilities, HostCapability } from "../capabilities-protocol.js";
export { inject, isRemoteFailure, RemoteStreamCarrierError, RemoteJournalStream, RemoteStream, RemoteSnapshotStream, } from "./service.js";
export type { ClientRemote, RemoteHostFacts, TypertGatewayFaultDetails, RemoteJournalChange, RemoteJournalFrame, RemoteJournalStreamOptions, RemoteStreamFactory, RemoteStreamItem, RemoteStreamOptions, RemoteSnapshotStreamOptions, } from "./service.js";
export type { RemoteStreamSignal, RemoteStreamSocket } from "./stream-client.js";
/** Explicit host and platform inputs for a multiplexed Remote stream carrier. */
export interface RemoteStreamMuxOptions {
    /** HTTP(S) host origin; the Gateway route is absolute within this origin. */
    readonly baseUrl: string;
    /**
     * Create an authenticated socket for the selected host. Credential handling belongs to the adapter.
     * @param url - complete ws(s) Gateway URL.
     * @returns a fresh socket whose lifecycle events begin after this call returns.
     */
    createSocket(url: string): RemoteStreamSocket;
    /** @returns a unique identity for each logical stream, including after reconnect. */
    randomId(): string;
}
/**
 * Create one host's stream carrier without browser globals. Start/reconnect belongs to Connection;
 * streams never replay themselves. Close permanently releases this instance's transport.
 * @param options - host URL, authenticated socket adapter and correlation identity generator.
 * @returns an independent multiplexed carrier; invalid host URLs throw before any socket is opened.
 */
export declare function createRemoteStreamMux(options: RemoteStreamMuxOptions): RemoteStreamMuxClient;
/** Platform inputs for the complete Remote service. */
export interface RemoteClientOptions extends RemoteStreamMuxOptions, RemoteClientAdmission {
    /** Creates fresh controllers with abort reasons and throwIfAborted support. */
    readonly createAbortController: () => AbortController;
}
/**
 * Install typed Remote calls, streams and forwarded events for one HTTP(S) host.
 * The owning Cordis fiber disposes the transport and registrations together.
 * @param ctx - Client Cordis root with Typert and Connection services.
 * @param options - authenticated socket adapter, host URL and identity generator.
 */
export declare function applyRemoteClient(ctx: Context, options: RemoteClientOptions): void;
