/** Positive prompt admission facts from one Session's authoritative read model. */
import { type ObservableSnapshot } from "../../../../../client/store/lib/types/index.js";
import type { SessionRequestId } from "../types.js";
import type { SessionBinding } from "./sessions/service.js";
/** Absence from the loaded window cannot establish rejection. */
export type PromptAdmissionState = 'unknown' | 'observed';
/** Watches one request without sending or retrying a mutation or loading more history. */
export declare class PromptAdmission implements ObservableSnapshot<PromptAdmissionState> {
    private readonly binding;
    private readonly requestId;
    private state;
    private revision;
    private closed;
    private readonly listeners;
    private readonly unsubscribe;
    /**
     * @param binding - Session and event source belonging to the same Host and Session.
     * @param requestId - original prompt identity, never text or a transport RPC identity.
     */
    constructor(binding: Pick<SessionBinding, 'session' | 'eventSource'>, requestId: SessionRequestId);
    /** @returns the latched positive observation, or unknown while no matching fact was received. */
    getSnapshot: () => PromptAdmissionState;
    /** @param listener - observation callback. @returns the subscription disposer. */
    subscribe: (listener: () => void) => (() => void);
    private refresh;
    private matches;
    private observe;
    /** Release read subscriptions and callbacks; the last observation remains readable. */
    dispose(): void;
}
