/** Host-wide accounting for explicitly hydrated history entries. */
import type { HistoryDetailRetentionPolicy } from "./platform.js";
/** An exact entry exceeds the caller's retained-detail allowance; its compact entry is unchanged. */
export declare class HistoryDetailLimitError extends Error {
    readonly serializedChars: number;
    readonly maxSerializedChars: number;
    /**
     * @param serializedChars - complete JSON entry length in UTF-16 code units.
     * @param maxSerializedChars - configured Host-wide allowance in the same units.
     */
    constructor(serializedChars: number, maxSerializedChars: number);
}
/** Oldest-hydration eviction shared by every resident Session of one Host connection. */
export declare class HistoryDetailRetention {
    private readonly entries;
    private chars;
    private readonly maxSerializedChars;
    /** @param policy - positive serialized-character limit validated at Client composition. */
    constructor(policy: HistoryDetailRetentionPolicy);
    /**
     * Admit one complete entry, restoring older compact entries until it fits.
     * @param chars - complete JSON entry length in UTF-16 code units.
     * @param evict - synchronously restore this entry's compact projection.
     * @returns an idempotent release that removes accounting without invoking eviction.
     */
    retain(chars: number, evict: () => void): () => void;
    private remove;
}
