/** Client Session object layer, Agent scopes, and Remote lifecycle wiring. */
import type { Context } from '@deepseek-ai/cordis';
export { applySessions, inject as sessionInject } from "./portable.js";
export type { SessionPlatform, SessionSelection, SessionSelectionStore, SessionClientOptions } from "./platform.js";
export { createSessionControlStream, SessionEventStream, SESSION_SEARCH_RESULT_LIMIT, SESSION_SEARCH_SNIPPET_MAX_CODE_POINTS, } from "./transport.js";
export type { ClientSessionPageRequest, SessionControlStream, SessionControlStreamOptions, SessionEventStreamOptions, SessionJournalChange, SessionRemote, } from "./transport.js";
export { createScope, scopeOf } from "./scope.js";
export type { AgentContext, AgentScopeHandle } from "./scope.js";
export { SessionCreateError, SessionForkError } from "./sessions/service.js";
export type { SessionBinding, SessionListState, SessionSummary } from "./sessions/service.js";
export type { SessionListPhase, SessionListSnapshot, SessionSearchResultItem, SubagentCatalogSnapshot, } from "./sessions/manager.js";
export type { Session } from "./sessions/session.js";
export type { ProjectionsBaseline, ProjectionValueStore, SessionProjectionMap, UseProjection, } from "./sessions/projection-store.js";
export type { BeginSubmissionInput, ISession, PendingSubmissionRetirement, ProjectionsFace, SessionFace, SubmissionHandle, } from "./contract/session.js";
export type { ISessions } from "./contract/sessions.js";
export { MutableSessionEventSource } from "./contract/events.js";
export type { AssistantLiveChunkEvent, SessionAssistantSettlementEntry, SessionEventChange, SessionEventLike, SessionEventLikeEntry, SessionEventSource, SessionEventWindow, SessionLiveEventEntry, SessionTransientEventEntry, } from "./contract/events.js";
export type { OpenState, PendingSubmission, PendingSubmissionAttachment, PendingSubmissionFileAttachment, PendingSubmissionImage, PendingSubmissionImageAttachment, PendingSubmissionPlacement, PromptError, QueuedMessage, SessionSnapshot, } from "./contract/snapshot.js";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Client Session object layer and Agent scope owner. */
        sessions: import("./contract/sessions.js").ISessions;
    }
}
/** Required services for the browser Session and attachment composition. */
export declare const inject: string[];
/**
 * Install Session state using browser identity, time zone and saved navigation.
 * @param ctx - Client Cordis context.
 */
export declare function apply(ctx: Context): void;
