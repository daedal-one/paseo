/** Shared Client Session installation with caller-owned platform inputs. */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionClientOptions } from "./platform.js";
/** Required Remote and Context projection services. */
export declare const inject: string[];
/**
 * Install Client Session state and its reconnecting control stream.
 * @param ctx - Client Cordis context for one host.
 * @param options - platform callbacks and hydrated host-specific navigation.
 */
export declare function applySessions(ctx: Context, options: SessionClientOptions): void;
