/** Bounded live activity summaries generated from durable agent operations. */
import type { Context } from '@deepseek-ai/cordis';
import z from "../../../../../vendor/schemastery/lib/types/index.js";
import { ReasoningEffortId } from "../../../../llm/llm/lib/types/index.js";
import type { Message } from "../../../../llm/llm/lib/types/index.js";
import type { SessionSeq } from "../../../../core/session/lib/types/index.js";
export declare const name = "session-activity-summary-llm";
export declare const inject: string[];
/** One bounded operation supplied to the auxiliary summary model. */
export type ActivitySummaryOperation = {
    readonly kind: 'assistant-update';
    readonly seq: SessionSeq;
    readonly step?: number;
    readonly status: 'reasoning-completed-without-hidden-content';
    readonly visibleText?: string;
} | {
    readonly kind: 'tool';
    readonly seq: SessionSeq;
    readonly step?: number;
    readonly name: string;
    readonly input: string;
    readonly output: string;
    readonly isError: boolean;
};
/** Exact model-visible request recorded before one activity-summary dispatch. */
export interface ActivitySummaryRequestEventData {
    readonly turn: number;
    readonly revision: number;
    readonly operationSeqs: SessionSeq[];
    readonly route: {
        readonly provider: string;
        readonly model: string;
    };
    readonly system: string;
    readonly messages: Message[];
    readonly maxTokens: number;
    readonly reasoningEffort: ReasoningEffortId;
}
/** Latest-wins accepted summary for one Turn. */
export interface ActivitySummaryEventData {
    readonly turn: number;
    readonly revision: number;
    readonly operationSeqs: SessionSeq[];
    readonly throughSeq: SessionSeq;
    readonly lines: string[];
    readonly route: {
        readonly provider: string;
        readonly model: string;
    };
}
declare module "../../../../core/session/lib/types/types.js" {
    interface SessionEventMap {
        /** Log-only pre-dispatch record of one activity-summary model request. */
        'activity-summary/request': ActivitySummaryRequestEventData;
        /** Log-only accepted activity summary for Chat presentation. */
        'activity-summary/update': ActivitySummaryEventData;
    }
}
/** Required deployment policy for live activity summaries. */
export interface Config {
    /** Completed operations in one normal summary batch; constrained to four through six. */
    readonly operationsPerSummary: number;
    /** Maximum UTF-8 bytes retained from one operation field. */
    readonly maxOperationBytes: number;
    /** Maximum UTF-8 bytes in the complete JSON-framed request. */
    readonly maxInputBytes: number;
    /** Auxiliary output-token cap. */
    readonly maxOutputTokens: number;
    /** Maximum UTF-8 bytes accepted in one summary. */
    readonly maxSummaryBytes: number;
    /** Maximum accepted non-empty output lines; constrained to one through three. */
    readonly maxLines: number;
    /** End-to-end request deadline in milliseconds. */
    readonly timeoutMs: number;
    /** Explicit auxiliary provider route. */
    readonly provider: string;
    /** Explicit auxiliary model id. */
    readonly model: string;
}
/** Loader schema with no library defaults. */
export declare const Config: z<Config>;
/** Install bounded live activity summarization for this composition. */
export declare function apply(ctx: Context, config: Config): void;
