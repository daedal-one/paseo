/** Browser defaults for the shared unary RPC caller. */
import { type ClientConnectionRpc } from "../rpc.js";
import { type RpcFetch, type RpcStreamOpen } from "./rpc-caller.js";
export type { RpcFetch, RpcFetchResponse, RpcStreamOpen } from "./rpc-caller.js";
/**
 * Create the browser-backed generic RPC caller.
 * @param doFetch - transport override; defaults to the page's global fetch.
 * @param openStream - optional shell-owned Gateway stream carrier.
 * @returns caller that owns request correlation and response-envelope validation.
 */
export declare function createWebConnectionRpc(doFetch?: RpcFetch, openStream?: RpcStreamOpen): ClientConnectionRpc;
