/** Host identity and device access exports shared by both Client entries. */
export { readHostIdentity } from "./host-identity.js";
export type { ConnectionIdentity, ConnectionHostId, ConnectionActivationId } from "../host-identity-protocol.js";
export { connectionIdentitySchema, connectionHostIdSchema } from "../host-identity-protocol.js";
export { claimDeviceEnrollment } from "./device-access.js";
export type { DeviceEnrollmentClaimOptions } from "./device-access.js";
export type { ConnectionDeviceId, ConnectionDeviceCredential, ConnectionDeviceInfo, ConnectionDeviceEnrollment, ConnectionDeviceGrant } from "../device-protocol.js";
export { connectionDeviceGrantSchema, connectionDeviceEnrollmentSchema, DEVICE_ACCESS_PATHS } from "../device-protocol.js";
