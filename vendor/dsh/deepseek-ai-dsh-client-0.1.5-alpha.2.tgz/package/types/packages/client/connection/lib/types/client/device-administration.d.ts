import { type ObservableSnapshot } from "../../../../store/lib/types/index.js";
import type { ConnectionGenerationState } from "./handle.js";
import type { RpcFetch } from "./rpc-caller.js";
import { type ConnectionHostId } from "../host-identity-protocol.js";
import { type ConnectionDeviceId, type ConnectionDeviceInfo, type ConnectionDeviceEnrollment } from "../device-protocol.js";
/** Fixed presentation diagnostics; wire messages and request bodies never enter this state. */
export type DeviceAdministrationError = 'owner-required' | 'unavailable' | 'read-failed' | 'enrollment-unknown' | 'revocation-unknown' | 'invalid-response' | 'enrollment-limit' | 'expired';
/** A browser-owned snapshot; the enrollment exists only while its visible section owns it. */
export interface DeviceAdministrationSnapshot {
    status: 'unavailable' | 'disconnected' | 'idle' | 'ready' | 'error';
    origin: string | null;
    hostId: ConnectionHostId | null;
    devices: ConnectionDeviceInfo[];
    enrollment: ConnectionDeviceEnrollment | null;
    busy: 'list' | 'enroll' | 'revoke' | null;
    error: DeviceAdministrationError | null;
}
/** Browser administration operations; only the Host can authorize an owner request. */
export interface DeviceAdministrationService {
    readonly state: ObservableSnapshot<DeviceAdministrationSnapshot>;
    /** Open the section and read its current device list. */
    open(): void;
    /** Close the section, cancel its requests and erase enrollment material. */
    close(): void;
    /**
     * Refresh authoritative metadata without retrying a mutation.
     * @returns after the read settles.
     */
    refresh(): Promise<void>;
    /**
     * Create one short-lived challenge after an explicit gesture.
     * @returns after that attempt settles.
     */
    enroll(): Promise<void>;
    /** Hide a QR and discard a pending creation; the Host challenge still expires on its own. */
    hideEnrollment(): void;
    /**
     * Revoke one confirmed device without retry.
     * @param deviceId - currently listed device.
     * @returns after the attempt settles.
     */
    revoke(deviceId: ConnectionDeviceId): Promise<void>;
}
/** Browser inputs kept separate from native bearer and private shell transports. */
export interface DeviceAdministrationOptions {
    readonly origin: string | undefined;
    readonly fetch: RpcFetch;
    readonly generation: ConnectionGenerationState;
}
/** React-free owner of browser requests, metadata and transient QR material. */
export declare class BrowserDeviceAdministration implements DeviceAdministrationService {
    private readonly options;
    private readonly store;
    /** Read-only source consumed through the renderer's injected hook binding. */
    readonly state: ObservableSnapshot<DeviceAdministrationSnapshot>;
    private visible;
    private disposed;
    private closing;
    private revision;
    private controller;
    private expiry;
    private stopFollowing;
    private readonly inFlight;
    /** @param options - explicit same-page browser transport and live generation source. */
    constructor(options: DeviceAdministrationOptions);
    /** Subscribe once; opening the Settings section owns all network reads. */
    start(): void;
    /** Open the section and load owner metadata; repeated mounts do not duplicate pending work. */
    open(): void;
    /** Cancel this section's work and remove all retained metadata and enrollment material. */
    close(): void;
    /**
     * Read once through the active generation.
     * @returns after that attempt settles.
     */
    refresh(): Promise<void>;
    /**
     * Mint one QR challenge; a failed or lost result is never retried.
     * @returns after the attempt settles.
     */
    enroll(): Promise<void>;
    /** Remove QR material without claiming to cancel its still-valid Host challenge. */
    hideEnrollment(): void;
    /**
     * Revoke the selected current device.
     * @param deviceId - confirmed listed device.
     * @returns after the attempt settles.
     */
    revoke(deviceId: ConnectionDeviceId): Promise<void>;
    /**
     * Cancel requests, release listeners and await owned work.
     * @returns after all cancelled requests settle.
     */
    dispose(): Promise<void>;
    private cancel;
    private reset;
    private clearExpiry;
    private expire;
    private perform;
    private request;
}
