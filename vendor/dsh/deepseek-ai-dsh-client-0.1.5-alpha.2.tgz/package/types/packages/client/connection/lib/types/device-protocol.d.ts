/** Versioned device enrollment payloads shared by Connection and portable clients. */
import { z } from 'zod';
import type { Branded } from '@deepseek-ai/dsh-brand';
import { type ConnectionHostId } from "./host-identity-protocol.js";
/** Identity of one independently revocable device grant. */
export type ConnectionDeviceId = Branded<'connection-device-id'>;
/** Device bearer secret returned only by a successful enrollment claim. */
export type ConnectionDeviceCredential = Branded<'connection-device-credential'>;
/** Exact Connection-owned HTTP routes; enrollment secrets travel only in JSON bodies. */
export declare const DEVICE_ACCESS_PATHS: {
    readonly enroll: "/api/connection/devices/enroll";
    readonly claim: "/api/connection/devices/claim";
    readonly list: "/api/connection/devices";
    readonly revoke: "/api/connection/devices/revoke";
};
/** Security budget for the unauthenticated claim body, including bounded device metadata. */
export declare const DEVICE_CLAIM_MAX_BYTES = 2048;
/** Validate an opaque device identity at wire and persistence boundaries. */
export declare const connectionDeviceIdSchema: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionDeviceId, string>>;
/** Fixed 256-bit token encoding; equality checks still require the exact minted token. */
export declare const enrollmentChallengeSchema: z.ZodString;
/** A credential is never accepted from a URL or a cookie. */
export declare const deviceCredentialSchema: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionDeviceCredential, string>>;
/** Public device metadata; neither token digests nor provider credentials are exposed. */
export interface ConnectionDeviceInfo {
    readonly deviceId: ConnectionDeviceId;
    readonly label: string;
    readonly createdAt: number;
}
/** Bounded owner-visible metadata and persisted grant fields. */
export declare const connectionDeviceInfoSchema: z.ZodType<ConnectionDeviceInfo>;
/** Short-lived, single-use enrollment issued to an authenticated owner. */
export interface ConnectionDeviceEnrollment {
    readonly version: 1;
    readonly hostId: ConnectionHostId;
    readonly challenge: string;
    readonly expiresAt: number;
}
/** Validate owner-issued enrollment metadata before application QR consumption. */
export declare const connectionDeviceEnrollmentSchema: z.ZodType<ConnectionDeviceEnrollment>;
/** Successful claim, persisted before its secret is returned. */
export interface ConnectionDeviceGrant {
    readonly version: 1;
    readonly hostId: ConnectionHostId;
    readonly device: ConnectionDeviceInfo;
    readonly credential: ConnectionDeviceCredential;
}
/** Exact claim body; the expected Host prevents enrollment against another host. */
export declare const deviceClaimSchema: z.ZodObject<{
    hostId: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionHostId, string>>;
    challenge: z.ZodString;
    label: z.ZodString;
}, z.core.$strict>;
/** Exact owner revocation body. */
export declare const deviceRevokeSchema: z.ZodObject<{
    deviceId: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionDeviceId, string>>;
}, z.core.$strict>;
/** Owner enrollment creation carries no options or delegated authority. */
export declare const deviceEnrollSchema: z.ZodObject<{}, z.core.$strict>;
/** Validate the one-time credential result before a native caller stores it. */
export declare const connectionDeviceGrantSchema: z.ZodType<ConnectionDeviceGrant>;
