/** Unary RPC envelopes over explicit per-host transports. */
import { type RpcId as RpcIdType } from "../rpc.js";
import type { ClientConnectionRpc } from "../rpc.js";
/** HTTP and JSON facts consumed by Connection; browser Response objects satisfy this interface. */
export interface RpcFetchResponse {
    readonly ok: boolean;
    readonly status: number;
    /** @returns decoded, still-unvalidated response body. */
    json(): Promise<unknown>;
}
/** Platform transport retaining cancellation ownership until response JSON decoding settles. */
export type RpcFetch = (input: URL, init: RequestInit) => Promise<RpcFetchResponse>;
/** Transport-owned opener for decoded Gateway Remote streams. */
export type RpcStreamOpen = (endpoint: string, payload: unknown, signal: AbortSignal) => AsyncIterable<unknown>;
/** Explicit transport inputs for one Host's RPC calls. */
export interface ConnectionRpcOptions {
    /** Base authority used to resolve absolute RPC channel paths. */
    readonly baseUrl: string;
    /** Host-authenticated Fetch implementation; owns credentials and networking. */
    readonly fetch: RpcFetch;
    /** Mint a new correlation id for each request. */
    readonly randomId: () => RpcIdType;
    /** Optional carrier for decoded Gateway streams. */
    readonly openStream?: RpcStreamOpen;
}
/**
 * Create an RPC caller without reading browser, crypto, or transport globals.
 * Requests are sent once; a rejected transport leaves command acceptance unknown.
 * @param options - Host authority, transport, and correlation-id source.
 * @returns caller validating targets, response envelopes, and correlation without retrying mutations.
 */
export declare function createConnectionRpc(options: ConnectionRpcOptions): ClientConnectionRpc;
