/** Per-host Connection ownership independent of page globals and UI frameworks. */
import { type ConnectionRecoveryConfig, type ConnectionGeneration, type ConnectionGenerationSource, type ConnectionSinks, type ConnectionState } from "./connection.js";
import type { ClientConnectionRpc } from "../rpc.js";
/** Observable identity and Host facts for the active connection generation. */
export interface ConnectionGenerationState {
    /** Active generation, or undefined before readiness and while reconnecting. */
    getSnapshot(): ConnectionGeneration | undefined;
    /** Subscribe to generation establishment, replacement, and loss. */
    subscribe(listener: () => void): () => void;
}
/** Observable recovery lifecycle of the owned Connection loop. */
export interface ConnectionStateSource {
    /** Current state, or undefined before the first connection outcome. */
    getSnapshot(): ConnectionState | undefined;
    /** Subscribe to state changes. */
    subscribe(listener: () => void): () => void;
}
/**
 * The ctx.connection service API. API Gateway supplies generation readiness
 * and reset callbacks; Connection stays independent of downstream domain state.
 */
export interface ConnectionHandle {
    /**
     * Whether the caller declares a local or shell-owned Host. This is a
     * presentation hint; the Host authenticates and authorizes every operation.
     */
    readonly isLoopback: boolean;
    /** Current Remote event generation and the Host facts carried by its opening frame. */
    readonly generation: ConnectionGenerationState;
    /** Current recovery lifecycle for connection-specific consumers. */
    readonly state: ConnectionStateSource;
    /** Generic logical RPC channels over the same Connection transport. */
    readonly rpc: ClientConnectionRpc;
    /** Reset retry progression and replace the current attempt immediately. */
    reconnect(): void;
    /**
     * Register the sole source defining Host generations. The source reports
     * ready only after its incremental listeners are attached.
     * @param source - long-lived generation source owned by the push carrier.
     * @returns disposer withdrawing the source and stopping an active loop.
     */
    registerGenerationSource(source: ConnectionGenerationSource): () => void;
    /**
     * Start the connect/reconnect loop with the consumer's state callbacks.
     * API Gateway owns the loop; a second call throws.
     * @param sinks - connection-state callbacks.
     * @param config - explicit timing overrides; omitted fields use Host bootstrap timing.
     * @returns lifecycle controls for the loop.
     */
    start(sinks: ConnectionSinks, config?: ConnectionRecoveryConfig): ConnectionLoop;
}
/** Controls retained by the sole owner of a running connection loop. */
export interface ConnectionLoop {
    /** Stop the loop and withdraw its active generation. */
    stop(): void;
}
/** Network availability supplied by the transport owner. */
export interface ConnectionNetworkSource {
    /** Whether another transport attempt can currently reach a network. */
    getSnapshot(): boolean;
    /** Subscribe to availability changes; the disposer releases the subscription. */
    subscribe(listener: () => void): () => void;
}
/** Inputs owned by one Host connection, never read from page globals. */
export interface ConnectionOptions {
    /** Authenticated unary and optional stream transport for this Host. */
    readonly rpc: ClientConnectionRpc;
    /** Explicit local-Host presentation hint; does not grant server privileges. */
    readonly isLoopback: boolean;
    /** Validated timing overrides for this Host. */
    readonly recovery?: ConnectionRecoveryConfig;
    /** Availability observer; omit for carriers without network suspension. */
    readonly network?: ConnectionNetworkSource;
    /** Controller factory preserving abort reasons; defaults to the platform AbortController. */
    readonly createAbortController?: () => AbortController;
}
/**
 * Create an independent Host connection using caller-owned transport and network state.
 * @param options - explicit Host inputs; malformed recovery timing throws before ownership begins.
 * @returns connection whose active loop and network subscription are released by its loop or source disposer.
 */
export declare function createConnection(options: ConnectionOptions): ConnectionHandle;
