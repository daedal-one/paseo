import type { ConnectionRpcResult } from "../rpc.js";
import type { RpcFetch } from "./rpc-caller.js";
import type { ConnectionHostId } from "../host-identity-protocol.js";
import { type ConnectionDeviceGrant } from "../device-protocol.js";
/** Platform inputs for a single enrollment claim; no ambient device credential is used. */
export interface DeviceEnrollmentClaimOptions {
    readonly baseUrl: string;
    readonly expectedHostId: ConnectionHostId;
    readonly challenge: string;
    readonly label: string;
    /** Dedicated unauthenticated fetch; must not add another Host's credentials. */
    readonly fetch: RpcFetch;
    readonly signal: AbortSignal;
}
/**
 * Claim once without redirects, ambient cookies or automatic retry.
 * @param options - selected Host, QR challenge and platform-owned cancellation and transport.
 * @returns validated credential or a failure; cancellation and carrier rejection propagate.
 */
export declare function claimDeviceEnrollment(options: DeviceEnrollmentClaimOptions): Promise<ConnectionRpcResult<ConnectionDeviceGrant>>;
