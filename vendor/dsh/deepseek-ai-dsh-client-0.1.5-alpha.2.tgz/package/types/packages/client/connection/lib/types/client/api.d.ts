/** Browser-safe Connection protocol and shared application value exports. */
export type { ClientRequest, RpcMessage, RpcRequest, RpcResponse, RpcResult, ServerResponse, } from "../rpc.js";
export { RpcId, transportError } from "../rpc.js";
export type { SessionId, SessionEvent } from "../../../../../core/session/lib/types/types.js";
export type { MessageId } from "../../../../../llm/llm/lib/types/brand.js";
export type { ContentBlock, StreamChunk } from "../../../../../llm/llm/lib/types/types.js";
import type { RpcResponse, RpcResult } from "../rpc.js";
/**
 * Return the business result carried by a narrow fixture response.
 * @param response - fixture response to unwrap.
 * @returns the response's business result.
 */
export declare function resultOf<T>(response: RpcResponse<T>): RpcResult<T>;
