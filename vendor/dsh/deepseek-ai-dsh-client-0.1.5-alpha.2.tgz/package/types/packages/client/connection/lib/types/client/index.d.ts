/** Browser adapter for the shared per-host Connection. */
import { type DeviceAdministrationService } from "./device-administration.js";
import type { Context } from '@deepseek-ai/cordis';
import { type RpcFetch, type RpcStreamOpen } from "./rpc.js";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Browser-owner administration over the current page origin; unavailable on private carriers. */
        connectionDevices: DeviceAdministrationService;
    }
    interface Events {
        /**
         * A connection generation was established. Wire-derived caches must
         * repull; long-lived streams own their own resume and baseline lifecycle.
         * @mode emit
         */
        'connection/reset'(): void;
    }
}
export type { MessageId, RpcRequest, RpcResponse, RpcResult, ClientRequest, ServerResponse, RpcMessage, SessionId, SessionEvent, ContentBlock, StreamChunk, } from "./api.js";
export { RpcId, transportError, } from "./api.js";
export type { ConnectionRecoveryConfig, ConnectionGeneration, ConnectionGenerationSource, ConnectionHostInfo, ConnectionSinks, ConnectionState, } from "./connection.js";
export type { ClientConnectionRpc, ConnectionRpcFailure, ConnectionRpcResult, } from "../rpc.js";
export type { RpcFetch, RpcFetchResponse } from "./rpc.js";
export type { ConnectionGenerationState, ConnectionHandle, ConnectionLoop, ConnectionStateSource, } from "./handle.js";
/** Required services (none — this is the wire root). */
export declare const inject: string[];
/**
 * Carrier override installed on the page global before plugin boot. The served
 * web app leaves it unset and gets HTTP + WebSocket; a shell that owns a
 * different physical transport (the worker preview's postMessage tunnel)
 * provides both halves here instead of forking this plugin.
 */
export interface ClientTransportHooks {
    /** Transport for generic unary RPC channels (the Typert gateway). */
    fetch: RpcFetch;
    /** Worker-local Gateway stream carrier; absent when the page uses the Gateway WebSocket. */
    openStream?: RpcStreamOpen;
    /**
     * Bundle transport for the module system, present when the carrier also owns
     * bundle bytes (the worker tunnel). Absent in the served web app, whose
     * bundles load over HTTP.
     */
    loadBundle?(url: string): Promise<void>;
    /**
     * The transport owner declares the page owns the Host outright: the Host
     * runs inside a worker this page spawned, so no other party can reach it and
     * the loopback stand-in for "the operator's own machine" is vacuous.
     * `ctx.connection.isLoopback` then reports the privileged surface reachable
     * regardless of the page authority. Only a shell that assembles its own
     * transport can set this; served pages never carry the global at all.
     */
    ownsHost?: boolean;
}
/**
 * Mount the shared Connection with browser fixture, transport, and network inputs.
 * @param ctx - client Cordis context.
 */
export declare function apply(ctx: Context): void;
export { readHostIdentity } from "./host-identity.js";
export type { ConnectionIdentity, ConnectionHostId, ConnectionActivationId } from "../host-identity-protocol.js";
export { connectionIdentitySchema, connectionHostIdSchema } from "../host-identity-protocol.js";
export { claimDeviceEnrollment } from "./device-access.js";
export type { DeviceEnrollmentClaimOptions } from "./device-access.js";
export type { ConnectionDeviceId, ConnectionDeviceCredential, ConnectionDeviceInfo, ConnectionDeviceEnrollment, ConnectionDeviceGrant } from "../device-protocol.js";
export { connectionDeviceGrantSchema, connectionDeviceEnrollmentSchema, DEVICE_ACCESS_PATHS } from "../device-protocol.js";
export type { DeviceAdministrationService, DeviceAdministrationSnapshot, DeviceAdministrationError } from "./device-administration.js";
