import type { ConnectionHostId } from "../host-identity-protocol.js";
import { type HostDiscoveryResult } from "../discovery-protocol.js";
import type { ClientConnectionRpc, ConnectionRpcResult } from "../rpc.js";
/**
 * Discover candidate metadata without retrying, enrolling, or transferring credentials.
 * @param rpc - authenticated transport to one assisting Host.
 * @param expectedHostId - paired assisting Host whose response is acceptable.
 * @param signal - caller lifetime forwarded to the transport.
 * @returns validated metadata or a fixed failure; unavailable endpoints remain optional.
 */
export declare function discoverHosts(rpc: ClientConnectionRpc, expectedHostId: ConnectionHostId, signal?: AbortSignal): Promise<ConnectionRpcResult<HostDiscoveryResult>>;
