/** Public candidate metadata and authenticated Host-assisted discovery responses. */
import { z } from 'zod';
import type { Branded } from '@deepseek-ai/dsh-brand';
/** Canonical HTTP origin on a numeric Tailscale address; never an authorization fact. */
export type TailnetOrigin = Branded<'connection-tailnet-origin'>;
/** Exact opt-in public advertisement path. */
export declare const HOST_ADVERTISEMENT_PATH = "/api/connection/discovery/advertisement";
/** Authenticated Connection endpoint; discovery remains optional for Session clients. */
export declare const HOST_DISCOVERY_ENDPOINT = "connection/discovery";
/** Version-one wire bound, independent of lower deployment scan limits. */
export declare const MAX_DISCOVERY_CANDIDATES = 256;
/**
 * Classify canonical numeric addresses without DNS or URL normalization aliases.
 * @param address - raw Tailscale status address, without brackets or a zone id.
 * @returns whether the address belongs to Tailscale's IPv4 or IPv6 allocation.
 */
export declare function isTailnetAddress(address: string): boolean;
/** Validate probe-derived origins without accepting peer-supplied paths or credentials. */
export declare const tailnetOriginSchema: z.ZodPipe<z.ZodString, z.ZodTransform<TailnetOrigin, string>>;
/** Anonymous correlation claims only; no URLs, grants, or enrollment challenges. */
export declare const hostAdvertisementSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    identity: z.ZodObject<{
        version: z.ZodLiteral<1>;
        hostId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionHostId, string>>;
        activationId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionActivationId, string>>;
    }, z.core.$strict>;
    label: z.ZodString;
}, z.core.$strict>;
/** Complete metadata supplied by an opt-in Host. */
export type HostAdvertisement = z.infer<typeof hostAdvertisementSchema>;
/** A probe-derived address with untrusted advertised identity and display label. */
export declare const hostDiscoveryCandidateSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    identity: z.ZodObject<{
        version: z.ZodLiteral<1>;
        hostId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionHostId, string>>;
        activationId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionActivationId, string>>;
    }, z.core.$strict>;
    label: z.ZodString;
    origin: z.ZodPipe<z.ZodString, z.ZodTransform<TailnetOrigin, string>>;
}, z.core.$strict>;
/** Candidate metadata never authorizes a device or transfers another Host's grant. */
export type HostDiscoveryCandidate = z.infer<typeof hostDiscoveryCandidateSchema>;
/** Exact empty request: callers cannot supply scan targets or credentials. */
export declare const hostDiscoveryRequestSchema: z.ZodObject<{}, z.core.$strict>;
/** Version-one response, including its authenticated assisting Host. */
export declare const hostDiscoveryResultSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    host: z.ZodObject<{
        version: z.ZodLiteral<1>;
        hostId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionHostId, string>>;
        activationId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionActivationId, string>>;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        ready: "ready";
        "tailscale-unavailable": "tailscale-unavailable";
        "tailscale-disconnected": "tailscale-disconnected";
        "scan-failed": "scan-failed";
    }>;
    truncated: z.ZodBoolean;
    candidates: z.ZodArray<z.ZodObject<{
        version: z.ZodLiteral<1>;
        identity: z.ZodObject<{
            version: z.ZodLiteral<1>;
            hostId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionHostId, string>>;
            activationId: z.ZodPipe<z.ZodString, z.ZodTransform<import("./host-identity-protocol.js").ConnectionActivationId, string>>;
        }, z.core.$strict>;
        label: z.ZodString;
        origin: z.ZodPipe<z.ZodString, z.ZodTransform<TailnetOrigin, string>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Bounded scan result; absence does not prove that no other Host exists. */
export type HostDiscoveryResult = z.infer<typeof hostDiscoveryResultSchema>;
