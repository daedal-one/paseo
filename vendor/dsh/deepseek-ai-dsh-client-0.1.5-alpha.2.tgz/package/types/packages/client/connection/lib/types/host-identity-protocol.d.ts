/** Host correlation values shared by authenticated Connection carriers. */
import { z } from 'zod';
import type { Branded } from '@deepseek-ai/dsh-brand';
/** Durable identity of one credential store; copying the store copies this id. */
export type ConnectionHostId = Branded<'connection-host-id'>;
/** Identity of one application root, retained across Connection reloads. */
export type ConnectionActivationId = Branded<'connection-activation-id'>;
/** Correlation facts only; version describes this envelope, not API compatibility. */
export interface ConnectionIdentity {
    readonly version: 1;
    readonly hostId: ConnectionHostId;
    readonly activationId: ConnectionActivationId;
}
/** Validate a persisted or transferred Host reference without inventing an activation. */
export declare const connectionHostIdSchema: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionHostId, string>>;
/** Durable owner payload; signing secrets have a separate credential record. */
export declare const storedHostIdentitySchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    hostId: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionHostId, string>>;
}, z.core.$strict>;
/** Exact identity response accepted at the Client wire boundary. */
export declare const connectionIdentitySchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    hostId: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionHostId, string>>;
    activationId: z.ZodPipe<z.ZodString, z.ZodTransform<ConnectionActivationId, string>>;
}, z.core.$strict>;
/** Identity reads carry no arguments. */
export declare const connectionIdentityRequestSchema: z.ZodObject<{}, z.core.$strict>;
/** Connection-owned endpoint shared by Host registration and portable callers. */
export declare const CONNECTION_IDENTITY_ENDPOINT = "connection/identity";
