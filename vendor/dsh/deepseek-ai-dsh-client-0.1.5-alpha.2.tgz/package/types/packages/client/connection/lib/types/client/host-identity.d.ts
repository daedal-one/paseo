import { type ConnectionIdentity } from "../host-identity-protocol.js";
import type { ClientConnectionRpc, ConnectionRpcResult } from "../rpc.js";
/**
 * Read correlation facts without retrying or treating them as authorization.
 * @param rpc - authenticated carrier for the selected Host.
 * @param signal - caller lifetime forwarded to the transport.
 * @returns validated identity or the Host failure; transport rejection propagates.
 */
export declare function readHostIdentity(rpc: ClientConnectionRpc, signal?: AbortSignal): Promise<ConnectionRpcResult<ConnectionIdentity>>;
