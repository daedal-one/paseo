/** Shared Connection API for native, browser, and shell-owned transports. */
export { createConnection } from "./handle.js";
export type { ConnectionGenerationState, ConnectionHandle, ConnectionLoop, ConnectionNetworkSource, ConnectionOptions, ConnectionStateSource, } from "./handle.js";
export { createConnectionRpc } from "./rpc-caller.js";
export type { ConnectionRpcOptions, RpcFetch, RpcFetchResponse, RpcStreamOpen } from "./rpc-caller.js";
export type { ConnectionRecoveryConfig, ConnectionGeneration, ConnectionGenerationSource, ConnectionHostInfo, ConnectionSinks, ConnectionState, } from "./connection.js";
export { RpcId, transportError } from "../rpc.js";
export type { ClientConnectionRpc, ConnectionRpcFailure, ConnectionRpcResult } from "../rpc.js";
export * from "./device-api.js";
