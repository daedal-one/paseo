/** Shared Connection API for native, browser, and shell-owned transports. */
export { createConnection } from "./handle.js";
export type { ConnectionGenerationState, ConnectionHandle, ConnectionLoop, ConnectionNetworkSource, ConnectionOptions, ConnectionStateSource, } from "./handle.js";
export { createConnectionRpc } from "./rpc-caller.js";
export type { ConnectionRpcOptions, RpcFetch, RpcFetchResponse, RpcStreamOpen } from "./rpc-caller.js";
export type { ConnectionRecoveryConfig, ConnectionGeneration, ConnectionGenerationSource, ConnectionHostInfo, ConnectionSinks, ConnectionState, } from "./connection.js";
export { RpcId, transportError } from "../rpc.js";
export type { ClientConnectionRpc, ConnectionRpcFailure, ConnectionRpcResult } from "../rpc.js";
export { readHostIdentity } from "./host-identity.js";
export type { ConnectionIdentity, ConnectionHostId, ConnectionActivationId } from "../host-identity-protocol.js";
export { connectionIdentitySchema, connectionHostIdSchema } from "../host-identity-protocol.js";
export { claimDeviceEnrollment } from "./device-access.js";
export type { DeviceEnrollmentClaimOptions } from "./device-access.js";
export type { ConnectionDeviceId, ConnectionDeviceCredential, ConnectionDeviceInfo, ConnectionDeviceEnrollment, ConnectionDeviceGrant } from "../device-protocol.js";
export { connectionDeviceGrantSchema, connectionDeviceEnrollmentSchema, DEVICE_ACCESS_PATHS } from "../device-protocol.js";
