/** Renderer-independent approval requests for native and browser composition. */
export { PendingApproval } from "./pending-approval.js";
export type { ApprovalDecision, ApprovalPresentationRequest } from "./pending-approval.js";
export { registerApprovalRequests } from "./requests.js";
