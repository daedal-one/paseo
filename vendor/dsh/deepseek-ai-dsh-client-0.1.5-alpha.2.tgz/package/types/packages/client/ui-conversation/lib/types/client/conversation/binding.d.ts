/** Portable event-window subscription and publication for Conversation targets. */
import type { SessionEventSource } from "../../../../../../api/session-controller/lib/types/client/index.js";
import { type ObservableSnapshot } from "../../../../../store/lib/types/index.js";
import type { ConversationViewSnapshotMap } from "../contract/conversation.js";
import type { ConversationSnapshot } from "../contract/snapshot.js";
import type { ConversationNodeAssembler } from "./assembler.js";
/** Platform-owned deferred publication. Each callback runs at most once and never synchronously. */
export interface ConversationScheduler {
    /**
     * @param publish - callback scheduled after this call returns.
     * @returns cancellation for queued work; a racing late callback is ignored by the binding.
     */
    schedule(publish: () => void): () => void;
}
/** Observable faces published for one Session's Conversation assembly. */
export interface ConversationBinding {
    readonly snapshot: ObservableSnapshot<ConversationSnapshot>;
    /**
     * Add one selected target to the Session's monotonic active set.
     * @param target - registered or subsequently registered Conversation target.
     */
    activate(target: string): void;
    /**
     * Resolve one target-owned snapshot source.
     * The first subscriber activates the target unless shell selection already
     * activated it; activation lasts for the remaining Session lifetime.
     * @param target - registered Conversation target.
     * @returns identity-stable source following the target.
     */
    target<Target extends Extract<keyof ConversationViewSnapshotMap, string>>(target: Target): ObservableSnapshot<ConversationViewSnapshotMap[Target] | undefined>;
}
/** One portable Session event-window owner with platform-supplied publication timing. */
export declare class ConversationBindingModel implements ConversationBinding {
    private readonly assembler;
    private readonly scheduler;
    readonly snapshot: ObservableSnapshot<ConversationSnapshot>;
    private readonly store;
    private readonly viewStore;
    private readonly targetSources;
    private revision;
    private cancelPublication;
    private publicationEpoch;
    private disposed;
    private readonly disposeFeed;
    /**
     * @param feed - shared contiguous Session window; this binding never opens a transport.
     * @param assembler - exclusively owned assembler with the selected Definitions.
     * @param scheduler - deferred streaming publication, or null for immediate publication.
     */
    constructor(feed: SessionEventSource, assembler: ConversationNodeAssembler, scheduler: ConversationScheduler | null);
    /** @param target - registered target key. @returns identity-stable target source. */
    target<Target extends Extract<keyof ConversationViewSnapshotMap, string>>(target: Target): ObservableSnapshot<ConversationViewSnapshotMap[Target] | undefined>;
    /** @param target - target to activate for this binding; ignored after disposal. */
    activate(target: string): void;
    /** Rebuild contributed Definitions while retaining this binding and target sources. */
    rebuild(): void;
    /** Detach the source and cancel publication; retained snapshots remain readable. Idempotent. */
    dispose(): void;
    private replace;
    private accept;
    private publish;
    private cancelScheduled;
    private flush;
    private currentSnapshot;
}
