/** Shared Trajectory composition, data and layout without browser rendering. */
export { registerTrajectoryConversation } from "./register.js";
export type { TrajectoryConversationRegistration } from "./register.js";
export { EMPTY_TRAJECTORY_SNAPSHOT } from "./trajectory-snapshot-builder.js";
export type * from "./trajectory-contract.js";
export { deriveTrajectoryLayout, appendTrajectoryPartialLayout } from "./layout.js";
export type * from "./layout.js";
export { deriveTrajectoryTimeline, trajectoryTimelineFocusIndexes, formatTimelineOffset } from "./timeline.js";
export type * from "./timeline.js";
export { trajectoryRecordId, formatDurationMillis, formatElapsedSeconds } from "./trajectory-record.js";
export type * from "./trajectory-record.js";
export type { TrajectoryKey, TrajectoryLayoutTranslate } from "./trajectory-labels.js";
export { en as trajectoryEnglish } from "./trajectory-labels.js";
