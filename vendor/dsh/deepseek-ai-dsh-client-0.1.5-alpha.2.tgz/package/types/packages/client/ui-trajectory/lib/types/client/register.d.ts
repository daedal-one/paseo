/** Renderer-independent registration of the shared Trajectory projection. */
import type { ConversationEventRegistry, ConversationViewRegistry, RequestPromptInspector, SystemPromptInspector } from "../../../../ui-conversation/lib/types/client/portable.js";
/** Caller-owned registries and exact recorded-prompt interpreters. */
export interface TrajectoryConversationRegistration {
    readonly events: Pick<ConversationEventRegistry, 'register'>;
    readonly views: Pick<ConversationViewRegistry, 'register'>;
    readonly inspectSystemPrompt: SystemPromptInspector;
    readonly inspectRequestPrompt: RequestPromptInspector;
}
/**
 * Register Trajectory definitions and its incremental snapshot for the registry owner's lifetime.
 * @param conversation - Scoped registries and shared prompt interpreters.
 */
export declare function registerTrajectoryConversation(conversation: TrajectoryConversationRegistration): void;
