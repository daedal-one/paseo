import type { ClientRemote } from "../../../../../api/remotes/lib/types/client/index.js";
import type { ISessions } from "../../../../../api/session-controller/lib/types/client/index.js";
import type { PendingInteractionPublisher } from "../../../../ui-session/lib/types/client/contract/pending-interactions.js";
import { PendingQuestion } from "./pending-question.js";
/**
 * Register question delivery and its pending domain in the same caller-owned fiber.
 * The Remote service and domain registrar must belong to that fiber; its teardown
 * withdraws requests and waits for delegation before completing.
 * @param remote - Caller-scoped generated Remote service.
 * @param sessions - Session owner that resolves each delivered request's Context.
 * @param registerPendingInteraction - Caller-owned domain registration.
 */
export declare function registerQuestionRequests(remote: Pick<ClientRemote, '$on'>, sessions: Pick<ISessions, 'scopeOf'>, registerPendingInteraction: (precedence: (interaction: PendingQuestion) => number) => PendingInteractionPublisher<PendingQuestion>): void;
