/** Shared pending-interaction ownership without browser rendering or Session transport. */
import type { Context } from '@deepseek-ai/cordis';
import { type ObservableSnapshot } from "../../../../store/lib/types/index.js";
import type { PendingInteractionPublisher, SessionPendingInteractionBase, SessionPendingInteractionSnapshot } from "./contract/pending-interactions.js";
/** Per-Host registry of effect-owned pending requests, shared across presentation targets. */
export declare class PendingInteractions {
    private readonly pendingDomains;
    private pendingSnapshot;
    private readonly pendingListeners;
    /** Root source of pending UI interactions, independent from Controller snapshots. */
    readonly source: ObservableSnapshot<SessionPendingInteractionSnapshot>;
    /**
     * Register one pending-interaction domain and return its publication function.
     * Domain teardown first removes its visible values, then delegates and awaits
     * every still-active owner request.
     * Released domains reject subsequent publication.
     * @param ctx - Contributing plugin context that owns domain teardown.
     * @param precedence - deterministic cross-domain precedence; larger values win.
     * @returns a function that publishes one interaction and its teardown delegation.
     */
    register<T extends SessionPendingInteractionBase>(ctx: Context, precedence: (interaction: T) => number): PendingInteractionPublisher<T>;
    private publishPendingInteractions;
}
