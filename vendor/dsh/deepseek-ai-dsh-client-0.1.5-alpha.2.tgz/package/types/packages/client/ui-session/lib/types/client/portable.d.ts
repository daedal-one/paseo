/** Ordinary ESM pending-interaction ownership without browser Slots or React. */
export { PendingInteractions } from "./pending-interactions.js";
export type * from "./contract/pending-interactions.js";
