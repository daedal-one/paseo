import type { ConversationEventRegistry, ConversationViewRegistry, RequestPromptInspector, SystemPromptInspector } from "../../../../../ui-conversation/lib/types/client/portable.js";
/** Effect-owned registration and pure prompt inspection required by the Chat target. */
export interface ChatConversationRegistration {
    readonly events: Pick<ConversationEventRegistry, 'register' | 'registerFallback'>;
    readonly views: Pick<ConversationViewRegistry, 'register'>;
    readonly inspectSystemPrompt: SystemPromptInspector;
    readonly inspectRequestPrompt: RequestPromptInspector;
}
/**
 * Install the Chat business Definitions and snapshot builder for the registry owner's lifetime.
 * Duplicate contribution names fail through the registry; the caller owns registration-scope disposal.
 * @param conversation - scoped registries and the shared prompt inspectors.
 */
export declare function registerConversationNodes(conversation: ChatConversationRegistration): void;
