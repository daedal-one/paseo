import type { ConversationNodeDefinition, TurnMaxTokensNode } from "../../../../../ui-conversation/lib/types/client/portable.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Turn ended by the per-request output-token cap. */
        'turn-max-tokens': TurnMaxTokensNode;
    }
}
interface TurnMaxTokensState {
    readonly turn: number;
    readonly seq: number;
    readonly time: number;
}
/** Notice Definition for a turn the provider ended at its output-token cap. */
export declare const turnMaxTokensDefinition: ConversationNodeDefinition<TurnMaxTokensState>;
export {};
