import type { ConversationNodeDefinition, ModelRetryNode } from "../../../../../ui-conversation/lib/types/client/portable.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Producer-correlated model retry chain. */
        'model-retry': RetryChatData;
    }
}
/** Accumulated retry attempts sharing one producer-owned RetryId. */
export interface RetryState {
    readonly turn: number;
    readonly step: number;
    readonly attempts: readonly ModelRetryNode[];
}
/** Producer-correlated model retry chain Definition. */
export declare const retryDefinition: ConversationNodeDefinition<RetryState>;
