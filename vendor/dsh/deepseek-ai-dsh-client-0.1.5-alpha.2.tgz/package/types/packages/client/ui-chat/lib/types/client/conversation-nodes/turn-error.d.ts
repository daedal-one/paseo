import type { ConversationNodeDefinition, TurnErrorNode } from "../../../../../ui-conversation/lib/types/client/portable.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Terminal turn failure recorded on the turn's end reason. */
        'turn-error': TurnErrorNode;
    }
}
interface TurnErrorState {
    readonly turn: number;
    readonly failure?: {
        readonly seq: number;
        readonly time: number;
        readonly message: string;
        readonly code?: string;
    };
}
/**
 * Terminal turn failure Definition. Retries run inside the failing turn, so the
 * turn's `llm/retry` history never suppresses this terminal row; the model-retry
 * node renders that history separately.
 */
export declare const turnErrorDefinition: ConversationNodeDefinition<TurnErrorState>;
export {};
