import type { AssistantMessageNode, ConversationNode } from "../../../../../ui-conversation/lib/types/client/portable.js";
/** Latency and end-to-end output-rate readings for one turn's footer. */
export interface TurnMetrics {
    /** First-step TTFT in ms; absent when that step carries no recorded timing. */
    ttftMs?: number;
    /** Output tokens per request second over steps carrying both timing and provider usage. */
    tokensPerSecond?: number;
}
/** One assistant step's derivable latency facts; null marks an unrecorded part. */
export interface StepReading {
    /** step/start → first token delta, in ms. */
    ttftMs: number | null;
    /** Request start → final message, in ms. */
    requestMs: number | null;
    /** Provider-reported completion tokens. */
    outputTokens: number | null;
}
type AssistantNode = AssistantMessageNode;
/**
 * Read one assistant node's TTFT, request wall time, and output tokens.
 * @param node - A settled assistant node.
 * @returns Per-part readings with `null` for unrecorded values.
 */
export declare function assistantStepReading(node: AssistantNode): StepReading;
/**
 * Fold assistant nodes into per-turn footer metrics.
 *
 * TTFT is the turn's lowest-step request-dispatch-to-first-token reading, so
 * it is only meaningful when the turn's start is inside
 * the loaded window (the caller gates on `turnTimings`, which shares that
 * window). Output rate divides summed output tokens by summed full request wall
 * time, counting only steps that carry both. Chunk-arrival spans are excluded:
 * a buffered transport can drain generated chunks much faster than the model
 * produced them.
 * @param nodes - Snapshot nodes of the loaded window.
 * @returns Turn number → available metrics; turns with none are absent.
 */
export declare function deriveTurnMetrics(nodes: readonly ConversationNode[]): Map<number, TurnMetrics>;
export {};
