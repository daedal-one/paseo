import type { ConversationNodeDefinition, UnknownSurfaceNode } from "../../../../../ui-conversation/lib/types/client/portable.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Generic presentation of an unclaimed append-surface event. */
        unknown: UnknownSurfaceNode;
    }
}
/** Unclaimed append-surface fallback Definition. */
export declare const unknownFallbackDefinition: ConversationNodeDefinition<UnknownSurfaceNode>;
