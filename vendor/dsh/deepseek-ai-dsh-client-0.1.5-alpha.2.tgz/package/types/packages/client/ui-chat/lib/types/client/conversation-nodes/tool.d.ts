import type { ConversationNodeDefinition, ToolCallBlock } from "../../../../../ui-conversation/lib/types/client/portable.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Root Tool lifecycle with recursively nested subcalls. */
        'tool-call': ToolChatData;
    }
}
interface ToolState {
    readonly root: ToolCallBlock;
    readonly children: ReadonlyMap<string, readonly ToolCallBlock[]>;
    readonly parents: ReadonlyMap<string, string>;
}
/** Root Tool lifecycle and nested PTC dispatch Definition. */
export declare const toolDefinition: ConversationNodeDefinition<ToolState>;
export {};
