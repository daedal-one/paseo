import type { ConversationMatch, ConversationNodeDefinition } from "../../../../../ui-conversation/lib/types/client/portable.js";
import type { TurnTailChatData } from "../contract/chat-nodes.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Completed-turn actions and extension tail. */
        'turn-tail': TurnTailChatData;
    }
}
declare module "../../../../../ui-conversation/lib/types/client/contract/conversation.js" {
    interface ConversationTurnDataMap {
        /** Closing Assistant and footer facts derived for this completed Turn. */
        'turn-tail': TurnTailChatData;
    }
}
interface TurnTailState {
    readonly turn: number;
    readonly end?: ConversationMatch;
}
/** Completed-turn footer Definition independent of any Assistant row. */
export declare const turnTailDefinition: ConversationNodeDefinition<TurnTailState>;
export {};
