import type { AssistantBlock, ConversationMatch, ConversationNodeDefinition } from "../../../../../ui-conversation/lib/types/client/portable.js";
import type { AssistantChatData } from "../contract/chat-nodes.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Streaming, settled, or interrupted Assistant step. */
        'assistant-step': AssistantChatData;
    }
}
declare module "../../../../../ui-conversation/lib/types/client/contract/conversation.js" {
    interface ConversationStepDataMap {
        /** Streaming, settled, or interrupted Assistant material for this Step. */
        'assistant-step': AssistantChatData;
    }
}
interface AssistantState {
    readonly turn: number;
    readonly step: number;
    readonly blocks: readonly (AssistantBlock | undefined)[];
    readonly visibleBlocks: number;
    readonly firstVisibleSeq: number | undefined;
    readonly firstVisibleTime: number | undefined;
    readonly firstTokenTime: number | undefined;
    readonly hidden: boolean;
    readonly final: ConversationMatch | undefined;
    readonly usage: unknown;
}
/** Per-step Assistant streaming/final/interruption Definition. */
export declare const assistantDefinition: ConversationNodeDefinition<AssistantState>;
export {};
