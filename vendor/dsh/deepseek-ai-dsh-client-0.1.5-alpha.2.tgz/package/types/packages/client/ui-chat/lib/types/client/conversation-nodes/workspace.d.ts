import type { ConversationNodeDefinition } from "../../../../../ui-conversation/lib/types/client/portable.js";
import type { WorkspaceState } from "../../../../../../sandbox/local-container-runtime/lib/types/workspace-types.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Workspace save outcome, separate from the model's turn result. */
        'workspace-state': WorkspaceState;
    }
}
/** Turn-local save progress and the final branch-return receipt. */
export declare const workspaceDefinition: ConversationNodeDefinition<WorkspaceState | null>;
