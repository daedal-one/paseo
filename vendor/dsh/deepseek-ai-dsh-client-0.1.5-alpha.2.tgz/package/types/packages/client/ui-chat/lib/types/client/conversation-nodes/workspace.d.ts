import type { ConversationNodeDefinition } from "../../../../../ui-conversation/lib/types/client/portable.js";
import type { WorkspaceAdmissionState, WorkspaceState } from "../../../../../../sandbox/local-container-runtime/lib/types/workspace-types.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Workspace save outcome, separate from the model's turn result. */
        'workspace-state': WorkspaceState;
        /** Pending workspace execution capacity or its failure. */
        'workspace-admission': WorkspaceAdmissionState;
    }
}
/** Turn-local save progress and the final branch-return receipt. */
export declare const workspaceDefinition: ConversationNodeDefinition<WorkspaceState | null>;
/** Waiting work remains visible before its first turn and model request. */
export declare const workspaceAdmissionDefinition: ConversationNodeDefinition<WorkspaceAdmissionState | null>;
