import type { ConversationNodeDefinition } from "../../../../../ui-conversation/lib/types/client/portable.js";
import { type TurnProcessSpec } from "../contract/turn-process.js";
declare module "../contract/chat-nodes.js" {
    interface ChatNodeDataMap {
        /** Turn-level disclosure controlling process rows before the finalized answer. */
        'turn-process': import("../contract/chat-nodes.js").TurnProcessChatData;
    }
}
declare module "../../../../../ui-conversation/lib/types/client/contract/conversation.js" {
    interface ConversationTurnDataMap {
        /** Process range and finalized answer boundary for this Turn. */
        'turn-process': TurnProcessSpec;
    }
}
interface TurnProcessState {
    readonly turn: number;
    readonly assistantStartByStep: ReadonlyMap<number, number>;
    readonly messageCountByStep: ReadonlyMap<number, number>;
    readonly otherStartSeq?: number;
    readonly controlAnchorSeq?: number;
    readonly messageCount: number;
    readonly toolCallCount: number;
    readonly subagentCount: number;
}
/** Turn-scoped process range and answer-boundary Definition. */
export declare const turnProcessDefinition: ConversationNodeDefinition<TurnProcessState>;
export {};
