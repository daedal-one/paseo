/** Immutable publication and Workspace artifact vocabulary. @module */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { SessionId } from "../../../../core/session/lib/types/types.js";
import type { WorkspaceId } from "../../../../workspace/workspace/lib/types/types.js";
import type { FileAttachmentRef } from "../../../../attachment/attachment/lib/types/types.js";
/** Host-assigned artifact identity; never a storage path or bearer credential. */
export type ArtifactId = Branded<'ArtifactId'>;
/** Host-assigned immutable revision identity. */
export type ArtifactRevisionId = Branded<'ArtifactRevisionId'>;
/** Caller retry identity scoped to its creating Session. */
export type ArtifactOperationId = Branded<'ArtifactOperationId'>;
/** Closed execution policy; unknown policies are refused. */
export type ArtifactProfile = 'document' | 'interactive-local';
/** One immutable, explicitly published asset. */
export interface ArtifactAsset {
    readonly name: string;
    readonly mediaType: string;
    readonly sha256: string;
    readonly file: FileAttachmentRef;
}
/** Project identity checked by the procedure publication authority. */
export type ArtifactProjectId = Branded<'ArtifactProjectId'>;
/** Task identity retained by the procedure owner. */
export type ArtifactTaskId = Branded<'ArtifactTaskId'>;
/** Invocation identity retained by the procedure owner. */
export type ArtifactInvocationId = Branded<'ArtifactInvocationId'>;
/** Principal supplied by the trusted procedure consumer. */
export type ArtifactPrincipalId = Branded<'ArtifactPrincipalId'>;
/** Exact non-Session producer attribution; installing the authority grants no rights by itself. */
export type ArtifactProcedureAttribution = {
    readonly workspaceId: WorkspaceId;
    readonly project: ArtifactProjectId;
    readonly task: ArtifactTaskId;
    readonly invocation: ArtifactInvocationId;
    readonly producer: ArtifactPrincipalId;
    readonly inputDigest: string;
    readonly expectedInvocationRevision: number;
};
/** Revision fields shared by real Session and deterministic procedure publication. */
interface ArtifactRevisionFields {
    readonly artifactId: ArtifactId;
    readonly revisionId: ArtifactRevisionId;
    readonly workspaceId: WorkspaceId;
    readonly operationId: ArtifactOperationId;
    readonly parent: ArtifactRevisionId | null;
    readonly restoredFrom: ArtifactRevisionId | null;
    readonly title: string;
    readonly entry: string;
    readonly profile: ArtifactProfile;
    readonly capabilities: readonly ['published-assets', 'transient-input'] | readonly ['published-assets'];
    readonly assets: readonly ArtifactAsset[];
    readonly createdAt: string;
}
/** Historical Session publications retain their existing serialized representation. */
export type ArtifactSessionRevision = ArtifactRevisionFields & {
    readonly sessionId: SessionId;
    readonly procedure?: never;
};
/** Procedure publications have no fabricated Session or Session event. */
export type ArtifactProcedureRevision = ArtifactRevisionFields & {
    readonly sessionId: null;
    readonly procedure: ArtifactProcedureAttribution;
};
/** Complete immutable revision and its durable provenance. */
export type ArtifactRevision = ArtifactSessionRevision | ArtifactProcedureRevision;
/** Procedure-owned durable publication evidence; catalogue commits may be reconstructed from it. */
export type ArtifactProcedureReceipt = {
    readonly revision: ArtifactProcedureRevision;
    readonly fingerprint: string;
    readonly chargedBytes: number;
};
/** Inline asset input; publication never discovers files or follows URLs. */
export interface ArtifactAssetInput {
    readonly name: string;
    readonly mediaType: string;
    readonly data: string;
}
/** A complete proposed revision, with explicit optimistic concurrency. */
export interface ArtifactPublish {
    readonly operationId: ArtifactOperationId;
    readonly artifactId: ArtifactId | null;
    readonly expectedHead: ArtifactRevisionId | null;
    readonly title: string;
    readonly entry: string;
    readonly profile: ArtifactProfile;
    readonly assets: readonly ArtifactAssetInput[];
}
/** New head plus the number of retained immutable revisions. */
export interface ArtifactSummary {
    readonly head: ArtifactRevision;
    readonly revisionCount: number;
}
/** Bounded deterministic catalogue page; cursor belongs to this Workspace. */
export interface ArtifactPage {
    readonly items: readonly ArtifactSummary[];
    readonly next: ArtifactId | null;
}
/** Interrupted operation retained until explicit reconciliation. */
export interface ArtifactPending {
    readonly artifactId: ArtifactId;
    readonly revisionId: ArtifactRevisionId;
    readonly sessionId: SessionId | null;
    readonly procedure?: ArtifactProcedureAttribution;
    readonly operationId: ArtifactOperationId;
    readonly createdAt: string;
}
/** Verified complete bytes of one explicitly selected revision asset. */
export interface ArtifactContent {
    readonly revision: ArtifactRevision;
    readonly asset: ArtifactAsset;
    readonly data: string;
}
declare module "../../../../core/session/lib/types/types.js" {
    interface SessionEventMap {
        /** Complete publication manifest; bytes precede this durable event. */
        'artifact/published': {
            readonly revision: ArtifactSessionRevision;
        };
    }
}
export {};
