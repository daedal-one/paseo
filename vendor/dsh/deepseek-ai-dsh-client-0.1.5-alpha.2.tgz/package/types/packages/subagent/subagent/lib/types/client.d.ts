/**
 * Browser-safe subagent projection and control vocabulary.
 *
 * @module @deepseek-ai/dsh-subagent/client
 */
export type * from "./control-types.js";
export type { SubagentCatalogEntry, SubagentIdentityProjection, SubagentTimingProjection } from "./projection-types.js";
