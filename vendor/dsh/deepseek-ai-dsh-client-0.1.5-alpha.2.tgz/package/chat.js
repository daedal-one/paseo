//#region lib/types/client/conversation-nodes/common.js
/**
* Relative positions in one durable event's seq neighborhood: interrupted
* Assistant, its follow-up Nodes, then follow-ups to an ordinary final. The
* max-tokens notice sits between a closing Assistant and the turn-tail so the
* tail stays the turn's last node and keeps its branch action enabled.
*/
const CHAT_SYNTHETIC_SEQ_OFFSETS = {
	interruptedAssistant: -.9,
	interruptedFollowup: -.8,
	processControl: -.1,
	maxTokensNotice: .05,
	finalizedFollowup: .1
};
/**
* Resolve one Context's best currently loaded event Location.
* @param context - assembled business Context.
* @returns start or first-match Location, otherwise unresolved.
*/
function contextLocation(context) {
	return context.start?.location ?? context.matches[0]?.location ?? { kind: "unresolved" };
}
/**
* Build one final Chat target Node with the engine-owned stable key.
* @param context - assembled business Context.
* @param kind - Chat renderer dispatch key.
* @param anchorSeq - sortable render position.
* @param data - renderer-owned payload.
* @param options - optional Location and visibility overrides.
* @returns final Chat view Node.
*/
function chatNode(context, kind, anchorSeq, data, options = {}) {
	return {
		key: context.key,
		kind,
		id: context.id,
		target: "chat",
		anchorSeq,
		location: options.location ?? contextLocation(context),
		visibility: options.visibility ?? "visible",
		data
	};
}
//#endregion
//#region lib/types/client/conversation-nodes/event-projection.js
/** Chat-owned conversion from durable Session events to Chat view data. */
function asRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value) ? value : null;
}
function readString(record, key) {
	const value = record[key];
	return typeof value === "string" && value.length > 0 ? value : null;
}
function collect(source, member, field) {
	const list = source[member];
	if (!Array.isArray(list)) return [];
	const seen = [];
	for (const entry of list) {
		const record = asRecord(entry);
		const value = record === null ? null : readString(record, field);
		if (value !== null && !seen.includes(value)) seen.push(value);
	}
	return seen;
}
function joined(names) {
	return names.length > 0 ? names.join(", ") : null;
}
/** Forms Chat presents structurally; unknown merge-extensible values remain opaque. */
const KNOWN_FORMS = [
	"instructions",
	"catalog",
	"snapshot",
	"notice",
	"relay",
	"recall"
];
/**
* Read the target-supported presentation form from a durable message source.
* @param source - Logged `user/message` source.
* @returns Supported form, or null for the opaque presentation.
*/
function contextForm(source) {
	const record = asRecord(source);
	const form = record === null ? null : readString(record, "form");
	return form !== null && KNOWN_FORMS.includes(form) ? form : null;
}
/**
* Project a durable message source to the Chat row's role and producer label.
* @param source - Logged `user/message` source.
* @returns Role and label rendered by Chat.
*/
function contextProvenance(source) {
	const record = asRecord(source);
	const kind = record === null ? null : readString(record, "kind");
	if (record === null || kind === null) return {
		role: "inject",
		label: null
	};
	switch (kind) {
		case "session-reference": return {
			role: "recall",
			label: joined(collect(record, "references", "label")) ?? kind
		};
		case "agent-instructions": return {
			role: "inject",
			label: joined(collect(record, "changes", "path")) ?? kind
		};
		case "plugin": return {
			role: "inject",
			label: readString(record, "plugin") ?? kind
		};
		case "skill-invocation": return {
			role: "inject",
			label: readString(record, "name") ?? kind
		};
		default: return {
			role: "inject",
			label: kind
		};
	}
}
/**
* Read distinct labels cited by a durable cross-session recall source.
* @param source - Logged `user/message` source.
* @returns Labels in first-seen order.
*/
function sessionRecallLabels(source) {
	const record = asRecord(source);
	if (record === null || readString(record, "kind") !== "session-reference") return [];
	return collect(record, "references", "label");
}
/**
* Read the skill name a durable skill-invocation injection loaded.
* @param source - Logged `user/message` source.
* @returns The skill name, or null for every other source.
*/
function skillInvocationName(source) {
	const record = asRecord(source);
	if (record === null || readString(record, "kind") !== "skill-invocation") return null;
	return readString(record, "name");
}
/**
* Classify finalized Assistant content for Chat rendering.
* @param content - Core content blocks.
* @returns Chat blocks in source order.
*/
function toAssistantBlocks(content) {
	return content.map(toAssistantBlock);
}
/**
* Classify one finalized Assistant block for Chat rendering.
* @param block - Core content block.
* @returns Chat block.
*/
function toAssistantBlock(block) {
	switch (block.type) {
		case "text": return {
			kind: "text",
			text: block.text
		};
		case "reasoning": return {
			kind: "reasoning",
			text: block.text
		};
		case "image": return {
			kind: "image",
			attachment: block.attachment
		};
		case "tool-call": return {
			kind: "tool-call",
			callId: String(block.id),
			name: block.name,
			argsRaw: block.arguments
		};
		default: return {
			kind: "other",
			block
		};
	}
}
/**
* Create the initial Chat block for one streamed Assistant block kind.
* @param blockType - Wire block kind.
* @returns Empty block ready to receive deltas.
*/
function emptyAssistantBlock(blockType) {
	switch (blockType) {
		case "text": return {
			kind: "text",
			text: ""
		};
		case "reasoning": return {
			kind: "reasoning",
			text: ""
		};
		case "tool-call": return {
			kind: "tool-call",
			callId: "",
			name: "",
			argsRaw: ""
		};
		default: return {
			kind: "other",
			block: null
		};
	}
}
/**
* Convert a durable failure to locale-independent fields safe for Chat.
* @param failure - Failure preserved by a Session event.
* @returns Sanitized message and optional stable provider code.
*/
function displayFailure(failure) {
	if (failure === null || typeof failure !== "object") return { message: String(failure) };
	const record = failure;
	const code = typeof record.code === "string" ? record.code : void 0;
	if (code === "AUTH") return {
		code,
		message: ""
	};
	return {
		...code === void 0 ? {} : { code },
		message: typeof record.message === "string" ? record.message : JSON.stringify(failure)
	};
}
/**
* Whether a stream chunk carries visible model output for Chat timing.
* @param chunk - Stream chunk to inspect.
* @returns true for a non-empty text, reasoning, or Tool-call delta.
*/
function isTokenDelta(chunk) {
	switch (chunk.type) {
		case "text-delta":
		case "reasoning-delta": return chunk.text !== "";
		case "tool-call-delta": return chunk.argumentsDelta !== "" || chunk.name !== void 0;
		default: return false;
	}
}
//#endregion
//#region lib/types/client/conversation-nodes/assistant.js
function initialState(turn, step) {
	return {
		turn,
		step,
		blocks: [],
		visibleBlocks: 0,
		firstVisibleSeq: void 0,
		firstVisibleTime: void 0,
		firstTokenTime: void 0,
		hidden: false,
		final: void 0,
		usage: void 0
	};
}
function compactBlocks(blocks) {
	return blocks.filter((block) => block !== void 0);
}
function blockIsVisible(block) {
	if (block === void 0 || block.kind === "tool-call") return false;
	if (block.kind === "text" || block.kind === "reasoning") return block.text.trim() !== "";
	return true;
}
function countVisibleBlocks(blocks) {
	let count = 0;
	for (const block of blocks) if (blockIsVisible(block)) count++;
	return count;
}
function hasVisibleContent(blocks) {
	return blocks.some(blockIsVisible);
}
function hasInterruptionEvidence(blocks) {
	return blocks.some((block) => {
		if (block.kind === "text" || block.kind === "reasoning") return block.text.trim() !== "";
		return true;
	});
}
function resetForRetry(state) {
	return {
		...initialState(state.turn, state.step),
		firstTokenTime: state.firstTokenTime,
		hidden: true
	};
}
function updateChunk(state, chunk, seq, time) {
	const blocks = [...state.blocks];
	let changedIndex = -1;
	let previousVisible = false;
	switch (chunk.type) {
		case "block-start":
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(blocks[chunk.index]);
			blocks[chunk.index] = emptyAssistantBlock(chunk.blockType);
			break;
		case "text-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			blocks[chunk.index] = {
				kind: "text",
				text: (previous?.kind === "text" ? previous.text : "") + chunk.text
			};
			break;
		}
		case "reasoning-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			blocks[chunk.index] = {
				kind: "reasoning",
				text: (previous?.kind === "reasoning" ? previous.text : "") + chunk.text
			};
			break;
		}
		case "tool-call-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			const base = previous?.kind === "tool-call" ? previous : {
				kind: "tool-call",
				callId: "",
				name: "",
				argsRaw: ""
			};
			blocks[chunk.index] = {
				kind: "tool-call",
				callId: base.callId || String(chunk.id),
				name: chunk.name ?? base.name,
				argsRaw: base.argsRaw + chunk.argumentsDelta
			};
			break;
		}
		case "block-end":
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(blocks[chunk.index]);
			blocks[chunk.index] = toAssistantBlock(chunk.block);
			break;
		case "usage": return {
			...state,
			usage: chunk.usage
		};
		default: return state;
	}
	const visibleBlocks = state.visibleBlocks - Number(previousVisible) + Number(blockIsVisible(blocks[changedIndex]));
	const firstToken = isTokenDelta(chunk);
	return {
		...state,
		blocks,
		visibleBlocks,
		hidden: visibleBlocks > 0 ? false : state.hidden,
		...visibleBlocks > 0 && state.firstVisibleSeq === void 0 ? {
			firstVisibleSeq: seq,
			firstVisibleTime: time
		} : {},
		...firstToken && state.firstTokenTime === void 0 ? { firstTokenTime: time } : {}
	};
}
function settleMessage(state, match, event) {
	const blocks = toAssistantBlocks(event.data.message.content);
	return {
		...state,
		blocks,
		visibleBlocks: countVisibleBlocks(blocks),
		hidden: false,
		final: match,
		usage: event.data.usage
	};
}
function closedBoundary(location) {
	if (location.kind === "step" && location.step.status === "closed" && location.step.end !== void 0) return location.step.end;
	if ((location.kind === "step" || location.kind === "turn") && location.turn.status === "closed" && location.turn.end !== void 0) return location.turn.end;
}
function finalNode(state, context) {
	const final = state.final;
	if (final?.event.type === "assistant/message") {
		const event = final.event;
		return {
			kind: "assistant",
			seq: event.seq,
			messageId: event.data.message.id,
			time: event.time,
			turn: state.turn,
			step: state.step,
			blocks: toAssistantBlocks(event.data.message.content),
			usage: event.data.usage,
			timing: {
				stepStartTime: context.start?.event.time ?? null,
				firstTokenTime: state.firstTokenTime ?? null,
				completedTime: event.time
			},
			...event.data.interrupted === true ? { interrupted: true } : {}
		};
	}
	const location = context.start?.location ?? context.matches.at(-1)?.location;
	const boundary = location === void 0 ? void 0 : closedBoundary(location);
	if (boundary === void 0) return void 0;
	const blocks = compactBlocks(state.blocks);
	if (!hasInterruptionEvidence(blocks)) return void 0;
	return {
		kind: "assistant",
		seq: boundary.seq + CHAT_SYNTHETIC_SEQ_OFFSETS.interruptedAssistant,
		time: boundary.time,
		turn: state.turn,
		step: state.step,
		blocks,
		interrupted: true
	};
}
function fallbackState$5(context) {
	let state;
	for (const match of context.matches) {
		if (match.event.type === "assistant/live-chunk") {
			state ??= initialState(match.event.data.turn, match.event.data.step);
			state = updateChunk(state, match.event.data.chunk, match.event.seq, match.event.time);
			continue;
		}
		if (match.event.type === "assistant/message") {
			state ??= initialState(match.event.data.turn, match.event.data.step);
			state = settleMessage(state, match, match.event);
			continue;
		}
		if (match.event.type === "llm/retry" && state !== void 0) state = resetForRetry(state);
	}
	return state;
}
function projectAssistant(context) {
	const state = context.state ?? fallbackState$5(context);
	if (state === void 0) return void 0;
	const settled = finalNode(state, context);
	const blocks = settled?.blocks ?? compactBlocks(state.blocks);
	const visible = settled === void 0 ? state.visibleBlocks > 0 : hasVisibleContent(blocks);
	const status = settled?.interrupted === true ? "interrupted" : settled === void 0 ? "running" : "settled";
	const anchorSeq = settled?.seq ?? state.firstVisibleSeq ?? context.matches[0]?.event.seq ?? 0;
	const time = settled?.time ?? state.firstVisibleTime ?? context.matches[0]?.event.time ?? 0;
	return {
		anchorSeq,
		visible,
		settled,
		data: {
			status,
			turn: state.turn,
			step: state.step,
			blocks,
			time,
			...state.usage === void 0 ? {} : { usage: state.usage },
			...settled === void 0 ? {} : { finalNode: settled }
		}
	};
}
function publishedAssistantData(context) {
	const location = context.start?.location ?? context.matches.at(-1)?.location;
	return location?.kind === "step" ? location.step.data.get("assistant-step") : void 0;
}
/** Per-step Assistant streaming/final/interruption Definition. */
const assistantDefinition = {
	kind: "assistant-step",
	target: "chat",
	match: (event) => {
		if (event.type === "step/start") return {
			id: `${event.data.turn}:${event.data.step}`,
			role: "start"
		};
		if (event.type === "assistant/live-chunk" || event.type === "assistant/message" && event.surfaceOp === "append") return {
			id: `${event.data.turn}:${event.data.step}`,
			role: "update"
		};
		if (event.type === "llm/retry") return {
			id: `${event.data.turn}:${event.data.step}`,
			role: "update"
		};
		return null;
	},
	start: (_context, match) => {
		if (match.event.type !== "step/start") throw new Error("assistant-step start requires step/start");
		return initialState(match.event.data.turn, match.event.data.step);
	},
	update: (context, match) => {
		if (match.event.type === "assistant/live-chunk") return updateChunk(context.state, match.event.data.chunk, match.event.seq, match.event.time);
		if (match.event.type === "assistant/message") return settleMessage(context.state, match, match.event);
		if (match.event.type === "llm/retry") return resetForRetry(context.state);
		return context.state;
	},
	publication: (match) => {
		if (match.event.type === "step/start") return "none";
		if (match.event.type !== "assistant/live-chunk") return "immediate";
		const type = match.event.data.chunk.type;
		return type === "usage" || type === "finish" ? "none" : "animation-frame";
	},
	buildLocationData: (context, scope) => {
		if (scope !== "step") return null;
		const projected = projectAssistant(context);
		if (projected === void 0) return null;
		return {
			kind: "step",
			turn: projected.data.turn,
			step: projected.data.step,
			key: "assistant-step",
			value: projected.data
		};
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$5(context);
		if (state === void 0) return null;
		const data = publishedAssistantData(context);
		if (data === void 0) return null;
		const settled = data.finalNode;
		const visible = settled === void 0 ? state.visibleBlocks > 0 : hasVisibleContent(data.blocks);
		if (settled === void 0 && !visible) {
			const current = context.current.get("chat");
			if (!state.hidden || current === void 0 || current === null) return null;
		}
		return chatNode(context, "assistant-step", settled?.seq ?? state.firstVisibleSeq ?? context.matches[0]?.event.seq ?? 0, data, { visibility: settled?.interrupted === true || visible ? "visible" : "hidden" });
	}
};
//#endregion
//#region ../store/src/index.ts
/**
* Notify an observer set without allowing one callback to starve the rest.
* @param listeners - current observer callbacks; copied before dispatch.
* @param label - diagnostic owner prefix.
* @param args - callback arguments.
*/
function notifySubscribers(listeners, label, ...args) {
	for (const listener of [...listeners]) try {
		listener(...args);
	} catch (error) {
		console.error(`${label} subscriber failed:`, error);
	}
}
//#endregion
//#region lib/types/client/contract/chat-nodes.js
/**
* Test whether a Tool root has settled.
* @param block - Tool root lifecycle value.
* @returns whether the root carries its final result.
*/
function isSettledTool(block) {
	return "kind" in block;
}
/**
* Test whether a Tool root is still running.
* @param block - Tool root lifecycle value.
* @returns whether the root lacks a final result.
*/
function isRunningTool(block) {
	return !isSettledTool(block);
}
/** Chat Node kinds that remain independent of a Turn's process disclosure. */
const TURN_PROCESS_INDEPENDENT_KINDS = new Set([
	"system-prompt",
	"user",
	"steering",
	"turn-process",
	"turn-error",
	"turn-max-tokens",
	"turn-tail",
	"workspace-state"
]);
/**
* Compare immutable Turn-process specifications by their published fields.
* @param left - previous specification.
* @param right - next specification.
* @returns whether both values describe the same process presentation.
*/
function sameTurnProcessSpec(left, right) {
	return left.turn === right.turn && left.controlAnchorSeq === right.controlAnchorSeq && left.processStartSeq === right.processStartSeq && left.answerAnchorSeq === right.answerAnchorSeq && left.answerStep === right.answerStep && left.inlineReasoning === right.inlineReasoning && left.messageCount === right.messageCount && left.toolCallCount === right.toolCallCount && left.subagentCount === right.subagentCount;
}
/**
* Recognize the shipped subagent delegation name and its configured variants.
* Control tools use distinct names such as `send_message` and `list_agents`.
* @param name - durable Tool-call name.
* @returns whether the call creates or forks a subagent.
*/
function isSubagentDelegationTool(name) {
	return name === "subagent" || name.startsWith("subagent_");
}
//#endregion
//#region lib/types/client/conversation-nodes/turn-navigation.js
/**
* Preview budgets, sized to the rail card's clamps (one prompt line, up to
* three response lines) and mirrored by the turnOutline projection so a turn
* shows the same words before and after its events load. Anything past a
* budget is invisible; copying whole transcripts into navigation state would
* otherwise grow with the loaded window on every structural update.
*/
const PROMPT_PREVIEW_LIMIT = 50;
const RESPONSE_PREVIEW_LIMIT = 120;
/** Join rendered text, collapse whitespace, and cap at `limit` with a trailing ellipsis when clipped. */
function preview(parts, limit) {
	let text = "";
	let unread = false;
	for (const part of parts) {
		if (text.length >= limit * 2) {
			unread = true;
			break;
		}
		const clipped = part.length > limit * 2;
		const chunk = clipped ? part.slice(0, limit * 2) : part;
		text += text === "" ? chunk : ` ${chunk}`;
		if (clipped) {
			unread = true;
			break;
		}
	}
	const normalized = text.replace(/\s+/g, " ").trim();
	if (normalized.length > limit - 1) return `${normalized.slice(0, limit - 1).trimEnd()}…`;
	return unread ? `${normalized}…` : normalized;
}
function promptText(node) {
	if (node.kind !== "user") return "";
	return preview(node.data.content.flatMap((block) => block.type === "text" ? [block.text] : []), PROMPT_PREVIEW_LIMIT);
}
function responseText(node) {
	if (node.kind !== "assistant-step") return "";
	return preview(node.data.blocks.flatMap((block) => block.kind === "text" ? [block.text] : []), RESPONSE_PREVIEW_LIMIT);
}
/**
* Whether two items carry the same rail state, so the reader can keep its array.
* @param left - previously published item, when the Turn had one.
* @param right - freshly derived item, when the Turn still has one.
* @returns whether both sides describe the same mark.
*/
function sameTurnNavigationItem(left, right) {
	if (left === void 0 || right === void 0) return left === right;
	return left.turn === right.turn && left.anchorKey === right.anchorKey && left.prompt === right.prompt && left.response === right.response;
}
/**
* Project one loaded Turn into its rail item.
* @param turn - Turn number the item addresses.
* @param locations - live Location index supplying the Turn's node keys.
* @param nodes - live Chat node store.
* @returns the item, or undefined when the Turn has no visible loaded node.
*/
function turnNavigationItem(turn, locations, nodes) {
	const loaded = locations.getTurn(turn).map((key) => nodes.get(key)).filter((node) => node !== void 0 && node.visibility === "visible");
	const user = loaded.find((node) => node.kind === "user");
	const anchor = user ?? loaded[0];
	if (anchor === void 0) return void 0;
	const response = loaded.findLast((node) => responseText(node) !== "");
	return {
		turn,
		anchorKey: anchor.key,
		prompt: user === void 0 ? "" : promptText(user),
		response: response === void 0 ? "" : responseText(response)
	};
}
//#endregion
//#region lib/types/client/conversation-nodes/turn-process-presentation.js
function nodeTurn(node) {
	const location = node?.location;
	return location?.kind === "turn" || location?.kind === "step" ? location.turn.turn : void 0;
}
function samePresentation(left, right) {
	return left === right || left !== void 0 && right !== void 0 && left.spec === right.spec && left.turn === right.turn && left.turnClosed === right.turnClosed && left.hasExternalProcess === right.hasExternalProcess && left.compactAnswer === right.compactAnswer;
}
function derivePresentation(turn, locations, nodes) {
	const keys = locations.getTurn(turn);
	const control = keys.map((key) => nodes.get(key)).find((node) => node?.kind === "turn-process");
	if (control === void 0) return void 0;
	const spec = control.data;
	const location = control.location;
	if (location.kind !== "turn" && location.kind !== "step") return void 0;
	let openingHumanAnchor;
	for (const key of keys) {
		const node = nodes.get(key);
		if ((node?.kind === "user" || node?.kind === "steering") && node.anchorSeq < spec.controlAnchorSeq) openingHumanAnchor = Math.min(openingHumanAnchor ?? node.anchorSeq, node.anchorSeq);
	}
	let hasExternalProcess = false;
	let compactAnswer = true;
	for (const key of keys) {
		const node = nodes.get(key);
		if (node === void 0 || node.kind === "turn-process") continue;
		if ((node.kind === "user" || node.kind === "steering") && (openingHumanAnchor === void 0 || node.anchorSeq > openingHumanAnchor) && (spec.answerAnchorSeq === null || node.anchorSeq < spec.answerAnchorSeq)) compactAnswer = false;
		if (TURN_PROCESS_INDEPENDENT_KINDS.has(node.kind) || node.anchorSeq < spec.processStartSeq || spec.answerAnchorSeq !== null && node.anchorSeq >= spec.answerAnchorSeq) continue;
		if (node.kind !== "assistant-step" || spec.answerStep === null || node.data.step !== spec.answerStep) hasExternalProcess = true;
	}
	return {
		turn,
		spec,
		turnClosed: location.turn.status === "closed",
		hasExternalProcess,
		compactAnswer
	};
}
/** Mutable projection of cross-Node process layout facts by Turn. */
var ChatTurnProcessProjector = class {
	presentations = /* @__PURE__ */ new Map();
	/**
	* Read the retained process presentation for a Node's Turn.
	* @param node - Current Chat Node.
	* @returns The Turn's process presentation, when present.
	*/
	get(node) {
		const turn = nodeTurn(node);
		return turn === void 0 ? void 0 : this.presentations.get(turn);
	}
	/**
	* Replace every projected Turn.
	* @param order - visible Chat Node order.
	* @param locations - current Chat Location index.
	* @param nodes - current Chat Node store.
	* @returns Turns whose process presentation changed.
	*/
	replace(order, locations, nodes) {
		const turns = /* @__PURE__ */ new Set();
		for (const key of order) {
			const turn = nodeTurn(nodes.get(key));
			if (turn !== void 0) turns.add(turn);
		}
		const changed = /* @__PURE__ */ new Set();
		for (const turn of new Set([...this.presentations.keys(), ...turns])) if (this.set(turn, turns.has(turn) ? derivePresentation(turn, locations, nodes) : void 0)) changed.add(turn);
		return changed;
	}
	/**
	* Recompute selected Turns after incremental Node changes.
	* @param turns - affected Turn numbers.
	* @param locations - current Chat Location index.
	* @param nodes - current Chat Node store.
	* @returns Turns whose process presentation changed.
	*/
	update(turns, locations, nodes) {
		const changed = /* @__PURE__ */ new Set();
		for (const turn of turns) if (this.set(turn, derivePresentation(turn, locations, nodes))) changed.add(turn);
		return changed;
	}
	set(turn, next) {
		if (samePresentation(this.presentations.get(turn), next)) return false;
		if (next === void 0) this.presentations.delete(turn);
		else this.presentations.set(turn, next);
		return true;
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/chat-snapshot-builder.js
const EMPTY_KEYS = [];
const EMPTY_TURNS = [];
const EMPTY_ITEMS = [];
const EMPTY_LIST$1 = [];
function sameReferences$1(left, right) {
	return left.length === right.length && left.every((value, index) => value === right[index]);
}
function cachedSource(sources, key, create) {
	let source = sources.get(key);
	if (source === void 0) {
		source = create();
		sources.set(key, source);
	}
	return source;
}
var MutableChatSource = class {
	read;
	label;
	listeners = /* @__PURE__ */ new Set();
	published;
	constructor(read, label) {
		this.read = read;
		this.label = label;
		this.published = read();
	}
	getSnapshot = () => this.read();
	subscribe = (listener) => {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	};
	publish() {
		const next = this.getSnapshot();
		if (this.published === next) return;
		this.published = next;
		notifySubscribers(this.listeners, this.label);
	}
};
var MutableChatNodeStore = class {
	byKey = /* @__PURE__ */ new Map();
	turnProcesses = new ChatTurnProcessProjector();
	sources = /* @__PURE__ */ new Map();
	processSources = /* @__PURE__ */ new Map();
	dirtyKeys = /* @__PURE__ */ new Set();
	dirtyProcessKeys = /* @__PURE__ */ new Set();
	valuesCache = EMPTY_LIST$1;
	valuesDirty = false;
	get(key) {
		return this.byKey.get(key);
	}
	source(key) {
		return cachedSource(this.sources, key, () => new MutableChatSource(() => this.get(key), `[ui-chat] node source ${key}`));
	}
	processSource(key) {
		return cachedSource(this.processSources, key, () => new MutableChatSource(() => this.process(key), `[ui-chat] node process source ${key}`));
	}
	process(key) {
		return this.turnProcesses.get(this.get(key));
	}
	values() {
		if (this.valuesDirty) {
			this.valuesCache = [...this.byKey.values()];
			this.valuesDirty = false;
		}
		return this.valuesCache;
	}
	replace(nodes) {
		const previous = new Map(this.byKey);
		this.byKey.clear();
		for (const node of nodes) {
			this.byKey.set(node.key, node);
			if (previous.get(node.key) !== node) {
				this.dirtyKeys.add(node.key);
				this.dirtyProcessKeys.add(node.key);
			}
			previous.delete(node.key);
		}
		for (const key of previous.keys()) {
			this.dirtyKeys.add(key);
			this.dirtyProcessKeys.add(key);
		}
		this.valuesCache = [...this.byKey.values()];
		this.valuesDirty = false;
	}
	upsert(nodes) {
		let changed = false;
		for (const node of nodes) {
			if (this.byKey.get(node.key) === node) continue;
			this.byKey.set(node.key, node);
			this.dirtyKeys.add(node.key);
			this.dirtyProcessKeys.add(node.key);
			changed = true;
		}
		if (changed) this.valuesDirty = true;
	}
	touchProcesses(turns, locations) {
		for (const turn of turns) for (const key of locations.getTurn(turn)) this.dirtyProcessKeys.add(key);
	}
	replaceProcesses(order, locations) {
		this.touchProcesses(this.turnProcesses.replace(order, locations, this), locations);
	}
	updateProcesses(turns, locations) {
		this.touchProcesses(this.turnProcesses.update(turns, locations, this), locations);
	}
	publish() {
		const dirty = [...this.dirtyKeys];
		const dirtyProcesses = [...this.dirtyProcessKeys];
		this.dirtyKeys.clear();
		this.dirtyProcessKeys.clear();
		for (const key of dirty) this.sources.get(key)?.publish();
		for (const key of dirtyProcesses) this.processSources.get(key)?.publish();
	}
};
var MutableChatLocationIndex = class {
	turns = /* @__PURE__ */ new Map();
	steps = /* @__PURE__ */ new Map();
	getTurn(turn) {
		return this.turns.get(turn) ?? EMPTY_KEYS;
	}
	getStep(turn, step) {
		return this.steps.get(stepKey(turn, step)) ?? EMPTY_KEYS;
	}
	rebuild(order, store) {
		const turns = /* @__PURE__ */ new Map();
		const steps = /* @__PURE__ */ new Map();
		for (const key of order) {
			const location = store.get(key)?.location;
			if (location === void 0) continue;
			const coordinates = locationCoordinates(location);
			if (coordinates.turn === void 0) continue;
			const turnKeys = turns.get(coordinates.turn) ?? [];
			turnKeys.push(key);
			turns.set(coordinates.turn, turnKeys);
			if (coordinates.step === void 0) continue;
			const step = stepKey(coordinates.turn, coordinates.step);
			const stepKeys = steps.get(step) ?? [];
			stepKeys.push(key);
			steps.set(step, stepKeys);
		}
		this.turns = updateIndex(this.turns, turns);
		this.steps = updateIndex(this.steps, steps);
	}
	/** Invalidate aggregate readers when member data changes without moving. */
	touch(nodes) {
		const turns = /* @__PURE__ */ new Set();
		const steps = /* @__PURE__ */ new Set();
		for (const node of nodes) {
			const coordinates = locationCoordinates(node.location);
			if (coordinates.turn === void 0 || !this.turns.get(coordinates.turn)?.includes(node.key)) continue;
			turns.add(coordinates.turn);
			if (coordinates.step !== void 0) steps.add(stepKey(coordinates.turn, coordinates.step));
		}
		for (const turn of turns) {
			const keys = this.turns.get(turn);
			if (keys === void 0) continue;
			this.turns.set(turn, [...keys]);
		}
		for (const step of steps) {
			const keys = this.steps.get(step);
			if (keys === void 0) continue;
			this.steps.set(step, [...keys]);
		}
	}
};
function updateIndex(previous, nextMutable) {
	const next = /* @__PURE__ */ new Map();
	const keys = new Set([...previous.keys(), ...nextMutable.keys()]);
	for (const key of keys) {
		const before = previous.get(key) ?? EMPTY_KEYS;
		const candidate = nextMutable.get(key) ?? EMPTY_KEYS;
		const value = sameReferences$1(before, candidate) ? before : candidate;
		if (candidate.length > 0) next.set(key, value);
	}
	return next;
}
/**
* Loaded-Turn rail projection accumulated alongside the node store: a
* structural change re-derives the Turn set, a content-only upsert re-derives
* only the Turns whose nodes moved, and the published array keeps its identity
* until an item actually changes. Renderers therefore consume final Turn data
* instead of scanning the loaded window per frame.
*/
var MutableTurnNavigationIndex = class {
	current = EMPTY_ITEMS;
	byTurn = /* @__PURE__ */ new Map();
	items() {
		return this.current;
	}
	/** Re-derive the whole Turn set; runs only when the loaded structure moves. */
	rebuild(timeline, locations, nodes) {
		const next = [];
		const byTurn = /* @__PURE__ */ new Map();
		for (const turn of timeline.turnOrder) {
			const derived = turnNavigationItem(turn, locations, nodes);
			if (derived === void 0) continue;
			const previous = this.byTurn.get(turn);
			const item = previous !== void 0 && sameTurnNavigationItem(previous, derived) ? previous : derived;
			next.push(item);
			byTurn.set(turn, item);
		}
		this.byTurn = byTurn;
		if (!(next.length === this.current.length && next.every((item, index) => item === this.current[index]))) this.current = next;
	}
	/** Re-derive only the Turns a content-only upsert touched. */
	touch(turns, locations, nodes) {
		if (turns.size === 0) return;
		const next = this.current.map((item) => {
			if (!turns.has(item.turn)) return item;
			const derived = turnNavigationItem(item.turn, locations, nodes);
			if (derived === void 0 || sameTurnNavigationItem(item, derived)) return item;
			this.byTurn.set(item.turn, derived);
			return derived;
		});
		if (next.some((item, index) => item !== this.current[index])) this.current = next;
	}
};
function stepKey(turn, step) {
	return `${turn}:${step}`;
}
function locationCoordinates(location) {
	if (location.kind === "step") return {
		turn: location.turn.turn,
		step: location.step.step
	};
	if (location.kind === "turn") return { turn: location.turn.turn };
	return {};
}
function locationTurnStatus(location) {
	return location.kind === "turn" || location.kind === "step" ? location.turn.status : void 0;
}
function processPresentationInputChanged(previous, next, structural) {
	if (structural || previous === void 0) return true;
	if (locationTurnStatus(previous.location) !== locationTurnStatus(next.location)) return true;
	if (previous.kind === "turn-process" && next.kind === "turn-process") return previous.data !== next.data;
	return previous.kind === "assistant-step" && next.kind === "assistant-step" && previous.data.step !== next.data.step;
}
function turnProcessPresentations(nodes) {
	const presentations = /* @__PURE__ */ new Map();
	for (const raw of nodes) {
		const node = raw;
		if (node.kind === "turn-process") presentations.set(node.data.turn, {
			...presentations.get(node.data.turn),
			control: node
		});
	}
	for (const raw of nodes) {
		const node = raw;
		const location = node.location;
		if (location.kind !== "turn" && location.kind !== "step") continue;
		const current = presentations.get(location.turn.turn) ?? {};
		if ((node.kind === "user" || node.kind === "steering") && node.anchorSeq < (current.control?.data.controlAnchorSeq ?? Number.POSITIVE_INFINITY)) {
			presentations.set(location.turn.turn, {
				...current,
				openingHumanAnchor: Math.min(current.openingHumanAnchor ?? node.anchorSeq, node.anchorSeq)
			});
			continue;
		}
		if (TURN_PROCESS_INDEPENDENT_KINDS.has(node.kind)) continue;
		presentations.set(location.turn.turn, {
			...current,
			earliestProcessAnchor: Math.min(current.earliestProcessAnchor ?? node.anchorSeq, node.anchorSeq)
		});
	}
	return presentations;
}
function presentationPosition(raw, presentations) {
	const node = raw;
	const location = node.location;
	if (location.kind !== "turn" && location.kind !== "step") return {
		anchor: node.anchorSeq,
		rank: 0,
		originalAnchor: node.anchorSeq
	};
	const presentation = presentations.get(location.turn.turn);
	if (presentation === void 0) return {
		anchor: node.anchorSeq,
		rank: 0,
		originalAnchor: node.anchorSeq
	};
	const openingHumanAnchor = presentation.openingHumanAnchor;
	if (openingHumanAnchor !== void 0 && node.anchorSeq < openingHumanAnchor && !TURN_PROCESS_INDEPENDENT_KINDS.has(node.kind)) return {
		anchor: openingHumanAnchor,
		rank: 2,
		originalAnchor: node.anchorSeq
	};
	if (presentation.control !== void 0 && node.key === presentation.control.key) return openingHumanAnchor === void 0 ? {
		anchor: presentation.earliestProcessAnchor ?? node.anchorSeq,
		rank: -1,
		originalAnchor: node.anchorSeq
	} : {
		anchor: openingHumanAnchor,
		rank: 1,
		originalAnchor: node.anchorSeq
	};
	return {
		anchor: node.anchorSeq,
		rank: 0,
		originalAnchor: node.anchorSeq
	};
}
/**
* Order visible Chat Nodes without changing existing relative order as process
* eligibility changes. Opening human input precedes process candidates, while
* each synthetic process control sits between them.
* @param nodes - currently materialized Chat Nodes.
* @returns visible Nodes in presentation order.
*/
function orderedVisibleChatNodes(nodes) {
	const visible = nodes.filter((node) => node.visibility === "visible");
	const presentations = turnProcessPresentations(visible);
	return visible.sort((left, right) => {
		const leftPosition = presentationPosition(left, presentations);
		const rightPosition = presentationPosition(right, presentations);
		return leftPosition.anchor - rightPosition.anchor || leftPosition.rank - rightPosition.rank || leftPosition.originalAnchor - rightPosition.originalAnchor || left.key.localeCompare(right.key);
	});
}
function referenceMessageSeq(node) {
	const candidate = node;
	return candidate.kind === "user" || candidate.kind === "steering" ? candidate.data.seq : void 0;
}
function followingRecall(node) {
	const candidate = node;
	if (candidate.kind !== "context") return void 0;
	return {
		messageSeq: candidate.data.seq - 1,
		labels: sessionRecallLabels(candidate.data.source)
	};
}
function withReferenceLabels(node, labels) {
	const candidate = node;
	if (candidate.kind !== "user" && candidate.kind !== "steering") return node;
	const current = candidate.data.referenceLabels ?? EMPTY_KEYS;
	const hasLabels = Object.hasOwn(candidate.data, "referenceLabels");
	if (sameReferences$1(current, labels) && hasLabels === labels.length > 0) return node;
	const data = { ...candidate.data };
	if (labels.length === 0) delete data.referenceLabels;
	else data.referenceLabels = labels;
	return {
		...candidate,
		data
	};
}
/** Associates a direct message with the sourced recall event that immediately follows it. */
var ReferenceLabelProjector = class {
	messagesBySeq = /* @__PURE__ */ new Map();
	labelsByMessageSeq = /* @__PURE__ */ new Map();
	replace(nodes) {
		this.messagesBySeq.clear();
		this.labelsByMessageSeq.clear();
		for (const node of nodes) {
			const messageSeq = referenceMessageSeq(node);
			if (messageSeq !== void 0) this.messagesBySeq.set(messageSeq, node.key);
			const recall = followingRecall(node);
			if (recall !== void 0 && recall.labels.length > 0) this.labelsByMessageSeq.set(recall.messageSeq, recall.labels);
		}
		return nodes.map((node) => {
			const messageSeq = referenceMessageSeq(node);
			return messageSeq === void 0 ? node : withReferenceLabels(node, this.labelsByMessageSeq.get(messageSeq) ?? EMPTY_KEYS);
		});
	}
	apply(upserts, store) {
		const byKey = new Map(upserts.map((node) => [node.key, node]));
		const affected = /* @__PURE__ */ new Set();
		for (const node of upserts) {
			const messageSeq = referenceMessageSeq(node);
			if (messageSeq !== void 0) {
				this.messagesBySeq.set(messageSeq, node.key);
				affected.add(messageSeq);
			}
			const recall = followingRecall(node);
			if (recall === void 0) continue;
			const current = this.labelsByMessageSeq.get(recall.messageSeq);
			if (recall.labels.length === 0) this.labelsByMessageSeq.delete(recall.messageSeq);
			else this.labelsByMessageSeq.set(recall.messageSeq, current !== void 0 && sameReferences$1(current, recall.labels) ? current : recall.labels);
			affected.add(recall.messageSeq);
		}
		for (const messageSeq of affected) {
			const key = this.messagesBySeq.get(messageSeq);
			if (key === void 0) continue;
			const node = byKey.get(key) ?? store.get(key);
			if (node === void 0) continue;
			byKey.set(key, withReferenceLabels(node, this.labelsByMessageSeq.get(messageSeq) ?? EMPTY_KEYS));
		}
		return [...byKey.values()];
	}
};
function withSkillNames(node, names) {
	const candidate = node;
	if (candidate.kind !== "user" && candidate.kind !== "steering") return node;
	const current = candidate.data.skillNames ?? EMPTY_KEYS;
	const hasNames = Object.hasOwn(candidate.data, "skillNames");
	if (sameReferences$1(current, names) && hasNames === names.length > 0) return node;
	const data = { ...candidate.data };
	if (names.length === 0) delete data.skillNames;
	else data.skillNames = names;
	return {
		...candidate,
		data
	};
}
/**
* Classify one Node for batching: a direct message, a `skill-invocation`
* context, or a boundary of any other kind. A context that injects no skill
* (workspace rules, the catalog, a recall) is transparent and yields null.
*/
function slashEntryOf(node) {
	const candidate = node;
	if (candidate.kind === "user" || candidate.kind === "steering") return {
		key: node.key,
		seq: node.anchorSeq,
		kind: "message",
		name: null
	};
	if (candidate.kind === "context") {
		const name = skillInvocationName(candidate.data.source);
		return name === null ? null : {
			key: node.key,
			seq: node.anchorSeq,
			kind: "skill",
			name
		};
	}
	return {
		key: node.key,
		seq: node.anchorSeq,
		kind: "boundary",
		name: null
	};
}
function sameSlashEntry(left, right) {
	return left.seq === right.seq && left.kind === right.kind && left.name === right.name;
}
/**
* Attaches each direct message's step-loaded skill names to its Node.
*
* A step's `skill-invocation` injections follow the direct messages the host
* scanned for `/name` gestures and precede the step's first Node of any other
* kind, so every non-message, non-context Node closes a batch. Every ended
* Turn publishes its `turn-tail` Node on `turn/end` whatever the reason, so a
* batch never spans Turns, and `step/start` precedes the direct message in
* the log, so no boundary separates a message from its injections. Names
* attach to every direct message of the batch: the bubble decorates only the
* tokens its own text carries.
*
* The index holds only messages, skill injections, and boundaries, ordered by
* `anchorSeq`. An apply re-reads just the batches around the Nodes whose
* classification changed and never scans the store, so an assistant
* streaming frame costs nothing here (the append hot path never scans the
* Chat Nodes).
*/
var SkillNameProjector = class {
	entries = /* @__PURE__ */ new Map();
	/** Every indexed entry in `anchorSeq` order. */
	sorted = [];
	/**
	* Rebuild the index from a whole Node set and attach names to its messages.
	* @param nodes - every materialized Chat Node, in any order.
	* @returns the same Nodes, direct messages carrying their batch's names.
	*/
	replace(nodes) {
		this.entries.clear();
		this.sorted = [];
		for (const node of nodes) {
			const entry = slashEntryOf(node);
			if (entry === null) continue;
			this.entries.set(entry.key, entry);
			this.sorted.push(entry);
		}
		this.sorted.sort((left, right) => left.seq - right.seq);
		const names = /* @__PURE__ */ new Map();
		for (let index = 0; index < this.sorted.length; index++) {
			if (this.sorted[index]?.kind === "boundary") continue;
			const end = this.runEnd(index);
			this.assignRun(index, end, names);
			index = end;
		}
		return nodes.map((node) => withSkillNames(node, names.get(node.key) ?? EMPTY_KEYS));
	}
	/**
	* Fold one incremental upsert set: re-read only the batches around the
	* Nodes whose classification changed.
	* @param upserts - the changed Nodes.
	* @param store - the resident Nodes, read by key for the messages of an affected batch.
	* @returns the upserts plus any resident message whose names changed.
	*/
	apply(upserts, store) {
		const dirty = [];
		for (const node of upserts) {
			const next = slashEntryOf(node);
			const previous = this.entries.get(node.key);
			if (previous !== void 0) {
				if (next !== null && sameSlashEntry(previous, next)) {
					if (next.kind === "message") dirty.push(next.seq);
					continue;
				}
				this.remove(previous);
				dirty.push(previous.seq);
			}
			if (next === null) continue;
			this.insert(next);
			dirty.push(next.seq);
		}
		if (dirty.length === 0) return upserts;
		const names = /* @__PURE__ */ new Map();
		for (const seq of dirty) this.collectAround(seq, names);
		const byKey = new Map(upserts.map((node) => [node.key, node]));
		for (const [key, list] of names) {
			const node = byKey.get(key) ?? store.get(key);
			if (node === void 0) continue;
			const next = withSkillNames(node, list);
			if (next !== node || byKey.has(key)) byKey.set(key, next);
		}
		return [...byKey.values()];
	}
	insert(entry) {
		this.sorted.splice(this.lowerBound(entry.seq), 0, entry);
		this.entries.set(entry.key, entry);
	}
	remove(entry) {
		this.sorted.splice(this.sorted.indexOf(entry), 1);
		this.entries.delete(entry.key);
	}
	/** First index whose seq is at least `seq`. */
	lowerBound(seq) {
		let low = 0;
		let high = this.sorted.length;
		while (low < high) {
			const middle = low + high >>> 1;
			if ((this.sorted[middle]?.seq ?? Number.POSITIVE_INFINITY) < seq) low = middle + 1;
			else high = middle;
		}
		return low;
	}
	/** Last index of the boundary-free run containing `index`. */
	runEnd(index) {
		let end = index;
		while (end + 1 < this.sorted.length && this.sorted[end + 1]?.kind !== "boundary") end++;
		return end;
	}
	/** First index of the boundary-free run containing `index`. */
	runStart(index) {
		let start = index;
		while (start - 1 >= 0 && this.sorted[start - 1]?.kind !== "boundary") start--;
		return start;
	}
	/** Record the names every message of the run `[start, end]` carries. */
	assignRun(start, end, names) {
		const list = [];
		for (let index = start; index <= end; index++) {
			const entry = this.sorted[index];
			if (entry?.kind === "skill" && entry.name !== null && !list.includes(entry.name)) list.push(entry.name);
		}
		for (let index = start; index <= end; index++) {
			const entry = this.sorted[index];
			if (entry?.kind === "message") names.set(entry.key, list);
		}
	}
	/**
	* Re-read the run(s) around one changed seq: the run holding a message or
	* skill entry, or — for a boundary, or a seq that left the index — the runs
	* on both sides of that position.
	*/
	collectAround(seq, names) {
		const at = this.lowerBound(seq);
		const here = this.sorted[at];
		if (here !== void 0 && here.seq === seq && here.kind !== "boundary") {
			this.assignRun(this.runStart(at), this.runEnd(at), names);
			return;
		}
		if (at - 1 >= 0 && this.sorted[at - 1]?.kind !== "boundary") this.assignRun(this.runStart(at - 1), at - 1, names);
		const right = here !== void 0 && here.seq === seq ? at + 1 : at;
		if (right < this.sorted.length && this.sorted[right]?.kind !== "boundary") this.assignRun(right, this.runEnd(right), names);
	}
};
const EMPTY_CONTRIBUTION = {
	anchorSeq: 0,
	nodes: EMPTY_LIST$1,
	partial: null,
	running: null
};
function legacyContribution(raw) {
	const node = raw;
	if (raw.visibility !== "visible" && node.kind !== "assistant-step") return EMPTY_CONTRIBUTION;
	switch (node.kind) {
		case "workspace-state": return EMPTY_CONTRIBUTION;
		case "user":
		case "steering":
		case "context":
		case "command":
		case "compaction":
		case "turn-error":
		case "turn-max-tokens":
		case "unknown": return {
			anchorSeq: node.anchorSeq,
			nodes: [node.data],
			partial: null,
			running: null
		};
		case "assistant-step": {
			const data = node.data;
			if (data.status === "running") {
				if (raw.visibility !== "visible") return EMPTY_CONTRIBUTION;
				return {
					anchorSeq: node.anchorSeq,
					nodes: EMPTY_LIST$1,
					partial: {
						turn: data.turn,
						step: data.step,
						blocks: data.blocks
					},
					running: null
				};
			}
			return {
				anchorSeq: node.anchorSeq,
				nodes: data.finalNode === void 0 ? EMPTY_LIST$1 : [data.finalNode],
				partial: null,
				running: null
			};
		}
		case "tool-call": {
			const root = node.data.root;
			return isRunningTool(root) ? {
				anchorSeq: node.anchorSeq,
				nodes: EMPTY_LIST$1,
				partial: null,
				running: root
			} : {
				anchorSeq: node.anchorSeq,
				nodes: [root],
				partial: null,
				running: null
			};
		}
		case "manual-compaction": {
			const data = node.data;
			return {
				anchorSeq: node.anchorSeq,
				nodes: data.compaction === null ? [data.command] : [data.command, data.compaction],
				partial: null,
				running: null
			};
		}
		case "model-retry": return {
			anchorSeq: node.anchorSeq,
			nodes: node.data.attempts,
			partial: null,
			running: null
		};
		case "turn-tail":
		case "system-prompt": return EMPTY_CONTRIBUTION;
		default: return EMPTY_CONTRIBUTION;
	}
}
function sameContribution(left, right) {
	return left !== void 0 && left.anchorSeq === right.anchorSeq && left.partial?.blocks === right.partial?.blocks && left.partial?.turn === right.partial?.turn && left.partial?.step === right.partial?.step && left.running === right.running && sameReferences$1(left.nodes, right.nodes);
}
/** Incremental compatibility projection for StatsPills and legacy top-level snapshot fields. */
var LegacySliceBuilder = class {
	contributions = /* @__PURE__ */ new Map();
	finalizedContributions = /* @__PURE__ */ new Map();
	runningContributions = /* @__PURE__ */ new Map();
	partialContributions = /* @__PURE__ */ new Map();
	finalized = EMPTY_LIST$1;
	runningCalls = EMPTY_LIST$1;
	partial = null;
	timeline;
	turnTimings = /* @__PURE__ */ new Map();
	turnEnds = /* @__PURE__ */ new Map();
	replace(nodes, timeline) {
		this.contributions.clear();
		this.finalizedContributions.clear();
		this.runningContributions.clear();
		this.partialContributions.clear();
		for (const node of nodes) {
			const contribution = legacyContribution(node);
			this.contributions.set(node.key, contribution);
			this.indexContribution(node.key, contribution);
		}
		this.rebuildFinalized();
		this.rebuildRunning();
		this.rebuildPartial();
		this.updateTimeline(timeline);
		return this.snapshot();
	}
	apply(upserts, timeline) {
		let finalizedChanged = false;
		let runningChanged = false;
		let partialChanged = false;
		for (const node of upserts) {
			const contribution = legacyContribution(node);
			const previous = this.contributions.get(node.key);
			if (sameContribution(previous, contribution)) continue;
			finalizedChanged ||= finalizedContributionChanged(previous, contribution);
			runningChanged ||= runningContributionChanged(previous, contribution);
			partialChanged ||= partialContributionChanged(previous, contribution);
			this.contributions.set(node.key, contribution);
			this.indexContribution(node.key, contribution);
		}
		if (finalizedChanged) this.rebuildFinalized();
		if (runningChanged) this.rebuildRunning();
		if (partialChanged) this.rebuildPartial();
		this.updateTimeline(timeline);
		return this.snapshot();
	}
	indexContribution(key, contribution) {
		updateContributionIndex(this.finalizedContributions, key, contribution, contribution.nodes.length > 0);
		updateContributionIndex(this.runningContributions, key, contribution, contribution.running !== null);
		updateContributionIndex(this.partialContributions, key, contribution, contribution.partial !== null);
	}
	rebuildFinalized() {
		const finalized = [...this.finalizedContributions.values()].flatMap((value) => value.nodes).sort((left, right) => left.seq - right.seq);
		if (!sameReferences$1(this.finalized, finalized)) this.finalized = finalized;
	}
	rebuildRunning() {
		const runningCalls = [...this.runningContributions.values()].sort((left, right) => left.anchorSeq - right.anchorSeq).flatMap((value) => value.running === null ? [] : [value.running]);
		if (!sameReferences$1(this.runningCalls, runningCalls)) this.runningCalls = runningCalls;
	}
	rebuildPartial() {
		const partial = [...this.partialContributions.values()].sort((left, right) => left.anchorSeq - right.anchorSeq).findLast((value) => value.partial !== null)?.partial ?? null;
		if (this.partial?.blocks !== partial?.blocks || this.partial?.turn !== partial?.turn || this.partial?.step !== partial?.step) this.partial = partial;
	}
	updateTimeline(timeline) {
		if (this.timeline === timeline) return;
		this.timeline = timeline;
		const turnTimings = /* @__PURE__ */ new Map();
		const turnEnds = /* @__PURE__ */ new Map();
		for (const turn of timeline.turns.values()) {
			if (turn.start !== void 0) turnTimings.set(turn.turn, {
				startTime: turn.start.time,
				...turn.end === void 0 ? {} : { endTime: turn.end.time }
			});
			if (turn.end !== void 0) turnEnds.set(turn.turn, turn.end.seq);
		}
		this.turnTimings = turnTimings;
		this.turnEnds = turnEnds;
	}
	snapshot() {
		return {
			nodes: this.finalized,
			turnTimings: this.turnTimings,
			turnEnds: this.turnEnds,
			partial: this.partial,
			runningCalls: this.runningCalls
		};
	}
};
function updateContributionIndex(index, key, contribution, present) {
	if (present) index.set(key, contribution);
	else index.delete(key);
}
function finalizedContributionChanged(previous, next) {
	const previousNodes = previous?.nodes ?? EMPTY_LIST$1;
	return !sameReferences$1(previousNodes, next.nodes) || (previousNodes.length > 0 || next.nodes.length > 0) && previous?.anchorSeq !== next.anchorSeq;
}
function runningContributionChanged(previous, next) {
	return previous?.running !== next.running || (previous.running !== null || next.running !== null) && previous.anchorSeq !== next.anchorSeq;
}
function partialContributionChanged(previous, next) {
	return previous?.partial?.blocks !== next.partial?.blocks || previous?.partial?.turn !== next.partial?.turn || previous?.partial?.step !== next.partial?.step || ((previous?.partial ?? null) !== null || next.partial !== null) && previous?.anchorSeq !== next.anchorSeq;
}
/** Incremental keyed Chat builder registered under the `chat` target. */
var ChatSnapshotBuilder = class {
	store = new MutableChatNodeStore();
	locations = new MutableChatLocationIndex();
	navigation = new MutableTurnNavigationIndex();
	legacy = new LegacySliceBuilder();
	referenceLabels = new ReferenceLabelProjector();
	skillNames = new SkillNameProjector();
	order = EMPTY_KEYS;
	/** Last published timeline: a Turn boundary can land without a new node. */
	timeline = null;
	empty;
	constructor() {
		this.empty = this.snapshot({
			turnOrder: EMPTY_TURNS,
			turns: /* @__PURE__ */ new Map()
		});
	}
	replace(input) {
		const nodes = this.skillNames.replace(this.referenceLabels.replace(input.nodes));
		this.store.replace(nodes);
		this.order = orderedVisibleChatNodes(nodes).map((node) => node.key);
		this.locations.rebuild(this.order, this.store);
		this.store.replaceProcesses(this.order, this.locations);
		this.navigation.rebuild(input.timeline, this.locations, this.store);
		this.timeline = input.timeline;
		const snapshot = this.snapshot(input.timeline, this.legacy.replace(nodes, input.timeline));
		this.store.publish();
		return snapshot;
	}
	apply(input) {
		const upserts = this.skillNames.apply(this.referenceLabels.apply(input.upserts, this.store), this.store);
		const processTurns = /* @__PURE__ */ new Set();
		let structural = false;
		const contentOnly = [];
		for (const node of upserts) {
			const previous = this.store.get(node.key);
			const nodeStructural = previous === void 0 || previous.kind !== node.kind || previous.anchorSeq !== node.anchorSeq || previous.visibility !== node.visibility || locationIdentity(previous.location) !== locationIdentity(node.location);
			structural ||= nodeStructural;
			if (!nodeStructural) contentOnly.push(node);
			if (processPresentationInputChanged(previous, node, nodeStructural)) {
				const previousTurn = previous === void 0 ? void 0 : locationCoordinates(previous.location).turn;
				const nextTurn = locationCoordinates(node.location).turn;
				if (previousTurn !== void 0) processTurns.add(previousTurn);
				if (nextTurn !== void 0) processTurns.add(nextTurn);
			}
		}
		this.store.upsert(upserts);
		if (structural) {
			const next = orderedVisibleChatNodes(this.store.values()).map((node) => node.key);
			this.order = sameReferences$1(this.order, next) ? this.order : next;
			this.locations.rebuild(this.order, this.store);
		}
		this.locations.touch(contentOnly);
		this.store.updateProcesses(processTurns, this.locations);
		if (structural || input.timeline !== this.timeline) this.navigation.rebuild(input.timeline, this.locations, this.store);
		else this.navigation.touch(turnsOf(contentOnly), this.locations, this.store);
		this.timeline = input.timeline;
		const snapshot = this.snapshot(input.timeline, this.legacy.apply(upserts, input.timeline));
		this.store.publish();
		return snapshot;
	}
	snapshot(timeline, legacy = this.legacy.replace(EMPTY_LIST$1, timeline)) {
		return {
			order: this.order,
			nodes: this.store,
			locations: this.locations,
			navigation: this.navigation,
			timeline,
			legacy
		};
	}
};
/** Turns owning the given nodes, for the content-only navigation update. */
function turnsOf(nodes) {
	const turns = /* @__PURE__ */ new Set();
	for (const node of nodes) {
		const turn = locationCoordinates(node.location).turn;
		if (turn !== void 0) turns.add(turn);
	}
	return turns;
}
function locationIdentity(location) {
	const coordinates = locationCoordinates(location);
	return `${location.kind}:${coordinates.turn ?? ""}:${coordinates.step ?? ""}`;
}
/** Chat target factory contributed to the Conversation view registry. */
const chatViewDefinition = {
	target: "chat",
	create: () => new ChatSnapshotBuilder(),
	isActive: (snapshot) => snapshot.order.some((key) => snapshot.nodes.get(key)?.kind !== "command")
};
//#endregion
//#region ../../core/session/src/surface.ts
/** Runtime counterpart of the message-producing event union. */
const SURFACE_EVENT_TYPES = new Set([
	"system/message",
	"user/message",
	"assistant/message",
	"tool/result"
]);
/**
* Narrow an event to a surface-eligible event carrying its required marker.
* @param event - event to test.
* @returns true when both the type and marker identify a surface event.
*/
function isSurfaceEvent(event) {
	if (!SURFACE_EVENT_TYPES.has(event.type)) return false;
	return event.surfaceOp !== void 0;
}
/**
* Narrow an event to an append-origin surface event: one that entered the
* surface at its own log position and was never itself a replacement copy.
*
* The model-visible surface deliberately shadows replaced ranges, so it is the
* wrong source for a human transcript — a landed replacement would erase
* conversation the user already saw. Append-origin events are that transcript's
* durable source material; replacement copies stay model-only.
* @param event - event to test.
* @returns true when the event appended to the surface tail.
*/
function isAppendSurfaceEvent(event) {
	return isSurfaceEvent(event) && event.surfaceOp === "append";
}
/**
* Narrow an event to a surface replacement: a node that shadowed an existing
* surface range instead of appending to the tail. The counterpart of
* {@link isAppendSurfaceEvent} over the two {@link SurfaceOp} variants.
* @param event - event to test.
* @returns true when the event replaced a surface range.
*/
function isReplacementSurfaceEvent(event) {
	return isSurfaceEvent(event) && event.surfaceOp !== "append";
}
//#endregion
//#region lib/types/client/conversation-nodes/command.js
const COMPACT_PLUGIN = "compact";
function commandFromRun(match) {
	if (match.event.type !== "command/run") throw new Error("command start requires command/run");
	const data = match.event.data;
	return {
		kind: "command",
		seq: match.event.seq,
		time: match.event.time,
		commandId: data.commandId,
		name: data.name,
		args: data.args ?? null,
		outcome: null
	};
}
function commandFromDone(match, previous) {
	if (match.event.type !== "command/done") throw new Error("command update requires command/done");
	const data = match.event.data;
	const sourceEventSeq = data.kind === "success" && data.sourceEventSeq !== void 0 && Number.isSafeInteger(data.sourceEventSeq) && data.sourceEventSeq >= 0 ? data.sourceEventSeq : void 0;
	return {
		kind: "command",
		seq: previous?.seq ?? match.event.seq,
		time: previous?.time ?? match.event.time,
		commandId: data.commandId,
		name: previous?.name ?? null,
		args: previous?.args ?? null,
		outcome: {
			kind: data.kind,
			...data.text === void 0 ? {} : { text: data.text },
			...sourceEventSeq === void 0 ? {} : { sourceEventSeq }
		}
	};
}
/**
* Read correlation identity from a compaction replacement checkpoint.
* @param event - candidate Session event.
* @returns correlated compaction and optional command identity.
*/
function compactSource(event) {
	if (event.type !== "user/message" || !isReplacementSurfaceEvent(event)) return void 0;
	const source = event.data.source;
	if (source.kind !== "plugin" || source.plugin !== COMPACT_PLUGIN || typeof source.compactionId !== "string") return void 0;
	return {
		compactionId: source.compactionId,
		...source.sourceCommandId === void 0 ? {} : { sourceCommandId: source.sourceCommandId }
	};
}
/**
* Build the visible summary marker from optional lifecycle evidence.
* @param match - compaction/summary Match, when loaded.
* @param checkpoint - replacement checkpoint Match.
* @returns final compaction summary Node data.
*/
function compactSummary(match, checkpoint) {
	let summary = null;
	let shadowedItemCount = null;
	let shadowedTokenCount = null;
	if (match?.event.type === "compaction/summary") {
		const data = match.event.data;
		if (Array.isArray(data.summary)) {
			const text = data.summary.map((block) => block.type === "text" ? block.text : "").join("");
			summary = text.trim() === "" ? null : text;
		}
		shadowedItemCount = Array.isArray(data.shadowedSeqs) && data.shadowedSeqs.every((seq) => Number.isSafeInteger(seq) && seq >= 0) ? data.shadowedSeqs.length : null;
		shadowedTokenCount = Number.isSafeInteger(data.shadowedTokenCount) && data.shadowedTokenCount >= 0 ? data.shadowedTokenCount : null;
	}
	return {
		kind: "compaction",
		seq: checkpoint.event.seq,
		time: checkpoint.event.time,
		summary,
		summaryEventSeq: match?.event.seq ?? null,
		shadowedItemCount,
		shadowedTokenCount
	};
}
function fallbackState$4(context) {
	const done = context.matches.find((match) => match.event.type === "command/done");
	const checkpoint = context.matches.find((match) => compactSource(match.event) !== void 0);
	const summary = context.matches.find((match) => match.event.type === "compaction/summary");
	if (checkpoint === void 0) return done === void 0 ? void 0 : { command: commandFromDone(done) };
	const source = compactSource(checkpoint.event);
	if (source?.sourceCommandId === void 0) return done === void 0 ? void 0 : { command: commandFromDone(done) };
	return {
		command: done === void 0 ? {
			kind: "command",
			seq: checkpoint.event.seq,
			time: checkpoint.event.time,
			commandId: source.sourceCommandId,
			name: "compact",
			args: null,
			outcome: null
		} : {
			...commandFromDone(done),
			name: "compact"
		},
		checkpoint,
		...summary === void 0 ? {} : { summary }
	};
}
/**
* Fold shared compaction evidence into a Definition-owned State.
* @param state - current business State carrying optional compaction evidence.
* @param match - next compaction lifecycle Match.
* @returns adopted State, preserving reference identity when the Match adds no evidence.
*/
function updateCompactionState(state, match) {
	if (match.event.type === "compaction/summary") return {
		...state,
		summary: match
	};
	if (compactSource(match.event) !== void 0) return {
		...state,
		checkpoint: match
	};
	return state;
}
/** Slash-command lifecycle, including integrated manual compaction, Definition. */
const commandDefinition = {
	kind: "command",
	target: "chat",
	match: (event) => {
		if (event.type === "command/run") return {
			id: String(event.data.commandId),
			role: "start"
		};
		if (event.type === "command/done") return {
			id: String(event.data.commandId),
			role: "update"
		};
		const checkpoint = compactSource(event);
		if (checkpoint?.sourceCommandId !== void 0) return {
			id: String(checkpoint.sourceCommandId),
			role: "update"
		};
		if (event.type === "compaction/start" || event.type === "compaction/summary" || event.type === "compaction/end") {
			if (event.data.sourceCommandId !== void 0) return {
				id: String(event.data.sourceCommandId),
				role: "update"
			};
		}
		return null;
	},
	start: (_context, match) => ({ command: commandFromRun(match) }),
	update: (context, match) => {
		if (match.event.type === "command/done") return {
			...context.state,
			command: commandFromDone(match, context.state.command)
		};
		return updateCompactionState(context.state, match);
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$4(context);
		if (state === void 0) return null;
		if (state.command.name !== "compact") return chatNode(context, "command", state.command.seq, state.command);
		const compaction = state.checkpoint === void 0 ? null : compactSummary(state.summary, state.checkpoint);
		const data = {
			command: state.command,
			compaction
		};
		return chatNode(context, "manual-compaction", compaction?.seq ?? state.command.seq, data);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/compaction.js
function fallbackState$3(context) {
	const summary = context.matches.find((match) => match.event.type === "compaction/summary");
	const checkpoint = context.matches.find((match) => compactSource(match.event) !== void 0);
	return {
		...summary === void 0 ? {} : { summary },
		...checkpoint === void 0 ? {} : { checkpoint }
	};
}
/** Automatic compaction lifecycle and landed checkpoint Definition. */
const compactionDefinition = {
	kind: "compaction",
	target: "chat",
	match: (event) => {
		const checkpoint = compactSource(event);
		if (checkpoint !== void 0 && checkpoint.sourceCommandId === void 0) return {
			id: checkpoint.compactionId,
			role: "update"
		};
		if (event.type === "compaction/start" || event.type === "compaction/summary" || event.type === "compaction/end") {
			if (event.data.sourceCommandId !== void 0) return null;
			const compactionId = event.data.compactionId;
			if (typeof compactionId !== "string" || compactionId === "") return null;
			return {
				id: compactionId,
				role: event.type === "compaction/start" ? "start" : "update"
			};
		}
		return null;
	},
	start: () => ({}),
	update: (context, match) => updateCompactionState(context.state, match),
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$3(context);
		if (state.checkpoint === void 0) return null;
		const marker = compactSummary(state.summary, state.checkpoint);
		return chatNode(context, "compaction", marker.seq, marker);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/fallback.js
/** Unclaimed append-surface fallback Definition. */
const unknownFallbackDefinition = {
	kind: "unknown-surface",
	target: "chat",
	match: (event) => event.type !== "assistant/live-chunk" && isAppendSurfaceEvent(event) ? {
		id: String(event.seq),
		role: "start"
	} : null,
	start: (_context, match) => ({
		kind: "unknown",
		seq: match.event.seq,
		time: match.event.time,
		type: match.event.type,
		data: match.event.data
	}),
	update: (context) => context.state,
	buildViewNode: (context) => context.state === void 0 ? null : chatNode(context, "unknown", context.state.seq, context.state)
};
//#endregion
//#region lib/types/client/conversation-nodes/inbox.js
const EMPTY_PENDING = {
	kind: "snapshot",
	ids: []
};
const EMPTY_CURRENT_CLAIMED = /* @__PURE__ */ new Set();
function materializePending(state) {
	const splices = [];
	let current = state;
	while (current.kind === "splice") {
		splices.push(current);
		current = current.previous;
	}
	const pending = [...current.ids];
	for (const splice of splices.reverse()) pending.splice(splice.start, splice.removedCount, ...splice.inserted);
	return pending;
}
function withoutInserted(claimed, inserted) {
	let next;
	for (const id of inserted) {
		if (!claimed.has(id)) continue;
		next ??= new Set(claimed);
		next.delete(id);
	}
	return next ?? claimed;
}
/**
* Apply one next-step splice under the AgentLoop's durable event ordering.
* An entered claim logs its complete message batch before another claim; a
* rejected claim logs no messages, so only the current claim can classify a
* later `user/message`.
*/
function applySplice(previous, splice) {
	const priorPending = previous?.state.pending ?? EMPTY_PENDING;
	const inserted = splice.inserted.map((identity) => identity.id);
	const removedCount = splice.removedCount ?? 0;
	if (removedCount > 0 && splice.outcome !== "canceled") {
		const pending = materializePending(priorPending);
		const removed = pending.splice(splice.start, removedCount, ...inserted);
		return {
			pending: {
				kind: "snapshot",
				ids: pending
			},
			currentClaimed: new Set(removed)
		};
	}
	const currentClaimed = withoutInserted(previous?.state.currentClaimed ?? EMPTY_CURRENT_CLAIMED, inserted);
	return {
		pending: {
			kind: "splice",
			previous: priorPending,
			start: splice.start,
			removedCount,
			inserted
		},
		currentClaimed
	};
}
const NEXT_STEP_INBOX_KIND = "inbox-next-step";
/** Persistent next-step Inbox state used to classify the current claimed batch as steering. */
const nextStepInboxDefinition = {
	kind: NEXT_STEP_INBOX_KIND,
	match: (event) => {
		if (event.type === "agent/inbox/spliced" && event.data.target === "next-step") return {
			id: String(event.seq),
			role: "start"
		};
		return null;
	},
	start: (_context, match, reader) => {
		if (match.event.type !== "agent/inbox/spliced") throw new Error("inbox-next-step start requires agent/inbox/spliced");
		return applySplice(reader.previous(NEXT_STEP_INBOX_KIND), match.event.data);
	},
	update: (context) => context.state,
	publication: () => "none"
};
//#endregion
//#region lib/types/client/conversation-nodes/message.js
function isCompactionCheckpoint(event) {
	if (event.type !== "user/message" || !isReplacementSurfaceEvent(event)) return false;
	const source = event.data.source;
	return source.kind === "plugin" && source.plugin === "compact";
}
/** User, steering, and injected-context message classification Definition. */
const messageDefinition = {
	kind: "input-message",
	target: "chat",
	match: (event) => event.type === "user/message" && isAppendSurfaceEvent(event) && !isCompactionCheckpoint(event) ? {
		id: String(event.data.id),
		role: "start"
	} : null,
	start: (_context, match, reader) => {
		if (match.event.type !== "user/message") throw new Error("input-message start requires user/message");
		const event = match.event;
		if (event.data.source.kind !== "user") return {
			kind: "context",
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source,
			provenance: contextProvenance(event.data.source),
			form: contextForm(event.data.source)
		};
		return reader.previous("inbox-next-step")?.state.currentClaimed.has(String(event.data.id)) === true ? {
			kind: "steering",
			messageId: event.data.id,
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source
		} : {
			kind: "user",
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source
		};
	},
	update: (context) => context.state,
	buildViewNode: (context) => {
		if (context.state === void 0) return null;
		return chatNode(context, context.state.kind, context.state.seq, context.state);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/request-prompt.js
/** Place a request's system prompt at the start of its visible message series. */
function requestPromptAnchor(match, previous, isInitial) {
	if (match.location.kind !== "step") return match.event.seq;
	if (previous === void 0 && !isInitial) return match.event.seq;
	if (previous?.turn === match.location.turn.turn && previous.step === match.location.step.step) return match.event.seq;
	return match.location.step.step === 1 ? match.location.turn.start?.seq ?? match.location.step.start?.seq ?? match.event.seq : match.location.step.start?.seq ?? match.event.seq;
}
/** Keep an already rendered prompt at its page-lifetime presentation anchor. */
function stableRequestPromptAnchor(context, match, previous, isInitial) {
	const current = context.current.get("chat");
	return current?.kind === "system-prompt" ? current.anchorSeq : requestPromptAnchor(match, previous, isInitial);
}
/**
* System-prompt surface node Definition for the Chat target. It owns every
* `system/message` event on the Chat target so the unknown-surface fallback
* never renders the prompt as a transcript row. Each nonempty append owns a
* prompt card, even without a loaded request header. Initial cards precede
* their step's input; in-history updates stay at their own positions. The
* request-prompt Definition owns replacement and later-series cards. Positional
* replacements advance the effective prompt without changing historical cards.
* @param inspect - Pure surface interpretation supplied by uiConversation.
* @returns The Chat system-prompt Definition.
*/
function systemMessageDefinition(inspect) {
	return {
		kind: "system-message",
		target: "chat",
		match: (event) => event.type === "system/message" || "surfaceOp" in event && event.surfaceOp !== "append" ? {
			id: String(event.seq),
			role: "start"
		} : null,
		start: (_context, match, reader) => {
			return inspect(reader.previous("system-message")?.state, match.event);
		},
		update: (context) => context.state,
		buildViewNode: (context) => {
			const state = context.state?.introduced;
			if (state === void 0 || state.text === "" || context.start?.event.type !== "system/message" || context.start.event.surfaceOp !== "append") return null;
			return chatNode(context, "system-prompt", state.update ? state.seq : requestPromptAnchor(context.start, void 0, true), {
				text: state.text,
				...state.update ? { update: true } : {}
			});
		}
	};
}
/**
* Request-header prompt Definition for the Chat target. Resume and explicit
* series starts retain a prompt card even when the system text is unchanged.
* @param inspect - the shared prompt interpretation, supplied by the
* uiConversation service (a client bundle cannot value-import it).
* @returns the Chat request-prompt Definition.
*/
function requestPromptDefinition(inspect) {
	return {
		kind: "request-prompt",
		target: "chat",
		match: (event) => event.type === "request/header" ? {
			id: String(event.seq),
			role: "start"
		} : null,
		start: (context, match, reader) => {
			if (match.event.type !== "request/header") throw new Error("request-prompt start requires request/header");
			const previous = reader.previous("request-prompt")?.state;
			const systemContext = reader.previous("system-message");
			const system = systemContext?.state.effective;
			const location = match.location.kind === "step" ? {
				turn: match.location.turn.turn,
				step: match.location.step.step
			} : {};
			const inspection = inspect(previous?.prompt, match.event, system);
			const change = inspection.change?.kind;
			const systemEvent = systemContext?.matches[0]?.event;
			const shownByUpdate = system !== void 0 && systemEvent?.type === "system/message" && systemEvent.surfaceOp === "append" && (system.update || previous === void 0) && system.turn === location.turn && system.step === location.step;
			return {
				anchorSeq: stableRequestPromptAnchor(context, match, previous, match.event.data.reason === "initial"),
				showsPrompt: !shownByUpdate && (previous === void 0 || match.event.data.reason !== "change" || match.event.data.startsSeries === true || change === "system" || change === "system-and-tools"),
				...location,
				...inspection
			};
		},
		update: (context) => context.state,
		buildViewNode: (context) => {
			const state = context.state;
			if (state === void 0) return null;
			const current = context.current.get("chat");
			const visible = state.showsPrompt && state.prompt.system !== "";
			if (!visible && current?.kind !== "system-prompt") return null;
			return chatNode(context, "system-prompt", state.anchorSeq, { text: state.prompt.system }, { visibility: visible ? "visible" : "hidden" });
		}
	};
}
//#endregion
//#region lib/types/client/conversation-nodes/retry.js
function scheduledNode(match) {
	if (match.event.type !== "llm/retry") return void 0;
	return {
		kind: "model-retry",
		seq: match.event.seq,
		time: match.event.time,
		retryState: "scheduled",
		...match.event.data
	};
}
/** A scheduled attempt is cancelled once either owning boundary closes. */
function isClosed(location) {
	return location.kind === "step" && location.step.status === "closed" || (location.kind === "step" || location.kind === "turn") && location.turn.status === "closed";
}
/** Producer-correlated model retry chain Definition. */
const retryDefinition = {
	kind: "model-retry",
	target: "chat",
	match: (event) => {
		if (event.type === "llm/retry") {
			const retryId = event.data.retryId;
			if (typeof retryId !== "string" || retryId === "") return null;
			return {
				id: retryId,
				role: event.data.retry === 1 ? "start" : "update"
			};
		}
		if (event.type === "llm/retry-started") {
			const retryId = event.data.retryId;
			return typeof retryId === "string" && retryId !== "" ? {
				id: retryId,
				role: "update"
			} : null;
		}
		return null;
	},
	start: (_context, match) => {
		const node = scheduledNode(match);
		if (node === void 0) throw new Error("model-retry start requires a valid llm/retry event");
		return {
			turn: node.turn,
			step: node.step,
			attempts: [node]
		};
	},
	update: (context, match) => {
		if (match.event.type === "llm/retry") {
			const node = scheduledNode(match);
			return node === void 0 ? context.state : {
				...context.state,
				attempts: [...context.state.attempts, node]
			};
		}
		if (match.event.type !== "llm/retry-started") return context.state;
		const retry = match.event.data.retry;
		return {
			...context.state,
			attempts: context.state.attempts.map((attempt) => attempt.retry === retry ? {
				...attempt,
				retryState: "started"
			} : attempt)
		};
	},
	buildViewNode: (context) => {
		if (context.state === void 0 || context.state.attempts.length === 0) return null;
		const location = context.start?.location ?? context.matches[0]?.location ?? { kind: "unresolved" };
		const stateAttempts = context.state.attempts;
		const attempts = stateAttempts.map((attempt, index) => index === stateAttempts.length - 1 && attempt.retryState === "scheduled" && isClosed(location) ? {
			...attempt,
			retryState: "cancelled"
		} : attempt);
		const current = attempts.at(-1);
		if (current === void 0) return null;
		const data = {
			attempts,
			current
		};
		return chatNode(context, "model-retry", attempts[0]?.seq ?? current.seq, data);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/tool.js
const MAX_DEPTH = 256;
const projectedBlocks = /* @__PURE__ */ new WeakMap();
function jsonArguments(value) {
	return JSON.stringify(value);
}
function rootCall(match) {
	if (match.event.type !== "tool/call") throw new Error("tool-call start requires tool/call");
	return {
		callId: String(match.event.data.callId),
		name: match.event.data.name,
		argsRaw: match.event.data.arguments,
		turn: match.event.data.turn,
		step: match.event.data.step,
		time: match.event.time,
		subCalls: []
	};
}
function rootResult(match, previous) {
	if (match.event.type !== "tool/result") return void 0;
	const result = match.event.data.message.content[0];
	return {
		kind: "tool-result",
		seq: match.event.seq,
		time: match.event.time,
		callId: String(match.event.data.message.source.callId),
		call: previous === void 0 ? null : {
			name: previous.name,
			argsRaw: previous.argsRaw
		},
		callTime: previous?.time ?? null,
		content: result.content,
		isError: result.isError === true,
		...match.event.data.error === void 0 ? {} : { error: match.event.data.error },
		meta: match.event.data.meta,
		subCalls: [],
		...match.detail?.kind === "tool-result" ? { deferred: true } : {}
	};
}
function childCall(match, data) {
	return {
		callId: data.subCallId,
		parentCallId: data.parentCallId,
		name: data.name,
		argsRaw: jsonArguments(data.arguments),
		turn: locationTurn(match),
		step: locationStep(match),
		time: match.event.time,
		subCalls: []
	};
}
function childResult(match, data, previous) {
	return {
		kind: "tool-result",
		seq: match.event.seq,
		time: match.event.time,
		callId: data.subCallId,
		parentCallId: data.parentCallId,
		call: {
			name: data.name,
			argsRaw: jsonArguments(data.arguments)
		},
		callTime: previous?.time ?? null,
		content: data.content ?? [],
		isError: data.isError === true,
		subCalls: []
	};
}
function locationTurn(match) {
	return match.location.kind === "step" || match.location.kind === "turn" ? match.location.turn.turn : 0;
}
function locationStep(match) {
	return match.location.kind === "step" ? match.location.step.step : 0;
}
function acceptsEdge(state, parent, child) {
	if (parent === child || state.parents.has(child)) return false;
	let cursor = parent;
	let parentDepth = 0;
	const ancestors = /* @__PURE__ */ new Set();
	while (cursor !== void 0) {
		if (cursor === child || ancestors.has(cursor)) return false;
		ancestors.add(cursor);
		parentDepth++;
		cursor = state.parents.get(cursor);
	}
	const pending = [{
		callId: child,
		depth: 1
	}];
	const descendants = /* @__PURE__ */ new Set();
	let subtreeDepth = 0;
	for (const candidate of pending) {
		if (descendants.has(candidate.callId)) return false;
		descendants.add(candidate.callId);
		subtreeDepth = Math.max(subtreeDepth, candidate.depth);
		for (const nested of state.children.get(candidate.callId) ?? []) pending.push({
			callId: nested.callId,
			depth: candidate.depth + 1
		});
	}
	return parentDepth + subtreeDepth <= MAX_DEPTH;
}
function updateDispatch(state, match) {
	const event = match.event;
	if (event.type !== "tool/ptc-dispatch-start" && event.type !== "tool/ptc-dispatch") return state;
	const data = event.data;
	const parentCallId = String(data.parentCallId);
	const subCallId = String(data.subCallId);
	const siblings = state.children.get(parentCallId) ?? [];
	const index = siblings.findIndex((candidate) => candidate.callId === subCallId);
	if (event.type === "tool/ptc-dispatch-start") {
		if (index >= 0 || !acceptsEdge(state, parentCallId, subCallId)) return state;
		const children = new Map(state.children);
		children.set(parentCallId, [...siblings, childCall(match, data)]);
		const parents = new Map(state.parents);
		parents.set(subCallId, parentCallId);
		return {
			...state,
			children,
			parents
		};
	}
	if (index < 0 && !acceptsEdge(state, parentCallId, subCallId)) return state;
	const settled = childResult(match, data, index < 0 ? void 0 : siblings[index]);
	const children = new Map(state.children);
	children.set(parentCallId, index < 0 ? [...siblings, settled] : siblings.map((child, at) => at === index ? settled : child));
	const parents = new Map(state.parents);
	if (index < 0) parents.set(subCallId, parentCallId);
	return {
		...state,
		children,
		parents
	};
}
function projectBlock(block, state, interruptedAt, visited = /* @__PURE__ */ new Set(), depth = 1) {
	if (visited.has(block.callId) || depth > MAX_DEPTH) return {
		...block,
		subCalls: []
	};
	const nextVisited = new Set(visited);
	nextVisited.add(block.callId);
	const children = (state.children.get(block.callId) ?? block.subCalls).map((child) => projectBlock(child, state, interruptedAt, nextVisited, depth + 1));
	const interruptionSeq = "kind" in block ? void 0 : interruptedAt?.seq;
	const interruptionTime = "kind" in block ? void 0 : interruptedAt?.time;
	const cached = projectedBlocks.get(block);
	if (cached !== void 0 && cached.interruptionSeq === interruptionSeq && cached.interruptionTime === interruptionTime && sameReferences(cached.children, children)) return cached.value;
	const projected = "kind" in block || interruptedAt === void 0 ? sameReferences(block.subCalls, children) ? block : {
		...block,
		subCalls: children
	} : {
		kind: "tool-result",
		seq: interruptedAt.seq + CHAT_SYNTHETIC_SEQ_OFFSETS.interruptedFollowup,
		time: interruptedAt.time,
		callId: block.callId,
		...block.parentCallId === void 0 ? {} : { parentCallId: block.parentCallId },
		call: {
			name: block.name,
			argsRaw: block.argsRaw
		},
		callTime: block.time,
		content: [],
		isError: true,
		error: {
			name: "Interrupted",
			code: "interrupted"
		},
		subCalls: children
	};
	projectedBlocks.set(block, {
		children,
		interruptionSeq,
		interruptionTime,
		value: projected
	});
	return projected;
}
function sameReferences(left, right) {
	return left.length === right.length && left.every((value, index) => value === right[index]);
}
function interruption(context) {
	const location = context.start?.location;
	if (location?.kind === "step" && location.step.status === "closed") return location.step.end;
	if ((location?.kind === "step" || location?.kind === "turn") && location.turn.status === "closed") return location.turn.end;
}
function fallbackState$2(context) {
	const match = context.matches.find((candidate) => candidate.event.type === "tool/result");
	const root = match === void 0 ? void 0 : rootResult(match);
	if (root === void 0) return void 0;
	let state = {
		root,
		children: /* @__PURE__ */ new Map(),
		parents: /* @__PURE__ */ new Map()
	};
	for (const candidate of context.matches) state = updateDispatch(state, candidate);
	return state;
}
/** Root Tool lifecycle and nested PTC dispatch Definition. */
const toolDefinition = {
	kind: "tool-call",
	target: "chat",
	match: (event) => {
		if (event.type === "tool/call") return {
			id: String(event.data.callId),
			role: "start"
		};
		if (event.type === "tool/result" && isAppendSurfaceEvent(event)) return {
			id: String(event.data.message.source.callId),
			role: "update"
		};
		if (event.type === "tool/ptc-dispatch-start" || event.type === "tool/ptc-dispatch") {
			const rootCallId = event.data.rootCallId;
			return typeof rootCallId === "string" && rootCallId !== "" ? {
				id: rootCallId,
				role: "update"
			} : null;
		}
		return null;
	},
	start: (_context, match) => ({
		root: rootCall(match),
		children: /* @__PURE__ */ new Map(),
		parents: /* @__PURE__ */ new Map()
	}),
	update: (context, match) => {
		if (match.event.type === "tool/result") {
			const result = rootResult(match, "kind" in context.state.root ? void 0 : context.state.root);
			return result === void 0 ? context.state : {
				...context.state,
				root: result
			};
		}
		return updateDispatch(context.state, match);
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$2(context);
		if (state === void 0) return null;
		const projected = projectBlock(state.root, state, interruption(context));
		return chatNode(context, "tool-call", context.start?.event.seq ?? ("kind" in state.root ? state.root.seq : context.matches[0]?.event.seq ?? 0), { root: projected });
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/turn-error.js
function lastStep$1(context) {
	const location = context.start?.location ?? context.matches[0]?.location;
	if (location?.kind !== "turn" && location?.kind !== "step") return 0;
	return location.turn.steps.at(-1)?.step ?? 0;
}
function failureFrom(match) {
	if (match.event.type !== "turn/end" || match.event.data.reason.kind !== "error") return void 0;
	const failure = match.event.data.reason.error;
	const display = displayFailure(failure);
	return {
		seq: match.event.seq,
		time: match.event.time,
		message: display.message,
		...display.code === void 0 ? {} : { code: display.code }
	};
}
function fallbackState$1(context) {
	const end = context.matches.find((match) => failureFrom(match) !== void 0);
	if (end?.event.type !== "turn/end") return void 0;
	const failure = failureFrom(end);
	if (failure === void 0) return void 0;
	return {
		turn: end.event.data.turn,
		failure
	};
}
/**
* Terminal turn failure Definition. Retries run inside the failing turn, so the
* turn's `llm/retry` history never suppresses this terminal row; the model-retry
* node renders that history separately.
*/
const turnErrorDefinition = {
	kind: "turn-error",
	target: "chat",
	match: (event) => {
		if (event.type === "turn/start") return {
			id: String(event.data.turn),
			role: "start"
		};
		if (event.type === "turn/end" && event.data.reason.kind === "error") return {
			id: String(event.data.turn),
			role: "update"
		};
		return null;
	},
	start: (_context, match) => {
		if (match.event.type !== "turn/start") throw new Error("turn-error start requires turn/start");
		return { turn: match.event.data.turn };
	},
	update: (context, match) => {
		const failure = failureFrom(match);
		return failure === void 0 ? context.state : {
			...context.state,
			failure
		};
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$1(context);
		if (state?.failure === void 0) return null;
		const failure = state.failure;
		const node = {
			kind: "turn-error",
			seq: failure.seq,
			time: failure.time,
			turn: state.turn,
			step: lastStep$1(context),
			message: failure.message,
			...failure.code === void 0 ? {} : { code: failure.code }
		};
		return chatNode(context, "turn-error", node.seq, node);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/turn-max-tokens.js
function lastStep(context) {
	const location = context.start?.location ?? context.matches[0]?.location;
	if (location?.kind !== "turn" && location?.kind !== "step") return 0;
	return location.turn.steps.at(-1)?.step ?? 0;
}
/**
* Anchor the notice between the closing Assistant and the turn-tail so the
* tail stays the turn's last Chat node and keeps its branch action enabled.
* Without a closing text Assistant there is no branch action to protect, and
* the turn/end seq keeps the notice at the truncation point.
*/
function noticeAnchor(context, seq) {
	const location = context.start?.location ?? context.matches[0]?.location;
	if (location?.kind !== "turn" && location?.kind !== "step") return seq;
	const closing = location.turn.data.get("turn-tail")?.closing;
	return closing === null || closing === void 0 ? seq : closing.finalNode.seq + CHAT_SYNTHETIC_SEQ_OFFSETS.maxTokensNotice;
}
function stateFrom(match) {
	if (match.event.type !== "turn/end" || match.event.data.reason.kind !== "max-tokens") return void 0;
	return {
		turn: match.event.data.turn,
		seq: match.event.seq,
		time: match.event.time
	};
}
/** Notice Definition for a turn the provider ended at its output-token cap. */
const turnMaxTokensDefinition = {
	kind: "turn-max-tokens",
	target: "chat",
	match: (event) => {
		if (event.type === "turn/end" && event.data.reason.kind === "max-tokens") return {
			id: String(event.data.turn),
			role: "start"
		};
		return null;
	},
	start: (_context, match) => {
		const state = stateFrom(match);
		if (state === void 0) throw new Error("turn-max-tokens start requires a max-tokens turn/end");
		return state;
	},
	update: (context) => context.state,
	buildViewNode: (context) => {
		const state = context.state;
		if (state === void 0) return null;
		const node = {
			kind: "turn-max-tokens",
			seq: state.seq,
			time: state.time,
			turn: state.turn,
			step: lastStep(context)
		};
		return chatNode(context, "turn-max-tokens", noticeAnchor(context, state.seq), node);
	}
};
//#endregion
//#region lib/types/client/contract/assistant-content.js
/**
* Test whether Assistant blocks contain a user-facing reply rather than only
* reasoning or Tool-call protocol material.
* @param blocks - Assistant content blocks.
* @returns whether the blocks contain visible reply content.
*/
function hasAssistantReplyContent(blocks) {
	return blocks.some((block) => {
		if (block.kind === "reasoning" || block.kind === "tool-call") return false;
		if (block.kind === "text") return block.text.trim() !== "";
		return true;
	});
}
//#endregion
//#region lib/types/client/conversation-nodes/turn-process.js
function eventTurn(event) {
	const data = event.data;
	return typeof data.turn === "number" ? data.turn : void 0;
}
function visibleChunk(chunk) {
	if (chunk.type === "text-delta" || chunk.type === "reasoning-delta") return chunk.text.trim() !== "";
	if (chunk.type === "block-start") return chunk.blockType !== "text" && chunk.blockType !== "reasoning" && chunk.blockType !== "tool-call";
	if (chunk.type !== "block-end") return false;
	const block = chunk.block;
	if (block.type === "tool-call") return false;
	if (block.type === "text" || block.type === "reasoning") return block.text.trim() !== "";
	return true;
}
function visibleAssistantEvent(event) {
	if (event.type === "assistant/live-chunk") return visibleChunk(event.data.chunk);
	if (event.type === "assistant/attempt") return false;
	return event.type === "assistant/message" && event.surfaceOp === "append" && toAssistantBlocks(event.data.message.content).some((block) => {
		if (block.kind === "tool-call") return false;
		if (block.kind === "text" || block.kind === "reasoning") return block.text.trim() !== "";
		return true;
	});
}
function processEvidence(event) {
	if (visibleAssistantEvent(event)) {
		if (event.type !== "assistant/live-chunk" && event.type !== "assistant/message" && event.type !== "assistant/attempt") return void 0;
		return {
			kind: "assistant",
			seq: event.seq,
			step: event.data.step
		};
	}
	if (event.type === "tool/call" || event.type === "tool/result" && event.surfaceOp === "append" || event.type === "llm/retry") return {
		kind: "other",
		seq: event.seq
	};
}
function turnLocation$1(context) {
	const location = context.start?.location ?? context.matches.at(-1)?.location;
	return location?.kind === "turn" || location?.kind === "step" ? location.turn : void 0;
}
function fallbackState(context) {
	const turn = context.matches.map((match) => eventTurn(match.event)).find((candidate) => candidate !== void 0);
	if (turn === void 0) return void 0;
	let state = {
		turn,
		assistantStartByStep: /* @__PURE__ */ new Map(),
		messageCountByStep: /* @__PURE__ */ new Map(),
		messageCount: 0,
		toolCallCount: 0,
		subagentCount: 0
	};
	for (const match of context.matches) state = updateProcessState(state, match.event);
	return state;
}
function isFinalAssistant(data) {
	return data?.finalNode !== void 0;
}
function latestAnswer(turn) {
	const data = turn.steps.at(-1)?.data.get("assistant-step");
	if (!isFinalAssistant(data) || !hasAssistantReplyContent(data.blocks)) return null;
	return data.blocks.some((block) => block.kind === "tool-call") ? null : data;
}
function processSpec(state, turn) {
	const controlAnchorSeq = state.controlAnchorSeq;
	if (controlAnchorSeq === void 0) return null;
	const answer = latestAnswer(turn);
	const counts = {
		messageCount: answer === null ? state.messageCount : [...state.messageCountByStep].filter(([step]) => step < answer.step).reduce((total, [, count]) => total + count, 0),
		toolCallCount: state.toolCallCount,
		subagentCount: state.subagentCount
	};
	if (answer === null) return {
		turn: turn.turn,
		controlAnchorSeq,
		processStartSeq: controlAnchorSeq,
		answerAnchorSeq: null,
		answerStep: null,
		inlineReasoning: false,
		...counts
	};
	const inlineReasoning = answer.blocks.some((block) => block.kind === "reasoning" && block.text.trim() !== "");
	const earlierAssistantSeq = Math.min(...[...state.assistantStartByStep].filter(([step]) => step < answer.step).map(([, seq]) => seq));
	const externalProcessSeq = Math.min(state.otherStartSeq ?? Number.POSITIVE_INFINITY, earlierAssistantSeq);
	return {
		turn: turn.turn,
		controlAnchorSeq,
		processStartSeq: turn.start?.seq ?? (Number.isFinite(externalProcessSeq) ? externalProcessSeq : answer.finalNode.seq),
		answerAnchorSeq: answer.finalNode.seq,
		answerStep: answer.step,
		inlineReasoning,
		...counts
	};
}
function updateProcessState(state, event) {
	let current = state;
	if (event.type === "assistant/message" && event.surfaceOp === "append" && hasAssistantReplyContent(toAssistantBlocks(event.data.message.content))) {
		const messageCountByStep = new Map(current.messageCountByStep);
		messageCountByStep.set(event.data.step, (messageCountByStep.get(event.data.step) ?? 0) + 1);
		current = {
			...current,
			messageCountByStep,
			messageCount: current.messageCount + 1
		};
	}
	if (event.type === "tool/call") {
		const subagent = isSubagentDelegationTool(event.data.name);
		current = {
			...current,
			toolCallCount: current.toolCallCount + (subagent ? 0 : 1),
			subagentCount: current.subagentCount + (subagent ? 1 : 0)
		};
	}
	const evidence = processEvidence(event);
	if (evidence === void 0) return current;
	if (evidence.kind === "other") return current.otherStartSeq === void 0 ? {
		...current,
		otherStartSeq: evidence.seq,
		controlAnchorSeq: Math.min(current.controlAnchorSeq ?? Number.POSITIVE_INFINITY, evidence.seq)
	} : current;
	if (current.assistantStartByStep.has(evidence.step)) return current;
	const assistantStartByStep = new Map(current.assistantStartByStep);
	assistantStartByStep.set(evidence.step, evidence.seq);
	return {
		...current,
		assistantStartByStep,
		controlAnchorSeq: Math.min(current.controlAnchorSeq ?? Number.POSITIVE_INFINITY, evidence.seq)
	};
}
/** Turn-scoped process range and answer-boundary Definition. */
const turnProcessDefinition = {
	kind: "turn-process",
	target: "chat",
	match: (event) => {
		if (event.type === "turn/start") return {
			id: String(event.data.turn),
			role: "start"
		};
		const turn = eventTurn(event);
		if (turn === void 0) return null;
		if (event.type === "assistant/live-chunk" || event.type === "assistant/message" || event.type === "tool/call" || event.type === "tool/result" || event.type === "llm/retry" || event.type === "step/start" || event.type === "step/end" || event.type === "turn/end") return {
			id: String(turn),
			role: "update"
		};
		return null;
	},
	start: (_context, match) => {
		if (match.event.type !== "turn/start") throw new Error("turn-process start requires turn/start");
		return {
			turn: match.event.data.turn,
			assistantStartByStep: /* @__PURE__ */ new Map(),
			messageCountByStep: /* @__PURE__ */ new Map(),
			messageCount: 0,
			toolCallCount: 0,
			subagentCount: 0
		};
	},
	update: (context, match) => updateProcessState(context.state, match.event),
	publication: (match) => {
		if (match.event.type === "assistant/live-chunk") {
			const type = match.event.data.chunk.type;
			return type === "usage" || type === "finish" ? "none" : "animation-frame";
		}
		return "immediate";
	},
	buildLocationData: (context, scope, previous) => {
		if (scope !== "turn") return null;
		const state = context.state ?? fallbackState(context);
		if (state === void 0) return null;
		const turn = turnLocation$1(context);
		if (turn === void 0) return null;
		const current = context.current.get("chat");
		const latestStep = turn.steps.at(-1);
		if (previous?.kind === "turn" && previous.key === "turn-process" && current?.kind === "turn-process" && current.data.answerAnchorSeq === null && current.data.controlAnchorSeq === state.controlAnchorSeq && current.data.messageCount === state.messageCount && current.data.toolCallCount === state.toolCallCount && current.data.subagentCount === state.subagentCount && turn.status !== "closed" && latestStep?.status !== "closed") return previous;
		const spec = processSpec(state, turn);
		if (spec === null) return null;
		if (previous?.kind === "turn" && previous.turn === spec.turn && previous.key === "turn-process" && sameTurnProcessSpec(previous.value, spec)) return previous;
		return {
			kind: "turn",
			turn: turn.turn,
			key: "turn-process",
			value: spec
		};
	},
	buildViewNode: (context) => {
		const turn = turnLocation$1(context);
		const data = turn?.data.get("turn-process");
		if (turn === void 0 || data === void 0) return null;
		const current = context.current.get("chat");
		const state = context.state;
		if (current?.kind === "turn-process" && state !== void 0 && current.data.answerAnchorSeq === null && current.data.controlAnchorSeq === state.controlAnchorSeq && current.data.messageCount === state.messageCount && current.data.toolCallCount === state.toolCallCount && current.data.subagentCount === state.subagentCount && turn.status !== "closed" && turn.steps.at(-1)?.status !== "closed" && current.location === (context.start?.location ?? context.matches[0]?.location)) return current;
		return chatNode(context, "turn-process", data.controlAnchorSeq + CHAT_SYNTHETIC_SEQ_OFFSETS.processControl, data);
	}
};
//#endregion
//#region ../../llm/llm/src/assistant-stream.ts
/**
* The last raw chunk of one never-packed type, scanning backwards and stopping at the first hit.
* @param stream - compact records from one durable Assistant settlement.
* @param type - chunk type that only appears as a raw record.
* @returns the stream's final chunk of that type, or undefined when it has none.
*/
function lastAssistantStreamChunk(stream, type) {
	for (let index = stream.length - 1; index >= 0; index -= 1) {
		const record = stream[index];
		if (record.type === "chunk" && record.chunk.type === type) return record.chunk;
	}
}
//#endregion
//#region ../../llm/token-meter/src/turn-usage.ts
function isCount(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function safeSum(values) {
	let total = 0;
	for (const value of values) {
		total += value;
		if (!Number.isSafeInteger(total)) return void 0;
	}
	return total;
}
function messageRoute(message) {
	const { provider, model } = message.source;
	return provider.length > 0 && model.length > 0 ? {
		provider,
		model
	} : void 0;
}
function streamUsage(stream) {
	return lastAssistantStreamChunk(stream, "usage")?.usage;
}
function normalizeUsage(usage, route) {
	const { inputTokens, outputTokens, cacheReadTokens, cacheWriteTokens, reasoningTokens, totalTokens } = usage;
	if (!isCount(inputTokens) || !isCount(outputTokens)) return void 0;
	if (cacheReadTokens !== void 0 && !isCount(cacheReadTokens)) return void 0;
	if (cacheWriteTokens !== void 0 && !isCount(cacheWriteTokens)) return void 0;
	if (reasoningTokens !== void 0 && (!isCount(reasoningTokens) || reasoningTokens > outputTokens)) return;
	const knownPrompt = safeSum([
		inputTokens,
		...cacheReadTokens === void 0 ? [] : [cacheReadTokens],
		...cacheWriteTokens === void 0 ? [] : [cacheWriteTokens]
	]);
	if (knownPrompt === void 0) return void 0;
	let exactTotal;
	if (totalTokens !== void 0) {
		if (!isCount(totalTokens)) return void 0;
		const exactPrompt = totalTokens - outputTokens;
		if (!isCount(exactPrompt) || exactPrompt < knownPrompt) return void 0;
		if (cacheReadTokens !== void 0 && cacheWriteTokens !== void 0 && exactPrompt !== knownPrompt) return;
		exactTotal = totalTokens;
	} else {
		if (cacheReadTokens === void 0 || cacheWriteTokens === void 0) return void 0;
		const derivedTotal = safeSum([knownPrompt, outputTokens]);
		if (derivedTotal === void 0) return void 0;
		exactTotal = derivedTotal;
	}
	return {
		inputTokens,
		outputTokens,
		totalTokens: exactTotal,
		...cacheReadTokens === void 0 ? {} : { cacheReadTokens },
		...cacheWriteTokens === void 0 ? {} : { cacheWriteTokens },
		...reasoningTokens === void 0 ? {} : { reasoningTokens },
		...route === void 0 ? {} : { route }
	};
}
function aggregateAttempts(attempts) {
	if (attempts.length === 0) return void 0;
	const inputTokens = safeSum(attempts.map((attempt) => attempt.inputTokens));
	const outputTokens = safeSum(attempts.map((attempt) => attempt.outputTokens));
	const totalTokens = safeSum(attempts.map((attempt) => attempt.totalTokens));
	if (inputTokens === void 0 || outputTokens === void 0 || totalTokens === void 0) return void 0;
	const cacheRead = attempts.map((attempt) => attempt.cacheReadTokens);
	const cacheWrite = attempts.map((attempt) => attempt.cacheWriteTokens);
	const reasoning = attempts.map((attempt) => attempt.reasoningTokens);
	const cacheReadTokens = cacheRead.every(isCount) ? safeSum(cacheRead) : void 0;
	const cacheWriteTokens = cacheWrite.every(isCount) ? safeSum(cacheWrite) : void 0;
	const reasoningTokens = reasoning.every(isCount) ? safeSum(reasoning) : void 0;
	let routes;
	const attributed = attempts.map((attempt) => attempt.route);
	if (attributed.every((route) => route !== void 0)) {
		const unique = /* @__PURE__ */ new Map();
		for (const route of attributed) unique.set(`${route.provider}\0${route.model}`, route);
		routes = [...unique.values()];
	}
	return {
		uncachedInputTokens: inputTokens,
		outputTokens,
		totalTokens,
		...cacheReadTokens === void 0 ? {} : { cacheReadTokens },
		...cacheWriteTokens === void 0 ? {} : { cacheWriteTokens },
		...reasoningTokens === void 0 ? {} : { reasoningTokens },
		...routes === void 0 ? {} : { routes }
	};
}
function sameAttempt(state, turn, step) {
	return state.turn === turn && state.step === step;
}
/**
* Fold one complete Turn's durable attempt lifecycle into exact token accounting.
*
* No attempt is inferred from a usage sample. Any missing lifecycle boundary,
* incomplete attempt usage, unsafe count, or contradictory exact total makes
* the whole disclosure unavailable.
* @param events - Turn-local durable events from `turn/start` through `turn/end`.
* @returns exact aggregate usage, or undefined when it cannot be proven.
*/
function deriveTurnTokenUsage(events) {
	let state = { kind: "idle" };
	const attempts = [];
	let turn;
	let sawEnd = false;
	let invalid = false;
	const closeOpen = (route) => {
		if (state.kind !== "open" || state.sample === void 0) return false;
		const normalized = normalizeUsage(state.sample, route);
		if (normalized === void 0) return false;
		attempts.push(normalized);
		return true;
	};
	for (const event of events) {
		if (invalid) break;
		if (event.type === "turn/start") {
			if (turn !== void 0 || state.kind !== "idle") invalid = true;
			else turn = event.data.turn;
			continue;
		}
		if (turn === void 0) {
			invalid = true;
			break;
		}
		if (event.type === "turn/end") {
			if (event.data.turn !== turn || state.kind !== "idle" || sawEnd) invalid = true;
			else sawEnd = true;
			continue;
		}
		if (sawEnd) {
			invalid = true;
			break;
		}
		if (event.type === "step/start") {
			if (event.data.turn !== turn || state.kind !== "idle") invalid = true;
			else state = {
				kind: "open",
				turn,
				step: event.data.step
			};
			continue;
		}
		if (event.type === "llm/retry-started") {
			if (event.data.turn !== turn || state.kind !== "settled" || state.by !== "retry" || !sameAttempt(state, event.data.turn, event.data.step)) invalid = true;
			else state = {
				kind: "open",
				turn,
				step: event.data.step
			};
			continue;
		}
		if (event.type === "assistant/attempt") {
			if (event.data.turn !== turn || state.kind !== "open" || !sameAttempt(state, event.data.turn, event.data.step)) {
				invalid = true;
				continue;
			}
			const sample = streamUsage(event.data.stream) ?? state.sample;
			state = {
				kind: "open",
				turn,
				step: event.data.step,
				...sample === void 0 ? {} : { sample }
			};
			if (!closeOpen()) invalid = true;
			else state = {
				kind: "finishClosed",
				turn,
				step: event.data.step
			};
			continue;
		}
		if (event.type === "assistant/message") {
			if (event.data.turn !== turn || state.kind !== "open" || !sameAttempt(state, event.data.turn, event.data.step)) {
				invalid = true;
				continue;
			}
			const sample = event.data.usage ?? streamUsage(event.data.stream);
			if (sample !== void 0) state = {
				...state,
				sample
			};
			if (!closeOpen(messageRoute(event.data.message))) invalid = true;
			else state = {
				kind: "settled",
				turn,
				step: event.data.step,
				by: "message"
			};
			continue;
		}
		if (event.type === "llm/retry") {
			if (event.data.turn !== turn || state.kind === "idle" || !sameAttempt(state, event.data.turn, event.data.step)) {
				invalid = true;
				continue;
			}
			if (state.kind === "settled" || state.kind === "open" && !closeOpen()) invalid = true;
			if (!invalid) state = {
				kind: "settled",
				turn,
				step: event.data.step,
				by: "retry"
			};
			continue;
		}
		if (event.type === "step/end") {
			if (event.data.turn !== turn || state.kind === "idle" || !sameAttempt(state, event.data.turn, event.data.step)) {
				invalid = true;
				continue;
			}
			if (state.kind === "open" && !closeOpen()) invalid = true;
			if (!invalid) state = { kind: "idle" };
		}
	}
	return invalid || !sawEnd || state.kind !== "idle" ? void 0 : aggregateAttempts(attempts);
}
//#endregion
//#region lib/types/client/contract/turn-metrics.js
function usageOutputTokens(usage) {
	if (typeof usage !== "object" || usage === null) return null;
	const value = usage.outputTokens;
	return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : null;
}
/**
* Read one assistant node's TTFT, request wall time, and output tokens.
* @param node - A settled assistant node.
* @returns Per-part readings with `null` for unrecorded values.
*/
function assistantStepReading(node) {
	const timing = node.timing;
	return {
		ttftMs: timing !== void 0 && timing.stepStartTime !== null && timing.firstTokenTime !== null ? Math.max(0, timing.firstTokenTime - timing.stepStartTime) : null,
		requestMs: timing !== void 0 && timing.stepStartTime !== null ? Math.max(0, timing.completedTime - timing.stepStartTime) : null,
		outputTokens: usageOutputTokens(node.usage)
	};
}
/**
* Fold assistant nodes into per-turn footer metrics.
*
* TTFT is the turn's lowest-step request-dispatch-to-first-token reading, so
* it is only meaningful when the turn's start is inside
* the loaded window (the caller gates on `turnTimings`, which shares that
* window). Output rate divides summed output tokens by summed full request wall
* time, counting only steps that carry both. Chunk-arrival spans are excluded:
* a buffered transport can drain generated chunks much faster than the model
* produced them.
* @param nodes - Snapshot nodes of the loaded window.
* @returns Turn number → available metrics; turns with none are absent.
*/
function deriveTurnMetrics(nodes) {
	const folds = /* @__PURE__ */ new Map();
	for (const node of nodes) {
		if (node.kind !== "assistant") continue;
		const reading = assistantStepReading(node);
		let fold = folds.get(node.turn);
		if (fold === void 0) {
			fold = {
				firstStep: node.step,
				firstStepTtftMs: reading.ttftMs,
				throughputMs: 0,
				outputTokens: 0,
				sampled: false
			};
			folds.set(node.turn, fold);
		} else if (node.step < fold.firstStep) {
			fold.firstStep = node.step;
			fold.firstStepTtftMs = reading.ttftMs;
		}
		if (reading.requestMs !== null && reading.outputTokens !== null) {
			fold.throughputMs += reading.requestMs;
			fold.outputTokens += reading.outputTokens;
			fold.sampled = true;
		}
	}
	const metrics = /* @__PURE__ */ new Map();
	for (const [turn, fold] of folds) {
		const entry = {};
		if (fold.firstStepTtftMs !== null) entry.ttftMs = fold.firstStepTtftMs;
		if (fold.sampled && fold.throughputMs > 0) entry.tokensPerSecond = fold.outputTokens / (fold.throughputMs / 1e3);
		if (entry.ttftMs !== void 0 || entry.tokensPerSecond !== void 0) metrics.set(turn, entry);
	}
	return metrics;
}
//#endregion
//#region lib/types/client/conversation-nodes/turn-tail.js
function isSessionEvent(event) {
	return event.type !== "assistant/live-chunk";
}
function hasTextAssistant(event) {
	return event.type === "assistant/message" && event.surfaceOp === "append" && toAssistantBlocks(event.data.message.content).some((block) => block.kind === "text" && block.text.trim() !== "");
}
function chunkHasText(chunk) {
	if (chunk.type === "text-delta") return chunk.text.trim() !== "";
	return chunk.type === "block-end" && chunk.block.type === "text" && chunk.block.text.trim() !== "";
}
function turnCoordinates(event) {
	if (event.type === "assistant/message" || event.type === "assistant/attempt" || event.type === "assistant/live-chunk" || event.type === "step/start" || event.type === "step/end") return {
		turn: event.data.turn,
		step: event.data.step
	};
	if (event.type === "llm/retry" || event.type === "llm/retry-started") return {
		turn: event.data.turn,
		step: event.data.step
	};
}
function closingAnchor(context) {
	let anchor = context.matches.find((match) => match.event.type === "turn/end")?.event.seq ?? context.start?.event.seq ?? context.matches[0]?.event.seq ?? 0;
	const steps = /* @__PURE__ */ new Map();
	for (const match of context.matches) {
		const event = match.event;
		if (event.type === "turn/end") continue;
		const coordinates = turnCoordinates(event);
		if (coordinates?.step === void 0) continue;
		const previous = steps.get(coordinates.step) ?? {
			streamedText: false,
			finalized: false
		};
		if (event.type === "assistant/live-chunk") {
			steps.set(coordinates.step, {
				...previous,
				streamedText: previous.streamedText || chunkHasText(event.data.chunk)
			});
			continue;
		}
		if (event.type === "assistant/message") {
			steps.set(coordinates.step, {
				streamedText: false,
				finalized: true
			});
			if (hasTextAssistant(event)) anchor = event.seq + CHAT_SYNTHETIC_SEQ_OFFSETS.finalizedFollowup;
			continue;
		}
		if (event.type === "llm/retry") {
			steps.set(coordinates.step, {
				streamedText: false,
				finalized: false
			});
			continue;
		}
		if (event.type === "step/end" && previous.streamedText && !previous.finalized) anchor = event.seq + CHAT_SYNTHETIC_SEQ_OFFSETS.interruptedFollowup;
	}
	return anchor;
}
function turnLocation(context) {
	const location = context.start?.location ?? context.matches[0]?.location;
	return location?.kind === "turn" || location?.kind === "step" ? location.turn : void 0;
}
function hasText(data) {
	return data.finalNode !== void 0 && data.blocks.some((block) => block.kind === "text" && block.text.trim() !== "");
}
function tailData(context) {
	const end = context.state === void 0 ? context.matches.find((match) => match.event.type === "turn/end") : context.state.end;
	if (end?.event.type !== "turn/end") return null;
	const turn = turnLocation(context);
	if (turn === void 0) return null;
	const finalized = turn.steps.map((step) => step.data.get("assistant-step")).filter((candidate) => candidate !== void 0).filter((candidate) => candidate.finalNode !== void 0).sort((left, right) => left.finalNode.seq - right.finalNode.seq);
	const closing = finalized.findLast(hasText) ?? null;
	let latestTranscriptSeq = finalized.at(-1)?.finalNode.seq;
	for (const match of context.matches) {
		const event = match.event;
		const candidate = event.type === "tool/call" || event.type === "tool/result" && event.surfaceOp === "append" || event.type === "turn/end" && event.data.reason.kind === "error" || event.type === "llm/retry" ? event.seq : void 0;
		if (candidate !== void 0 && (latestTranscriptSeq === void 0 || candidate > latestTranscriptSeq)) latestTranscriptSeq = candidate;
	}
	const metrics = deriveTurnMetrics(finalized.map((candidate) => candidate.finalNode)).get(end.event.data.turn);
	const tokenUsage = context.start?.event.type === "turn/start" ? deriveTurnTokenUsage(context.matches.map((match) => match.event).filter(isSessionEvent)) : void 0;
	return {
		turn: end.event.data.turn,
		seq: end.event.seq,
		time: end.event.time,
		closing,
		branchUnavailable: closing === null || latestTranscriptSeq !== closing.finalNode.seq,
		...metrics?.ttftMs === void 0 ? {} : { ttftMs: metrics.ttftMs },
		...metrics?.tokensPerSecond === void 0 ? {} : { tokensPerSecond: metrics.tokensPerSecond },
		...tokenUsage === void 0 ? {} : { tokenUsage }
	};
}
/** Completed-turn footer Definition independent of any Assistant row. */
const turnTailDefinition = {
	kind: "turn-tail",
	target: "chat",
	match: (event) => {
		if (event.type === "turn/start") return {
			id: String(event.data.turn),
			role: "start"
		};
		if (event.type === "turn/end") return {
			id: String(event.data.turn),
			role: "update"
		};
		if (event.type === "tool/call" || event.type === "tool/result") return {
			id: String(event.data.turn),
			role: "update"
		};
		const coordinates = turnCoordinates(event);
		if (coordinates !== void 0) return {
			id: String(coordinates.turn),
			role: "update"
		};
		return null;
	},
	start: (_context, match) => {
		if (match.event.type !== "turn/start") throw new Error("turn-tail start requires turn/start");
		return { turn: match.event.data.turn };
	},
	update: (context, match) => match.event.type === "turn/end" ? {
		...context.state,
		end: match
	} : context.state,
	publication: (match) => match.event.type === "turn/end" ? "immediate" : "none",
	buildLocationData: (context, scope) => {
		if (scope !== "turn") return null;
		const value = tailData(context);
		return value === null ? null : {
			kind: "turn",
			turn: value.turn,
			key: "turn-tail",
			value
		};
	},
	buildViewNode: (context) => {
		const data = turnLocation(context)?.data.get("turn-tail");
		return data === void 0 ? null : chatNode(context, "turn-tail", closingAnchor(context), data);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/workspace.js
/** Turn-local save progress and the final branch-return receipt. */
const workspaceDefinition = {
	kind: "workspace-state",
	target: "chat",
	match: (event) => {
		if (event.type === "turn/start") return {
			id: String(event.data.turn),
			role: "start"
		};
		return event.type === "workspace/state" && event.data.phase !== "ready" ? {
			id: String(event.data.turn),
			role: "update"
		} : null;
	},
	start: () => null,
	update: (context, match) => match.event.type === "workspace/state" ? match.event.data : context.state,
	publication: () => "immediate",
	buildViewNode: (context) => {
		const last = context.matches.at(-1);
		if (last?.event.type !== "workspace/state") return null;
		return chatNode(context, "workspace-state", last.event.seq, last.event.data);
	}
};
//#endregion
//#region lib/types/client/conversation-nodes/register.js
/**
* Install the Chat business Definitions and snapshot builder for the registry owner's lifetime.
* Duplicate contribution names fail through the registry; the caller owns registration-scope disposal.
* @param conversation - scoped registries and the shared prompt inspectors.
*/
function registerConversationNodes(conversation) {
	const definitions = [
		nextStepInboxDefinition,
		messageDefinition,
		systemMessageDefinition((previous, event) => conversation.inspectSystemPrompt(previous, event)),
		requestPromptDefinition((previous, event, system) => conversation.inspectRequestPrompt(previous, event, system)),
		assistantDefinition,
		turnProcessDefinition,
		toolDefinition,
		commandDefinition,
		compactionDefinition,
		retryDefinition,
		turnErrorDefinition,
		turnMaxTokensDefinition,
		turnTailDefinition,
		workspaceDefinition
	];
	for (const definition of definitions) conversation.events.register(definition);
	conversation.events.registerFallback(unknownFallbackDefinition);
	conversation.views.register(chatViewDefinition);
}
//#endregion
//#region lib/types/client/contract/snapshot.js
const EMPTY_LIST = [];
const EMPTY_TIMELINE = {
	turnOrder: EMPTY_LIST,
	turns: /* @__PURE__ */ new Map()
};
const EMPTY_NODE_SOURCE = {
	getSnapshot: () => void 0,
	subscribe: () => () => {}
};
const EMPTY_NODE_PROCESS_SOURCE = {
	getSnapshot: () => void 0,
	subscribe: () => () => {}
};
/** Empty Chat target used before a view builder is registered. */
const EMPTY_CHAT_SNAPSHOT = {
	order: EMPTY_LIST,
	nodes: {
		get: () => void 0,
		source: () => EMPTY_NODE_SOURCE,
		processSource: () => EMPTY_NODE_PROCESS_SOURCE,
		values: () => EMPTY_LIST
	},
	locations: {
		getTurn: () => EMPTY_LIST,
		getStep: () => EMPTY_LIST
	},
	navigation: { items: () => EMPTY_LIST },
	timeline: EMPTY_TIMELINE,
	legacy: {
		nodes: EMPTY_LIST,
		turnTimings: /* @__PURE__ */ new Map(),
		turnEnds: /* @__PURE__ */ new Map(),
		partial: null,
		runningCalls: EMPTY_LIST
	}
};
//#endregion
export { EMPTY_CHAT_SNAPSHOT, registerConversationNodes as registerChatConversation };
