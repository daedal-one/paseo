//#region lib/types/client/trajectory-definition-common.js
/**
* Wrap one contribution in the Engine-owned target envelope.
*
* @param context - Context that owns the contribution identity.
* @param anchorSeq - Sequence used to order the contribution.
* @param data - Trajectory-specific contribution payload.
* @returns The contribution wrapped as a Trajectory view node.
*/
function trajectoryNode(context, anchorSeq, data) {
	return {
		key: context.key,
		kind: context.kind,
		id: context.id,
		target: "trajectory",
		anchorSeq,
		location: context.start?.location ?? { kind: "unresolved" },
		data
	};
}
//#endregion
//#region lib/types/client/trajectory-event-projection.js
/** Trajectory-owned conversion from durable Session events to ledger view data. */
function asRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value) ? value : null;
}
function readString(record, key) {
	const value = record[key];
	return typeof value === "string" && value.length > 0 ? value : null;
}
function collect(source, member, field) {
	const list = source[member];
	if (!Array.isArray(list)) return [];
	const seen = [];
	for (const entry of list) {
		const record = asRecord(entry);
		const value = record === null ? null : readString(record, field);
		if (value !== null && !seen.includes(value)) seen.push(value);
	}
	return seen;
}
function joined(names) {
	return names.length > 0 ? names.join(", ") : null;
}
/** Forms Trajectory presents structurally; unknown merge-extensible values remain opaque. */
const KNOWN_FORMS = [
	"instructions",
	"catalog",
	"snapshot",
	"notice",
	"relay",
	"recall"
];
/**
* Read the target-supported presentation form from a durable message source.
* @param source - Logged `user/message` source.
* @returns Supported form, or null for the opaque presentation.
*/
function contextForm(source) {
	const record = asRecord(source);
	const form = record === null ? null : readString(record, "form");
	return form !== null && KNOWN_FORMS.includes(form) ? form : null;
}
/**
* Project a durable message source to the Trajectory row's role and producer label.
* @param source - Logged `user/message` source.
* @returns Role and label rendered by Trajectory.
*/
function contextProvenance(source) {
	const record = asRecord(source);
	const kind = record === null ? null : readString(record, "kind");
	if (record === null || kind === null) return {
		role: "inject",
		label: null
	};
	switch (kind) {
		case "session-reference": return {
			role: "recall",
			label: joined(collect(record, "references", "label")) ?? kind
		};
		case "agent-instructions": return {
			role: "inject",
			label: joined(collect(record, "changes", "path")) ?? kind
		};
		case "plugin": return {
			role: "inject",
			label: readString(record, "plugin") ?? kind
		};
		case "skill-invocation": return {
			role: "inject",
			label: readString(record, "name") ?? kind
		};
		default: return {
			role: "inject",
			label: kind
		};
	}
}
/**
* Classify finalized Assistant content for Trajectory rendering.
* @param content - Core content blocks.
* @returns Trajectory blocks in source order.
*/
function toAssistantBlocks(content) {
	return content.map(toAssistantBlock);
}
/**
* Classify one finalized Assistant block for Trajectory rendering.
* @param block - Core content block.
* @returns Trajectory block.
*/
function toAssistantBlock(block) {
	switch (block.type) {
		case "text": return {
			kind: "text",
			text: block.text
		};
		case "reasoning": return {
			kind: "reasoning",
			text: block.text
		};
		case "image": return {
			kind: "image",
			attachment: block.attachment
		};
		case "tool-call": return {
			kind: "tool-call",
			callId: String(block.id),
			name: block.name,
			argsRaw: block.arguments
		};
		default: return {
			kind: "other",
			block
		};
	}
}
/**
* Create the initial Trajectory block for one streamed Assistant block kind.
* @param blockType - Wire block kind.
* @returns Empty block ready to receive deltas.
*/
function emptyAssistantBlock(blockType) {
	switch (blockType) {
		case "text": return {
			kind: "text",
			text: ""
		};
		case "reasoning": return {
			kind: "reasoning",
			text: ""
		};
		case "tool-call": return {
			kind: "tool-call",
			callId: "",
			name: "",
			argsRaw: ""
		};
		default: return {
			kind: "other",
			block: null
		};
	}
}
/**
* Convert a durable failure to locale-independent fields safe for Trajectory.
* @param failure - Failure preserved by a Session event.
* @returns Sanitized message and optional stable provider code.
*/
function displayFailure(failure) {
	if (failure === null || typeof failure !== "object") return { message: String(failure) };
	const record = failure;
	const code = typeof record.code === "string" ? record.code : void 0;
	if (code === "AUTH") return {
		code,
		message: ""
	};
	return {
		...code === void 0 ? {} : { code },
		message: typeof record.message === "string" ? record.message : JSON.stringify(failure)
	};
}
/**
* Whether a stream chunk carries visible model output for Trajectory timing.
* @param chunk - Stream chunk to inspect.
* @returns true for a non-empty text, reasoning, or Tool-call delta.
*/
function isTokenDelta(chunk) {
	switch (chunk.type) {
		case "text-delta":
		case "reasoning-delta": return chunk.text !== "";
		case "tool-call-delta": return chunk.argumentsDelta !== "" || chunk.name !== void 0;
		default: return false;
	}
}
//#endregion
//#region lib/types/client/trajectory-assistant-definition.js
function initialState(turn, step, startSeq, startTime, started) {
	return {
		turn,
		step,
		startSeq,
		startTime,
		started,
		sawChunk: false,
		blocks: [],
		visibleBlocks: 0,
		firstVisibleSeq: void 0,
		firstVisibleTime: void 0,
		firstTokenTime: void 0,
		final: void 0,
		usage: void 0,
		retry: void 0,
		stepEnd: void 0
	};
}
function compactBlocks(blocks) {
	return blocks.filter((block) => block !== void 0);
}
function blockIsVisible(block) {
	if (block === void 0 || block.kind === "tool-call") return false;
	if (block.kind === "text" || block.kind === "reasoning") return block.text.trim() !== "";
	return true;
}
function countVisibleBlocks(blocks) {
	let count = 0;
	for (const block of blocks) if (blockIsVisible(block)) count++;
	return count;
}
function hasInterruptionEvidence(blocks) {
	return blocks.some((block) => {
		if (block.kind === "text" || block.kind === "reasoning") return block.text.trim() !== "";
		return true;
	});
}
function addUsage(current, next) {
	return {
		inputTokens: (current?.inputTokens ?? 0) + next.inputTokens,
		outputTokens: (current?.outputTokens ?? 0) + next.outputTokens,
		...current?.cacheReadTokens === void 0 && next.cacheReadTokens === void 0 ? {} : { cacheReadTokens: (current?.cacheReadTokens ?? 0) + (next.cacheReadTokens ?? 0) },
		...current?.cacheWriteTokens === void 0 && next.cacheWriteTokens === void 0 ? {} : { cacheWriteTokens: (current?.cacheWriteTokens ?? 0) + (next.cacheWriteTokens ?? 0) },
		...current?.reasoningTokens === void 0 && next.reasoningTokens === void 0 ? {} : { reasoningTokens: (current?.reasoningTokens ?? 0) + (next.reasoningTokens ?? 0) }
	};
}
function updateChunk(state, chunk, seq, time) {
	if (chunk.type === "usage") return {
		...state,
		sawChunk: true,
		usage: addUsage(state.usage, chunk.usage)
	};
	const blocks = [...state.blocks];
	let changedIndex = -1;
	let previousVisible = false;
	switch (chunk.type) {
		case "block-start":
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(blocks[chunk.index]);
			blocks[chunk.index] = emptyAssistantBlock(chunk.blockType);
			break;
		case "text-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			blocks[chunk.index] = {
				kind: "text",
				text: (previous?.kind === "text" ? previous.text : "") + chunk.text
			};
			break;
		}
		case "reasoning-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			blocks[chunk.index] = {
				kind: "reasoning",
				text: (previous?.kind === "reasoning" ? previous.text : "") + chunk.text
			};
			break;
		}
		case "tool-call-delta": {
			const previous = blocks[chunk.index];
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(previous);
			const base = previous?.kind === "tool-call" ? previous : {
				kind: "tool-call",
				callId: "",
				name: "",
				argsRaw: ""
			};
			blocks[chunk.index] = {
				kind: "tool-call",
				callId: base.callId || String(chunk.id),
				name: chunk.name ?? base.name,
				argsRaw: base.argsRaw + chunk.argumentsDelta
			};
			break;
		}
		case "block-end":
			changedIndex = chunk.index;
			previousVisible = blockIsVisible(blocks[chunk.index]);
			blocks[chunk.index] = toAssistantBlock(chunk.block);
			break;
		default: return {
			...state,
			sawChunk: true
		};
	}
	const visibleBlocks = state.visibleBlocks - Number(previousVisible) + Number(blockIsVisible(blocks[changedIndex]));
	return {
		...state,
		sawChunk: true,
		blocks,
		visibleBlocks,
		...visibleBlocks > 0 && state.firstVisibleSeq === void 0 ? {
			firstVisibleSeq: seq,
			firstVisibleTime: time
		} : {},
		...isTokenDelta(chunk) && state.firstTokenTime === void 0 ? { firstTokenTime: time } : {}
	};
}
function settleMessage(state, match, event) {
	const blocks = toAssistantBlocks(event.data.message.content);
	return {
		...state,
		sawChunk: false,
		blocks,
		visibleBlocks: countVisibleBlocks(blocks),
		final: match,
		usage: event.data.usage
	};
}
function closedBoundary(context) {
	if (context.state?.stepEnd?.event.type === "step/end") return context.state.stepEnd.event;
	const location = context.start?.location ?? context.matches.at(-1)?.location;
	if (location?.kind === "step" && location.step.status === "closed") return location.step.end;
	if ((location?.kind === "step" || location?.kind === "turn") && location.turn.status === "closed") return location.turn.end;
}
function fallbackState$1(context) {
	let state;
	for (const match of context.matches) {
		const event = match.event;
		if (event.type === "assistant/live-chunk") {
			state ??= initialState(event.data.turn, event.data.step, event.seq, event.time, false);
			state = updateChunk(state, event.data.chunk, event.seq, event.time);
		} else if (event.type === "assistant/message") {
			state ??= initialState(event.data.turn, event.data.step, event.seq, event.time, false);
			state = settleMessage(state, match, event);
		} else if (event.type === "step/end" && state !== void 0) state = {
			...state,
			stepEnd: match
		};
	}
	return state;
}
function finalNode(state, context) {
	const final = state.final;
	if (final?.event.type === "assistant/message") {
		const event = final.event;
		return {
			kind: "assistant",
			seq: event.seq,
			messageId: event.data.message.id,
			time: event.time,
			turn: state.turn,
			step: state.step,
			blocks: toAssistantBlocks(event.data.message.content),
			usage: event.data.usage,
			provenance: {
				provider: event.data.message.source.provider,
				model: event.data.message.source.model
			},
			timing: {
				stepStartTime: state.started ? state.startTime : null,
				firstTokenTime: state.firstTokenTime ?? null,
				completedTime: event.time
			},
			...event.data.interrupted === true ? { interrupted: true } : {}
		};
	}
	const boundary = closedBoundary(context);
	if (boundary === void 0) return void 0;
	const blocks = compactBlocks(state.blocks);
	if (!hasInterruptionEvidence(blocks)) return void 0;
	return {
		kind: "assistant",
		seq: boundary.seq - .9,
		time: boundary.time,
		turn: state.turn,
		step: state.step,
		blocks,
		interrupted: true
	};
}
function assistantRequest(state, node, boundary) {
	if (!state.started) return void 0;
	const status = node !== void 0 && node.interrupted !== true ? "complete" : state.retry !== void 0 || boundary !== void 0 ? "error" : "running";
	return {
		purpose: "assistant",
		startSeq: state.startSeq,
		turn: state.turn,
		step: state.step,
		startedAt: state.startTime,
		completedAt: node?.time ?? boundary?.time ?? null,
		status,
		...state.retry === void 0 ? {} : {
			error: state.retry.message,
			...state.retry.code === void 0 ? {} : { errorCode: state.retry.code },
			retry: state.retry.retry,
			...state.retry.maxRetries === void 0 ? {} : { maxRetries: state.retry.maxRetries },
			retryDelayMs: state.retry.delayMs
		},
		...node?.messageId === void 0 ? {} : {
			resultSeq: node.seq,
			...node.provenance === void 0 ? {} : { provenance: node.provenance }
		},
		...state.usage === void 0 ? {} : { usage: state.usage }
	};
}
/** Trajectory-owned Assistant streaming, settlement, and request lifecycle. */
const trajectoryAssistantDefinition = {
	kind: "trajectory-assistant-step",
	target: "trajectory",
	match: (event) => {
		if (event.type === "step/start") return {
			id: `${event.data.turn}:${event.data.step}`,
			role: "start"
		};
		if (event.type === "assistant/live-chunk" || event.type === "assistant/message" || event.type === "llm/retry" || event.type === "step/end") return {
			id: `${event.data.turn}:${event.data.step}`,
			role: "update"
		};
		return null;
	},
	start: (_context, match) => {
		if (match.event.type !== "step/start") throw new Error("trajectory-assistant-step start requires step/start");
		return initialState(match.event.data.turn, match.event.data.step, match.event.seq, match.event.time, true);
	},
	update: (context, match) => {
		if (match.event.type === "assistant/live-chunk") return updateChunk(context.state, match.event.data.chunk, match.event.seq, match.event.time);
		if (match.event.type === "assistant/message") return settleMessage(context.state, match, match.event);
		if (match.event.type === "step/end") return {
			...context.state,
			stepEnd: match
		};
		if (match.event.type !== "llm/retry") return context.state;
		const data = match.event.data;
		const failure = displayFailure(data.failure);
		return {
			...initialState(context.state.turn, context.state.step, context.state.startSeq, context.state.startTime, true),
			firstTokenTime: context.state.firstTokenTime,
			usage: context.state.usage,
			retry: {
				message: failure.message,
				...failure.code === void 0 ? {} : { code: failure.code },
				retry: data.retry,
				...data.mode === "normal" ? { maxRetries: data.maxRetries } : {},
				delayMs: data.delayMs
			}
		};
	},
	publication: (match) => {
		if (match.event.type === "step/start") return "none";
		if (match.event.type !== "assistant/live-chunk") return "immediate";
		const type = match.event.data.chunk.type;
		return type === "usage" || type === "finish" ? "none" : "animation-frame";
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState$1(context);
		if (state === void 0) return null;
		const node = finalNode(state, context);
		const boundary = closedBoundary(context);
		const partial = node === void 0 && boundary === void 0 && state.sawChunk ? {
			turn: state.turn,
			step: state.step,
			blocks: compactBlocks(state.blocks)
		} : null;
		const request = assistantRequest(state, node, boundary);
		if (node === void 0 && partial === null && request === void 0) return null;
		return trajectoryNode(context, state.startSeq, {
			kind: "assistant",
			...node === void 0 ? {} : { node },
			partial,
			...request === void 0 ? {} : { request }
		});
	}
};
const trajectoryTurnEndDefinition = {
	kind: "trajectory-turn-end",
	target: "trajectory",
	match: (event) => event.type === "turn/end" ? {
		id: String(event.seq),
		role: "start"
	} : null,
	start: (_context, match) => {
		if (match.event.type !== "turn/end") throw new Error("trajectory-turn-end start requires turn/end");
		const reason = match.event.data.reason;
		const failure = reason.kind === "error" ? displayFailure(reason.error) : void 0;
		return {
			turn: match.event.data.turn,
			seq: match.event.seq,
			time: match.event.time,
			...failure === void 0 ? {} : {
				error: failure.message,
				...failure.code === void 0 ? {} : { errorCode: failure.code }
			}
		};
	},
	update: (context) => context.state,
	buildViewNode: (context) => context.state === void 0 ? null : trajectoryNode(context, context.state.seq, {
		kind: "turn-end",
		turn: context.state.turn,
		time: context.state.time,
		...context.state.error === void 0 ? {} : { error: context.state.error },
		...context.state.errorCode === void 0 ? {} : { errorCode: context.state.errorCode }
	})
};
/**
* Register the Trajectory Assistant lifecycle.
*
* @param conversation - Plugin context receiving the Definitions.
*/
function registerTrajectoryAssistantDefinition(conversation) {
	conversation.events.register(trajectoryAssistantDefinition);
	conversation.events.register(trajectoryTurnEndDefinition);
}
//#endregion
//#region lib/types/client/trajectory-compaction-definition.js
function checkpointId(event) {
	if (event.type !== "user/message") return void 0;
	const source = event.data.source;
	return source.kind === "plugin" && source.plugin === "compact" && typeof source.compactionId === "string" && source.compactionId !== "" ? source.compactionId : void 0;
}
function eventCompactionId(event) {
	if (event.type !== "compaction/start" && event.type !== "compaction/summary" && event.type !== "compaction/end") return void 0;
	const value = event.data.compactionId;
	return typeof value === "string" && value !== "" ? value : void 0;
}
function requestFromState(state) {
	const start = state.start.event;
	if (start.type !== "compaction/start") return void 0;
	const summary = state.summary?.event;
	const end = state.end?.event;
	const checkpoint = state.checkpoint?.event;
	return {
		purpose: "compaction",
		startSeq: start.seq,
		turn: start.data.turn,
		step: 0,
		startedAt: start.time,
		completedAt: end?.type === "compaction/end" ? end.time : null,
		status: end?.type !== "compaction/end" ? "running" : end.data.error === void 0 ? "complete" : "error",
		...end?.type === "compaction/end" && end.data.error !== void 0 ? { error: end.data.error } : {},
		...summary?.type !== "compaction/summary" ? {} : {
			resultSeq: summary.seq,
			summary: summary.data.summary,
			...summary.data.rawOutput === void 0 ? {} : { rawOutput: summary.data.rawOutput },
			provenance: {
				provider: summary.data.provider,
				model: summary.data.model
			},
			requestConfig: {
				provider: summary.data.provider,
				model: summary.data.model,
				purpose: "compaction",
				...summary.data.maxTokens === void 0 ? {} : { maxTokens: summary.data.maxTokens }
			},
			...summary.data.usage === void 0 ? {} : { usage: summary.data.usage }
		},
		...checkpoint?.type === "user/message" ? { replacementSeq: checkpoint.seq } : {}
	};
}
const trajectoryCompactionDefinition = {
	kind: "trajectory-compaction",
	target: "trajectory",
	match: (event) => {
		const compactId = eventCompactionId(event);
		if (compactId !== void 0) return {
			id: compactId,
			role: event.type === "compaction/start" ? "start" : "update"
		};
		const checkpoint = checkpointId(event);
		return checkpoint === void 0 ? null : {
			id: checkpoint,
			role: "update"
		};
	},
	start: (_context, match) => {
		if (match.event.type !== "compaction/start") throw new Error("trajectory-compaction start requires compaction/start");
		return { start: match };
	},
	update: (context, match) => {
		if (match.event.type === "compaction/summary") return {
			...context.state,
			summary: match
		};
		if (match.event.type === "compaction/end") return {
			...context.state,
			end: match
		};
		return checkpointId(match.event) === void 0 ? context.state : {
			...context.state,
			checkpoint: match
		};
	},
	buildViewNode: (context) => {
		if (context.state === void 0) return null;
		const request = requestFromState(context.state);
		return request === void 0 ? null : trajectoryNode(context, request.startSeq, {
			kind: "compaction",
			request
		});
	}
};
const trajectorySessionEndDefinition = {
	kind: "trajectory-session-end",
	target: "trajectory",
	match: (event) => event.type === "session/end-seed" ? {
		id: String(event.seq),
		role: "start"
	} : null,
	start: (_context, match) => ({
		seq: match.event.seq,
		time: match.event.time
	}),
	update: (context) => context.state,
	buildViewNode: (context) => context.state === void 0 ? null : trajectoryNode(context, context.state.seq, {
		kind: "session-end",
		seq: context.state.seq,
		time: context.state.time
	})
};
/**
* Register Trajectory compaction requests and session boundaries.
*
* @param conversation - Plugin context receiving the Definitions.
*/
function registerTrajectoryCompactionDefinitions(conversation) {
	conversation.events.register(trajectoryCompactionDefinition);
	conversation.events.register(trajectorySessionEndDefinition);
}
//#endregion
//#region lib/types/client/trajectory-message-definitions.js
const EMPTY_PENDING = {
	kind: "snapshot",
	ids: []
};
const EMPTY_CURRENT_CLAIMED = /* @__PURE__ */ new Set();
function materializePending(state) {
	const splices = [];
	let current = state;
	while (current.kind === "splice") {
		splices.push(current);
		current = current.previous;
	}
	const pending = [...current.ids];
	for (const splice of splices.reverse()) pending.splice(splice.start, splice.removedCount, ...splice.inserted);
	return pending;
}
function withoutInserted(claimed, inserted) {
	let next;
	for (const id of inserted) {
		if (!claimed.has(id)) continue;
		next ??= new Set(claimed);
		next.delete(id);
	}
	return next ?? claimed;
}
/**
* Apply one next-step splice under the AgentLoop's durable event ordering.
* An entered claim logs its complete message batch before another claim; a
* rejected claim logs no messages, so only the current claim can classify a
* later `user/message`.
*/
function applySplice(previous, splice) {
	const priorPending = previous?.state.pending ?? EMPTY_PENDING;
	const inserted = splice.inserted.map((identity) => identity.id);
	const removedCount = splice.removedCount ?? 0;
	if (removedCount > 0 && splice.outcome !== "canceled") {
		const pending = materializePending(priorPending);
		const removed = pending.splice(splice.start, removedCount, ...inserted);
		return {
			pending: {
				kind: "snapshot",
				ids: pending
			},
			currentClaimed: new Set(removed)
		};
	}
	const currentClaimed = withoutInserted(previous?.state.currentClaimed ?? EMPTY_CURRENT_CLAIMED, inserted);
	return {
		pending: {
			kind: "splice",
			previous: priorPending,
			start: splice.start,
			removedCount,
			inserted
		},
		currentClaimed
	};
}
const trajectoryInboxDefinition = {
	kind: "trajectory-inbox-next-step",
	match: (event) => {
		if (event.type === "agent/inbox/spliced" && event.data.target === "next-step") return {
			id: String(event.seq),
			role: "start"
		};
		return null;
	},
	start: (_context, match, reader) => {
		if (match.event.type !== "agent/inbox/spliced") throw new Error("trajectory-inbox-next-step start requires agent/inbox/spliced");
		return applySplice(reader.previous("trajectory-inbox-next-step"), match.event.data);
	},
	update: (context) => context.state,
	publication: () => "none"
};
const trajectoryMessageDefinition = {
	kind: "trajectory-input-message",
	target: "trajectory",
	match: (event) => event.type === "user/message" ? {
		id: String(event.seq),
		role: "start"
	} : null,
	start: (_context, match, reader) => {
		if (match.event.type !== "user/message") throw new Error("trajectory-input-message start requires user/message");
		const event = match.event;
		if (event.data.source.kind !== "user") return {
			kind: "context",
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source,
			provenance: contextProvenance(event.data.source),
			form: contextForm(event.data.source)
		};
		return reader.previous("trajectory-inbox-next-step")?.state.currentClaimed.has(String(event.data.id)) === true ? {
			kind: "steering",
			messageId: event.data.id,
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source
		} : {
			kind: "user",
			seq: event.seq,
			time: event.time,
			content: event.data.content,
			source: event.data.source
		};
	},
	update: (context) => context.state,
	buildViewNode: (context) => context.state === void 0 ? null : trajectoryNode(context, context.state.seq, {
		kind: "node",
		node: context.state
	})
};
/**
* Register Trajectory-owned inbox classification and message records.
*
* @param conversation - Plugin context receiving the Definitions.
*/
function registerTrajectoryMessageDefinitions(conversation) {
	conversation.events.register(trajectoryInboxDefinition);
	conversation.events.register(trajectoryMessageDefinition);
}
//#endregion
//#region lib/types/client/trajectory-request-header-definition.js
/**
* Definition retaining each `system/message` surface node for the Trajectory
* request-header Definition, which reads it through `reader.previous` and
* presents the prompt through the request's `system` cell. A node that
* lacks a loaded header contributes known text without request config or tools; an in-history
* update contributes a request-header fact at its own position, since no
* `request/header` follows a prompt change that keeps the cached history.
* Surface replacements also contribute prompt changes when they remove the
* effective node; earlier request facts remain historical.
* @param inspect - Pure surface interpretation supplied by uiConversation.
* @returns The Trajectory system-prompt Definition.
*/
function trajectorySystemMessageDefinition(inspect) {
	return {
		kind: "trajectory-system-message",
		target: "trajectory",
		match: (event) => event.type === "system/message" || "surfaceOp" in event && event.surfaceOp !== "append" ? {
			id: String(event.seq),
			role: "start"
		} : null,
		start: (_context, match, reader) => {
			const prior = reader.previous("trajectory-system-message")?.state;
			const state = inspect(prior, match.event);
			const node = state.effective;
			if (state.uncertain) {
				const header = reader.previous("trajectory-request-header")?.state;
				if (header === void 0) return state;
				return {
					...state,
					header: {
						seq: match.event.seq,
						time: match.event.time,
						location: match.location,
						prompt: {
							...header.prompt,
							system: ""
						}
					}
				};
			}
			if (node === void 0 || node.text === prior?.effective?.text || state.introduced !== void 0 && !state.introduced.update) return {
				...state,
				...prior?.header === void 0 ? {} : { header: prior.header }
			};
			const header = reader.previous("trajectory-request-header")?.state;
			const systemHeader = prior?.header;
			const previous = systemHeader !== void 0 && (header === void 0 || systemHeader.seq > header.seq) ? systemHeader : header;
			if (previous === void 0) return state;
			return {
				...state,
				header: {
					seq: node.seq,
					time: node.time,
					prompt: {
						...previous.prompt,
						system: node.text
					},
					change: {
						seq: node.seq,
						time: node.time,
						kind: "system",
						previous: previous.prompt
					},
					location: match.location
				}
			};
		},
		update: (context) => context.state,
		buildViewNode: (context) => {
			const state = context.state;
			if (state?.header !== void 0 && state.header.seq === context.start?.event.seq) return trajectoryNode(context, state.header.seq, {
				kind: "request-header",
				header: state.header
			});
			const prompt = state?.introduced;
			return prompt !== void 0 && prompt.text !== "" && context.start?.event.type === "system/message" && context.start.event.surfaceOp === "append" ? trajectoryNode(context, prompt.seq, {
				kind: "system-prompt",
				prompt
			}) : null;
		}
	};
}
/**
* Request-header fact Definition for the Trajectory target.
* @param inspect - the shared prompt interpretation, supplied by the
* uiConversation service (a client bundle cannot value-import it).
* @returns the Trajectory request-header Definition.
*/
function trajectoryRequestHeaderDefinition(inspect) {
	return {
		kind: "trajectory-request-header",
		target: "trajectory",
		match: (event) => event.type === "request/header" ? {
			id: String(event.seq),
			role: "start"
		} : null,
		start: (_context, match, reader) => {
			if (match.event.type !== "request/header") throw new Error("trajectory-request-header start requires request/header");
			const header = reader.previous("trajectory-request-header")?.state;
			const state = reader.previous("trajectory-system-message")?.state;
			const systemHeader = state?.header;
			const previous = systemHeader !== void 0 && (header === void 0 || systemHeader.seq > header.seq) ? systemHeader.prompt : header?.prompt;
			const system = state?.effective;
			const inspection = inspect(previous, match.event, system);
			const { prompt } = inspection;
			const change = inspection.change ?? (systemHeader !== void 0 && (header === void 0 || systemHeader.seq > header.seq) ? systemHeader.change : void 0);
			return {
				seq: match.event.seq,
				time: match.event.time,
				prompt,
				location: match.location,
				...change === void 0 ? {} : { change }
			};
		},
		update: (context) => context.state,
		buildViewNode: (context) => context.state === void 0 ? null : trajectoryNode(context, context.state.seq, {
			kind: "request-header",
			header: context.state
		})
	};
}
/**
* Register Trajectory system-prompt node and request-header facts.
*
* @param conversation - Plugin context receiving the Definitions.
*/
function registerTrajectoryRequestHeaderDefinition(conversation) {
	conversation.events.register(trajectorySystemMessageDefinition((previous, event) => conversation.inspectSystemPrompt(previous, event)));
	conversation.events.register(trajectoryRequestHeaderDefinition((previous, event, system) => conversation.inspectRequestPrompt(previous, event, system)));
}
//#endregion
//#region lib/types/client/copy-codes.js
/** Stable non-display markers for client-synthesized trajectory copy. */
/** Error marker localized only when the trajectory renders it. */
const COMPACTION_INTERRUPTED_ERROR = "trajectory.compaction-interrupted";
//#endregion
//#region lib/types/client/trajectory-snapshot-builder.js
const EMPTY_LIST = [];
/** Stable empty target used until a Session has assembled Trajectory records. */
const EMPTY_TRAJECTORY_SNAPSHOT = {
	eventNodes: EMPTY_LIST,
	eventLocations: /* @__PURE__ */ new Map(),
	requests: EMPTY_LIST,
	callSchemas: /* @__PURE__ */ new Map(),
	partial: null,
	runningCalls: EMPTY_LIST
};
function stepKey(turn, step) {
	return `${turn}\u0000${step}`;
}
function headerStepKey(header) {
	const location = header.location;
	return location.kind === "step" ? stepKey(location.turn.turn, location.step.step) : void 0;
}
function headerFor(request, headersByStep, previous) {
	return headersByStep.get(stepKey(request.turn, request.step)) ?? (previous !== void 0 && previous.seq < request.startSeq ? {
		latest: previous,
		...previous.change === void 0 ? {} : { change: previous.change }
	} : void 0);
}
function applyHeader(request, header, includeChange) {
	return header === void 0 ? request : {
		...request,
		prompt: header.latest.prompt,
		requestConfig: header.latest.prompt.config,
		...includeChange && header.change !== void 0 ? { promptChange: header.change } : {}
	};
}
function withRequestConfig(node, prompt) {
	return prompt === void 0 ? node : {
		...node,
		requestConfig: prompt.config
	};
}
function captureSchemas(block, toolsByName, output) {
	const name = "kind" in block ? block.call?.name : block.name;
	const schema = name === void 0 ? void 0 : toolsByName.get(name);
	if (schema !== void 0) output.set(block.callId, schema);
	for (const child of block.subCalls) captureSchemas(child, toolsByName, output);
}
function indexTools(tools) {
	return new Map(tools.map((tool) => [tool.name, tool]));
}
function interruptCompactions(requests, boundaries) {
	let nextRequest = 0;
	const runningCompactions = [];
	for (const boundary of boundaries) {
		while (nextRequest < requests.length) {
			const request = requests[nextRequest];
			if (request === void 0 || request.startSeq >= boundary.seq) break;
			if (request.purpose === "compaction" && request.status === "running") runningCompactions.push(nextRequest);
			nextRequest++;
		}
		let index = runningCompactions.pop();
		while (index !== void 0 && requests[index]?.status !== "running") index = runningCompactions.pop();
		if (index === void 0) continue;
		const request = requests[index];
		if (request?.purpose !== "compaction") continue;
		requests[index] = {
			...request,
			completedAt: boundary.time,
			status: "error",
			error: COMPACTION_INTERRUPTED_ERROR
		};
	}
}
function applyTurnErrors(requests, endings) {
	const lastAssistantByTurn = /* @__PURE__ */ new Map();
	for (const [index, request] of requests.entries()) if (request.purpose === "assistant") lastAssistantByTurn.set(request.turn, index);
	for (const ending of endings) {
		if (ending.error === void 0) continue;
		const index = lastAssistantByTurn.get(ending.turn);
		if (index === void 0) continue;
		const request = requests[index];
		if (request?.purpose !== "assistant") continue;
		requests[index] = {
			...request,
			completedAt: request.completedAt ?? ending.time,
			status: "error",
			error: ending.error,
			...ending.errorCode === void 0 ? {} : { errorCode: ending.errorCode }
		};
	}
}
/** Simple keyed adapter retaining the old Trajectory snapshot and stage layout. */
var TrajectorySnapshotBuilder = class {
	nodes = /* @__PURE__ */ new Map();
	positions = /* @__PURE__ */ new Map();
	contributions = [];
	empty = EMPTY_TRAJECTORY_SNAPSHOT;
	replace(input) {
		this.nodes.clear();
		for (const node of input.nodes) this.nodes.set(node.key, node);
		this.rebuildContributions();
		return this.snapshot();
	}
	apply(input) {
		let structural = false;
		for (const node of input.upserts) {
			const previous = this.nodes.get(node.key);
			this.nodes.set(node.key, node);
			if (previous === void 0 || previous.anchorSeq !== node.anchorSeq) {
				structural = true;
				continue;
			}
			const position = this.positions.get(node.key);
			if (position === void 0) structural = true;
			else this.contributions[position] = node;
		}
		if (structural) this.rebuildContributions();
		return this.snapshot();
	}
	snapshot() {
		const headersByStep = /* @__PURE__ */ new Map();
		for (const contribution of this.contributions) {
			if (contribution.data.kind !== "request-header") continue;
			const key = headerStepKey(contribution.data.header);
			if (key === void 0) continue;
			const previous = headersByStep.get(key);
			headersByStep.set(key, {
				latest: contribution.data.header,
				...contribution.data.header.change !== void 0 ? { change: contribution.data.header.change } : previous?.change === void 0 ? {} : { change: previous.change }
			});
		}
		const representedPrompts = new Set(this.contributions.flatMap((node) => node.data.kind === "request-header" && node.data.header.change !== void 0 ? [node.data.header.change.seq] : []));
		const systemPrompts = [];
		const finalized = [];
		const eventLocations = /* @__PURE__ */ new Map();
		const requests = [];
		const boundaries = [];
		const turnEndings = [];
		const callSchemas = /* @__PURE__ */ new Map();
		const consumedPromptChanges = /* @__PURE__ */ new Set();
		let previousHeader;
		let previousTools = /* @__PURE__ */ new Map();
		let partial = null;
		const runningCalls = [];
		for (const contribution of this.contributions) {
			const data = contribution.data;
			if (data.kind === "system-prompt") {
				if (!representedPrompts.has(data.prompt.seq)) systemPrompts.push(data.prompt);
				continue;
			}
			if (data.kind === "request-header") {
				previousHeader = data.header;
				previousTools = indexTools(data.header.prompt.tools);
				continue;
			}
			if (data.kind === "node") {
				finalized.push(data.node);
				eventLocations.set(data.node.seq, contribution.location);
				continue;
			}
			if (data.kind === "assistant") {
				const header = data.request === void 0 ? void 0 : headerFor(data.request, headersByStep, previousHeader);
				if (data.node !== void 0) finalized.push(withRequestConfig(data.node, header?.latest.prompt));
				if (data.partial !== null) partial = data.partial;
				if (data.request !== void 0) {
					const change = header?.change;
					const includeChange = change !== void 0 && !consumedPromptChanges.has(change.seq);
					requests.push(applyHeader(data.request, header, includeChange));
					if (includeChange) consumedPromptChanges.add(change.seq);
				}
				continue;
			}
			if (data.kind === "tool") {
				if ("kind" in data.root) finalized.push(data.root);
				else runningCalls.push(data.root);
				if (previousHeader !== void 0 && previousHeader.seq < contribution.anchorSeq) captureSchemas(data.root, previousTools, callSchemas);
				continue;
			}
			if (data.kind === "compaction") {
				requests.push(data.request);
				continue;
			}
			if (data.kind === "session-end") {
				boundaries.push({
					seq: data.seq,
					time: data.time
				});
				continue;
			}
			turnEndings.push({
				turn: data.turn,
				time: data.time,
				...data.error === void 0 ? {} : { error: data.error },
				...data.errorCode === void 0 ? {} : { errorCode: data.errorCode }
			});
		}
		requests.sort((left, right) => left.startSeq - right.startSeq);
		interruptCompactions(requests, boundaries);
		applyTurnErrors(requests, turnEndings);
		finalized.sort((left, right) => left.seq - right.seq);
		return {
			eventNodes: finalized,
			...systemPrompts.length > 0 ? { systemPrompts } : {},
			eventLocations,
			requests,
			callSchemas,
			partial,
			runningCalls
		};
	}
	rebuildContributions() {
		this.contributions = [...this.nodes.values()].sort((left, right) => left.anchorSeq - right.anchorSeq || left.key.localeCompare(right.key));
		this.positions.clear();
		for (const [index, contribution] of this.contributions.entries()) this.positions.set(contribution.key, index);
	}
};
/** Trajectory target factory preserving the existing stage-oriented view model. */
const trajectoryViewDefinition = {
	target: "trajectory",
	create: () => new TrajectorySnapshotBuilder()
};
/**
* Register the stage-oriented Trajectory target builder.
*
* @param conversation - Plugin context receiving the view Definition.
*/
function registerTrajectoryConversationView(conversation) {
	conversation.views.register(trajectoryViewDefinition);
}
//#endregion
//#region lib/types/client/trajectory-tool-definition.js
const MAX_DEPTH = 256;
function rootCall(match) {
	if (match.event.type !== "tool/call") throw new Error("trajectory-tool-call start requires tool/call");
	return {
		callId: String(match.event.data.callId),
		name: match.event.data.name,
		argsRaw: match.event.data.arguments,
		turn: match.event.data.turn,
		step: match.event.data.step,
		time: match.event.time,
		subCalls: []
	};
}
function rootResult(match, previous) {
	if (match.event.type !== "tool/result") return void 0;
	const result = match.event.data.message.content[0];
	return {
		kind: "tool-result",
		seq: match.event.seq,
		time: match.event.time,
		callId: String(match.event.data.message.source.callId),
		call: previous === void 0 ? null : {
			name: previous.name,
			argsRaw: previous.argsRaw
		},
		callTime: previous?.time ?? null,
		content: result.content,
		isError: result.isError === true,
		...match.event.data.error === void 0 ? {} : { error: match.event.data.error },
		meta: match.event.data.meta,
		subCalls: [],
		...match.detail?.kind === "tool-result" ? { deferred: true } : {}
	};
}
function locationTurn(match) {
	return match.location.kind === "step" || match.location.kind === "turn" ? match.location.turn.turn : 0;
}
function locationStep(match) {
	return match.location.kind === "step" ? match.location.step.step : 0;
}
function childCall(match, data) {
	return {
		callId: data.subCallId,
		parentCallId: data.parentCallId,
		name: data.name,
		argsRaw: JSON.stringify(data.arguments),
		turn: locationTurn(match),
		step: locationStep(match),
		time: match.event.time,
		subCalls: []
	};
}
function childResult(match, data, previous) {
	return {
		kind: "tool-result",
		seq: match.event.seq,
		time: match.event.time,
		callId: data.subCallId,
		parentCallId: data.parentCallId,
		call: {
			name: data.name,
			argsRaw: JSON.stringify(data.arguments)
		},
		callTime: previous === void 0 || "kind" in previous ? null : previous.time,
		content: data.content ?? [],
		isError: data.isError === true,
		subCalls: []
	};
}
function acceptsEdge(state, parent, child) {
	if (parent === child || state.parents.has(child)) return false;
	let cursor = parent;
	let parentDepth = 0;
	const ancestors = /* @__PURE__ */ new Set();
	while (cursor !== void 0) {
		if (cursor === child || ancestors.has(cursor)) return false;
		ancestors.add(cursor);
		parentDepth++;
		cursor = state.parents.get(cursor);
	}
	const pending = [{
		callId: child,
		depth: 1
	}];
	const descendants = /* @__PURE__ */ new Set();
	let subtreeDepth = 0;
	for (const candidate of pending) {
		if (descendants.has(candidate.callId)) return false;
		descendants.add(candidate.callId);
		subtreeDepth = Math.max(subtreeDepth, candidate.depth);
		for (const nested of state.children.get(candidate.callId) ?? []) pending.push({
			callId: nested,
			depth: candidate.depth + 1
		});
	}
	return parentDepth + subtreeDepth <= MAX_DEPTH;
}
function updateDispatch(state, match) {
	const event = match.event;
	if (event.type !== "tool/ptc-dispatch-start" && event.type !== "tool/ptc-dispatch") return state;
	const data = event.data;
	const parentId = String(data.parentCallId);
	const childId = String(data.subCallId);
	const siblings = state.children.get(parentId) ?? [];
	const index = siblings.indexOf(childId);
	if (index < 0 && !acceptsEdge(state, parentId, childId)) return state;
	if (event.type === "tool/ptc-dispatch-start" && index >= 0) return state;
	const calls = new Map(state.calls);
	calls.set(childId, event.type === "tool/ptc-dispatch-start" ? childCall(match, data) : childResult(match, data, calls.get(childId)));
	if (index >= 0) return {
		...state,
		calls
	};
	const children = new Map(state.children);
	children.set(parentId, [...siblings, childId]);
	const parents = new Map(state.parents);
	parents.set(childId, parentId);
	return {
		...state,
		calls,
		children,
		parents
	};
}
function interruption(context) {
	const location = context.start?.location;
	if (location?.kind === "step" && location.step.status === "closed") return location.step.end;
	if ((location?.kind === "step" || location?.kind === "turn") && location.turn.status === "closed") return location.turn.end;
}
function projectCall(state, callId, interruptedAt, visited = /* @__PURE__ */ new Set(), depth = 1) {
	const block = state.calls.get(callId);
	if (block === void 0) return void 0;
	if (visited.has(callId) || depth > MAX_DEPTH) return {
		...block,
		subCalls: []
	};
	const nextVisited = new Set(visited);
	nextVisited.add(callId);
	const subCalls = (state.children.get(callId) ?? []).flatMap((childId) => {
		const child = projectCall(state, childId, interruptedAt, nextVisited, depth + 1);
		return child === void 0 ? [] : [child];
	});
	if ("kind" in block || interruptedAt === void 0) return {
		...block,
		subCalls
	};
	return {
		kind: "tool-result",
		seq: interruptedAt.seq - .8,
		time: interruptedAt.time,
		callId: block.callId,
		...block.parentCallId === void 0 ? {} : { parentCallId: block.parentCallId },
		call: {
			name: block.name,
			argsRaw: block.argsRaw
		},
		callTime: block.time,
		content: [],
		isError: true,
		error: {
			name: "Interrupted",
			code: "interrupted"
		},
		subCalls
	};
}
function fallbackState(context) {
	const resultMatch = context.matches.find((match) => match.event.type === "tool/result");
	const root = resultMatch === void 0 ? void 0 : rootResult(resultMatch);
	if (root === void 0) return void 0;
	let state = {
		rootId: root.callId,
		calls: new Map([[root.callId, root]]),
		children: /* @__PURE__ */ new Map(),
		parents: /* @__PURE__ */ new Map()
	};
	for (const match of context.matches) state = updateDispatch(state, match);
	return state;
}
/** Trajectory-owned root Tool lifecycle with nested PTC dispatch calls. */
const trajectoryToolDefinition = {
	kind: "trajectory-tool-call",
	target: "trajectory",
	match: (event) => {
		if (event.type === "tool/call") return {
			id: String(event.data.callId),
			role: "start"
		};
		if (event.type === "tool/result") return {
			id: String(event.data.message.source.callId),
			role: "update"
		};
		if (event.type === "tool/ptc-dispatch-start" || event.type === "tool/ptc-dispatch") {
			const rootCallId = event.data.rootCallId;
			return typeof rootCallId === "string" && rootCallId !== "" ? {
				id: rootCallId,
				role: "update"
			} : null;
		}
		return null;
	},
	start: (_context, match) => {
		const root = rootCall(match);
		return {
			rootId: root.callId,
			calls: new Map([[root.callId, root]]),
			children: /* @__PURE__ */ new Map(),
			parents: /* @__PURE__ */ new Map()
		};
	},
	update: (context, match) => {
		if (match.event.type !== "tool/result") return updateDispatch(context.state, match);
		const previous = context.state.calls.get(context.state.rootId);
		const result = rootResult(match, previous !== void 0 && !("kind" in previous) ? previous : void 0);
		if (result === void 0) return context.state;
		const calls = new Map(context.state.calls);
		calls.set(context.state.rootId, result);
		return {
			...context.state,
			calls
		};
	},
	buildViewNode: (context) => {
		const state = context.state ?? fallbackState(context);
		if (state === void 0) return null;
		const root = projectCall(state, state.rootId, interruption(context));
		if (root === void 0) return null;
		return trajectoryNode(context, context.start?.event.seq ?? ("kind" in root ? root.seq : context.matches[0]?.event.seq ?? 0), {
			kind: "tool",
			root
		});
	}
};
/**
* Register the Trajectory Tool lifecycle.
*
* @param conversation - Plugin context receiving the Definition.
*/
function registerTrajectoryToolDefinition(conversation) {
	conversation.events.register(trajectoryToolDefinition);
}
//#endregion
//#region lib/types/client/register.js
/**
* Register Trajectory definitions and its incremental snapshot for the registry owner's lifetime.
* @param conversation - Scoped registries and shared prompt interpreters.
*/
function registerTrajectoryConversation(conversation) {
	registerTrajectoryMessageDefinitions(conversation);
	registerTrajectoryRequestHeaderDefinition(conversation);
	registerTrajectoryAssistantDefinition(conversation);
	registerTrajectoryToolDefinition(conversation);
	registerTrajectoryCompactionDefinitions(conversation);
	registerTrajectoryConversationView(conversation);
}
//#endregion
//#region lib/types/client/trajectory-record.js
/** Shared trajectory record data and formatting contracts. */
/**
* Resolve the identity that survives prepending older projected records.
* @param cell - Projected trajectory record.
* @returns Stable identity from the owning event or tool call, with a fixture fallback.
*/
function trajectoryRecordId(cell) {
	if (cell.recordId !== void 0) return cell.recordId;
	if (cell.callId !== void 0) return `${cell.kind}\u0000call\u0000${cell.callId}`;
	if (cell.sourceSeq !== void 0) return `${cell.kind}\u0000seq\u0000${cell.sourceSeq}`;
	return `${cell.kind}\u0000index\u0000${cell.index}`;
}
/**
* Format a duration in milliseconds with thousands separators.
* @param milliseconds - Duration in milliseconds, or `null` when absent.
* @param t - Trajectory locale translator.
* @returns `—` when unknown, otherwise an integer-millisecond label.
*/
function formatDurationMillis(milliseconds, t) {
	if (milliseconds === null || !Number.isFinite(milliseconds)) return "—";
	return t("unit.milliseconds", { value: String(Math.round(milliseconds)).replace(/\B(?=(\d{3})+(?!\d))/g, ",") });
}
/**
* Format an elapsed duration given in seconds as a millisecond label.
* @param seconds - Duration seconds, or `null` when absent.
* @param t - Trajectory locale translator.
* @returns `—` when unknown, otherwise an integer-millisecond label.
*/
function formatElapsedSeconds(seconds, t) {
	return formatDurationMillis(seconds === null ? null : seconds * 1e3, t);
}
//#endregion
//#region lib/types/client/layout.js
function layoutEntryOrder(entry) {
	return entry.kind === "system" && entry.change.kind === "initial" ? Number.NEGATIVE_INFINITY : entry.seq;
}
function inputCellDetail(node, t) {
	const preview = previewContent(node.content);
	const previewMarkdown = preview === "" ? void 0 : preview;
	const images = imageBlockCount(node.content);
	const files = fileBlockCount(node.content);
	return {
		text: [previewMarkdown === void 0 && images > 0 ? t("layout.imageOnly", { count: images }) : void 0, files > 0 ? t("layout.fileAttachments", { count: files }) : void 0].filter((value) => value !== void 0).join(" · "),
		...previewMarkdown === void 0 ? {} : { previewMarkdown },
		sourceSeq: node.seq,
		messageSource: node.source,
		inputDetail: detailContent(node.content),
		sourceBlocks: node.content.map((block) => sourceBlock(block)),
		timeSeconds: 0,
		startedAt: finiteTime(node.time)
	};
}
/**
* Fold a snapshot into turn → Message/Step groups with expanded cells.
* @param input - nodes plus in-flight partial/runningCalls.
* @param t - Trajectory locale translator.
* @returns turns ordered by first appearance.
*/
function deriveTrajectoryLayout(input, t) {
	const { nodes, eventLocations, partial, runningCalls, requests = [], callSchemas } = input;
	const resultByCall = indexResults(nodes);
	const callById = new Map(resultByCall);
	for (const call of runningCalls) callById.set(call.callId, call);
	const emittedCallIds = indexAssistantCallIds(nodes);
	const followingAssistants = indexFollowingAssistants(nodes);
	const callStartById = /* @__PURE__ */ new Map();
	for (const result of resultByCall.values()) {
		const startedAt = finiteTime(result.callTime);
		if (startedAt !== null) callStartById.set(result.callId, startedAt);
	}
	for (const call of runningCalls) {
		const startedAt = finiteTime(call.time);
		if (startedAt !== null) callStartById.set(call.callId, startedAt);
	}
	const turns = /* @__PURE__ */ new Map();
	const standaloneCompactions = [];
	let index = 0;
	let prevAbsTime = null;
	let lastAssistantTurn = null;
	const bucket = (turn) => {
		let entry = turns.get(turn);
		if (entry === void 0) {
			entry = { groups: [] };
			turns.set(turn, entry);
		}
		return entry;
	};
	const pushMessage = (turn, laid) => {
		const groups = bucket(turn).groups;
		const last = groups.at(-1);
		if (last?.title === t("group.message")) {
			last.laid.push(laid);
			return;
		}
		groups.push({
			title: t("group.message"),
			laid: [laid]
		});
	};
	const pushStep = (turn, step, laid) => {
		if (laid.length === 0) return;
		const groups = bucket(turn).groups;
		const title = t("group.step", { step });
		const existing = groups.find((group) => group.title === title);
		if (existing !== void 0) {
			existing.laid.push(...laid);
			return;
		}
		groups.push({
			title,
			laid: [...laid]
		});
	};
	const pushStepInput = (turn, step, laid) => {
		if (laid.length === 0) return;
		const groups = bucket(turn).groups;
		const title = t("group.step", { step });
		const existing = groups.find((group) => group.title === title);
		if (existing === void 0) {
			groups.push({
				title,
				laid: [...laid]
			});
			return;
		}
		const request = existing.laid.findIndex((entry) => entry.cell.requestOnly === true);
		if (request === -1) existing.laid.push(...laid);
		else existing.laid.splice(request, 0, ...laid);
	};
	const representedRequests = /* @__PURE__ */ new Set();
	for (const node of nodes) if (node.kind === "assistant" && node.step > 0) representedRequests.add(`${node.turn}\u0000${node.step}`);
	if (partial !== null && partial.step > 0) representedRequests.add(`${partial.turn}\u0000${partial.step}`);
	for (const call of runningCalls) if (call.step > 0) representedRequests.add(`${call.turn}\u0000${call.step}`);
	const entries = [
		...(input.systemPrompts ?? []).map((prompt) => ({
			kind: "system",
			seq: prompt.seq,
			systemPrompt: prompt.text,
			change: {
				seq: prompt.seq,
				time: prompt.time,
				kind: prompt.update ? "system" : "initial"
			}
		})),
		...nodes.map((node, nodeIndex) => ({
			kind: "node",
			seq: node.seq,
			node,
			nodeIndex
		})),
		...requests.filter((request) => request.purpose === "compaction").map((request) => ({
			kind: "compaction",
			seq: request.startSeq,
			request
		})),
		...requests.flatMap((request) => request.purpose !== "assistant" || request.promptChange === void 0 || request.prompt === void 0 ? [] : [{
			kind: "system",
			seq: request.promptChange.seq,
			request,
			change: request.promptChange
		}]),
		...requests.filter((request) => request.purpose === "assistant").filter((request) => !representedRequests.has(`${request.turn}\u0000${request.step}`)).map((request) => ({
			kind: "request",
			seq: request.startSeq,
			request
		}))
	].sort((left, right) => layoutEntryOrder(left) - layoutEntryOrder(right));
	for (const entry of entries) {
		if (entry.kind === "request") {
			const { request } = entry;
			pushStep(request.turn, request.step, [{
				absTime: finiteTime(request.startedAt),
				cell: {
					index: ++index,
					kind: "message",
					text: "",
					sourceSeq: request.startSeq,
					requestOnly: true,
					timeSeconds: request.completedAt === null ? null : durationSeconds(request.completedAt, request.startedAt),
					startedAt: finiteTime(request.startedAt),
					...request.status === "error" ? { isError: true } : {}
				}
			}]);
			prevAbsTime = finiteTime(request.completedAt) ?? finiteTime(request.startedAt) ?? prevAbsTime;
			continue;
		}
		if (entry.kind === "system") {
			const { change, request } = entry;
			pushMessage(change.kind === "initial" ? firstVisibleTurn(nodes, partial) : enclosingPromptTurn(nodes, change.seq, partial), {
				absTime: finiteTime(change.time),
				cell: {
					index: ++index,
					kind: "system",
					text: promptChangeLabel(change, t),
					sourceSeq: change.seq,
					...request?.prompt === void 0 ? {} : { promptDetail: request.prompt },
					...entry.systemPrompt === void 0 ? {} : { systemPromptDetail: entry.systemPrompt },
					...change.previous === void 0 ? {} : { previousPromptDetail: change.previous },
					timeSeconds: 0,
					startedAt: finiteTime(change.time)
				}
			});
			prevAbsTime = finiteTime(change.time) ?? prevAbsTime;
			continue;
		}
		if (entry.kind === "compaction") {
			const request = entry.request;
			const rawOutput = request.rawOutput ?? request.summary;
			const thinkingDetail = rawOutput === void 0 ? "" : detailReasoning(rawOutput);
			const cell = {
				index: ++index,
				kind: "compacted",
				text: request.status === "running" ? t("layout.compacting") : request.status === "error" ? request.error === "trajectory.compaction-interrupted" ? t("layout.compactionInterrupted") : request.error ?? t("layout.compactionFailed") : request.summary === void 0 ? t("layout.compacted") : "",
				...request.status === "complete" && request.summary !== void 0 ? previewContentProperty(request.summary) : {},
				sourceSeq: request.startSeq,
				...request.summary === void 0 ? {} : {
					outputDetail: detailContent(request.summary),
					outputBlocks: request.summary.map((block) => sourceBlock(block))
				},
				...thinkingDetail === "" ? {} : { thinkingDetail },
				...rawOutput === void 0 ? {} : { sourceBlocks: rawOutput.map((block) => sourceBlock(block)) },
				...request.status === "error" ? { isError: true } : {},
				timeSeconds: request.completedAt === null ? null : durationSeconds(request.completedAt, request.startedAt),
				startedAt: finiteTime(request.startedAt)
			};
			attachUsage(cell, request.usage);
			const compaction = { groups: [{
				title: t("group.compaction", { seq: request.startSeq }),
				laid: [{
					absTime: finiteTime(request.startedAt),
					cell
				}]
			}] };
			if (request.turn === null) standaloneCompactions.push(compaction);
			else bucket(request.turn).groups.push(...compaction.groups);
			prevAbsTime = finiteTime(request.completedAt) ?? finiteTime(request.startedAt) ?? prevAbsTime;
			continue;
		}
		const { node, nodeIndex: i } = entry;
		if (node.kind === "user") {
			pushMessage(enclosingUserTurn(followingAssistants[i], partial, lastAssistantTurn), {
				absTime: finiteTime(node.time),
				cell: {
					index: ++index,
					kind: "user",
					...inputCellDetail(node, t),
					opensTurn: true
				}
			});
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
			continue;
		}
		if (node.kind === "steering") {
			const placement = steeringPlacement(followingAssistants[i], partial, lastAssistantTurn, eventLocations?.get(node.seq));
			const laid = {
				absTime: finiteTime(node.time),
				cell: {
					index: ++index,
					kind: "user",
					...inputCellDetail(node, t)
				}
			};
			if (placement.step === void 0) pushMessage(placement.turn, laid);
			else pushStepInput(placement.turn, placement.step, [laid]);
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
			continue;
		}
		if (node.kind === "assistant") {
			const laidList = withSubCalls(expandAssistant(node, index + 1, prevAbsTime, resultByCall, callStartById, callById, t), t);
			if (node.step > 0) pushStep(node.turn, node.step, laidList);
			else for (const laid of laidList) pushMessage(node.turn, laid);
			const last = laidList[laidList.length - 1];
			if (last !== void 0) index = last.cell.index;
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
			lastAssistantTurn = node.turn;
			continue;
		}
		if (node.kind === "context") {
			pushMessage(enclosingUserTurn(followingAssistants[i], partial, lastAssistantTurn), {
				absTime: finiteTime(node.time),
				cell: {
					index: ++index,
					kind: "context",
					...inputCellDetail(node, t)
				}
			});
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
			continue;
		}
		if (node.kind === "compaction") {
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
			continue;
		}
		if (node.kind === "tool-result") {
			if (!emittedCallIds.has(node.callId)) {
				const toolName = node.call?.name;
				const resultPreview = summarizeResult(node, t);
				const laidList = [{
					absTime: finiteTime(node.callTime ?? node.time),
					...toolName !== void 0 ? { toolName } : {},
					callId: node.callId,
					subCalls: node.subCalls,
					cell: {
						index: ++index,
						kind: "tool",
						sourceSeq: node.seq,
						...node.call !== null ? summarizeCall(node.call.name, node.call.argsRaw) : resultAsText(resultPreview),
						...node.call !== null ? { inputDetail: node.call.argsRaw } : {},
						outputDetail: detailResult(node, t),
						...node.deferred === true ? { deferredResultSeq: node.seq } : {},
						outputBlocks: node.content.map((block) => sourceBlock(block)),
						...resultPreview,
						callId: node.callId,
						isError: node.isError,
						timeSeconds: durationSeconds(node.time, node.callTime),
						startedAt: finiteTime(node.callTime)
					}
				}];
				for (const laid of expandSubCalls(node.subCalls, index, t)) {
					laidList.push(laid);
					index = laid.cell.index;
				}
				pushStep(0, 1, laidList);
			}
			prevAbsTime = finiteTime(node.time) ?? prevAbsTime;
		}
	}
	if (partial !== null) {
		const laidList = withSubCalls(expandAssistant({
			kind: "assistant",
			seq: Number.MAX_SAFE_INTEGER,
			time: 0,
			turn: partial.turn,
			step: partial.step,
			blocks: partial.blocks
		}, index + 1, prevAbsTime, resultByCall, callStartById, callById, t, { streaming: true }), t);
		if (partial.step > 0) pushStep(partial.turn, partial.step, laidList);
		else for (const laid of laidList) pushMessage(partial.turn, laid);
		const last = laidList[laidList.length - 1];
		if (last !== void 0) index = last.cell.index;
	}
	const seenCalls = collectCallIds(turns);
	for (const call of runningCalls) {
		if (seenCalls.has(call.callId)) continue;
		const laidList = [{
			absTime: null,
			toolName: call.name,
			callId: call.callId,
			subCalls: call.subCalls,
			cell: {
				index: ++index,
				kind: "tool",
				...summarizeCall(call.name, call.argsRaw),
				inputDetail: call.argsRaw,
				callId: call.callId,
				timeSeconds: null,
				startedAt: finiteTime(call.time)
			}
		}];
		for (const laid of expandSubCalls(call.subCalls, index, t)) {
			laidList.push(laid);
			index = laid.cell.index;
		}
		if (call.step > 0) pushStep(call.turn, call.step, laidList);
		else for (const laid of laidList) pushMessage(call.turn, laid);
	}
	const prologue = turns.get(0);
	if (prologue !== void 0) {
		turns.delete(0);
		const emptyTurn = () => ({ groups: [] });
		const first = turns.get(1) ?? emptyTurn();
		first.groups = [...prologue.groups, ...first.groups];
		turns.set(1, first);
	}
	for (const entry of [...turns.values(), ...standaloneCompactions]) for (const group of entry.groups) for (const laid of group.laid) attachToolSchema(laid, callSchemas);
	return [...[...turns.entries()].map(([turn, entry]) => toTurnModel(turn, entry, t)), ...standaloneCompactions.map((entry) => toTurnModel(null, entry, t))].sort((left, right) => firstCellIndex(left) - firstCellIndex(right));
}
/**
* Append the changing in-flight assistant cells to a stable finalized layout.
* @param turns - Finalized layout derived with an empty-block partial anchor.
* @param partial - Current in-flight assistant projection.
* @param lastIndex - Highest cell index in the finalized layout.
* @param t - Trajectory locale translator.
* @returns The original layout without a partial, otherwise a layout sharing every unaffected turn.
*/
function appendTrajectoryPartialLayout(turns, partial, lastIndex, t) {
	if (partial === null) return turns;
	const partialTurn = deriveTrajectoryLayout({
		nodes: [],
		partial,
		runningCalls: []
	}, t).at(0);
	if (partialTurn === void 0) return turns;
	const streamed = {
		...partialTurn,
		groups: partialTurn.groups.map((group) => ({
			...group,
			cells: group.cells.map((cell) => ({
				...cell,
				index: cell.index + lastIndex
			}))
		}))
	};
	const turnIndex = turns.findIndex((turn) => turn.turn === streamed.turn);
	if (turnIndex === -1) return [...turns, streamed];
	const current = turns[turnIndex];
	/* v8 ignore next -- findIndex proved the dense array position exists. */
	if (current === void 0) return turns;
	const groups = [...current.groups];
	for (const streamedGroup of streamed.groups) {
		const groupIndex = groups.findIndex((group) => group.title === streamedGroup.title);
		if (groupIndex === -1) {
			groups.push(streamedGroup);
			continue;
		}
		const group = groups[groupIndex];
		/* v8 ignore next -- findIndex proved the dense array position exists. */
		if (group === void 0) continue;
		const streamedCallIds = new Set(streamedGroup.cells.flatMap((cell) => cell.callId === void 0 ? [] : [cell.callId]));
		groups[groupIndex] = {
			...streamedGroup,
			cells: [...group.cells.filter((cell) => cell.requestOnly !== true && (cell.callId === void 0 || !streamedCallIds.has(cell.callId))), ...streamedGroup.cells]
		};
	}
	const updated = [...turns];
	updated[turnIndex] = {
		...current,
		groups
	};
	return updated;
}
function attachToolSchema(laid, callSchemas) {
	if (laid.callId === void 0 || callSchemas === void 0) return;
	const schema = callSchemas.get(laid.callId);
	if (schema === void 0) return;
	laid.cell.schemaDetail = JSON.stringify(schema, null, 2);
}
function toTurnModel(turn, entry, t) {
	return {
		turn,
		groups: entry.groups.map(({ title, laid }) => {
			const description = groupDescription(laid, t);
			return {
				title,
				...description !== void 0 ? { description } : {},
				cells: laid.map((l) => l.cell)
			};
		})
	};
}
/** Chronological section position from the fold's monotonically assigned cell indexes. */
function firstCellIndex(turn) {
	return Math.min(...turn.groups.flatMap((group) => group.cells.map((cell) => cell.index)), Number.POSITIVE_INFINITY);
}
/** Wall-span duration + tool histogram, e.g. `1.5 s bash×6`. */
function groupDescription(laid, t) {
	const parts = [];
	const times = [];
	for (const l of laid) {
		if (l.absTime === null || !Number.isFinite(l.absTime)) continue;
		times.push(l.absTime);
		if (l.cell.kind === "tool" && l.cell.timeSeconds !== null && Number.isFinite(l.cell.timeSeconds)) times.push(l.absTime + l.cell.timeSeconds * 1e3);
	}
	if (times.length >= 2) {
		const span = formatGroupDuration((Math.max(...times) - Math.min(...times)) / 1e3, t);
		if (span !== void 0) parts.push(span);
	} else if (times.length === 1) {
		const own = laid.find((l) => l.absTime === times[0])?.cell.timeSeconds;
		const span = own !== null && own !== void 0 ? formatGroupDuration(own, t) : void 0;
		if (span !== void 0) parts.push(span);
	}
	const tools = /* @__PURE__ */ new Map();
	for (const l of laid) {
		if (l.toolName === void 0 || l.cell.kind !== "tool") continue;
		tools.set(l.toolName, (tools.get(l.toolName) ?? 0) + 1);
	}
	for (const [name, count] of tools) parts.push(count > 1 ? `${name}×${count}` : name);
	return parts.length === 0 ? void 0 : parts.join(" ");
}
function formatGroupDuration(seconds, t) {
	if (!Number.isFinite(seconds)) return void 0;
	return formatElapsedSeconds(seconds, t);
}
/** Own-duration seconds from two epoch-ms stamps; null when either is unusable. */
function durationSeconds(later, earlier) {
	if (earlier === null || !Number.isFinite(later) || !Number.isFinite(earlier)) return null;
	return Math.max(0, (later - earlier) / 1e3);
}
/** Epoch-ms usable as an absolute time, else null. */
function finiteTime(time) {
	return typeof time === "number" && Number.isFinite(time) ? time : null;
}
function expandAssistant(node, startIndex, prevAbsTime, results, callStarts, calls, t, opts) {
	if (opts?.streaming === true && node.blocks.length === 0) return [];
	const out = [];
	let index = startIndex - 1;
	const usage = node.usage;
	const streaming = opts?.streaming === true;
	const recordedStart = finiteTime(node.timing?.stepStartTime);
	const messageDuration = streaming ? null : durationSeconds(node.time, recordedStart ?? prevAbsTime);
	const nodeAbs = streaming ? null : finiteTime(node.time);
	const messageText = node.blocks.filter((block) => block.kind === "text" && (!streaming || block.text !== "")).map((block) => block.kind === "text" ? block.text : "").join("\n\n");
	const thinkingText = node.blocks.filter((block) => block.kind === "reasoning" && (!streaming || block.text !== "")).map((block) => block.kind === "reasoning" ? block.text : "").join("\n\n");
	const message = {
		index: ++index,
		recordId: `assistant\u0000${node.turn}\u0000${node.step}`,
		kind: "message",
		sourceSeq: node.seq,
		text: messageText !== "" || thinkingText !== "" ? "" : summarizeAssistantActivity(node.blocks, t),
		...messageText !== "" ? { previewMarkdown: messageText } : thinkingText !== "" ? { previewMarkdown: thinkingText } : {},
		...messageText !== "" ? { outputDetail: messageText } : {},
		...thinkingText !== "" ? { thinkingDetail: thinkingText } : {},
		sourceBlocks: node.blocks.map((block) => assistantSourceBlock(block)),
		timeSeconds: messageDuration,
		startedAt: recordedStart
	};
	attachUsage(message, usage);
	message.assistantMetrics = {
		timingRecorded: node.timing !== void 0,
		stepStartTime: node.timing?.stepStartTime ?? null,
		firstTokenTime: node.timing?.firstTokenTime ?? null,
		completedTime: streaming ? null : finiteTime(node.time),
		usageProvided: usage !== void 0,
		outputTokens: Number.isFinite(usage?.outputTokens) ? usage?.outputTokens ?? null : null
	};
	out.push({
		absTime: nodeAbs,
		cell: message
	});
	for (const block of node.blocks) {
		if (block.kind !== "tool-call") continue;
		const result = results.get(block.callId);
		const toolDuration = streaming || result === void 0 ? null : durationSeconds(result.time, result.callTime);
		const callAbs = finiteTime(callStarts.get(block.callId));
		const call = calls.get(block.callId);
		const resultPreview = result === void 0 ? void 0 : summarizeResult(result, t);
		out.push({
			absTime: callAbs,
			toolName: block.name,
			callId: block.callId,
			...call === void 0 ? {} : { subCalls: call.subCalls },
			cell: {
				index: ++index,
				kind: "tool",
				...summarizeCall(block.name, block.argsRaw),
				inputDetail: block.argsRaw,
				callId: block.callId,
				...result !== void 0 ? {
					outputDetail: detailResult(result, t),
					...result.deferred === true ? { deferredResultSeq: result.seq } : {},
					outputBlocks: result.content.map((block) => sourceBlock(block)),
					...resultPreview,
					isError: result.isError
				} : {},
				timeSeconds: toolDuration,
				startedAt: callAbs
			}
		});
	}
	return out;
}
function summarizeAssistantActivity(blocks, t) {
	const tools = /* @__PURE__ */ new Map();
	for (const block of blocks) {
		if (block.kind !== "tool-call") continue;
		tools.set(block.name, (tools.get(block.name) ?? 0) + 1);
	}
	if (tools.size > 0) return t("layout.toolCallOnly");
	const images = blocks.filter((block) => block.kind === "image").length;
	if (images > 0) return t("layout.imageOnly", { count: images });
	return "";
}
function promptChangeLabel(change, t) {
	if (change.kind === "initial") return t("layout.initialSystemPrompt");
	if (change.kind === "system") return t("layout.systemPromptUpdated");
	if (change.kind === "tools") return t("layout.toolsUpdated");
	return t("layout.systemPromptAndToolsUpdated");
}
function assistantSourceBlock(block) {
	switch (block.kind) {
		case "text": return {
			type: "text",
			content: block.text
		};
		case "reasoning": return {
			type: "thinking",
			content: block.text
		};
		case "tool-call": return {
			type: "tool-call",
			content: block.argsRaw,
			callId: block.callId,
			toolName: block.name
		};
		case "image": return {
			type: "image",
			content: "",
			attachment: block.attachment
		};
		case "other": return sourceBlock(block.block);
	}
}
function sourceBlock(value) {
	if (typeof value !== "object" || value === null) return {
		type: "unknown",
		content: stringifySourceValue(value)
	};
	const block = value;
	const type = typeof block.type === "string" ? block.type : "unknown";
	if (typeof block.text === "string") return {
		type: type === "reasoning" ? "thinking" : type,
		content: block.text
	};
	if (type === "image" && typeof block.attachment === "object" && block.attachment !== null && typeof block.attachment.attachmentId === "string") return {
		type,
		content: "",
		attachment: block.attachment
	};
	return {
		type,
		content: stringifySourceValue(value)
	};
}
function imageBlockCount(content) {
	return content.filter((block) => block.type === "image").length;
}
function fileBlockCount(content) {
	return content.filter((block) => block.type === "file").length;
}
function stringifySourceValue(value) {
	return JSON.stringify(value, null, 2) || String(value);
}
/**
* Turn that encloses a user/message: next assistant turn, else the
* in-flight partial, else the turn after the last finalized assistant (or 1).
*/
function enclosingUserTurn(followingAssistant, partial, lastAssistantTurn) {
	if (followingAssistant !== void 0) return followingAssistant.turn;
	if (partial !== null) return partial.turn;
	if (lastAssistantTurn !== null) return lastAssistantTurn + 1;
	return 1;
}
function steeringPlacement(followingAssistant, partial, lastAssistantTurn, location) {
	if (location?.kind === "step") return {
		turn: location.turn.turn,
		step: location.step.step
	};
	const locatedTurn = location?.kind === "turn" ? location.turn.turn : void 0;
	if (followingAssistant !== void 0 && (locatedTurn === void 0 || followingAssistant.turn === locatedTurn)) return {
		turn: followingAssistant.turn,
		...followingAssistant.step > 0 ? { step: followingAssistant.step } : {}
	};
	if (partial !== null && (locatedTurn === void 0 || partial.turn === locatedTurn)) return {
		turn: partial.turn,
		...partial.step > 0 ? { step: partial.step } : {}
	};
	if (locatedTurn !== void 0) return { turn: locatedTurn };
	return { turn: lastAssistantTurn ?? 1 };
}
function indexFollowingAssistants(nodes) {
	const following = new Array(nodes.length);
	let assistant;
	for (let index = nodes.length - 1; index >= 0; index--) {
		following[index] = assistant;
		const node = nodes[index];
		if (node?.kind === "assistant") assistant = node;
	}
	return following;
}
function enclosingPromptTurn(nodes, seq, partial) {
	const next = nodes.find((node) => node.seq > seq && node.kind === "assistant" && node.step > 0);
	if (next?.kind === "assistant") return next.turn;
	return partial?.turn ?? 1;
}
/** Earliest raw turn represented by the selected trajectory branch. */
function firstVisibleTurn(nodes, partial) {
	const turns = nodes.flatMap((node) => node.kind === "assistant" && node.turn > 0 ? [node.turn] : []);
	if (partial !== null && partial.turn > 0) turns.push(partial.turn);
	return turns.length === 0 ? 1 : Math.min(...turns);
}
/** Copy provider usage onto a Message cell when present. */
function attachUsage(cell, usage) {
	if (usage === void 0) return;
	if (usage.inputTokens !== void 0) cell.input = usage.inputTokens;
	if (usage.cacheReadTokens !== void 0) cell.cacheRead = usage.cacheReadTokens;
	if (usage.cacheWriteTokens !== void 0) cell.cacheWrite = usage.cacheWriteTokens;
	if (usage.outputTokens !== void 0) cell.output = usage.outputTokens;
	if (usage.reasoningTokens !== void 0) cell.think = usage.reasoningTokens;
}
function indexResults(nodes) {
	const map = /* @__PURE__ */ new Map();
	for (const node of nodes) if (node.kind === "tool-result") map.set(node.callId, node);
	return map;
}
function indexAssistantCallIds(nodes) {
	const ids = /* @__PURE__ */ new Set();
	for (const node of nodes) {
		if (node.kind !== "assistant") continue;
		for (const block of node.blocks) if (block.kind === "tool-call") ids.add(block.callId);
	}
	return ids;
}
function collectCallIds(turns) {
	const ids = /* @__PURE__ */ new Set();
	for (const entry of turns.values()) for (const group of entry.groups) for (const laid of group.laid) if (laid.callId !== void 0) ids.add(laid.callId);
	return ids;
}
/** Interleave each tool cell's nested child calls right after it, reindexing followers. */
function withSubCalls(laidList, t) {
	if (!laidList.some((laid) => laid.subCalls !== void 0 && laid.subCalls.length > 0)) return laidList;
	const out = [];
	let index = laidList[0] !== void 0 ? laidList[0].cell.index - 1 : 0;
	for (const laid of laidList) {
		out.push({
			...laid,
			cell: {
				...laid.cell,
				index: ++index
			}
		});
		for (const sub of expandSubCalls(laid.subCalls, index, t)) {
			out.push(sub);
			index = sub.cell.index;
		}
	}
	return out;
}
/** Sub-dispatch cells for one run_code parent, in start order (running = null duration). */
function expandSubCalls(subs, startIndex, t) {
	if (subs === void 0 || subs.length === 0) return [];
	const out = [];
	let index = startIndex;
	for (const sub of subs) {
		const settled = "kind" in sub;
		const resultPreview = settled ? summarizeResult(sub, t) : void 0;
		const laid = {
			absTime: settled ? finiteTime(sub.callTime ?? sub.time) : finiteTime(sub.time),
			toolName: settled ? sub.call?.name ?? sub.callId : sub.name,
			callId: sub.callId,
			cell: {
				index: ++index,
				kind: "subtool",
				callId: sub.callId,
				...settled ? sub.call !== null ? summarizeCall(sub.call.name, sub.call.argsRaw) : resultAsText(resultPreview) : summarizeCall(sub.name, sub.argsRaw),
				...settled ? sub.call !== null ? { inputDetail: sub.call.argsRaw } : {} : { inputDetail: sub.argsRaw },
				...settled ? {
					outputDetail: detailResult(sub, t),
					...sub.deferred === true ? { deferredResultSeq: sub.seq } : {},
					outputBlocks: sub.content.map((block) => sourceBlock(block)),
					...resultPreview,
					isError: sub.isError
				} : {},
				timeSeconds: settled ? durationSeconds(sub.time, sub.callTime) : null,
				startedAt: settled ? finiteTime(sub.callTime) : finiteTime(sub.time)
			}
		};
		out.push(laid);
		for (const child of expandSubCalls(sub.subCalls, index, t)) {
			out.push(child);
			index = child.cell.index;
		}
	}
	return out;
}
function summarizeCall(name, argsRaw) {
	return {
		text: name,
		...argsRaw === "" ? {} : { previewMarkdown: argsRaw }
	};
}
function summarizeResult(node, t) {
	if (node.isError) return { result: node.error?.code ?? "error" };
	for (const block of node.content) if (block.type === "text" && typeof block.text === "string" && block.text !== "") return {
		result: "",
		resultPreviewMarkdown: block.text
	};
	const images = imageBlockCount(node.content);
	if (images > 0) return { result: t("layout.imageOnly", { count: images }) };
	return { result: t(node.deferred === true ? "record.resultNotLoaded" : "record.noOutput") };
}
function resultAsText(result) {
	return {
		text: result?.result ?? "",
		...result?.resultPreviewMarkdown === void 0 ? {} : { previewMarkdown: result.resultPreviewMarkdown }
	};
}
function detailResult(node, t) {
	if (node.deferred === true) return t("record.resultNotLoaded");
	if (node.isError) return node.error === void 0 ? "error" : `${node.error.name}: ${node.error.code}`;
	const text = node.content.filter((block) => block.type === "text" && typeof block.text === "string").map((block) => block.type === "text" ? block.text : "").join("\n");
	if (text !== "") return text;
	const images = imageBlockCount(node.content);
	if (images > 0) return t("layout.imageOnly", { count: images });
	if (node.content.length === 0 || node.content.every((block) => block.type === "text" && (typeof block.text !== "string" || block.text === ""))) return t("record.noOutput");
	return JSON.stringify(node.content, null, 2);
}
function detailContent(content) {
	return content.filter((block) => block.type === "text" && typeof block.text === "string").map((block) => block.text ?? "").join("\n");
}
function detailReasoning(content) {
	return content.filter((block) => block.type === "reasoning" && typeof block.text === "string").map((block) => block.text ?? "").join("\n");
}
function previewContent(content) {
	for (const block of content) if (block.type === "text" && typeof block.text === "string") return block.text;
}
function previewContentProperty(content) {
	const previewMarkdown = previewContent(content);
	return previewMarkdown === void 0 ? {} : { previewMarkdown };
}
//#endregion
//#region lib/types/client/timeline.js
/** Operation-sequence and recorded-time projections for the trajectory overview. */
/**
* Format a timeline duration as an integer-millisecond label.
* @param milliseconds - Non-negative duration in milliseconds.
* @param t - Trajectory locale translator.
* @returns Millisecond label with thousands separators.
*/
function formatTimelineOffset(milliseconds, t) {
	return formatDurationMillis(milliseconds, t);
}
function laneFor(kind) {
	if (kind === "tool" || kind === "subtool") return 2;
	if (kind === "message" || kind === "compacted") return 1;
	return 0;
}
function finite(value) {
	return value !== null && value !== void 0 && Number.isFinite(value);
}
function cellRange(cell) {
	if (!finite(cell.startedAt)) return null;
	const durationMs = finite(cell.timeSeconds) ? Math.max(0, cell.timeSeconds * 1e3) : 0;
	return {
		start: cell.startedAt,
		end: cell.startedAt + durationMs
	};
}
/**
* Project every visible record into a stable three-lane timeline.
* @param turns - Unfiltered trajectory layout.
* @param mode - Independent equal/recorded duration and compressed/complete time projection.
* @returns Timeline model, or `null` when no record is visible.
*/
function deriveTrajectoryTimeline(turns, mode = "sequence") {
	if (mode !== "sequence") return deriveTimedTimeline(turns, mode === "duration" || mode === "actual", mode === "duration");
	const spans = [];
	const turnBoundaries = [];
	for (const turn of turns) {
		const cells = turn.groups.flatMap((group) => group.cells.filter((cell) => cell.requestOnly !== true));
		if (cells.length === 0) continue;
		if (turn.turn !== null) turnBoundaries.push({
			turn: turn.turn,
			time: spans.length
		});
		spans.push(...cells.map((cell, offset) => ({
			start: spans.length + offset,
			end: spans.length + offset + 1,
			index: cell.index,
			isError: cell.isError === true,
			kind: cell.kind,
			label: cell.text,
			lane: laneFor(cell.kind)
		})));
	}
	if (spans.length === 0) return null;
	return {
		start: 0,
		end: spans.length,
		spans,
		turnBoundaries
	};
}
function deriveTimedTimeline(turns, actualDuration, compressIdle) {
	const timedTurns = turns.flatMap((turn) => {
		const rawSpans = turn.groups.flatMap((group) => group.cells.flatMap((cell) => {
			if (cell.requestOnly === true) return [];
			const range = cellRange(cell);
			return range === null ? [] : [{
				...range,
				index: cell.index,
				isError: cell.isError === true,
				kind: cell.kind,
				label: cell.text,
				lane: laneFor(cell.kind)
			}];
		}));
		return rawSpans.length === 0 ? [] : [{
			turn: turn.turn,
			rawSpans
		}];
	});
	const rawSpans = timedTurns.flatMap((turn) => turn.rawSpans);
	if (rawSpans.length === 0) return null;
	const removedIdleBySpan = /* @__PURE__ */ new Map();
	let removedIdle = 0;
	let coveredUntil = null;
	for (const span of [...rawSpans].sort((left, right) => left.start - right.start || left.end - right.end)) {
		if (compressIdle && coveredUntil !== null && span.start > coveredUntil) removedIdle += span.start - coveredUntil;
		removedIdleBySpan.set(span, removedIdle);
		coveredUntil = coveredUntil === null ? span.end : Math.max(coveredUntil, span.end);
	}
	const spans = [];
	const turnBoundaries = [];
	for (const turn of timedTurns) {
		const projected = turn.rawSpans.map((span) => {
			const offset = removedIdleBySpan.get(span) ?? 0;
			return {
				...span,
				start: span.start - offset,
				end: (actualDuration ? span.end : span.start) - offset
			};
		});
		spans.push(...projected);
		if (turn.turn !== null) turnBoundaries.push({
			turn: turn.turn,
			time: Math.min(...projected.map((span) => span.start))
		});
	}
	return {
		start: Math.min(...spans.map((span) => span.start)),
		end: Math.max(...spans.map((span) => span.end)),
		spans,
		turnBoundaries
	};
}
/**
* Identify records active at any point inside an inclusive selected interval.
* @param turns - Unfiltered trajectory layout.
* @param range - Selected interval in the active projection.
* @param mode - Independent equal/recorded duration and compressed/complete time projection.
* @returns Record indexes inside the focus interval.
*/
function trajectoryTimelineFocusIndexes(turns, range, mode = "sequence") {
	const model = deriveTrajectoryTimeline(turns, mode);
	return new Set(model?.spans.filter((span) => span.start <= range.end && span.end >= range.start).map((span) => span.index));
}
//#endregion
//#region lib/types/client/trajectory-labels.js
/** English copy for this feature. */
const en = {
	"view.trajectory": "Trajectory",
	"toolbar.aria": "Trajectory toolbar",
	"toolbar.duration": "Duration",
	"toolbar.useActualDuration": "Use actual duration",
	"toolbar.useEqualWidth": "Use equal-width operations",
	"toolbar.actualTime": "Actual time",
	"toolbar.turns": "Turns",
	"toolbar.expandTurns": "Expand turns",
	"toolbar.collapseTurns": "Collapse turns",
	"toolbar.calls": "Calls",
	"toolbar.expandCalls": "Expand calls",
	"toolbar.collapseCalls": "Collapse calls",
	"toolbar.search": "Search trajectory",
	"toolbar.searchPlaceholder": "Search",
	"kind.system": "SYSTEM",
	"kind.user": "USER",
	"kind.context": "CONTEXT",
	"kind.compacted": "COMPACTED",
	"kind.message": "Message",
	"kind.assistant": "ASSISTANT",
	"kind.tool": "TOOL",
	"kind.subtool": "SUBTOOL",
	"kind.sub": "Sub",
	"column.input": "Input",
	"column.output": "Output",
	"column.think": "Think",
	"column.time": "Time",
	"column.model": "Model",
	"column.tools": "Tools",
	"turn.label": "Turn {turn}",
	"section.betweenTurns": "Between turns",
	"group.message": "Message",
	"group.step": "Step {step}",
	"group.compaction": "Compaction {seq}",
	"status.failed": "Failed",
	"status.pending": "Pending",
	"status.completed": "Completed",
	"timing.notAvailable": "Not available",
	"timing.notRecorded": "Not recorded",
	"timing.stepStartUnavailable": "Step start unavailable",
	"timing.firstTokenUnavailable": "First token unavailable",
	"timing.usageUnavailable": "Usage unavailable",
	"timing.outputTokensUnavailable": "Output tokens unavailable",
	"timing.durationTooShort": "Duration too short",
	"timing.showLocalTime": "Show local time",
	"timing.showUnixTimestamp": "Show Unix timestamp",
	"timing.started": "Started",
	"timing.totalDuration": "Total duration",
	"timing.ttft": "TTFT",
	"timing.generation": "Stream span",
	"timing.throughput": "Output rate",
	"timing.duration": "Duration",
	"timing.source": "Timing source",
	"timing.sessionTimestamps": "Session timestamps",
	"timing.sessionTimestampsRunning": "Session timestamps (running)",
	"timing.request": "Request Timing",
	"unit.milliseconds": "{value} ms",
	"unit.seconds": "{value} s",
	"unit.tokens": "{value} tok",
	"unit.tokensPerSecond": "{value} tok/s",
	"usage.tokens": "Tokens",
	"usage.reasoning": "Reasoning",
	"usage.content": "Content",
	"usage.notReported": "Usage not reported",
	"usage.input": "Input",
	"usage.cached": "Cached",
	"usage.cacheCreated": "Cache created",
	"usage.other": "Other",
	"usage.output": "Output",
	"usage.thisRequest": "This request",
	"usage.sessionCumulative": "Session cumulative",
	"options.notRecorded": "Options not recorded",
	"options.json": "Request options JSON",
	"source.unknown": "Unknown",
	"source.user": "User",
	"source.plugin": "Plugin",
	"source.pluginNamed": "Plugin · {plugin}",
	"source.goal": "Goal",
	"source.goalRound": "Goal · Round {round}",
	"source.notRecorded": "Source not recorded",
	"source.messageJson": "Message source JSON",
	"tab.summary": "Summary",
	"tab.rawOutput": "Raw Output",
	"tab.preview": "Preview",
	"tab.raw": "Raw",
	"tab.source": "Source",
	"tab.payload": "Payload",
	"tab.result": "Result",
	"tab.schema": "Schema",
	"tab.timing": "Timing",
	"tab.diff": "Diff",
	"tab.systemPrompt": "System Prompt",
	"tab.tools": "Tools",
	"tab.options": "Options",
	"tab.usage": "Usage",
	"record.toolCallOnly": "(tool call only)",
	"record.noContent": "No content",
	"record.noPayload": "No payload captured",
	"record.noResult": "No result captured",
	"record.noOutput": "No output",
	"record.resultNotLoaded": "Result not loaded",
	"record.loadResult": "Load full result",
	"record.loadingResult": "Loading result…",
	"record.schemaUnavailable": "Schema unavailable",
	"record.parameters": "Parameters",
	"record.resultJson": "Result JSON",
	"record.json": "JSON",
	"record.parametersJson": "parameters JSON",
	"record.namedParametersJson": "{name} parameters JSON",
	"record.payloadJson": "Payload JSON",
	"record.outputJson": "Result JSON",
	"record.thinking": "Thinking",
	"record.systemPromptMissing": "No system prompt in this request",
	"record.toolsMissing": "No tools in this request",
	"record.systemPrompt": "System Prompt",
	"record.tools": "Tools",
	"block.openSummary": "Open Block #{index} tool call summary",
	"block.openSummaryTitle": "Open tool call summary",
	"block.label": "Block #{index} {type}",
	"history.loadingTrajectory": "Loading trajectory…",
	"history.loadingEarlier": "Loading earlier history…",
	"history.loadingEarlierAria": "Loading earlier history…",
	"history.loadEarlier": "Load earlier history",
	"history.clickToLoadEarlier": "Click to load earlier history",
	"request.label": "Request #{request}",
	"request.labelCompaction": "Request #{request} · Compaction",
	"request.compaction": "Compaction · {section}",
	"request.compactionPurpose": "Compaction",
	"request.retryProgress": "{retry} of {maximum}",
	"request.collapsedSummary": "Collapsed {kind} summary, {summary}",
	"request.collapsedTurn": "turn",
	"request.collapsedAssistant": "assistant",
	"request.rowAria": "{request}{kind}, {content}",
	"request.rowPrefix": "Request {request}, ",
	"request.rowAriaCompaction": "Request {request}, compaction",
	"request.noContent": "no content",
	"summary.toolCalls.one": "{count} tool call",
	"summary.toolCalls.other": "{count} tool calls",
	"summary.steps.one": "{count} step",
	"summary.steps.other": "{count} steps",
	"details.event": "Event details",
	"details.resize": "Resize event details",
	"details.resizeTitle": "Drag to resize. Double-click to reset.",
	"details.close": "Close details",
	"details.status": "Status",
	"details.purpose": "Purpose",
	"details.provider": "Provider",
	"details.model": "Model",
	"details.toolCalls": "Tool calls",
	"details.subtoolCalls": "Subtool calls",
	"details.error": "Error",
	"details.failure.auth": "API key is invalid",
	"details.retry": "Retry",
	"details.scheduled": "Scheduled",
	"details.retryDelay": "Retry delay",
	"details.result": "Result",
	"details.compacted": "Compacted",
	"details.assistantMessage": "Assistant Message",
	"details.source": "Source",
	"details.hierarchy": "Hierarchy",
	"details.toolCall": "Tool Call",
	"timeline.aria": "Trajectory timeline",
	"timeline.overviewAria": "Timeline overview; drag horizontally to focus events",
	"timeline.noTimingData": "No timing data",
	"timeline.total": "Total {duration}",
	"timeline.started": "Started {time}",
	"timeline.ttftDecoding": "TTFT {ttft} · Decoding {decoding}",
	"layout.compacting": "Compacting context…",
	"layout.compactionFailed": "Compaction failed",
	"layout.compacted": "Context compacted",
	"layout.toolCallOnly": "Tool call only",
	"layout.imageOnly": "Images ×{count}",
	"layout.fileAttachments": "Files ×{count}",
	"layout.initialSystemPrompt": "Initial System Prompt",
	"layout.systemPromptUpdated": "System Prompt Updated",
	"layout.toolsUpdated": "Tools Updated",
	"layout.systemPromptAndToolsUpdated": "System Prompt and Tools Updated",
	"layout.compactionInterrupted": "Compaction was interrupted before completion."
};
//#endregion
export { EMPTY_TRAJECTORY_SNAPSHOT, appendTrajectoryPartialLayout, deriveTrajectoryLayout, deriveTrajectoryTimeline, formatDurationMillis, formatElapsedSeconds, formatTimelineOffset, registerTrajectoryConversation, en as trajectoryEnglish, trajectoryRecordId, trajectoryTimelineFocusIndexes };
